@echo off
chcp 65001 >nul
setlocal
rem FtpReport v0.9.10 - builds the inventory workbook from run_local_* folders (read-only on inputs).
rem Usage: double-click (asks for the input folder; Enter = current folder), or: run_report.bat "D:\MFT\results"
set "PYTHONIOENCODING=utf-8"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYEXE=python"
where py >nul 2>&1
if not errorlevel 1 set "PYEXE=py -3"
%PYEXE% "%~dp0ftp_report.py" %*
set "RC=%ERRORLEVEL%"
echo.
echo Exit code: %RC%  (0=OK)
if "%~1"=="" pause
exit /b %RC%

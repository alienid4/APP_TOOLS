﻿<#
.SYNOPSIS
  FTP 主機本機收集（PowerShell 版）：在 Serv-U／FileZilla 主機「上面」執行，唯讀複製設定檔（遮掉密碼）與近 N 天 log。
  給沒裝 Python 的主機用；結果格式與 Python 版 ftp_collect.py 相同（_run_info.txt、_run.csv、manifest.csv），之後整理程式一起讀。

.USAGE
  雙擊 run.bat（會問 SOC 通知單號與存放目錄），或：
    powershell -NoProfile -ExecutionPolicy Bypass -File .\FtpCollect.ps1 -SocTicket SOC-123 [-OutDir D:\FtpCollect\out] [-Days 90] [-MaxMB 500] [-ExtraPaths 'D:\FTPLog;E:\x']

.RULES（與 Python 版相同）
  - 跑之前先知會資安／SOC，通知單號必填並記入結果。
  - 只讀不寫來源；開檔用共用讀取，不鎖 FTP 服務正在寫的 log。每次另開資料夾，不覆蓋舊結果。
  - 設定檔：只收認得格式（XML／JSON／INI）且解析成功者，依欄位名遮掉 pass／pwd／salt／hash／secret／token 後才寫入；
    格式不明、二進位、含私鑰者一律不落地，只記在 manifest。第一次對新版本主機跑完要人工抽看一份。
  - log：只收 *.log、*.log.N、*.log.YYYYMMDD；分塊複製、單檔上限、目的磁碟保留 2 GB。
  - 不改系統設定（執行原則用單次 -ExecutionPolicy Bypass，不改機器設定）。
  - 只用 Windows 內建 PowerShell 5.1，不需要安裝任何東西。
#>
[CmdletBinding()]
param(
    [string]$SocTicket = '',
    [string]$OutDir = '',
    [ValidateRange(1, 400)][int]$Days = 90,
    [ValidateRange(10, 20000)][int]$MaxMB = 500,
    [string]$ExtraPaths = ''
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

$VERSION = '1.0 (2026-11-10)'
$CHUNK = 1MB
$MIN_FREE = 2GB
$MAX_CONFIG = 20MB

$DEFAULT_ROOTS = @(
    'C:\ProgramData\RhinoSoft\Serv-U', 'C:\Program Files\RhinoSoft\Serv-U', 'C:\Program Files (x86)\RhinoSoft\Serv-U',
    'C:\Program Files (x86)\FileZilla Server', 'C:\Program Files\FileZilla Server', 'C:\ProgramData\filezilla-server'
)
$MAIN_CONFIG = '^(serv-u\.archive|servudaemon\.ini|filezilla server\.xml|users\.xml)$'
$CONFIG_EXT = @('.xml', '.ini', '.archive', '.config', '.cfg', '.json')
$LOG_NAME = '\.log(\.\d{1,3}|\.\d{4}-?\d{2}-?\d{2})?$'
$SECRET = 'pass|pwd|salt|hash|secret|token'
$PRIVATE_KEY = '-----BEGIN [A-Z ]*PRIVATE KEY-----'

function Ts([datetime]$t) { $t.ToString('yyyy/MM/dd HH:mm:ss') }

# 本工具不刪除、不修改主機上任何既有檔案或設定：只在本次新開的結果資料夾裡「新建」檔案。
$script:RunDir = $null

# ---------- 執行 LOG 與 ERROR LOG ----------
# _run_log.txt：每一步都記（含時間）；_error_log.txt：只記錯誤。都放在結果資料夾。
# 結果資料夾建好之前的訊息先暫存；若在那之前就中止，寫到工具所在資料夾的 FtpCollect_error_<時間>.log。
$script:LogFile = $null; $script:ErrFile = $null
$script:LogBuf = New-Object System.Collections.Generic.List[string]
$script:ErrBuf = New-Object System.Collections.Generic.List[string]
$script:ErrCount = 0
function Add-LogLine([string]$file, [System.Collections.Generic.List[string]]$buf, [string]$line) {
    if ($file) { [IO.File]::AppendAllText($file, $line + "`r`n", (New-Object Text.UTF8Encoding($true))) } else { $buf.Add($line) }
}
function Log([string]$msg, [string]$color = '') {
    if ($color) { Write-Host $msg -ForegroundColor $color } else { Write-Host $msg }
    Add-LogLine $script:LogFile $script:LogBuf ("{0}  {1}" -f (Get-Date).ToString('yyyy/MM/dd HH:mm:ss'), $msg)
}
function ErrLog([string]$msg) {
    $script:ErrCount++
    Log "[ERROR] $msg" 'Yellow'
    Add-LogLine $script:ErrFile $script:ErrBuf ("{0}  {1}" -f (Get-Date).ToString('yyyy/MM/dd HH:mm:ss'), $msg)
}
function Open-RunLogs([string]$dir) {
    $script:LogFile = Join-Path $dir '_run_log.txt'; $script:ErrFile = Join-Path $dir '_error_log.txt'
    foreach ($pair in @(@($script:LogFile, $script:LogBuf), @($script:ErrFile, $script:ErrBuf))) {
        $text = ($pair[1] -join "`r`n"); if ($text) { $text += "`r`n" }
        [IO.File]::WriteAllText($pair[0], $text, (New-Object Text.UTF8Encoding($true)))   # 新建；錯誤 log 沒錯誤時是空檔
        $pair[1].Clear()
    }
}
function Stop-Early([string]$msg) {
    ErrLog $msg
    if (-not $script:LogFile) {
        $f = Join-Path $PSScriptRoot ("FtpCollect_error_{0}.log" -f (Get-Date).ToString('yyyyMMdd_HHmmss'))
        [IO.File]::WriteAllText($f, (($script:LogBuf -join "`r`n") + "`r`n"), (New-Object Text.UTF8Encoding($true)))
        Write-Host "錯誤紀錄：$f"
    }
    exit 2
}
function Assert-InRun([string]$path) {
    if (-not $script:RunDir -or -not (Test-Inside $path $script:RunDir)) { throw "STOP:安全檢查：要寫入的位置不在結果資料夾內（$path），中止" }
    if (Test-Path -LiteralPath $path) { throw "STOP:安全檢查：目的檔已存在（$path），不覆蓋，中止" }
}

function Test-Inside([string]$child, [string]$parent) {
    $c = [IO.Path]::GetFullPath($child).TrimEnd('\') + '\'
    $p = [IO.Path]::GetFullPath($parent).TrimEnd('\') + '\'
    return $c.StartsWith($p, [StringComparison]::OrdinalIgnoreCase)
}

# ---------- 設定檔遮罩（解析後依欄位名遮，不認得的格式不收） ----------
function Hide-XmlSubtree($el) {
    foreach ($n in @($el.SelectNodes('.//text()|.//*[@*]|self::*'))) {
        if ($n.NodeType -eq 'Text' -or $n.NodeType -eq 'CDATA') {
            if ($n.Value.Trim()) { $n.Value = '***' }
        } elseif ($n.NodeType -eq 'Element') {
            foreach ($a in @($n.Attributes)) {
                if (-not ([object]::ReferenceEquals($n, $el) -and $a.Name -ieq 'name')) { $a.Value = '***' }
            }
        }
    }
}

function Protect-Xml([string]$text) {
    $settings = New-Object Xml.XmlReaderSettings
    $settings.DtdProcessing = [Xml.DtdProcessing]::Ignore
    $settings.XmlResolver = $null
    $reader = [Xml.XmlReader]::Create((New-Object IO.StringReader($text)), $settings)
    $doc = New-Object Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    try { $doc.Load($reader) } finally { $reader.Close() }
    foreach ($el in @($doc.SelectNodes('//*'))) {
        $secretByName = $false
        foreach ($a in @($el.Attributes)) { if ($a.Name -ieq 'name' -and $a.Value -match $SECRET) { $secretByName = $true } }
        if ($el.LocalName -match $SECRET -or $secretByName) { Hide-XmlSubtree $el; continue }
        foreach ($a in @($el.Attributes)) { if ($a.Name -match $SECRET) { $a.Value = '***' } }
    }
    return $doc.OuterXml
}

function Protect-JsonNode($o) {
    if ($o -is [System.Management.Automation.PSCustomObject]) {
        foreach ($p in @($o.PSObject.Properties)) {
            if ($p.Name -match $SECRET) { $p.Value = '***' } else { $p.Value = Protect-JsonNode $p.Value }
        }
        return $o
    }
    if ($o -is [System.Array]) { return ,@($o | ForEach-Object { Protect-JsonNode $_ }) }
    return $o
}

function Protect-Ini([string]$text) {
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($line in ($text -split "`r?`n")) {
        $m = [regex]::Match($line, '^\s*(?:[;#].*|\[[^\]]*\]\s*|([^=]+?)\s*=(.*))?$')
        if (-not $m.Success) { throw '不是 INI 格式' }
        if ($m.Groups[1].Success -and $m.Groups[1].Value -match $SECRET) { $line = $m.Groups[1].Value + '=***' }
        $out.Add($line)
    }
    return ($out -join "`r`n")
}

function Protect-Config([string]$text) {
    $t = $text.TrimStart()
    if ($t.StartsWith('<')) { return @((Protect-Xml $text), 'XML') }
    if ($t.StartsWith('{') -or $t.StartsWith('[')) {
        try { return @(((Protect-JsonNode ($text | ConvertFrom-Json)) | ConvertTo-Json -Depth 64), 'JSON') }
        catch { if ($t.StartsWith('{')) { throw } }
    }
    return @((Protect-Ini $text), 'INI')
}

function Get-Sha256([byte[]]$bytes) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($bytes)) -replace '-', '').ToLower() } finally { $h.Dispose() }
}

function Copy-Config([IO.FileInfo]$f, [string]$dst) {
    # 回傳 @(位元組, sha256, 註記, 是否有遮)
    if ($f.Length -gt $MAX_CONFIG) { return @(0, '', '設定檔超過 20 MB，未收集', $false) }
    $fs = [IO.File]::Open($f.FullName, 'Open', 'Read', 'ReadWrite, Delete')
    try { $data = New-Object byte[] $f.Length; [void]$fs.Read($data, 0, $data.Length) } finally { $fs.Close() }
    $bom16 = $data.Length -ge 2 -and (($data[0] -eq 0xFF -and $data[1] -eq 0xFE) -or ($data[0] -eq 0xFE -and $data[1] -eq 0xFF))
    if (-not $bom16 -and ([Array]::IndexOf($data, [byte]0) -ge 0)) {
        return @(0, '', '未收集：二進位，無法安全遮罩（請在主機上用主控台匯出）', $false)
    }
    $text = $null
    try {
        if ($bom16) {
            $enc = if ($data[0] -eq 0xFF) { New-Object Text.UnicodeEncoding($false, $true, $true) } else { New-Object Text.UnicodeEncoding($true, $true, $true) }
            $text = $enc.GetString($data, 2, $data.Length - 2)
        } else {
            $start = if ($data.Length -ge 3 -and $data[0] -eq 0xEF -and $data[1] -eq 0xBB -and $data[2] -eq 0xBF) { 3 } else { 0 }
            $text = (New-Object Text.UTF8Encoding($false, $true)).GetString($data, $start, $data.Length - $start)
        }
    } catch {
        try { $text = [Text.Encoding]::GetEncoding(950, [Text.EncoderFallback]::ExceptionFallback, [Text.DecoderFallback]::ExceptionFallback).GetString($data) }
        catch { return @(0, '', '未收集：編碼無法辨識，無法安全遮罩', $false) }
    }
    if ($text -match $PRIVATE_KEY) { return @(0, '', '未收集：內含私鑰', $false) }
    try { $r = Protect-Config $text } catch {
        $msg = "$($_.Exception.Message)"; if ($msg.Length -gt 60) { $msg = $msg.Substring(0, 60) }
        return @(0, '', "未收集：格式無法確認，無法安全遮罩（$msg）", $false)
    }
    $new, $fmt = $r[0], $r[1]
    $out = (New-Object Text.UTF8Encoding($false)).GetBytes($new)
    Assert-InRun $dst
    $fo = [IO.File]::Open($dst, 'CreateNew', 'Write', 'None')   # 只建新檔，不覆蓋任何既有檔
    try { $fo.Write($out, 0, $out.Length) } finally { $fo.Close() }
    $countOld = ([regex]::Matches($text, '\*\*\*')).Count
    $countNew = ([regex]::Matches($new, '\*\*\*')).Count
    $changed = $countNew -gt $countOld
    $note = "$fmt，" + $(if ($changed) { '已遮密碼' } else { '無密碼欄位' })
    return @($out.Length, (Get-Sha256 $out), $note, $changed)
}

function Copy-Log([IO.FileInfo]$f, [string]$dst, [long]$maxBytes) {
    # 回傳 @(位元組, sha256, 註記)；共用讀取，不鎖 FTP 服務
    if ($f.Length -gt $maxBytes) { return @(0, '', "超過單檔上限 $([int]($maxBytes / $CHUNK)) MB，未收集") }
    Assert-InRun $dst
    $sha = [Security.Cryptography.SHA256]::Create()
    $n = [long]0
    $fi = $null; $fo = $null
    try {
        $fi = [IO.File]::Open($f.FullName, 'Open', 'Read', 'ReadWrite, Delete')   # 來源只讀、共用，不鎖 FTP 服務
        $fo = [IO.File]::Open($dst, 'CreateNew', 'Write', 'None')                  # 只建新檔，不覆蓋任何既有檔
        $buf = New-Object byte[] $CHUNK
        while ($n -lt $maxBytes) {
            $want = [int][Math]::Min($CHUNK, $maxBytes - $n)
            $k = $fi.Read($buf, 0, $want)
            if ($k -le 0) { break }
            $fo.Write($buf, 0, $k); [void]$sha.TransformBlock($buf, 0, $k, $null, 0); $n += $k
        }
        [void]$sha.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        $hash = $sha.Hash
    } finally {
        if ($fi) { $fi.Close() }
        if ($fo) { $fo.Close() }
        $sha.Dispose()
    }
    $note = @()
    try {
        $after = Get-Item -LiteralPath $f.FullName -Force
        if ($after.Length -ne $f.Length -or $after.LastWriteTime -ne $f.LastWriteTime) { $note += '複製中檔案有變動' }
        if ($n -ge $maxBytes -and $after.Length -gt $n) { $note += '達上限，只收前段' }
    } catch { $note += '複製完成後來源已不在（可能被輪替）' }
    return @($n, (([BitConverter]::ToString($hash) -replace '-', '').ToLower()), ($note -join '；'))
}

function Get-ServiceRoots {
    # 從服務的執行檔路徑找安裝目錄（裝在非預設路徑時也找得到）
    $roots = @()
    try {
        $svcs = Get-CimInstance Win32_Service | Where-Object { $_.PathName -match 'serv-?u|filezilla' -or $_.Name -match 'serv-?u|filezilla' }
        foreach ($s in $svcs) {
            $m = [regex]::Match([string]$s.PathName, '^\s*"?([^"]+?\.exe)')
            if ($m.Success) { $roots += [IO.Path]::GetDirectoryName($m.Groups[1].Value) }
        }
    } catch { ErrLog "找服務安裝目錄失敗：$($_.Exception.Message)" }
    return $roots
}

function Get-LocalIPv4 {
    try {
        # 有預設閘道的網卡優先（主機有多張網卡時，避免抓到備份網段或虛擬網卡）
        $ip = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' |
            Sort-Object { if ($_.DefaultIPGateway) { 0 } else { 1 } } |
            ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' -and $_ -notmatch '^(127|169\.254)\.' } |
            Select-Object -First 1
        if ($ip) { return $ip }
    } catch { ErrLog "取本機 IP 失敗：$($_.Exception.Message)" }
    return 'unknown-ip'
}

function Write-CsvRow([string]$path, [object[]]$cells) {
    $line = ($cells | ForEach-Object { '"' + ([string]$_).Replace('"', '""') + '"' }) -join ','
    [IO.File]::AppendAllText($path, $line + "`r`n", (New-Object Text.UTF8Encoding($true)))
}

trap { ErrLog ("未預期錯誤（第 {0} 行）：{1}" -f $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message); if (-not $script:LogFile) { Stop-Early '未預期錯誤，中止' }; break }

# ================= 主流程 =================
Log "FTP 主機本機收集（PowerShell 版 $VERSION）" 'Green'
Log '只讀不改、不刪除；設定檔遮密碼後才寫入；log 只收近期。'
Log ''

if (-not $SocTicket.Trim()) { $SocTicket = Read-Host '資安／SOC 通知單號（必填）' }
if (-not $SocTicket.Trim()) { Stop-Early '沒有通知單號，不執行。' }
if (-not $OutDir) {
    $def = Join-Path $PSScriptRoot 'out'
    $ans = Read-Host "存放目錄（直接按 Enter＝$def）"
    $OutDir = if ($ans.Trim()) { $ans.Trim().Trim('"') } else { $def }
}
if ($OutDir.StartsWith('\\')) { Stop-Early '存放目錄請用本機磁碟，不要放網路共用。' }
$OutDir = [IO.Path]::GetFullPath($OutDir)
$drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($OutDir))
if ($drive.DriveType -eq 'Network') { Stop-Early '存放目錄請用本機磁碟，不要放對應的網路磁碟。' }

$extra = @($ExtraPaths -split ';' | Where-Object { $_.Trim() } | ForEach-Object { $_.Trim() })
foreach ($p in $extra) { if ($p -notmatch '^[A-Za-z]:\\') { Stop-Early "ExtraPaths 要是 X:\... 完整路徑：$p" } }
$svcRoots = @(Get-ServiceRoots)
$roots = @($DEFAULT_ROOTS + $svcRoots + $extra | Select-Object -Unique)
foreach ($p in $roots) {
    if (Test-Inside $OutDir $p) { Stop-Early "存放目錄不能放在要收集的資料夾裡：$p" }
}

$ip = Get-LocalIPv4
$hostName = $env:COMPUTERNAME
$start = Get-Date
$runDir = Join-Path $OutDir ("run_local_{0}_{1}_{2}" -f $ip, $hostName, $start.ToString('yyyyMMdd_HHmmss'))
$k = 1; $baseDir = $runDir
while (Test-Path -LiteralPath $runDir) { $k++; $runDir = "${baseDir}_$k" }
$hdir = Join-Path $runDir $ip
$script:RunDir = $runDir
New-Item -ItemType Directory -Path $hdir -Force | Out-Null
Open-RunLogs $runDir
Log "結果資料夾已建立：$runDir"

$info = Join-Path $runDir '_run_info.txt'
$who = [Security.Principal.WindowsIdentity]::GetCurrent().Name
@"
SOC 通知單號：$SocTicket
執行者（Windows 登入）：$who
連線帳號：（本機模式）
執行機器：$hostName（$ip）
開始：$(Ts $start)
收集工具：FtpCollect.ps1 $VERSION
log 天數：$Days
單檔上限：$MaxMB MB
模式：本機（PowerShell）
從服務找到的安裝目錄：$($svcRoots -join '；')
額外路徑：$($extra -join '；')
"@ | Out-File -LiteralPath $info -Encoding utf8

$runCsv = Join-Path $runDir '_run.csv'
Write-CsvRow $runCsv @('#', 'IP', 'Type', '狀態', '主設定檔', '設定檔', 'log 檔', '最舊 log 檔修改日', '未收集', '列出檔名數', '已遮密碼檔', 'MB', 'Note')
$manifest = Join-Path $hdir 'manifest.csv'
Write-CsvRow $manifest @('kind', 'source_path', 'size', 'mtime', 'sha256', 'note')

$cutoff = $start.AddDays(-$Days)
$maxBytes = [long]$MaxMB * $CHUNK
$s = @{ found = 0; denied = 0; main = 0; config = 0; log = 0; bytes = [long]0; masked = 0; errors = 0; skipped = 0; oldest = $null }
$types = @()
$endReason = '正常結束'
$seen = @{}

try {
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        try { [void](Get-Item -LiteralPath $root -Force) } catch { $s.denied++; $s.errors++; ErrLog "無法存取 $root：$($_.Exception.Message)"; Write-CsvRow $manifest @('error', $root, '', '', '', "無法存取：$($_.Exception.Message)"); continue }
        $s.found++
        if ($root -match 'serv-?u') { $types += 'ServU' } elseif ($root -match 'filezilla') { $types += 'FileZilla' }
        Write-CsvRow $manifest @('root', $root, '', '', '', '找到')
        Log "找到：$root"
        $errs = $null
        $files = @(Get-ChildItem -LiteralPath $root -Recurse -File -Force -ErrorAction SilentlyContinue -ErrorVariable errs)
        foreach ($e in @($errs)) { $s.errors++; ErrLog "無法列目錄 $($e.TargetObject)：$($e.Exception.Message)"; Write-CsvRow $manifest @('error', "$($e.TargetObject)", '', '', '', "無法列目錄：$($e.Exception.Message)") }
        foreach ($f in $files) {
            if ($seen.ContainsKey($f.FullName.ToLower())) { continue }   # 預設路徑與服務路徑重疊時不重複收
            $seen[$f.FullName.ToLower()] = $true
            if (Test-Inside $f.FullName $runDir) { continue }
            $ext = $f.Extension.ToLower()
            $kind = if ($CONFIG_EXT -contains $ext) { 'config' } elseif ($f.Name -match $LOG_NAME) { 'log' } else { '' }
            if (-not $kind) { continue }
            if ($kind -eq 'log' -and $f.LastWriteTime -lt $cutoff) { continue }
            try {
                $free = (New-Object IO.DriveInfo([IO.Path]::GetPathRoot($runDir))).AvailableFreeSpace
                if ($free - $f.Length -lt $MIN_FREE) { throw [InvalidOperationException]::new('STOP:目的磁碟剩不到 2 GB') }
                $rel = $f.FullName.Substring(0, 1) + $f.FullName.Substring(2)   # C:\x\y → C\x\y
                $dst = Join-Path $hdir $rel
                New-Item -ItemType Directory -Path (Split-Path $dst) -Force | Out-Null
                if ($kind -eq 'log') {
                    $r = Copy-Log $f $dst $maxBytes
                    $n, $sha, $note = $r[0], $r[1], $r[2]
                } else {
                    $r = Copy-Config $f $dst
                    $n, $sha, $note = $r[0], $r[1], $r[2]
                    if ($r[3]) { $s.masked++ }
                }
                if ($sha) {   # 收到（0 位元組的空 log 也算收到）
                    $s[$kind]++
                    $s.bytes += $n
                    if ($kind -eq 'config' -and $f.Name -match $MAIN_CONFIG) { $s.main++ }
                    if ($kind -eq 'log' -and ($null -eq $s.oldest -or $f.LastWriteTime -lt $s.oldest)) { $s.oldest = $f.LastWriteTime }
                } else { $s.skipped++; ErrLog "未收集 $($f.FullName)：$note" }
                Write-CsvRow $manifest @($kind, $f.FullName, $f.Length, (Ts $f.LastWriteTime), $sha, $note)
            } catch {
                if ("$($_.Exception.Message)".StartsWith('STOP:')) { throw }
                $s.errors++
                ErrLog "收集失敗 $($f.FullName)：$($_.Exception.Message)"
                Write-CsvRow $manifest @('error', $f.FullName, '', '', '', "$($_.Exception.Message)")
            }
        }
    }
    if (-not $s.found -and $s.denied) { $status = "失敗：$($s.denied) 個安裝目錄存取被拒（看 manifest）" }
    elseif (-not $s.found) { $status = '失敗：找不到 Serv-U／FileZilla 安裝目錄（裝在別處請用 -ExtraPaths）' }
    elseif (-not $s.main) { $status = '失敗：找到目錄但沒收到主設定檔（看 manifest）' }
    else {
        $status = 'OK'
        if ($s.errors) { $status = "部分成功：$($s.errors) 個錯誤" }
        if (-not $s.log) { $status += "；近 $Days 天沒有 log（log 可能沒開或在別處）" }
        if ($s.skipped) { $status += "；$($s.skipped) 個檔未收集（看 manifest）" }
    }
} catch {
    $msg = "$($_.Exception.Message)" -replace '^STOP:', ''
    $endReason = "中止：$msg"; ErrLog $endReason
    $status = "$endReason（本台資料不完整）"
}

# ---------- 補充資料（盤點要用、log 抓不到的） ----------
# 1. 版本與監聽埠：知道是哪一版、實際開了哪些 port（21／990／22…）
$hostInfo = Join-Path $runDir 'host_info.csv'
Write-CsvRow $hostInfo @('item', 'name', 'value')
foreach ($a in @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' -ErrorAction SilentlyContinue)) {
    foreach ($x in @($a.IPAddress)) { if ($x -match '^\d+\.\d+\.\d+\.\d+$') { Write-CsvRow $hostInfo @('ipv4', $a.Description, $x) } }
}
try { $os = Get-CimInstance Win32_OperatingSystem; Write-CsvRow $hostInfo @('os', $os.Caption, $os.Version) } catch { ErrLog "取作業系統資訊失敗：$($_.Exception.Message)" }
$ftpPids = @()
try {
    foreach ($svc in @(Get-CimInstance Win32_Service | Where-Object { $_.PathName -match 'serv-?u|filezilla' -or $_.Name -match 'serv-?u|filezilla' })) {
        $exe = [regex]::Match([string]$svc.PathName, '^\s*"?([^"]+?\.exe)').Groups[1].Value
        $ver = ''; if ($exe -and (Test-Path -LiteralPath $exe)) { $ver = (Get-Item -LiteralPath $exe).VersionInfo.ProductVersion }
        Write-CsvRow $hostInfo @('service', $svc.Name, "狀態=$($svc.State)；啟動=$($svc.StartMode)；版本=$ver；$exe")
        if ($svc.ProcessId) { $ftpPids += [int]$svc.ProcessId }
    }
} catch { Write-CsvRow $hostInfo @('error', 'service', "$($_.Exception.Message)"); ErrLog "讀服務資訊失敗：$($_.Exception.Message)" }
try {
    foreach ($c in @(Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object { $ftpPids -contains $_.OwningProcess })) {
        Write-CsvRow $hostInfo @('listen', "pid $($c.OwningProcess)", "$($c.LocalAddress):$($c.LocalPort)")
    }
} catch {
    foreach ($ln in @(netstat -ano -p tcp | Select-String 'LISTENING')) {
        $p = ($ln.ToString().Trim() -split '\s+')
        if ($p.Count -ge 5 -and $ftpPids -contains [int]$p[4]) { Write-CsvRow $hostInfo @('listen', "pid $($p[4])", $p[1]) }
    }
}

# 2. 憑證到期日（只讀憑證，不碰私鑰）：FTPS／SFTP 憑證到期會讓 AP 斷線
foreach ($root in $roots) {
    if (-not (Test-Path -LiteralPath $root)) { continue }
    foreach ($cf in @(Get-ChildItem -LiteralPath $root -Recurse -File -Force -Include *.pem, *.crt, *.cer -ErrorAction SilentlyContinue)) {
        try {
            $t = [IO.File]::ReadAllText($cf.FullName)
            foreach ($m in [regex]::Matches($t, '-----BEGIN CERTIFICATE-----([A-Za-z0-9+/=\s]+)-----END CERTIFICATE-----')) {
                $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2(, [Convert]::FromBase64String(($m.Groups[1].Value -replace '\s', '')))
                Write-CsvRow $hostInfo @('cert', $cf.FullName, "到期=$($c.NotAfter.ToString('yyyy/MM/dd'))；Subject=$($c.Subject)")
            }
        } catch { ErrLog "讀憑證失敗 $($cf.FullName)：$($_.Exception.Message)" }
    }
}

# 3. 帳號家目錄的檔案清單（只列檔名／大小／時間，不複製內容）
#    log 只留約 30 天；月結、季結、年結的檔案要靠「檔案最後修改時間」才看得出有在用。
$fileList = Join-Path $hdir 'filelist.csv'
Write-CsvRow $fileList @('path', 'size', 'mtime')
$homeDirs = @{}
foreach ($cfgOut in @(Get-ChildItem -LiteralPath $hdir -Recurse -File -Force | Where-Object { $CONFIG_EXT -contains $_.Extension.ToLower() })) {
    $txt = [IO.File]::ReadAllText($cfgOut.FullName)
    foreach ($m in [regex]::Matches($txt, '(?i)(?<![A-Za-z])([A-Z]:\\[^"<>|\r\n*?=]*)')) {
        $p = $m.Groups[1].Value.Trim().TrimEnd('\', '/', ' ', ';', ',')
        if ($p.Length -lt 4) { continue }
        if ($p -match '(?i)^C:\\(Windows|Program Files|ProgramData|Users)(\\|$)') { continue }   # 系統與安裝目錄不是家目錄
        if ($p -match '(?i)\.(exe|dll|log|xml|ini|pem|key|crt|txt)$') { continue }
        if (Test-Path -LiteralPath $p -PathType Container) { $homeDirs[$p.ToLower()] = $p }
    }
}
$listed = 0; $MAX_LIST = 200000
$tops = @($homeDirs.Values | Sort-Object)
$tops = @($tops | Where-Object { $d = $_; -not ($tops | Where-Object { $_ -ne $d -and (Test-Inside $d $_) }) })   # 去掉被上層包含的
foreach ($d in $tops) {
    Write-CsvRow $hostInfo @('homedir', 'listed', $d)
    if (Test-Inside $runDir $d) { continue }
    foreach ($f in @(Get-ChildItem -LiteralPath $d -Recurse -File -Force -ErrorAction SilentlyContinue)) {
        if ($listed -ge $MAX_LIST) { break }
        Write-CsvRow $fileList @($f.FullName, $f.Length, (Ts $f.LastWriteTime)); $listed++
    }
    if ($listed -ge $MAX_LIST) { Write-CsvRow $fileList @("（超過 $MAX_LIST 筆，以下未列）", '', ''); break }
}
Log "家目錄 $($tops.Count) 個，列出檔名 $listed 筆"

$typeStr = (@($types | Select-Object -Unique) -join '+')
if (-not $typeStr) { $typeStr = 'auto' }
$oldest = if ($s.oldest) { $s.oldest.ToString('yyyy/MM/dd') } else { '' }
Write-CsvRow $runCsv @(1, $ip, $typeStr, $status, $s.main, $s.config, $s.log, $oldest, $s.skipped, $listed, $s.masked, [Math]::Round($s.bytes / $CHUNK, 1), $hostName)
$okCount = if ($status.StartsWith('OK')) { 1 } else { 0 }
"結束：$(Ts (Get-Date))（$endReason）`r`n結果：$okCount/1 台 OK" | Out-File -LiteralPath $info -Encoding utf8 -Append

Log ''
Log "狀態：$status" $(if ($okCount) { 'Green' } else { 'Yellow' })
Log "主設定檔 $($s.main)、設定檔 $($s.config)（遮密碼 $($s.masked)）、log $($s.log)、未收集 $($s.skipped)、共 $([Math]::Round($s.bytes / $CHUNK, 1)) MB"
Log "結果資料夾：$runDir"
Log "執行紀錄：$script:LogFile；錯誤紀錄：$script:ErrFile（錯誤 $script:ErrCount 筆）"
Log '請把整個 run_local_ 資料夾拷回集中的地方；第一次跑請打開一份設定檔確認密碼已遮。'

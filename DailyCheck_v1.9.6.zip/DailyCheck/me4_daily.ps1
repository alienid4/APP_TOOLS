﻿# Me4Daily v1.0.0 (2026-11-17)
# 每日檢查「3. Storage/San Switch」— Dell EMC PowerVault ME4 系列精簡版（唯讀）
#   讀：系統健康、控制器、硬碟、電源、Pool 用量、目前告警（讀不到的列「收集缺口」）
#   設備清單.csv：類別 3、型號以 ME4 開頭（例 ME4024）。帳號預設 webit3sc（Monitor 角色）。
#   判定：硬體／控制器非 OK＝立即處理（⚠影響營運）；Pool ≥95%＝立即處理、≥90%＝立即處理（⚠空間）、≥85%＝本週追蹤；系統健康非 OK＝立即處理
#   輸出格式與 Unity 相同（00_重點整理.csv、00_檢查表文字.csv），總覽可直接讀
param(
  [ValidateRange(1, 100)][double]$PoolWarnPct = 85,
  [ValidateRange(1, 100)][double]$PoolBadPct = 90,
  [switch]$NonInteractive,
  [ValidateRange(1, 65535)][int]$Port = 443,
  [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
$ToolVersion = 'Me4Daily v1.0.0'
$here = $PSScriptRoot
. (Join-Path $here 'devlist.ps1')
$targets = Read-DevList $here '3' '(?i)^ME4' ''
if ($null -eq $targets) { exit 3 }
if ($targets.Count -eq 0) { Write-Host '設備清單.csv 裡沒有類別 3、型號 ME4 開頭的設備。'; exit 3 }
foreach ($tg in $targets) { if (-not $tg.User) { $tg.User = 'webit3sc' } }
$needAsk = @($targets | Where-Object { -not $_.Reject -and $null -eq $_.Sec })
$remember = $null; $rememberLines = @()
if ($needAsk.Count) {
  if ($NonInteractive) { foreach ($tg in $needAsk) { $tg.Reject = '沒有可用的密碼（非互動模式不詢問）' } }
  else { $sh = Read-Host ("有 " + $needAsk.Count + " 台 ME4 沒有可用的密碼，請輸入密碼（不會顯示）") -AsSecureString; foreach ($tg in $needAsk) { $tg.Sec = $sh }; $remember = ConvertFrom-SecureString -SecureString $sh; $rememberLines = @($needAsk | ForEach-Object { $_.Line }); $sh = $null }
}
$curl = Join-Path $env:SystemRoot 'System32\curl.exe'
if (-not (Test-Path $curl)) { Write-Host '找不到 Windows 內建 curl.exe。'; exit 3 }

class AuthFail : System.Exception { AuthFail([string]$m) : base($m) {} }
function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
# 一次 GET。URL 與標頭（含登入雜湊、session key）都經標準輸入給 curl，不出現在命令列
function Get-Me4($dev, [string]$path, [string[]]$hdr) {
  $cfg = @('url = "https://' + $dev.Host + $(if ($Port -ne 443) { ":$Port" } else { '' }) + $path + '"') + @($hdr | ForEach-Object { 'header = "' + $_ + '"' })
  $psi = New-Object Diagnostics.ProcessStartInfo; $psi.FileName = $curl
  $psi.Arguments = '-q -s -S -k --max-redirs 0 --proto "=https" --noproxy "*" --connect-timeout 15 --max-time 90 -K - -w "\n%{http_code}"'
  $psi.UseShellExecute = $false; $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
  $ie = [Console]::InputEncoding
  try { if ($ie.GetPreamble().Length) { [Console]::InputEncoding = New-Object Text.UTF8Encoding($false) } } catch {}
  try { $pr = [Diagnostics.Process]::Start($psi) } finally { try { if ([Console]::InputEncoding -ne $ie) { [Console]::InputEncoding = $ie } } catch {} }
  try {
    $bin = [Text.Encoding]::ASCII.GetBytes((($cfg | ForEach-Object { $_ + "`n" }) -join ''))
    $pr.StandardInput.BaseStream.Write($bin, 0, $bin.Length); $pr.StandardInput.Close(); $bin = $null
    $et = $pr.StandardError.ReadToEndAsync(); $ot = $pr.StandardOutput.ReadToEndAsync()
    if (-not $pr.WaitForExit(110000)) { try { $pr.Kill() } catch {}; throw '超過 110 秒沒回應' }
    $out = $ot.Result; $er = $et.Result; $xc = $pr.ExitCode
  } finally { $pr.Dispose() }
  if ($xc -ne 0) { throw ('連線失敗（curl ' + $xc + '）：' + (($er -replace '\s+', ' ').Trim())) }
  $i = $out.LastIndexOf("`n"); $code = $out.Substring($i + 1).Trim(); $body = $out.Substring(0, [Math]::Max($i, 0))
  if ($code -eq '401' -or $code -eq '403') { throw [AuthFail]::new("HTTP $code：帳號或密碼被拒（為避免鎖帳號，整批停止、不重試）") }
  if ($code -ne '200') { throw "HTTP $code：讀 $path 失敗" }
  return ($body | ConvertFrom-Json)
}
function St($j) { if ($j.status) { return @($j.status)[0] } return $null }
function Rows($j, [string[]]$names) { foreach ($n in $names) { if ($j.PSObject.Properties.Name -contains $n) { return @($j.$n) } }; return $null }
function Hl([object]$hv) { $t = ([string]$hv).Trim(); if (-not $t) { return '不知道' }; if ($t -eq 'OK') { return '正常' }; if ($t -in 'N/A') { return '正常' }; return '異常' }

$runStart = Get-Date
$R = @{}; foreach ($k in 'Summary', 'Focus', 'Sheet', 'Hw', 'Pools', 'Alerts', 'Gaps') { $R[$k] = New-Object System.Collections.Generic.List[object] }
$abort = $null
try {
foreach ($tg in $targets) {
  $label = Label $tg 'ME4'
  Write-Host ("──── " + $tg.No + " / " + $targets.Count + "：" + $label)
  $sum = [ordered]@{ 項次 = $tg.No; 項目 = $label; 設備 = $tg.Host; 系統健康 = '不知道'; 硬體異常 = $null; Pool最高用量 = $null; 告警 = $null; 完整度 = '查不到'; 處置 = '須補查'; 說明 = '' }
  function Gap([string]$item, [string]$why) { $R.Gaps.Add([pscustomobject]@{ 設備 = $label; 項目 = $item; 原因 = $why }) }
  function Fx([string]$lvl, [string]$imp, [string]$obj, [string]$now, [string]$todo) { $R.Focus.Add([pscustomobject]@{ 等級 = $lvl; 影響營運 = $imp; 設備 = $tg.Host; 物件 = $obj; 現況 = $now; 依據 = '目前狀態'; 第一次 = ''; 最後一次 = ''; 建議 = $todo }) }
  if ($abort) { $sum.完整度 = '沒檢查'; $sum.說明 = '前面的設備帳密被拒，整批停止'; $R.Summary.Add([pscustomobject]$sum); continue }
  if ($tg.Reject) { $sum.說明 = $tg.Reject; Gap '登入' $tg.Reject; Fx '立即處理' '' '收集缺口 登入' $tg.Reject '人工登入 ME4 管理介面確認'; $R.Summary.Add([pscustomobject]$sum); continue }
  $dev = [pscustomobject]@{ Host = $tg.Host }
  $miss = New-Object System.Collections.Generic.List[string]
  $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($tg.Sec)
  try {
    # 1) 登入：/api/login/<SHA256(帳號_密碼)>，回傳 session key
    Write-Host '  [1/6] 登入'
    $sha = [Security.Cryptography.SHA256]::Create()
    $hash = -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($tg.User + '_' + [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b))) | ForEach-Object { $_.ToString('x2') })
    $sha.Dispose()
    $lj = Get-Me4 $dev ('/api/login/' + $hash) @('datatype: json'); $hash = $null
    $ls = St $lj
    if (-not $ls -or [string]$ls.'response-type' -ne 'Success' -or -not $ls.response) { throw [AuthFail]::new('登入被拒：' + [string]$ls.response) }
    $H = @('datatype: json', ('sessionKey: ' + [string]$ls.response))
    $hwBad = 0
    # 2) 系統
    Write-Host '  [2/6] 系統健康'
    try { $sj = Get-Me4 $dev '/api/show/system' $H; $sy = @(Rows $sj 'system')[0]; $sum.系統健康 = Hl $sy.health
          if ($sum.系統健康 -ne '正常') { Fx '立即處理' '⚠影響營運：儲存系統健康異常' '系統' ("健康 $($sy.health)：$($sy.'health-reason')") '登入 ME4 管理介面看原因' } }
    catch { if ($_.Exception -is [AuthFail]) { throw }; $miss.Add('系統'); Gap '系統' $_.Exception.Message }
    # 3) 控制器、電源（硬體）
    Write-Host '  [3/6] 控制器／電源'
    foreach ($p in @(@('/api/show/controllers', @('controllers'), '控制器', 'controller-id'), @('/api/show/power-supplies', @('power-supplies', 'power-supply'), '電源', 'name'))) {
      try {
        $rows = Rows (Get-Me4 $dev $p[0] $H) $p[1]
        if ($null -eq $rows) { throw '回應格式看不懂' }
        foreach ($x in $rows) { $lv = Hl $x.health; $nm = [string]$x.($p[3])
          $R.Hw.Add([pscustomobject]@{ 設備 = $label; 類型 = $p[2]; 名稱 = $nm; 健康 = [string]$x.health; 判定 = $lv })
          if ($lv -ne '正常') { $hwBad++; Fx '立即處理' '⚠影響營運：硬體異常，備援減少' ("硬體 $($p[2]) $nm") ("健康 $($x.health) $($x.'health-reason')") '報修' } }
      } catch { if ($_.Exception -is [AuthFail]) { throw }; $miss.Add($p[2]); Gap $p[2] $_.Exception.Message }
    }
    # 4) 硬碟
    Write-Host '  [4/6] 硬碟'
    try {
      $rows = Rows (Get-Me4 $dev '/api/show/disks' $H) @('drives', 'disks')
      if ($null -eq $rows) { throw '回應格式看不懂' }
      foreach ($x in $rows) { $lv = Hl $x.health; $nm = [string]$x.location
        $R.Hw.Add([pscustomobject]@{ 設備 = $label; 類型 = '硬碟'; 名稱 = $nm; 健康 = [string]$x.health; 判定 = $lv })
        if ($lv -ne '正常') { $hwBad++; Fx '立即處理' '⚠影響營運：硬碟異常，再壞一顆可能停機' ("硬體 硬碟 $nm") ("健康 $($x.health) $($x.'health-reason')") '報修更換' } }
    } catch { if ($_.Exception -is [AuthFail]) { throw }; $miss.Add('硬碟'); Gap '硬碟' $_.Exception.Message }
    $sum.硬體異常 = $hwBad
    # 5) Pool 用量（數值是 512 bytes 區塊）
    Write-Host '  [5/6] Pool'
    try {
      $rows = Rows (Get-Me4 $dev '/api/show/pools' $H) @('pools')
      if ($null -eq $rows) { throw '回應格式看不懂' }
      $top = $null
      foreach ($x in $rows) {
        $tot = [double]$x.'total-size-numeric'; $av = [double]$x.'total-avail-numeric'
        $pct = if ($tot -gt 0) { [math]::Round(100 * ($tot - $av) / $tot, 1) } else { $null }
        $gb = { param($n) [math]::Round($n * 512 / 1073741824, 1) }
        $R.Pools.Add([pscustomobject]@{ 設備 = $label; Pool = $x.name; 總容量GB = (& $gb $tot); 剩餘GB = (& $gb $av); 用量 = $pct; 健康 = [string]$x.health })
        if ($null -ne $pct -and ($null -eq $top -or $pct -gt $top)) { $top = $pct }
        $now = "Pool $($x.name) 已用 $(& $gb ($tot - $av))/$(& $gb $tot) GB（$pct%），健康 $($x.health)"
        if ($null -ne $pct -and $pct -ge $PoolBadPct) { Fx '立即處理' '⚠影響營運：空間將滿，上面的資料可能寫不進去' ("Pool $($x.name)") $now '擴充或清理' }
        elseif ((Hl $x.health) -ne '正常') { Fx '立即處理' '' ("Pool $($x.name)") $now '登入 ME4 管理介面看原因' }
        elseif ($null -ne $pct -and $pct -ge $PoolWarnPct) { Fx '本週追蹤' '' ("Pool $($x.name)") $now '規劃擴充' }
      }
      $sum.Pool最高用量 = $top
    } catch { if ($_.Exception -is [AuthFail]) { throw }; $miss.Add('Pool'); Gap 'Pool' $_.Exception.Message }
    # 6) 目前告警（舊韌體可能沒有這個指令，讀不到只列缺口、不影響完整度）
    Write-Host '  [6/6] 告警'
    try {
      $rows = Rows (Get-Me4 $dev '/api/show/alerts' $H) @('alerts')
      if ($null -eq $rows) { throw '回應格式看不懂' }
      $act = @($rows | Where-Object { [string]$_.resolved -notmatch '(?i)^yes|true$' -and [string]$_.acknowledged -notmatch '(?i)^yes|true$' })
      foreach ($x in $rows) { $R.Alerts.Add([pscustomobject]@{ 設備 = $label; 時間 = $x.'detected-time'; 嚴重度 = $x.severity; 元件 = $x.component; 原因 = $x.reason; 已處理 = $x.resolved; 已確認 = $x.acknowledged }) }
      $sum.告警 = $act.Count
      foreach ($x in $act) { $sv = [string]$x.severity; Fx $(if ($sv -match '(?i)critical|error') { '立即處理' } else { '本週追蹤' }) '' ("告警 $($x.component)") ("$sv：$($x.reason)") '登入 ME4 管理介面確認' }
    } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '告警（選用）' $_.Exception.Message }
    try { [void](Get-Me4 $dev '/api/exit' $H) } catch {}
    $sum.完整度 = if ($miss.Count) { '不完整（缺 ' + ($miss -join '、') + '）' } else { '完整' }
  } catch {
    if ($_.Exception -is [AuthFail]) { $abort = $label + '：' + $_.Exception.Message }
    $sum.說明 = $_.Exception.Message; Gap '登入／連線' $_.Exception.Message
    Fx '立即處理' '' '收集缺口 登入' $_.Exception.Message '人工登入 ME4 管理介面確認'
  } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b); $tg.Sec = $null; $H = $null }
  $bad = @($R.Focus | Where-Object { $_.設備 -eq $tg.Host -and $_.等級 -eq '立即處理' }).Count
  $sum.處置 = if ($sum.完整度 -eq '查不到' -or $sum.完整度 -eq '沒檢查') { '須補查' } elseif ($bad) { '須回報' } elseif ($sum.完整度 -ne '完整') { '須補查' } elseif (@($R.Focus | Where-Object { $_.設備 -eq $tg.Host }).Count) { '可結案（有注意事項）' } else { '可結案' }
  $R.Summary.Add([pscustomobject]$sum)
  # 檢查表文字（一行一件）
  $L = New-Object System.Collections.Generic.List[string]
  $L.Add('結論：' + $sum.處置)
  $k = 0; foreach ($f in @($R.Focus | Where-Object { $_.設備 -eq $tg.Host })) { $k++; $L.Add("$k. " + $(if ($f.影響營運) { '⚠' } else { '' }) + $f.物件 + '：' + $f.現況) }
  $L.Add('System Health：' + $sum.系統健康)
  $L.Add('硬體異常：' + $(if ($null -ne $sum.硬體異常) { "$($sum.硬體異常) 件" } else { '不知道' }))
  $L.Add('Pool 最高用量：' + $(if ($null -ne $sum.Pool最高用量) { "$($sum.Pool最高用量)%" } else { '不知道' }))
  $L.Add('告警：' + $(if ($null -ne $sum.告警) { "$($sum.告警) 件未處理" } else { '讀不到（請人工看）' }))
  $L.Add('Me4Daily ' + $runStart.ToString('MM-dd HH:mm'))
  $R.Sheet.Add([pscustomobject]@{ 項目 = $label; 處置 = $sum.處置; 檢查表文字 = ($L -join "`n") })
  Write-Host ("  結論：" + $sum.處置 + "｜" + $sum.完整度)
}
} finally {}

# ---------------- 輸出（格式與 Unity 相同，總覽直接讀）
$outDir = Join-Path (Join-Path $here 'me4_out') ($runStart.ToString('yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0, 6))
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$COLS = @{ Sheet = @('項目', '處置', '檢查表文字'); Focus = @('等級', '影響營運', '設備', '物件', '現況', '依據', '第一次', '最後一次', '建議')
  Summary = @('項次', '項目', '設備', '系統健康', '硬體異常', 'Pool最高用量', '告警', '完整度', '處置', '說明'); Hw = @('設備', '類型', '名稱', '健康', '判定')
  Pools = @('設備', 'Pool', '總容量GB', '剩餘GB', '用量', '健康'); Alerts = @('設備', '時間', '嚴重度', '元件', '原因', '已處理', '已確認'); Gaps = @('設備', '項目', '原因') }
$FILE = @{ Sheet = '00_檢查表文字.csv'; Focus = '00_重點整理.csv'; Summary = '01_總表.csv'; Hw = '02_硬體.csv'; Pools = '03_Pool.csv'; Alerts = '04_告警.csv'; Gaps = '09_收集缺口.csv' }
function CsvV([object]$v) { if ($null -eq $v) { return '""' }; $t = [string]$v; if ($v -is [string] -and $t -match '^[=+\-@]') { $t = "'" + $t }; return '"' + ($t -replace '"', '""') + '"' }
foreach ($k in $FILE.Keys) {
  $sb = New-Object Text.StringBuilder
  [void]$sb.AppendLine((($COLS[$k] | ForEach-Object { CsvV $_ }) -join ','))
  foreach ($r0 in $R[$k]) { [void]$sb.AppendLine((($COLS[$k] | ForEach-Object { CsvV $r0.$_ }) -join ',')) }
  [IO.File]::WriteAllText((Join-Path $outDir $FILE[$k]), $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
}
function Tbl([string]$k, [string]$pre) {
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<table class='t'><thead><tr><th>項次</th>" + (($COLS[$k] | ForEach-Object { '<th>' + (Esc $_) + '</th>' }) -join '') + '</tr></thead><tbody>')
  $n = 0; foreach ($r0 in $R[$k]) { $n++; [void]$sb.Append("<tr><td data-v='$n'>$pre$n</td>" + (($COLS[$k] | ForEach-Object { $v = $r0.$_; $(if ($_ -eq '檢查表文字') { "<td class='cp'>" } else { '<td>' }) + (Esc $v) + '</td>' }) -join '') + $(if ($k -eq 'Sheet') { "<td><button class='copy'>複製</button></td>" } else { '' }) + '</tr>') }
  if (-not $n) { [void]$sb.Append("<tr><td colspan='12' class='u'>沒有資料</td></tr>") }
  [void]$sb.Append('</tbody></table>'); return $sb.ToString()
}
$overall = if (@($R.Summary | Where-Object { $_.處置 -eq '須回報' }).Count) { '須回報' } elseif (@($R.Summary | Where-Object { $_.處置 -eq '須補查' }).Count -or $abort) { '須補查' } elseif (@($R.Summary | Where-Object { $_.處置 -ne '可結案' }).Count) { '可結案（有注意事項）' } else { '可結案' }
$color = switch ($overall) { '須回報' { '#B3261E' } '須補查' { '#6B5E00' } default { '#0C6B37' } }
$html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>ME4 每日檢查 $($runStart.ToString('yyyy-MM-dd HH:mm'))</title>
<style>body{font-family:"Microsoft JhengHei",sans-serif;margin:0;background:#f6f7f9}header{background:$color;color:#fff;padding:12px 16px}h1{margin:0;font-size:20px}.m{font-size:13px}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:8px 16px;background:#fff;border-bottom:1px solid #ddd}nav button{border:1px solid #ccc;background:#fff;padding:6px 10px;cursor:pointer;border-radius:4px}nav button.on{background:#0C6B37;color:#fff}
section{display:none;padding:12px 16px}section.on{display:block}table.t{border-collapse:collapse;background:#fff;width:100%;font-size:13px}th{background:#eef2ef;cursor:pointer}td,th{border:1px solid #ddd;padding:4px 6px;vertical-align:top}td.cp{white-space:pre-wrap;line-height:1.6}.u{color:#999}</style></head><body>
<header><h1>3-Storage ME4 檢查　結論：$(Esc $overall)</h1><div class="m">執行 $($runStart.ToString('yyyy-MM-dd HH:mm:ss'))｜$ToolVersion｜Pool ≥$PoolBadPct% 立即處理、≥$PoolWarnPct% 本週追蹤$(if ($abort) { '｜⚠ 整批中止：' + (Esc $abort) })</div></header>
<nav id="nav"></nav>
<section id="s1" data-n="1 檢查表文字">$(Tbl 'Sheet' 'T')<h3>總表</h3>$(Tbl 'Summary' 'S')</section>
<section id="s2" data-n="2 重點整理">$(Tbl 'Focus' 'K')</section>
<section id="s3" data-n="3 硬體">$(Tbl 'Hw' 'H')</section>
<section id="s4" data-n="4 Pool">$(Tbl 'Pools' 'P')</section>
<section id="s5" data-n="5 告警">$(Tbl 'Alerts' 'A')</section>
<section id="s6" data-n="6 收集缺口">$(Tbl 'Gaps' 'G')</section>
<script>(function(){var secs=document.querySelectorAll('section'),nav=document.getElementById('nav');
function show(id){secs.forEach(function(s){s.classList.toggle('on',s.id==id)});nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-for')==id)})}
secs.forEach(function(s){var b=document.createElement('button');b.textContent=s.getAttribute('data-n');b.setAttribute('data-for',s.id);b.addEventListener('click',function(){show(s.id)});nav.appendChild(b)});
function cp(t){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(a);if(!ok)alert('複製失敗，請直接選取文字後按 Ctrl+C');return ok}
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t=b.closest('tr').querySelector('td.cp').textContent;if(t.indexOf('\n')>=0)t='"'+t.split('"').join('""')+'"';if(!cp(t))return;b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)})});
document.querySelectorAll('table.t th').forEach(function(th){th.addEventListener('click',function(){var tb=th.closest('table').tBodies[0],i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');var rows=Array.prototype.slice.call(tb.rows);
rows.sort(function(a,b){var x=a.cells[i],y=b.cells[i];if(!x||!y)return 0;var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var r=(p!==null&&q!==null)?parseFloat(p)-parseFloat(q):x.textContent.localeCompare(y.textContent,'zh-Hant',{numeric:true});return asc?r:-r});rows.forEach(function(r){tb.appendChild(r)})})});
show('s1');})();</script></body></html>
"@
[IO.File]::WriteAllText((Join-Path $outDir 'report.html'), $html, (New-Object Text.UTF8Encoding($true)))
Write-Host ''
foreach ($x in $R.Sheet) { Write-Host ($x.項目 + "`n" + $x.檢查表文字) }
Write-Host ("結論：" + $overall)
Write-Host ("報告：" + (Join-Path $outDir 'report.html'))
if ($remember -and -not $abort -and @($R.Summary | Where-Object { $_.完整度 -ne '查不到' }).Count) { Ask-Remember $here $rememberLines $remember 'ME4' }
$remember = $null
if (-not $NoOpen) { try { Start-Process (Join-Path $outDir 'report.html') } catch {} }
exit $(switch ($overall) { '可結案' { 0 } '可結案（有注意事項）' { 1 } '須回報' { 2 } default { 3 } })

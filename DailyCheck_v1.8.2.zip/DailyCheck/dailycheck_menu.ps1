﻿# DailyCheck 選單 v1.0.1 (2026-11-17)：仿 AIX SMIT 的全螢幕選單
#   操作只有兩個：↑↓ 移動、Enter 執行。離開／回上一層都是選單裡的一個項目。
#   「0 全部檢查」跑完會另外產生一份總覽報告（照紙本 1～4 分頁），只開總覽，不開四份。
param([switch]$NoOpen)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
if ([Console]::IsInputRedirected -or $Host.Name -ne 'ConsoleHost') {
  Write-Host '這個選單要在一般命令視窗（雙擊「每日檢查選單.bat」）執行；排程或 ISE 請改用 1_～4_ 開頭的 bat。'
  exit 3
}
. (Join-Path $here 'devlist.ps1')
try { $Host.UI.RawUI.WindowTitle = 'DailyCheck 每日檢查' } catch {}

$ITEMS = @(
  @{ Key = '1'; Text = 'WhatsUp 監控檢查'; Script = 'whatsup_daily.ps1'; Cat = '1'; Pick = $false; Out = 'whatsup_out' },
  @{ Key = '2'; Text = 'VMware 系統檢查'; Script = 'vmware_daily.ps1'; Cat = '2'; Pick = $true; Out = 'vmware_out' },
  @{ Key = '3'; Text = 'Storage/San Switch 檢查'; Script = 'unity_daily.ps1'; Cat = '3'; Pick = $true; Out = 'unity_out' },
  @{ Key = '4'; Text = '其他：AD net time'; Script = 'ad_time.ps1'; Cat = '4'; Pick = $false; Out = 'ad_out' },
  @{ Key = '0'; Text = '全部檢查（1～4 依序執行，產生總覽報告）'; Script = ''; Cat = ''; Pick = $false; Out = '' },
  @{ Key = 'Q'; Text = '離開'; Script = ''; Cat = ''; Pick = $false; Out = '' }
)
$CODE = @{ 0 = '正常'; 1 = '注意'; 2 = '須回報'; 3 = '查不到或不完整'; 4 = '有維護中裝置（須記錄）' }

function W([string]$t) { $n = 0; foreach ($ch in $t.ToCharArray()) { $n += $(if ([int]$ch -ge 0x1100) { 2 } else { 1 }) }; return $n }
function Cut([string]$t, [int]$w) { $o = ''; $n = 0; foreach ($ch in $t.ToCharArray()) { $c = $(if ([int]$ch -ge 0x1100) { 2 } else { 1 }); if ($n + $c -gt $w) { break }; $o += $ch; $n += $c }; return $o }
function Width { $w = 78; try { $w = [Math]::Max([Console]::WindowWidth - 2, 20) } catch {}; return $w }
function Line([string]$t = '', [string]$fg = '', [string]$bg = '') {
  $w = Width; $t = Cut $t $w; $len = W $t; if ($len -lt $w) { $t = $t + (' ' * ($w - $len)) }
  $p = @{ Object = $t }; if ($fg) { $p.ForegroundColor = $fg }; if ($bg) { $p.BackgroundColor = $bg }
  Write-Host @p
}
# 共用：SMIT 樣式畫面，↑↓ 選、Enter 回傳選到的索引；項目太多時自動捲動
function Choose([string]$title, [string[]]$lines, [int]$start = 0) {
  $i = $start
  while ($true) {
    Clear-Host
    $w = Width; $h = 25; try { $h = [Console]::WindowHeight } catch {}
    $room = [Math]::Max($h - 9, 3)
    $top = [Math]::Min([Math]::Max($i - [int]($room / 2), 0), [Math]::Max($lines.Count - $room, 0))
    Line ((' ' * [Math]::Max([int](($w - (W $title)) / 2), 0)) + $title) 'White' 'DarkBlue'
    Line ''
    Line '將游標移到要執行的項目，按 Enter。' 'Gray'
    Line $(if ($top -gt 0) { '  ↑ 上面還有' } else { '' }) 'DarkGray'
    for ($k = $top; $k -lt [Math]::Min($top + $room, $lines.Count); $k++) { if ($k -eq $i) { Line ('  ' + $lines[$k]) 'Black' 'Gray' } else { Line ('  ' + $lines[$k]) } }
    Line $(if ($top + $room -lt $lines.Count) { '  ↓ 下面還有' } else { '' }) 'DarkGray'
    Line ('-' * [Math]::Min($w, 60)) 'DarkGray'
    Line '↑↓ 移動　　Enter 執行' 'Yellow'
    $key = [Console]::ReadKey($true)
    switch ($key.Key) {
      'UpArrow' { $i = ($i - 1 + $lines.Count) % $lines.Count }
      'DownArrow' { $i = ($i + 1) % $lines.Count }
      'Enter' { return $i }
    }
  }
}

# 跑一支檢查；回傳 結束代碼、報告資料夾、錯誤
function RunOne($item, [string]$only, [bool]$quiet) {
  Line ("==== 執行：$($item.Key). $($item.Text)" + $(if ($only) { "（第 $only 號）" } else { '（全部）' })) 'White' 'DarkBlue'
  $t0 = Get-Date
  $sp = @{ NoOpen = ($NoOpen -or $quiet) }
  if ($only) { $sp.Only = $only }
  $global:LASTEXITCODE = $null; $err = ''
  try { & (Join-Path $here $item.Script) @sp | Out-Host } catch { $err = $_.Exception.Message; Write-Host ('執行失敗：' + $err) -ForegroundColor Red }
  $xc = if ($err) { 3 } elseif ($null -eq $LASTEXITCODE) { 3 } else { [int]$LASTEXITCODE }
  $dir = $null
  $od = Join-Path $here $item.Out
  if (Test-Path $od) { $dir = Get-ChildItem $od -Directory | Where-Object { $_.LastWriteTime -ge $t0.AddSeconds(-2) -and (Test-Path (Join-Path $_.FullName 'report.html')) } | Sort-Object LastWriteTime | Select-Object -Last 1 }
  return [pscustomobject]@{ Item = $item; Code = $xc; Dir = $(if ($dir) { $dir.FullName } else { '' }); Err = $err }
}

function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
function Overview($res) {
  $ts = Get-Date
  $od = Join-Path (Join-Path $here 'daily_out') $ts.ToString('yyyyMMdd_HHmmss')
  New-Item -ItemType Directory -Force -Path $od | Out-Null
  if (-not $res.Count) { Write-Host '設備清單沒有任何設備，沒有產生總覽。'; return }
  $bad = @($res | Where-Object { $_.Code -eq 2 }); $unk = @($res | Where-Object { $_.Code -eq 3 })
  $overall = if ($bad.Count) { '須回報' } elseif ($unk.Count) { '須補查' } elseif (@($res | Where-Object { $_.Code -ne 0 }).Count) { '可結案（有注意事項）' } else { '可結案' }
  $color = switch ($overall) { '須回報' { '#B3261E' } '須補查' { '#6B5E00' } default { '#0C6B37' } }
  $sum = New-Object Text.StringBuilder; $tabs = New-Object Text.StringBuilder; $n = 0
  foreach ($r in $res) {
    $n++; $id = 's' + $r.Item.Key
    $cls = switch ($r.Code) { 2 { 'bad' } 3 { 'unk' } 0 { '' } default { 'warn' } }
    $link = if ($r.Dir) { "<a href='" + (Esc ([Uri](Join-Path $r.Dir 'report.html')).AbsoluteUri) + "' target='_blank'>開詳細報告</a>" } else { '<span class=u>沒有報告</span>' }
    [void]$sum.Append("<tr class='$cls'><td data-v='$n'>$n</td><td><a href='#' data-go='$id'>$($r.Item.Key). $(Esc $r.Item.Text)</a></td><td><a href='#' data-go='$id'><b>$(Esc $CODE[$r.Code])</b></a></td><td>$link</td><td>$(Esc $r.Err)</td></tr>")
    # 每項的檢查表文字（各工具的 CSV）
    $rows = @()
    if ($r.Dir) {
      $f = @('00_檢查表文字.csv', 'Sheet.csv') | ForEach-Object { Join-Path $r.Dir $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
      if ($f) { try { $rows = @(Import-Csv $f -Encoding UTF8) } catch {} }
      elseif (Test-Path (Join-Path $r.Dir 'AD_net_time.csv')) { try { $rows = @(Import-Csv (Join-Path $r.Dir 'AD_net_time.csv') -Encoding UTF8) } catch {} }
    }
    $tb = New-Object Text.StringBuilder
    if ($rows.Count) {
      $cols = @($rows[0].PSObject.Properties.Name)
      [void]$tb.Append("<table class='t'><thead><tr><th>項次</th>" + (($cols | ForEach-Object { '<th>' + (Esc $_) + '</th>' }) -join '') + $(if ($cols -contains '檢查表文字') { '<th></th>' } else { '' }) + '</tr></thead><tbody>')
      $m = 0
      foreach ($x in $rows) {
        $m++
        [void]$tb.Append("<tr><td data-v='$m'>$($r.Item.Key)-$m</td>")
        foreach ($c in $cols) { [void]$tb.Append($(if ($c -eq '檢查表文字') { "<td class='cp'>" } else { '<td>' }) + (Esc $x.$c) + '</td>') }
        if ($cols -contains '檢查表文字') { [void]$tb.Append("<td><button class='copy'>複製</button></td>") }
        [void]$tb.Append('</tr>')
      }
      [void]$tb.Append('</tbody></table>')
    } else { [void]$tb.Append('<p class=u>這一項沒有讀到檢查表文字，請開詳細報告。</p>') }
    [void]$tabs.Append("<section id='$id' data-n='$($r.Item.Key) $(Esc $r.Item.Text)'><p>結果：<b>$(Esc $CODE[$r.Code])</b>　$link</p>" + $tb.ToString() + '</section>')
  }
  $html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>每日檢查總覽 $($ts.ToString('yyyy-MM-dd HH:mm'))</title>
<style>body{font-family:"Microsoft JhengHei",sans-serif;margin:0;background:#f6f7f9}header{background:$color;color:#fff;padding:12px 16px}h1{margin:0;font-size:20px}.m{font-size:13px}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:8px 16px;background:#fff;border-bottom:1px solid #ddd}nav button{border:1px solid #ccc;background:#fff;padding:6px 10px;cursor:pointer;border-radius:4px}nav button.on{background:#0C6B37;color:#fff}
section{display:none;padding:12px 16px}section.on{display:block}table.t{border-collapse:collapse;background:#fff;width:100%;font-size:13px}th{background:#eef2ef;cursor:pointer}td,th{border:1px solid #ddd;padding:4px 6px;vertical-align:top}
.cpt{white-space:pre-wrap;line-height:1.6}.cpt.fold{max-height:16em;overflow:hidden;position:relative}.cpt.fold:after{content:'';position:absolute;left:0;right:0;bottom:0;height:2em;background:linear-gradient(rgba(255,255,255,0),#fff)}button.more{display:block;margin-top:4px}tr.bad td{background:#fde8e8}tr.warn td{background:#fff6dc}tr.unk td{background:#efefef}.u{color:#999}</style></head><body>
<header><h1>每日檢查總覽　結論：$(Esc $overall)</h1><div class="m">產生 $($ts.ToString('yyyy-MM-dd HH:mm:ss'))｜執行人 $(Esc "$env:USERDOMAIN\$env:USERNAME")｜須回報 $($bad.Count) 項、查不到 $($unk.Count) 項</div></header>
<nav id="nav"></nav>
<section id="s0" data-n="總結論"><p>點項目或結果，跳到那一項的分頁；每一項都可以開詳細報告。</p><table class='t'><thead><tr><th>項次</th><th>檢查項目</th><th>結果</th><th>詳細報告</th><th>錯誤</th></tr></thead><tbody>$($sum.ToString())</tbody></table></section>
$($tabs.ToString())
<script>(function(){var secs=document.querySelectorAll('section'),nav=document.getElementById('nav');
function show(id){secs.forEach(function(s){s.classList.toggle('on',s.id==id)});nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-for')==id)})}
secs.forEach(function(s){var b=document.createElement('button');b.textContent=s.getAttribute('data-n');b.setAttribute('data-for',s.id);b.addEventListener('click',function(){show(s.id)});nav.appendChild(b)});
document.querySelectorAll('a[data-go]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();show(a.getAttribute('data-go'))})});
document.querySelectorAll('td.cp').forEach(function(td){var t=td.textContent,n=t.split('\n').length;td.textContent='';var d=document.createElement('div');d.className='cpt';d.textContent=t;td.appendChild(d);if(n>10){d.classList.add('fold');var b=document.createElement('button');b.className='more';b.textContent='顯示全部（'+n+' 行）';(td.nextElementSibling||td).appendChild(b);b.addEventListener('click',function(){var f=d.classList.toggle('fold');b.textContent=f?'顯示全部（'+n+' 行）':'收合'})}});
function cp(t){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(a);if(!ok)alert('複製失敗，請直接用滑鼠選取文字後按 Ctrl+C');return ok}
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t=b.closest('tr').querySelector('td.cp').textContent;if(t.indexOf('\n')>=0)t='"'+t.split('"').join('""')+'"';if(!cp(t))return;b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)})});
document.querySelectorAll('table.t th').forEach(function(th){th.addEventListener('click',function(){var tb=th.closest('table').tBodies[0],i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');var rows=Array.prototype.slice.call(tb.rows);
rows.sort(function(a,b){var x=a.cells[i],y=b.cells[i];if(!x||!y)return 0;var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var r=(p!==null&&q!==null)?parseFloat(p)-parseFloat(q):x.textContent.localeCompare(y.textContent,'zh-Hant',{numeric:true});return asc?r:-r});rows.forEach(function(r){tb.appendChild(r)})})});
show('s0');})();</script></body></html>
"@
  $p = Join-Path $od '總覽.html'
  [IO.File]::WriteAllText($p, $html, (New-Object Text.UTF8Encoding($true)))
  Write-Host ('總覽報告：' + $p)
  if (-not $NoOpen) { try { Start-Process $p } catch {} }
}

$pos = 0
while ($true) {
  $pos = Choose 'DailyCheck 每日檢查（唯讀，不改任何設定）' @($ITEMS | ForEach-Object { $_.Key + '. ' + $_.Text }) $pos
  $it = $ITEMS[$pos]
  if ($it.Key -eq 'Q') { Clear-Host; exit 0 }
  Clear-Host
  $res = @()
  if ($it.Key -eq '0') {
    # 這台電腦的設備清單裡沒有的類別就略過（例如 WhatsUp 只在能連到它的電腦上設定）
    foreach ($x in @($ITEMS | Where-Object { $_.Script })) {
      $n = 0; try { $dl = Read-DevList $here $x.Cat 6>$null; if ($null -ne $dl) { $n = $dl.Count } } catch {}
      if ($n -eq 0) { Line ("==== 略過：$($x.Key). $($x.Text)（這台的設備清單沒有設定）") 'DarkGray'; continue }
      $res += (RunOne $x '' $true)
    }
    try { Overview $res } catch { Write-Host ('總覽報告產生失敗：' + $_.Exception.Message) -ForegroundColor Red }
  } else {
    $only = ''
    if ($it.Pick) {
      $devs = Read-DevList $here $it.Cat   # 不要用 @()：PS5.1 對 List 會出錯
      if ($null -ne $devs -and $devs.Count -gt 1) {
        $opts = @("全部（$($devs.Count) 台）") + @($devs | ForEach-Object { ('{0}. {1}' -f $_.No, (Label $_ '')) + $(if ($_.Reject) { '（' + $_.Reject + '）' } else { '' }) }) + @('回上一層')
        $c = Choose "$($it.Key). $($it.Text)：選設備" $opts 0
        if ($c -eq $opts.Count - 1) { continue }
        if ($c -gt 0) { $only = [string]$devs[$c - 1].No }
        Clear-Host
      }
    }
    $res += (RunOne $it $only $false)
  }
  Write-Host ''
  foreach ($r in $res) { Write-Host ("$($r.Item.Key). $($r.Item.Text)：" + $CODE[$r.Code]) }
  Write-Host '按 Enter 回到選單…'
  do { $k = [Console]::ReadKey($true) } until ($k.Key -eq 'Enter')
}

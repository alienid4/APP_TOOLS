# -*- coding: utf-8 -*-
"""
FtpReport v0.6 -- 把 FtpCollect（PowerShell 版 v1.1.x）各主機的收集結果彙整成 AP 盤點清單。

用法：
    python ftp_report.py [收集結果資料夾] [--out 輸出上層資料夾]
    （不給參數會詢問；直接按 Enter＝目前資料夾）

輸入：資料夾底下的 run_local_* 結果資料夾（每台主機一個）。只讀，不修改任何輸入。
輸出：在輸出上層資料夾新建「盤點報表_<時間>」資料夾（只新建檔案）：
    盤點清單_SP_<時間>.xlsx、盤點清單_AP_<時間>.xlsx、總覽_<時間>.html
只用 Python 標準函式庫（3.8 以上）。
"""
import csv
import datetime as dt
import hashlib
import html
import json
import os
import re
import sys
import zipfile
from collections import Counter, OrderedDict, defaultdict

VERSION = '0.6'
AD_MIN_DAYS = 5        # 非本機（AD）帳號：傳檔天數 ≥ 這個數才看是否像排程
AD_HOUR_SHARE = 0.7    # 且 ≥ 這個比例的傳檔日落在同一個小時
REQUIRED_DAYS_DEFAULT = 90

# ============================================================ 檔案讀取（只讀）

def lp(path):
    """Windows 長路徑：加 \\\\?\\ 前綴（只用來開檔）"""
    p = os.path.abspath(path)
    if os.name == 'nt' and not p.startswith('\\\\?\\'):
        if p.startswith('\\\\'):
            return '\\\\?\\UNC\\' + p[2:]
        return '\\\\?\\' + p
    return p


def read_csv(path):
    if not os.path.exists(lp(path)):
        return []
    with open(lp(path), 'r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def read_kv_csv(path):
    out = OrderedDict()
    for r in read_csv(path):
        out[r.get('key', '')] = r.get('value', '')
    return out


def read_text(path):
    if not os.path.exists(lp(path)):
        return ''
    with open(lp(path), 'rb') as f:
        return f.read().decode('utf-8-sig', errors='replace')


# ============================================================ 主機資料

def parse_offset(s):
    """'08:00:00' / '-05:00:00' → timedelta"""
    m = re.match(r'^\s*(-)?(\d{1,2}):(\d{2})(?::(\d{2}))?', s or '')
    if not m:
        return None
    td = dt.timedelta(hours=int(m.group(2)), minutes=int(m.group(3)))
    return -td if m.group(1) else td


def load_host(run_dir):
    """讀一個 run_local_* 資料夾，回傳 host dict"""
    h = {'run_dir': run_dir, 'run_name': os.path.basename(run_dir), 'notes': []}
    run_csv = read_csv(os.path.join(run_dir, '_run.csv'))
    r0 = run_csv[0] if run_csv else {}
    h['ip'] = r0.get('IP', '')
    h['type'] = r0.get('Type', '')
    h['status'] = r0.get('狀態', '') or 'FAIL'
    h['reasons'] = r0.get('原因', '')
    h['hostname'] = r0.get('Note', '')
    info = read_text(os.path.join(run_dir, '_run_info.txt'))
    m = re.search(r'開始：(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})', info)
    h['start'] = dt.datetime.strptime(m.group(1), '%Y/%m/%d %H:%M:%S') if m else None
    m = re.search(r'收集工具：FtpCollect\.ps1 (\S+)', info)
    h['collector'] = m.group(1) if m else ''
    # 主機資料夾＝含 manifest.csv 的子資料夾
    hdir = ''
    for name in sorted(os.listdir(lp(run_dir))):
        if os.path.exists(lp(os.path.join(run_dir, name, 'manifest.csv'))):
            hdir = os.path.join(run_dir, name)
            break
    h['hdir'] = hdir
    if not h['ip'] and hdir:
        h['ip'] = os.path.basename(hdir)
    if not h['hostname']:
        m = re.match(r'run_local_[^_]+_(.+)_\d{8}_\d{6}', h['run_name'])
        h['hostname'] = m.group(1) if m else ''
    j = lambda n: os.path.join(hdir, n) if hdir else ''
    h['manifest'] = read_csv(j('manifest.csv')) if hdir else []
    h['accounts'] = read_csv(j('accounts.csv')) if hdir else []
    h['dirs'] = read_csv(j('dirs.csv')) if hdir else []
    h['dir_summary'] = read_csv(j('dir_summary.csv')) if hdir else []
    h['subdir_summary'] = read_csv(j('subdir_summary.csv')) if hdir else []   # v1.1.2 起才有
    h['eq'] = read_kv_csv(j('evidence_quality.csv')) if hdir else OrderedDict()
    h['host_info'] = read_csv(j('host_info.csv')) if hdir else []
    h['servu_users'] = read_csv(j('servu_users.csv')) if hdir else []   # v1.1.3 起才有（Serv-U 帳號檔累計統計）
    eq = h['eq']
    try:
        h['days_req'] = int(eq.get('days_requested') or REQUIRED_DAYS_DEFAULT)
    except ValueError:
        h['days_req'] = REQUIRED_DAYS_DEFAULT
    off = parse_offset(eq.get('host_utc_offset_now', ''))
    if off is None:
        for r in h['host_info']:
            if r.get('item') == 'timezone' and r.get('name') == 'current_utc_offset':
                off = parse_offset(r.get('value', ''))
    h['offset'] = off
    h['tz'] = eq.get('host_timezone', '')
    # 產品／版本（服務列：版本=...）
    vers = []
    for r in h['host_info']:
        if r.get('item') == 'service' and re.search(r'(?i)filezilla|serv-?u|rhinosoft', r.get('name', '') + r.get('value', '')):
            mv = re.search(r'版本=([^；]*)', r.get('value', ''))
            vers.append('%s %s' % (r.get('name', ''), mv.group(1) if mv else ''))
    h['versions'] = '；'.join(v.strip() for v in vers)
    h['is_servu'] = 'servu' in h['type'].lower()
    h['is_fz'] = 'filezilla' in h['type'].lower()
    return h


# ============================================================ 虛擬路徑

def vnorm(path, cwd='/'):
    path = (path or '').strip().strip('"')
    if not path:
        path = cwd
    if not path.startswith('/'):
        path = cwd.rstrip('/') + '/' + path
    parts = []
    for seg in path.split('/'):
        if seg in ('', '.'):
            continue
        if seg == '..':
            if parts:
                parts.pop()
            continue
        parts.append(seg)
    return '/' + '/'.join(parts)


def vparent(p):
    if p == '/':
        return '/'
    return p.rsplit('/', 1)[0] or '/'


def under(path, mount):
    if mount == '/':
        return True
    return path == mount or path.startswith(mount.rstrip('/') + '/')


# ============================================================ log 解析（FileZilla）

# FileZilla Server 1.x：2026-11-06T22:01:18.220Z >> [FTP Session 12 192.0.2.1 user] USER x
RX_FZ1 = re.compile(r'^(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?)(?P<z>Z)?\s+(?P<dir>\S{1,3})\s+\[(?P<br>[^\]]*)\]\s?(?P<msg>.*)$')
RX_BRACKET = re.compile(r'^(?P<mod>.*?Session)\s+(?P<sid>\d+)\s+(?P<ip>[0-9A-Fa-f:.]+)(?:\s+(?P<user>.+?))?\s*$')
# FileZilla Server 0.9.x：(000123)2026/11/6 22:01:18 - user (1.2.3.4)> STOR x
RX_FZ09 = re.compile(r'^\((?P<sid>\d+)\)\s*(?P<ts>\d{4}/\d{1,2}/\d{1,2} \d{1,2}:\d{2}:\d{2})\s*(?P<ampm>[AP]M)?\s*-\s*(?P<user>.*?)\s*\((?P<ip>[0-9A-Fa-f:.]+)\)>\s?(?P<msg>.*)$')
RX_CODE = re.compile(r'^(\d{3})(?:[ -]|$)')
UPLOAD = {'STOR', 'APPE', 'STOU'}
DOWNLOAD = {'RETR'}
OTHER = {'DELE', 'RNFR', 'RNTO', 'MKD', 'XMKD', 'RMD', 'XRMD', 'LIST', 'NLST', 'MLSD'}
OTHER_KIND = {'DELE': '刪', 'RNFR': '更名', 'RNTO': '更名', 'MKD': '建目錄', 'XMKD': '建目錄', 'RMD': '刪目錄', 'XRMD': '刪目錄',
              'LIST': '列目錄', 'NLST': '列目錄', 'MLSD': '列目錄'}
FILE_OPS = UPLOAD | DOWNLOAD | {'DELE', 'RNFR', 'RNTO'}
PARENT_OPS = {'MKD', 'XMKD', 'RMD', 'XRMD'}
LIST_OPS = {'LIST', 'NLST', 'MLSD'}
LOGIN_FAIL_TEXT = re.compile(r'(?i)login incorrect|authentication failed|invalid password|login failed')


class Session(object):
    __slots__ = ('ip', 'user', 'attempt', 'cwd', 'pending', 'logged')

    def __init__(self, ip):
        self.ip = ip
        self.user = ''
        self.attempt = ''
        self.cwd = '/'
        self.pending = None   # (verb, arg, ts)
        self.logged = False


def parse_ts(s, has_z, offset):
    s = s.replace(' ', 'T')
    t = dt.datetime.strptime(s[:19], '%Y-%m-%dT%H:%M:%S')
    if has_z and offset is not None:
        t = t + offset
    return t


def iter_log_files(h):
    """manifest 裡收到的 log（含 .partN 分段），依來源路徑排序"""
    rows = [r for r in h['manifest'] if r.get('kind') == 'log' and r.get('status') == 'collected' and r.get('out_path')]
    for r in sorted(rows, key=lambda x: (x.get('mtime', ''), x.get('source_path', ''))):   # 由舊到新（輪替檔接續同一個 session）
        first = os.path.join(h['run_dir'], r['out_path'])
        parts = [first]
        k = 2
        while os.path.exists(lp('%s.part%d' % (first, k))):
            parts.append('%s.part%d' % (first, k))
            k += 1
        yield r.get('source_path', ''), parts


def parse_logs(h):
    """回傳 events（每個成功／確認的動作）與統計"""
    off = h['offset']
    start = h['start'] or dt.datetime.now()
    win_start = start - dt.timedelta(days=h['days_req'])
    st = {'lines': 0, 'matched': 0, 'responses': 0, 'commands': 0, 'z': 0, 'formats': Counter()}
    events = []   # dict(kind, verb, user, ip, ts, vpath)
    raw_cmds = []  # 沒有回應紀錄時的備援

    def emit(kind, verb, user, ip, ts, vpath=''):
        if ts < win_start:
            return
        events.append({'kind': kind, 'verb': verb, 'user': user, 'ip': ip, 'ts': ts, 'vpath': vpath})

    sessions = {}
    for src, parts in iter_log_files(h):
        for part in parts:
            with open(lp(part), 'rb') as f:
                for bline in f:
                    st['lines'] += 1
                    line = bline.decode('utf-8', errors='replace').rstrip('\r\n')
                    m = RX_FZ1.match(line)
                    fmt = ''
                    if m:
                        bm = RX_BRACKET.match(m.group('br'))
                        if not bm:
                            continue
                        fmt = 'fz1'
                        sid, ip, buser = bm.group('sid'), bm.group('ip'), (bm.group('user') or '').strip()
                        try:
                            ts = parse_ts(m.group('ts'), bool(m.group('z')), off)
                        except ValueError:
                            continue
                        if m.group('z'):
                            st['z'] += 1
                        d = m.group('dir')
                        msg = m.group('msg')
                        is_cmd = d == '>>'
                        is_resp = d == '<<'
                        if msg.startswith('Command: '):
                            msg, is_cmd, is_resp = msg[9:], True, False
                        elif msg.startswith('Response: '):
                            msg, is_cmd, is_resp = msg[10:], False, True
                    else:
                        m = RX_FZ09.match(line)
                        if not m:
                            continue
                        fmt = 'fz09'
                        sid, ip = m.group('sid'), m.group('ip')
                        buser = m.group('user').strip()
                        if buser.lower() in ('(not logged in)', 'not logged in'):
                            buser = ''
                        try:
                            t = dt.datetime.strptime(m.group('ts'), '%Y/%m/%d %H:%M:%S')
                            if m.group('ampm') == 'PM' and t.hour < 12:
                                t += dt.timedelta(hours=12)
                            elif m.group('ampm') == 'AM' and t.hour == 12:
                                t -= dt.timedelta(hours=12)
                            ts = t
                        except ValueError:
                            continue
                        msg = m.group('msg')
                        is_resp = bool(RX_CODE.match(msg))
                        is_cmd = not is_resp
                    st['matched'] += 1
                    st['formats'][fmt] += 1
                    key = (sid, ip)
                    s = sessions.get(key)
                    if s is None:
                        s = sessions[key] = Session(ip)
                    if buser:
                        s.user = buser
                    if is_cmd:
                        st['commands'] += 1
                        tok = msg.strip().split(' ', 1)
                        verb = tok[0].upper()
                        arg = tok[1].strip() if len(tok) > 1 else ''
                        if verb == 'USER':
                            s.attempt = arg
                            s.user = buser or ''
                            s.logged = False
                            s.cwd = '/'
                        if verb in ('USER', 'PASS', 'CWD', 'XCWD', 'CDUP', 'XCUP') or verb in UPLOAD or verb in DOWNLOAD or verb in OTHER:
                            s.pending = (verb, arg, ts)
                            raw_cmds.append((verb, arg, s.user or s.attempt, ip, ts, s.cwd))
                        else:
                            s.pending = None
                    elif is_resp:
                        st['responses'] += 1
                        cm = RX_CODE.match(msg.strip())
                        if not cm or not s.pending:
                            if LOGIN_FAIL_TEXT.search(msg) and s.attempt:
                                emit('login_fail', 'PASS', s.attempt, ip, ts)
                            continue
                        code = int(cm.group(1))
                        verb, arg, cts = s.pending
                        if code < 200:
                            continue   # 1xx：等最後結果
                        s.pending = None
                        ok = 200 <= code < 400
                        user = s.user or s.attempt
                        if verb in ('USER', 'PASS'):
                            if code == 230:
                                s.logged = True
                                if not s.user:
                                    s.user = s.attempt
                                emit('login_ok', verb, s.user, ip, ts)
                            elif code >= 400:
                                emit('login_fail', verb, s.attempt or user, ip, ts)
                        elif verb in ('CWD', 'XCWD', 'CDUP', 'XCUP'):
                            if ok:
                                s.cwd = vparent(s.cwd) if verb in ('CDUP', 'XCUP') else vnorm(arg, s.cwd)
                        elif ok:
                            vp = vnorm(strip_opts(arg) if verb in LIST_OPS else arg, s.cwd)
                            kind = 'up' if verb in UPLOAD else ('down' if verb in DOWNLOAD else 'other')
                            emit(kind, verb, user, ip, ts, vp)
    st['events'] = len(events)
    # 若整份 log 都沒有回應紀錄（log 等級太低）：改用指令次數，標註
    st['no_responses'] = st['matched'] > 0 and st['responses'] == 0
    if st['no_responses']:
        cwd_by = {}
        for verb, arg, user, ip, ts, cwd in raw_cmds:
            if verb in UPLOAD or verb in DOWNLOAD or verb in OTHER:
                vp = vnorm(strip_opts(arg) if verb in LIST_OPS else arg, cwd)
                emit('up' if verb in UPLOAD else ('down' if verb in DOWNLOAD else 'other'), verb, user, ip, ts, vp)
    return events, st


# ============================================================ log 解析（Serv-U，zh-TW）
# [11] Tue 10Nov26 02:10:17 - (000528) 已成功收到檔案 "D:\FTP\u\x.csv" (… 位元組)
RX_SU = re.compile(r'^\[(?P<cat>\d+)\]\s+\S+\s+(?P<d>\d{1,2})(?P<mon>[A-Za-z]{3})(?P<y>\d{2})\s+(?P<t>\d{1,2}:\d{2}:\d{2})\s+-\s+\((?P<sid>\d+)\)\s?(?P<msg>.*)$')
SU_CONN = re.compile(r'^已連接到\s*(?P<ip>[0-9A-Fa-f:.]+)(?:.*?埠\s*(?P<port>\d+))?')
SU_LOGIN = re.compile(r'^使用者\s*"(?P<u>[^"]*)"\s*已登入')
SU_LOGOUT = re.compile(r'^使用者\s*"(?P<u>[^"]*)"\s*已登出')
SU_CLOSE = re.compile(r'^連線期間(?:已關閉|空閒逾時)')
SU_MSGS = [   # (regex, kind, verb)
    (re.compile(r'^已成功收到檔案\s*"(?P<p>[^"]*)"'), 'up', 'STOR'),
    (re.compile(r'^已成功發送檔案?\s*"(?P<p>[^"]*)"'), 'down', 'RETR'),
    (re.compile(r'^接收檔案\s*"(?P<p>[^"]*)"\s*時發生錯誤'), 'up_fail', 'STOR'),
    (re.compile(r'^發送檔案\s*"(?P<p>[^"]*)"\s*時發生錯誤'), 'down_fail', 'RETR'),
    (re.compile(r'^檔已移除\s*[:：]?\s*"(?P<p>[^"]*)"'), 'other', 'DELE'),
    (re.compile(r'^目錄已創建\s*[:：]?\s*"(?P<p>[^"]*)"'), 'other', 'MKD'),
]
SU_PROTO = {'21': 'FTP', '22': 'SFTP', '989': 'FTPS', '990': 'FTPS'}
AMBIG = object()   # 對到多個帳號（不猜）
MON = {m: i + 1 for i, m in enumerate(['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'])}


def parse_servu_logs(h):
    """Serv-U 檔案 log（UTF-8、繁中訊息）。回傳 (事件產生器, 統計)：邊讀邊交給 build_rows 彙總，不把整份 log 的事件存起來。
    連線編號 → 帳號：「使用者 "x" 已登入」設定（每次登入都重設身分）、「已登出」清掉、「連線期間已關閉／空閒逾時」整個連線丟掉；
    「已連接到」開新連線（來源 IP、埠→協定）。事件帶實體路徑 phys，帳號歸屬與虛擬路徑在 build_rows 決定。時間是主機當地時間。"""
    start = h['start'] or dt.datetime.now()
    win_start = start - dt.timedelta(days=h['days_req'])
    st = {'lines': 0, 'matched': 0, 'responses': 0, 'commands': 0, 'z': 0, 'formats': Counter(), 'no_responses': False, 'events': 0}

    def gen():
        sessions = {}
        for src, parts in iter_log_files(h):
            for part in parts:
                with open(lp(part), 'rb') as f:
                    for bline in f:
                        st['lines'] += 1
                        line = bline.decode('utf-8', errors='replace').lstrip('\ufeff').rstrip('\r\n')
                        m = RX_SU.match(line)
                        if not m or m.group('mon').lower() not in MON:
                            continue
                        try:
                            hh, mi, ss = (int(x) for x in m.group('t').split(':'))
                            ts = dt.datetime(2000 + int(m.group('y')), MON[m.group('mon').lower()], int(m.group('d')), hh, mi, ss)
                        except ValueError:
                            continue
                        st['matched'] += 1
                        st['formats']['servu'] += 1
                        sid, msg = m.group('sid'), m.group('msg').strip()
                        mc = SU_CONN.match(msg)
                        if mc:
                            port = mc.group('port') or ''
                            sessions[sid] = {'ip': mc.group('ip'), 'proto': SU_PROTO.get(port, ('port ' + port) if port else ''), 'user': ''}
                            continue
                        if SU_CLOSE.match(msg):
                            sessions.pop(sid, None)
                            continue
                        s = sessions.setdefault(sid, {'ip': '', 'proto': '', 'user': ''})
                        if SU_LOGOUT.match(msg):
                            s['user'] = ''
                            continue
                        ml = SU_LOGIN.match(msg)
                        if ml:
                            s['user'] = ml.group('u')
                            if ts >= win_start:
                                st['events'] += 1
                                yield {'kind': 'login_ok', 'verb': 'LOGIN', 'user': s['user'], 'ip': s['ip'], 'ts': ts, 'phys': '', 'proto': s['proto']}
                            continue
                        for rx, kind, verb in SU_MSGS:
                            mm = rx.match(msg)
                            if not mm:
                                continue
                            if ts >= win_start:
                                st['events'] += 1
                                yield {'kind': kind, 'verb': verb, 'user': s['user'], 'ip': s['ip'], 'ts': ts,
                                       'phys': mm.group('p').replace('/', '\\').rstrip('\\'), 'proto': s['proto']}
                            break
    return gen(), st


def strip_opts(arg):
    toks = [t for t in arg.split(' ') if t and not t.startswith('-')]
    return ' '.join(toks)


# ============================================================ 盤點列

FZ_ACCESS = {'0': '唯讀', '1': '讀寫', '2': '停用'}
FZ_RECURSIVE = {'0': '僅此層', '1': '含子目錄', '2': '含子目錄＋可改目錄結構'}


def perm_text(raw):
    m = dict(re.findall(r'(\w+)=([^;]*)', raw or ''))
    if 'access' in m:
        return '%s／%s（FileZilla 數值對照待確認）' % (FZ_ACCESS.get(m['access'], 'access=' + m['access']), FZ_RECURSIVE.get(m.get('recursive', ''), 'recursive=' + m.get('recursive', '')))
    return raw or ''


def short_id(*parts):
    hx = hashlib.sha1('|'.join(p or '' for p in parts).lower().encode('utf-8')).hexdigest()
    return 'R' + hx[:10].upper()


def top_counter(c, n=10):
    return '、'.join('%s(%d)' % (k, v) for k, v in c.most_common(n))


def hours_text(hc):
    tot = sum(hc.values())
    if not tot:
        return ''
    items = sorted(hc.items(), key=lambda kv: -kv[1])
    out = []
    for hr, n in items[:4]:
        out.append('%02d時 %d%%' % (hr, round(100.0 * n / tot)))
    return '、'.join(out)


def fmt_dt(t):
    return t.strftime('%Y-%m-%d %H:%M') if t else ''


def build_rows(h, events, st):
    """一台主機 → 主表列"""
    eq = h['eq']
    acc_by = OrderedDict()
    for a in h['accounts']:
        if a.get('kind') not in ('user', 'unknown'):
            continue
        name = a.get('name', '')
        if not name or name.startswith('<'):   # 內建 <system user> 等不是業務帳號
            continue
        acc_by[(a.get('product', ''), a.get('domain', ''), name)] = a
    names = defaultdict(list)   # 帳號名（小寫）→ [(product, domain, name)…]：不同 domain 同名不互相覆蓋
    for k in acc_by:
        names[k[2].lower()].append(k)
    homes = {}   # (product, domain, name) → 家目錄實體路徑
    for d in h['dirs']:
        k = (d.get('product', ''), d.get('domain', ''), d.get('owner', ''))
        if d.get('is_home') == 'yes' and d.get('physical_path') and k in acc_by:
            homes.setdefault(k, d['physical_path'].rstrip('\\'))

    def by_path(phys, cands):
        """實體路徑落在哪個帳號的家目錄底下（取最長的家目錄）；唯一→帳號，多個一樣長→AMBIG，都不是→None"""
        pl, best, blen = (phys or '').lower(), [], -1
        for k in cands:
            hl = (homes.get(k) or '').lower()
            if hl and (pl == hl or pl.startswith(hl + '\\')):
                if len(hl) > blen:
                    best, blen = [k], len(hl)
                elif len(hl) == blen:
                    best.append(k)
        return best[0] if len(best) == 1 else (AMBIG if best else None)
    # 每個帳號的掛載點
    mounts = defaultdict(OrderedDict)   # acckey -> vpath -> dict
    for d in h['dirs']:
        if d.get('owner_kind') not in ('user', 'user-via-group', 'unknown'):
            continue
        key = (d.get('product', ''), d.get('domain', ''), d.get('owner', ''))
        if key not in acc_by:
            continue
        v = d.get('virtual_path', '') or ''
        v = v.split(';')[0] if v else ''
        vkey = vnorm(v) if v.startswith('/') else (v or (d.get('physical_path') or d.get('physical_path_raw') or ''))
        src = 'user' if d.get('owner_kind') == 'user' else ('group:' + (re.search(r'via-group:([^;]+)', d.get('parse_method', '')) or [None, '?'])[1] if d.get('owner_kind') == 'user-via-group' else d.get('owner_kind', ''))
        e = mounts[key].get(vkey)
        if e is None and not v.startswith('/'):   # 例：Serv-U HomeDir 與 AccessN 指到同一個實體目錄 → 合併
            for m0 in mounts[key].values():
                if m0['phys'] and m0['phys'].lower() == (d.get('physical_path') or '').lower():
                    e = m0
                    break
        if e is None:
            mounts[key][vkey] = {'v': vkey, 'phys': d.get('physical_path', ''), 'raw': d.get('physical_path_raw', ''),
                                 'perm': [(src, d.get('perm_raw', ''))], 'config': d.get('config_file', ''), 'is_v': v.startswith('/')}
        else:
            e['perm'].append((src, d.get('perm_raw', '')))
            if not e['phys']:
                e['phys'] = d.get('physical_path', '')
    summ = {r.get('physical_path', '').lower(): r for r in h['dir_summary']}
    su_by = {((r.get('domain') or '').lower(), (r.get('name') or '').lower()): r for r in h.get('servu_users', [])}
    subsum = {(r.get('physical_path', '').lower(), r.get('subfolder', '').lower()): r for r in h.get('subdir_summary', [])}

    # 事件歸屬
    agg = defaultdict(lambda: {'up': 0, 'down': 0, 'other': 0, 'okind': Counter(), 'last_xfer': None, 'hours': Counter(), 'days': set()})
    acc_ev = defaultdict(lambda: {'ok': 0, 'fail': 0, 'last_ok': None, 'ok_ip': Counter(), 'fail_ip': Counter(), 'proto': Counter(), 'first': None})
    unknown = {'ok': 0, 'fail': 0, 'names': Counter(), 'ops': 0}
    nonlocal_ = defaultdict(lambda: {'up': 0, 'down': 0, 'days': defaultdict(set), 'ips': Counter()})   # Serv-U：不在帳號檔的登入（個人 AD）
    unattr = Counter()   # Serv-U：歸不到唯一本機帳號的事件（不猜）
    for e in events:
        cands = names.get((e['user'] or '').lower(), [])
        if 'phys' in e:   # Serv-U
            if e['user'] and not cands:   # 不在帳號檔＝非本機（個人 AD）登入：不轉置，只做提醒統計
                nl = nonlocal_[e['user']]
                nl['ips'][e['ip']] += 1
                if e['kind'] in ('up', 'down'):
                    nl[e['kind']] += 1
                    nl['days'][e['ts'].date()].add(e['ts'].hour)
                continue
            if e['user']:
                uk = cands[0] if len(cands) == 1 else by_path(e['phys'], cands)
                if uk is None or uk is AMBIG:
                    unattr['同名帳號（不同 domain）無法區分'] += 1
                    continue
            else:   # 這個連線沒看到登入行（期間前就連上、跨日、漏行）：用路徑對家目錄，唯一才算
                uk = by_path(e['phys'], list(acc_by))
                if uk is None or uk is AMBIG:
                    unattr['沒有登入行、路徑對不到唯一家目錄'] += 1
                    continue
            hm = homes.get(uk, '')
            pl = e['phys'].lower()
            e['vpath'] = None   # 不在家目錄底下 → 帳號級
            if hm and (pl == hm.lower() or pl.startswith(hm.lower() + '\\')):
                e['vpath'] = '/' + e['phys'][len(hm):].strip('\\').replace('\\', '/')
        else:
            uk = cands[0] if len(cands) == 1 else None
        if uk is not None:
            a0 = acc_ev[uk]
            if e.get('proto'):
                if e['kind'] == 'login_ok':
                    a0['proto'][e['proto']] += 1
            if not a0['first'] or e['ts'] < a0['first']:
                a0['first'] = e['ts']
        if e['kind'] in ('login_ok', 'login_fail'):
            if uk is None:
                unknown['fail' if e['kind'] == 'login_fail' else 'ok'] += 1
                unknown['names'][e['user'] or '(空白)'] += 1
                continue
            a = acc_ev[uk]
            if e['kind'] == 'login_ok':
                a['ok'] += 1
                a['ok_ip'][e['ip']] += 1
                if not a['last_ok'] or e['ts'] > a['last_ok']:
                    a['last_ok'] = e['ts']
            else:
                a['fail'] += 1
                a['fail_ip'][e['ip']] += 1
            continue
        if uk is None:
            unknown['ops'] += 1
            continue
        target = attribute(e, mounts.get(uk, {}))
        g = agg[(uk, target)]
        if e['kind'] in ('up_fail', 'down_fail'):   # 傳輸失敗：只記在其他明細，不算成功次數
            g['okind']['上傳失敗' if e['kind'] == 'up_fail' else '下載失敗'] += 1
            continue
        g[e['kind']] += 1
        if e['kind'] == 'other':
            g['okind'][OTHER_KIND.get(e['verb'], e['verb'])] += 1
        else:
            if not g['last_xfer'] or e['ts'] > g['last_xfer']:
                g['last_xfer'] = e['ts']
            g['hours'][e['ts'].hour] += 1
            g['days'].add(e['ts'].date())

    # 證據品質（主機級）
    try:
        covered = int(eq.get('days_with_entries') or 0)
    except ValueError:
        covered = 0
    complete = (eq.get('parse_complete', '') == 'yes') and h['status'] != 'FAIL'
    days_req = h['days_req']
    insufficient = covered < days_req or not complete
    b10 = '%s～%s，有 log %d 天（需 %d 天），缺 %s 天；收集 %s' % (
        eq.get('log_earliest_date', '') or '?', eq.get('log_latest_date', '') or '?', covered, days_req,
        eq.get('missing_days_count', '') or '?', h['status'])
    if not complete:
        b10 += '；證據不完整'
    if st.get('no_responses'):
        b10 += '；log 未記錄伺服器回應，次數以指令計'
    period = '%s～%s' % (eq.get('log_earliest_date', '') or '?', eq.get('log_latest_date', '') or '?')

    rows = []
    for uk, a in acc_by.items():
        product, domain, name = uk
        ms = mounts.get(uk, {})
        targets = OrderedDict()
        for mv, m in ms.items():
            if m['is_v'] and mv == '/':
                subs = sorted(t for (k2, t) in agg if k2 == uk and t[0] == mv and t[1] != '/')
                # 收集時看到、但 log 期間沒操作的第一層子目錄也要列（AP 才能逐一確認）
                seen = set(t[1].strip('/').lower() for t in subs)
                for (pp, sf) in sorted(subsum):
                    if m['phys'] and pp == m['phys'].lower() and sf not in ('(root)', '(其他)', '') and sf not in seen:
                        subs.append((mv, '/' + subsum[(pp, sf)].get('subfolder', sf)))
                        seen.add(sf)
                root_has = (uk, (mv, '/')) in agg or (bool(m['phys']) and (m['phys'].lower(), '(root)') in subsum)
                if root_has or not subs:
                    targets[(mv, '/')] = m
                for t in subs:
                    targets[t] = m
            else:
                targets[(mv, '')] = m
        if (uk, ('(帳號級)', '')) in agg or not targets:
            targets[('(帳號級)', '')] = None
        ae = acc_ev.get(uk, {'ok': 0, 'fail': 0, 'last_ok': None, 'ok_ip': Counter(), 'fail_ip': Counter(), 'proto': Counter(), 'first': None})
        su = su_by.get((domain.lower(), name.lower())) if product == 'ServU' else None
        for t, m in targets.items():
            mv, sub = t
            g = agg.get((uk, t), {'up': 0, 'down': 0, 'other': 0, 'okind': Counter(), 'last_xfer': None, 'hours': Counter(), 'days': set()})
            if m is None:
                vpath, phys, level = '（無法歸到目錄）' if ms else '（無掛載點）', '', '帳號級'
                perm_raw = perm_src = ''
            else:
                if sub and sub != '/':
                    vpath = sub
                    phys = (m['phys'].rstrip('\\') + '\\' + sub.strip('/').replace('/', '\\')) if m['phys'] else ''
                    level = '第一層子目錄'
                else:
                    vpath = mv
                    phys = m['phys'] or m['raw']
                    level = '掛載點'
                perm_raw = ' | '.join('%s:%s' % (s, p) for s, p in m['perm'])
                perm_src = '、'.join(s for s, _ in m['perm'])
            sm = summ.get((phys or '').lower()) if level == '掛載點' else None
            ss = subsum.get(((m['phys'] if m else '') .lower(), sub.strip('/').split('/')[0].lower())) if level == '第一層子目錄' else None
            if ss:
                b9 = {'files': num(ss.get('files_in_window')), 'mb': round(num(ss.get('bytes_in_window')) / 1048576.0, 1) if ss.get('bytes_in_window') else '',
                      'pat': ss.get('top_patterns_in_window', ''), 'newest': ss.get('newest_mtime_overall', ''), 'old': num(ss.get('files_older_than_window')),
                      'scan': ('截斷：' + ss.get('parent_truncated')) if ss.get('parent_truncated') else '第一層子目錄小計'}
            elif level == '第一層子目錄':
                b9 = {'files': '', 'mb': '', 'pat': '（收集程式 v1.1.2 前無子目錄小計，見該帳號 / 列）', 'newest': '', 'old': '', 'scan': ''}
            elif sm:
                b9 = {'files': num(sm.get('files_in_window')), 'mb': round(num(sm.get('bytes_in_window')) / 1048576.0, 1) if sm.get('bytes_in_window') else '',
                      'pat': sm.get('top_patterns_in_window', ''), 'newest': sm.get('newest_mtime_overall', ''), 'old': num(sm.get('files_older_than_window')),
                      'scan': ('不存在' if sm.get('exists') != 'yes' else sm.get('scan_time', '')) + (('；截斷：' + sm.get('truncated')) if sm.get('truncated') else '')}
            else:
                b9 = {'files': '', 'mb': '', 'pat': '', 'newest': '', 'old': '', 'scan': '無摘要' if level == '掛載點' else ''}
            stat_level = '帳號級' if level == '帳號級' else '目錄級'
            c1, c2 = decide_c1(g, ae, insufficient, covered, days_req, period, h, stat_level, product, su)
            okind = '、'.join('%s %d' % (k, v) for k, v in g['okind'].most_common())
            row = OrderedDict()
            row['A1 列ID'] = short_id(h['ip'], product, os.path.dirname(a.get('config_file', '')), domain, name, vpath)
            row['A2 主機IP'] = h['ip']
            row['A2 主機名'] = h['hostname']
            row['A2 機房'] = ''
            row['A2 環境'] = ''
            row['A3 產品／版本'] = (product + ' ' + h['versions']).strip()
            row['A3 服務實例（設定檔）'] = a.get('config_file', '')
            row['A3 Domain'] = domain
            row['A4 舊帳號'] = name
            row['A5 虛擬路徑'] = vpath
            row['A5 實體路徑'] = phys
            row['A5 目錄層級'] = level
            row['B1 設定狀態'] = enabled_text(a.get('enabled', ''))
            row['B2 權限（原始）'] = perm_raw
            row['B2 權限（解讀）'] = perm_text(m['perm'][0][1]) if m else ''
            row['B2 權限來源'] = perm_src
            row['B3 允許IP'] = a.get('allowed_ips', '')
            row['B3 拒絕IP'] = a.get('denied_ips', '')
            row['B4 最後成功登入'] = fmt_dt(ae['last_ok']) or ((su.get('last_login', '')[:16].replace('/', '-') + '（帳號檔）') if su and su.get('last_login') else '')
            row['B4 最後成功傳輸'] = fmt_dt(g['last_xfer'])
            row['B4 期間內首次活動'] = fmt_dt(ae['first'])
            row['B5 登入成功'] = ae['ok']
            row['B5 登入失敗'] = ae['fail']
            row['B6 成功來源IP'] = top_counter(ae['ok_ip'])
            row['B6 失敗來源IP'] = top_counter(ae['fail_ip'])
            row['B6 協定'] = top_counter(ae['proto'])
            row['B7 上傳'] = g['up']
            row['B7 下載'] = g['down']
            row['B7 其他操作'] = g['other']
            row['B7 其他明細'] = okind
            row['B7 統計層級'] = stat_level
            row['B8 傳輸時段'] = hours_text(g['hours'])
            row['B8 傳輸天數'] = len(g['days'])
            row['B9 期間內檔數'] = b9['files']
            row['B9 期間內大小MB'] = b9['mb']
            row['B9 檔名樣式'] = b9['pat']
            row['B9 最新修改'] = b9['newest']
            row['B9 期間外舊檔數'] = b9['old']
            row['B9 掃描'] = b9['scan']
            row['B10 證據品質'] = b10
            row['C1 觀察結果'] = c1
            row['C2 依據'] = c2
            rows.append(row)
    h['unknown'] = unknown
    h['unattr'] = unattr
    # 非本機（AD）帳號：不列入轉置；只提醒「疑似寫進排程」的（傳檔 ≥ AD_MIN_DAYS 天、且 ≥ AD_HOUR_SHARE 的天數在同一小時）
    flagged = []
    for nm, nl in sorted(nonlocal_.items(), key=lambda kv: kv[0].lower()):
        nd = len(nl['days'])
        if nd < AD_MIN_DAYS:
            continue
        hc = Counter(hr for hrs in nl['days'].values() for hr in hrs)
        hr, cnt = sorted(hc.items(), key=lambda kv: (-kv[1], kv[0]))[0]
        if cnt < AD_HOUR_SHARE * nd:
            continue
        flagged.append(OrderedDict([('主機IP', h['ip']), ('主機名', h['hostname']), ('帳號', nm), ('傳檔天數', nd),
                                    ('常見時段', '%02d時（%d／%d 天）' % (hr, cnt, nd)), ('上傳/下載次數', '上傳 %d／下載 %d' % (nl['up'], nl['down'])),
                                    ('來源 IP', top_counter(nl['ips'], 5)), ('說明', '疑似寫進排程，請通知本人申請系統帳號；不列入轉置')]))
    h['ad_flagged'] = flagged
    h['ad_total'] = len(nonlocal_)
    h['covered'] = covered
    h['insufficient'] = insufficient
    return rows


def num(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        try:
            return float(v)
        except (TypeError, ValueError):
            return 0


def enabled_text(v):
    v = (v or '').strip()
    if v.lower() in ('true', '1', 'enable=1', 'enabled=1'):
        return '啟用'
    if v.lower() in ('false', '0', 'enable=0', 'enabled=0', 'disable=1'):
        return '停用（設定）'
    return v or '未知'


def attribute(e, ms):
    """事件虛擬路徑 → (掛載點, 第一層子目錄) ；找不到回 ('(帳號級)','')"""
    if e['vpath'] is None:   # Serv-U：實體路徑不在帳號家目錄底下
        return ('(帳號級)', '')
    vp = e['vpath'] or '/'
    if e['verb'] in FILE_OPS or e['verb'] in PARENT_OPS:
        tdir = vparent(vp)
    else:
        tdir = vp
    best = None
    for mv, m in ms.items():
        if not m['is_v']:
            continue
        if under(tdir, mv) or (e['verb'] in PARENT_OPS and under(vp, mv)):
            if best is None or len(mv) > len(best):
                best = mv
    if best is None:
        return ('(帳號級)', '')
    if best == '/':
        segs = [s for s in tdir.split('/') if s]
        return ('/', '/' + segs[0] if segs else '/')
    return (best, '')


def decide_c1(g, ae, insufficient, covered, days_req, period, h, level, product, su=None):
    c1, c2 = decide_c1_log(g, ae, insufficient, covered, days_req, period, h, level)
    if product != 'ServU' or not su:
        return c1, c2
    # Serv-U 帳號檔的累計統計（開帳號以來）與最後登入：log 薄或沒有時當輔助證據
    last = su.get('last_login', '')
    extra = '帳號檔：累計上傳 %s／下載 %s 檔，最後登入 %s' % (su.get('files_uploaded', '') or '?', su.get('files_downloaded', '') or '?', last or '無紀錄')
    try:
        last_dt = dt.datetime.strptime(last, '%Y/%m/%d %H:%M:%S') if last else None
    except ValueError:
        last_dt = None
    win_start = (h['start'] or dt.datetime.now()) - dt.timedelta(days=h['days_req'])
    if c1 in ('證據不足', '期間內未觀察到活動') and last_dt and last_dt >= win_start:
        return '僅登入', '%s 的 log 沒看到活動，但帳號檔記錄最後登入 %s 在期間內；%s' % (period, last, extra)
    return c1, c2 + '；' + extra


def decide_c1_log(g, ae, insufficient, covered, days_req, period, h, level):
    xfer = g['up'] + g['down']
    obs = []
    if g['up']:
        obs.append('上傳 %d 次' % g['up'])
    if g['down']:
        obs.append('下載 %d 次' % g['down'])
    if g['other']:
        obs.append('其他操作 %d 次' % g['other'])
    if ae['ok']:
        obs.append('帳號登入成功 %d 次' % ae['ok'])
    lvl = '' if level == '目錄級' else '（帳號級）'
    # 有看到活動＝確定在用，不論涵蓋天數；只有「沒看到活動」且證據不夠時才是證據不足（2026-11-11 調整：有活動就是在用，不因天數短判證據不足）
    note = ''
    if insufficient:
        why = 'log 只涵蓋 %d 天（需 %d 天）' % (covered, days_req) if covered < days_req else '證據不完整（%s）' % h['status']
        if not (xfer or g['other'] or ae['ok']):
            return '證據不足', '%s；%s 未觀察到活動' % (why, period) + lvl
        note = '；注意：' + why
    if xfer:
        return '有傳輸', '%s %s' % (period, '、'.join(obs)) + lvl + note
    if g['other']:
        return '有其他操作', '%s %s' % (period, '、'.join(obs)) + lvl + note
    if ae['ok']:
        return '僅登入', '%s 帳號有登入 %d 次，此目錄未觀察到檔案操作' % (period, ae['ok']) + note
    return '期間內未觀察到活動', '%s 未觀察到登入或操作（請 AP 優先確認，不得作為停用依據）' % period


# ============================================================ 主機列

def fmt_off(off):
    if off is None:
        return '?'
    mins = int(off.total_seconds() // 60)
    return '%s%02d:%02d' % ('+' if mins >= 0 else '-', abs(mins) // 60, abs(mins) % 60)


def host_row(h, nrows):
    eq = h['eq']
    u = h.get('unknown') or {'ok': 0, 'fail': 0, 'names': Counter(), 'ops': 0}
    notes = list(h['notes'])
    if h['is_servu']:
        if h.get('ad_total'):
            notes.append('另有 %d 個非本機帳號登入（個人 AD，不在範圍、不轉置）%s' % (
                h['ad_total'], '；其中 %d 個疑似寫進排程，見「AD 帳號提醒（不轉置）」' % len(h['ad_flagged']) if h.get('ad_flagged') else ''))
        if h.get('unattr'):
            notes.append('未歸戶事件 %d 筆（%s）' % (sum(h['unattr'].values()), '、'.join('%s %d' % kv for kv in h['unattr'].most_common())))
        if not any(r.get('kind') == 'log' and r.get('status') == 'collected' for r in h['manifest']):
            notes.append('Serv-U 沒有收到 log（看收集原因：LogToFile、LogFilePath）')
    elif u['fail'] or u['ok']:
        notes.append('不存在帳號的登入嘗試：失敗 %d、成功 %d（%s）' % (u['fail'], u['ok'], top_counter(u['names'], 5)))
    if h.get('st', {}).get('no_responses'):
        notes.append('log 沒有伺服器回應紀錄，成功與否無法確認，以指令次數計')
    off = h['offset']
    r = OrderedDict()
    r['主機IP'] = h['ip']
    r['主機名'] = h['hostname']
    r['機房'] = h.get('site', '')
    r['環境'] = h.get('env', '')
    r['人工盤點'] = h.get('manual', '')
    r['合併到'] = h.get('merge_to', '')
    r['階段'] = h.get('stage', '')
    r['產品'] = h['type']
    r['版本'] = h['versions']
    r['收集狀態'] = h['status']
    r['狀態原因'] = h['reasons']
    r['盤點列數'] = nrows
    r['log 起'] = eq.get('log_earliest_date', '')
    r['log 訖'] = eq.get('log_latest_date', '')
    r['有 log 天數'] = num(eq.get('days_with_entries'))
    r['需要天數'] = h['days_req']
    r['缺日數'] = num(eq.get('missing_days_count'))
    r['缺哪幾天'] = eq.get('missing_days', '')
    r['log 等級設定'] = eq.get('logging_settings', '')
    r['時區'] = '%s（UTC%s）' % (h['tz'], fmt_off(off))
    r['收集工具版本'] = h['collector']
    r['收集時間'] = h['start'].strftime('%Y-%m-%d %H:%M') if h['start'] else ''
    r['備註'] = '；'.join(notes)
    return r


# ============================================================ xlsx（標準函式庫）

_BAD_XML = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]')


def xesc(s):
    return html.escape(_BAD_XML.sub('', s), quote=True)


def col_letter(i):
    s = ''
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def disp_len(s):
    return sum(2 if ord(ch) > 0x2e80 else 1 for ch in s)


def sheet_xml(header, rows, widths=None):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
           'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
           '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
           '<selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>'
           '<sheetFormatPr defaultRowHeight="15"/>']
    if widths is None:
        widths = []
        for ci, hname in enumerate(header):
            w = disp_len(hname)
            for r in rows[:500]:
                v = r[ci] if ci < len(r) else ''
                w = max(w, min(60, disp_len(str(v))))
            widths.append(max(8, min(60, w + 2)))
    out.append('<cols>')
    for ci, w in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (ci + 1, ci + 1, w))
    out.append('</cols><sheetData>')
    allrows = [header] + rows
    for ri, r in enumerate(allrows):
        out.append('<row r="%d">' % (ri + 1))
        for ci, v in enumerate(r):
            ref = '%s%d' % (col_letter(ci), ri + 1)
            st = ' s="1"' if ri == 0 else ''
            if isinstance(v, bool):
                v = str(v)
            if isinstance(v, (int, float)) and ri > 0:
                out.append('<c r="%s"%s><v>%s</v></c>' % (ref, st, v))
            else:
                s = '' if v is None else str(v)
                if s == '':
                    if ri == 0:
                        out.append('<c r="%s"%s/>' % (ref, st))
                    continue
                s = s[:32000]
                out.append('<c r="%s" t="inlineStr"%s><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, xesc(s)))
        out.append('</row>')
    out.append('</sheetData>')
    last = '%s%d' % (col_letter(max(len(header), 1) - 1), max(len(allrows), 1))
    out.append('<autoFilter ref="A1:%s"/>' % last)
    out.append('</worksheet>')
    return ''.join(out), 'A1:' + last


def write_xlsx(path, sheets):
    """sheets: list of (name, header, rows)"""
    ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    nr = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="%s" xmlns:r="%s"><bookViews><workbookView/></bookViews><sheets>' % (ns, nr)]
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    names = []
    parts = []
    for i, (name, header, rows) in enumerate(sheets):
        sname = re.sub(r'[\[\]:*?/\\]', '_', name)[:31]
        names.append(sname)
        xml, ref = sheet_xml(header, rows)
        parts.append(('xl/worksheets/sheet%d.xml' % (i + 1), xml, ref))
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (xesc(sname), i + 1, i + 1))
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1))
    wb.append('</sheets><definedNames>')
    for i, (p, x, ref) in enumerate(parts):
        a, b = ref.split(':')
        absref = '$%s$%s:$%s$%s' % (re.match(r'[A-Z]+', a).group(), re.search(r'\d+', a).group(), re.match(r'[A-Z]+', b).group(), re.search(r'\d+', b).group())
        wb.append('<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">\'%s\'!%s</definedName>' % (i, xesc(names[i].replace("'", "''")), absref))
    wb.append('</definedNames></workbook>')
    rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' % (len(sheets) + 1))
    rels.append('</Relationships>')
    ct.append('</Types>')
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="%s">'
              '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
              '<font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FFDDEBF7"/><bgColor indexed="64"/></patternFill></fill></fills>'
              '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
              '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
              '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>') % ns
    root_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    with open(lp(path), 'xb') as fh:   # 只新建，不覆蓋
        with zipfile.ZipFile(fh, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('[Content_Types].xml', ''.join(ct))
            z.writestr('_rels/.rels', root_rels)
            z.writestr('xl/workbook.xml', ''.join(wb))
            z.writestr('xl/_rels/workbook.xml.rels', ''.join(rels))
            z.writestr('xl/styles.xml', styles)
            for p, x, ref in parts:
                z.writestr(p, x)


# ============================================================ 欄位定義

D_COLS = ['D1 續用／停用／待確認', 'D2 APID（無→申請負責人／預計取得日）', 'D3 功能別（AP/DB/SY/EX/VD/TM）', 'D4 傳輸對象／是否對外／對端窗口',
          'D5 方向／頻率／最近一次實際執行日', 'D6 個資／敏感分級', 'D7 保管人／代理人／PAM', 'D8 jobname', 'D9 相依（列ID）', 'D10 是否寫死位址帳號路徑',
          'D11 對端能否同時段切換', 'D12 AP自估工時', 'D13 補列', 'E1 AP主管簽認']
AP_DROP = {'B6 失敗來源IP', 'A3 服務實例（設定檔）'}   # AP 版：不給失敗嘗試的來源 IP 與主機上的設定檔路徑
USAGE_COLS = ['列ID', '用途序', 'APID', 'jobname', '傳輸對象', '方向', '頻率／業務週期', '備註']
MAP_COLS = ['舊列ID', '新帳號', '新路徑', '權限', 'jobname', '保管人', '待拆註記', '備註']


def explain_rows(hosts, ts):
    return [
        ['產生時間', ts],
        ['來源', '各主機 FtpCollect v1.1.x 收集結果（run_local_*），共 %d 台' % len(hosts)],
        ['一列', '一個舊帳號＋一個目錄（掛載點；根目錄掛載「/」時以第一層子目錄為單位，另有根目錄本身一列）'],
        ['列ID', '由主機IP＋產品＋設定檔位置＋domain＋帳號＋目錄算出，重排、重跑都不變'],
        ['期間', '每台主機以收集當下往回 -Days（預設 90）天；log 實際起訖見「主機」頁'],
        ['時區', 'FileZilla 1.x log 時間是 UTC（Z），已依主機記錄的時差換成主機當地時間'],
        ['C1 觀察結果', '依序判定：有上傳／下載→有傳輸；'
                       '有刪除／更名／列目錄／建刪目錄→有其他操作；帳號有成功登入→僅登入；都沒有：log 涵蓋天數 < 需要天數或收集不完整→證據不足，否則→期間內未觀察到活動（有看到活動一律照活動判，涵蓋不足只在 C2 註記）'],
        ['注意', 'C1 只描述觀察到什麼，不是停用判定；「期間內未觀察到活動」只提示 AP 優先確認，不得作為停用依據。查無紀錄≠從未使用。'],
        ['B7 統計層級', '能從 log 路徑歸到目錄的記目錄級；歸不到的放在「（無法歸到目錄）」帳號級列'],
        ['B2 權限解讀', 'FileZilla 1.x access／recursive 數值的中文對照尚待以實機確認；以「權限（原始）」為準'],
        ['B9 目錄摘要', '只算期間內有修改的檔；第一層子目錄列用收集程式 v1.1.2 的子目錄小計（含 log 期間沒有操作、但目錄裡有檔的子目錄）'],
        ['不存在的帳號', 'log 裡用不存在的帳號（含 anonymous）嘗試登入，計在主機頁備註，不列為帳號'],
        ['Serv-U', 'log 依連線編號對應帳號（「使用者 "x" 已登入」，登出／連線關閉就清掉）；沒有登入行的傳輸用路徑對家目錄，對不到唯一帳號就記在主機頁「未歸戶」，不猜；埠 21＝FTP、22＝SFTP；傳輸失敗記在 B7 其他明細。'
                   'log 沒看到活動、但帳號檔最後登入在期間內→僅登入；C2 附帳號檔累計上下傳檔數'],
        ['AD 帳號', 'Serv-U 開了 LDAP 驗證，AD 帳號登入是個人行為，不列入主表、不轉置；傳檔 ≥ %d 天且 ≥ %d%% 的天數在同一小時者列在 SP 版「AD 帳號提醒（不轉置）」，'
                   '請通知本人申請系統帳號；其他 AD 登入只在主機頁備註計數' % (AD_MIN_DAYS, int(AD_HOUR_SHARE * 100))],
    ]


# ============================================================ HTML

HTML_TMPL = r'''<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FTP 盤點總覽</title>
<style>
:root{--bg:#fff;--fg:#1f2328;--mut:#656d76;--line:#d0d7de;--card:#f6f8fa;--acc:#0c6b37;--chip:#e6f2ea}
@media (prefers-color-scheme:dark){:root{--bg:#0d1117;--fg:#e6edf3;--mut:#8d96a0;--line:#30363d;--card:#161b22;--acc:#3fb96f;--chip:#1c3326}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.5 "Microsoft JhengHei",system-ui,sans-serif}
header{padding:12px 16px;border-bottom:1px solid var(--line)}h1{font-size:18px;margin:0}small{color:var(--mut)}
nav{display:flex;gap:4px;padding:8px 16px;border-bottom:1px solid var(--line);flex-wrap:wrap}
nav button{border:1px solid var(--line);background:var(--card);color:var(--fg);padding:6px 14px;border-radius:6px;cursor:pointer}
nav button.on{background:var(--acc);color:#fff;border-color:var(--acc)}
main{padding:12px 16px}.tab{display:none}.tab.on{display:block}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:10px;cursor:pointer}
.card:hover{border-color:var(--acc)}.card b{display:block;font-size:24px}.card span{color:var(--mut)}
.filter{margin:8px 0;display:none}.filter.on{display:block}
.chip{display:inline-block;background:var(--chip);border-radius:12px;padding:2px 10px;margin-right:6px}
.chip button{border:0;background:none;color:var(--fg);cursor:pointer}
.wrap{overflow:auto;max-height:70vh;border:1px solid var(--line);border-radius:6px}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{border-bottom:1px solid var(--line);padding:4px 8px;text-align:left;vertical-align:top;white-space:nowrap}
td.w{white-space:normal;min-width:240px;max-width:420px}
th{position:sticky;top:0;background:var(--card);cursor:pointer;user-select:none}th.asc:after{content:" ▲"}th.desc:after{content:" ▼"}
a.dd{color:var(--acc);cursor:pointer;text-decoration:underline}
.pager{margin:8px 0;display:flex;gap:8px;align-items:center}.pager button{padding:2px 10px}
input.q{padding:4px 8px;border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--fg);min-width:220px}
</style></head><body>
<header><h1>FTP 盤點總覽</h1><small>產生時間 __TS__ ｜ C1 只描述觀察結果，不是停用判定</small></header>
<nav id="nav"></nav><main id="main"></main>
<script>
const DATA=__DATA__;
const PAGE=50;
const tabs=[{id:'ov',name:'總覽'},{id:'hosts',name:'主機'},{id:'rows',name:'帳號目錄'},{id:'ad',name:'AD 帳號提醒（不轉置）'}];
const state={hosts:{sort:null,dir:1,filter:null,page:0,q:''},rows:{sort:null,dir:1,filter:null,page:0,q:''},ad:{sort:null,dir:1,filter:null,page:0,q:''}};
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function show(id){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.id===id));document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.id==='t_'+id));}
function drill(tab,label,fn){state[tab].filter={label:label,fn:fn};state[tab].page=0;render(tab);show(tab);}
function kpi(label,n,tab,fn){return {label,n,tab,fn};}
function build(){
  const nav=document.getElementById('nav'),main=document.getElementById('main');
  tabs.forEach(t=>{const b=document.createElement('button');b.textContent=t.name;b.dataset.id=t.id;b.onclick=()=>show(t.id);nav.appendChild(b);
    const d=document.createElement('section');d.className='tab';d.id='t_'+t.id;main.appendChild(d);});
  const H=DATA.hosts,R=DATA.rows,K=[];
  K.push(kpi('主機',H.length,'hosts',null));
  ['OK','PARTIAL','FAIL'].forEach(s=>K.push(kpi('收集 '+s,H.filter(h=>h['收集狀態']===s).length,'hosts',h=>h['收集狀態']===s)));
  K.push(kpi('盤點列',R.length,'rows',null));
  K.push(kpi('帳號',new Set(R.map(r=>r['A2 主機IP']+'|'+r['A4 舊帳號'])).size,'rows',null));
  DATA.c1.forEach(c=>K.push(kpi(c,R.filter(r=>r['C1 觀察結果']===c).length,'rows',r=>r['C1 觀察結果']===c)));
  K.push(kpi('帳號級（無法歸目錄）',R.filter(r=>r['A5 目錄層級']==='帳號級').length,'rows',r=>r['A5 目錄層級']==='帳號級'));
  K.push(kpi('設定停用的帳號列',R.filter(r=>String(r['B1 設定狀態']).indexOf('停用')>=0).length,'rows',r=>String(r['B1 設定狀態']).indexOf('停用')>=0));
  K.push(kpi('AD 疑似排程（不轉置）',DATA.ad.length,'ad',null));
  const ov=document.getElementById('t_ov');
  ov.innerHTML='<div class="cards">'+K.map((k,i)=>'<div class="card" data-k="'+i+'"><b>'+k.n+'</b><span>'+esc(k.label)+'</span></div>').join('')+'</div>'+
    '<p><small>點卡片看明細。log 涵蓋天數不足 '+DATA.days+' 天的主機：沒看到活動的帳號目錄列為「證據不足」；有看到活動的照活動列，並在依據註記天數不足。</small></p>';
  ov.querySelectorAll('.card').forEach(c=>c.onclick=()=>{const k=K[+c.dataset.k];if(k.fn)drill(k.tab,k.label,k.fn);else{state[k.tab].filter=null;state[k.tab].page=0;render(k.tab);show(k.tab);}});
  ['hosts','rows','ad'].forEach(t=>{const sec=document.getElementById('t_'+t);
    sec.innerHTML='<div class="pager"><input class="q" placeholder="搜尋（任何欄位）"><span class="info"></span><button class="pv">上一頁</button><button class="nx">下一頁</button></div>'+
      '<div class="filter"><span class="chip"><span class="fl"></span> <button title="清除篩選">✕</button></span></div><div class="wrap"><table><thead></thead><tbody></tbody></table></div>';
    sec.querySelector('.q').oninput=e=>{state[t].q=e.target.value.toLowerCase();state[t].page=0;render(t);};
    sec.querySelector('.pv').onclick=()=>{if(state[t].page>0){state[t].page--;render(t);}};
    sec.querySelector('.nx').onclick=()=>{state[t].page++;render(t);};
    sec.querySelector('.chip button').onclick=()=>{state[t].filter=null;state[t].page=0;render(t);};
    render(t);});
  show('ov');
}
function cols(t){return t==='hosts'?DATA.hostCols:(t==='ad'?DATA.adCols:DATA.rowCols);}
function data(t){return t==='hosts'?DATA.hosts:(t==='ad'?DATA.ad:DATA.rows);}
function render(t){
  const sec=document.getElementById('t_'+t),st=state[t],C=cols(t);let D=data(t).slice();
  if(st.filter)D=D.filter(st.filter.fn);
  if(st.q)D=D.filter(r=>C.some(c=>String(r[c]==null?'':r[c]).toLowerCase().indexOf(st.q)>=0));
  if(st.sort!==null){const c=st.sort,dir=st.dir;D.sort((a,b)=>{let x=a[c],y=b[c];const nx=typeof x==='number',ny=typeof y==='number';
    if(c==='項次'){x=+String(x).replace(/^\D+/,'');y=+String(y).replace(/^\D+/,'');}else if(!(nx&&ny)){x=String(x==null?'':x);y=String(y==null?'':y);return x.localeCompare(y,'zh-Hant')*dir;}
    return (x-y)*dir;});}
  const pages=Math.max(1,Math.ceil(D.length/PAGE));if(st.page>=pages)st.page=pages-1;
  const P=D.slice(st.page*PAGE,(st.page+1)*PAGE);
  sec.querySelector('.info').textContent='共 '+D.length+' 筆，第 '+(st.page+1)+'/'+pages+' 頁';
  const f=sec.querySelector('.filter');f.classList.toggle('on',!!st.filter);if(st.filter)f.querySelector('.fl').textContent='篩選：'+st.filter.label;
  sec.querySelector('thead').innerHTML='<tr>'+C.map(c=>'<th data-c="'+esc(c)+'" class="'+(st.sort===c?(st.dir>0?'asc':'desc'):'')+'">'+esc(c)+'</th>').join('')+'</tr>';
  sec.querySelectorAll('th').forEach(th=>th.onclick=()=>{const c=th.dataset.c;if(st.sort===c)st.dir=-st.dir;else{st.sort=c;st.dir=1;}render(t);});
  sec.querySelector('tbody').innerHTML=P.map(r=>'<tr>'+C.map(c=>cell(t,r,c)).join('')+'</tr>').join('');
  sec.querySelectorAll('a.dd').forEach(a=>a.onclick=()=>{const ip=a.dataset.ip,k=a.dataset.k;
    if(k==='rows')drill('rows','主機 '+ip,r=>r['A2 主機IP']===ip);
    else if(k)drill('rows','主機 '+ip+' '+k,r=>r['A2 主機IP']===ip&&r['C1 觀察結果']===k);});
}
function cell(t,r,c){const v=r[c];const w=(DATA.wide.indexOf(c)>=0)?' class="w"':'';
  if(t==='hosts'&&c==='盤點列數')return '<td><a class="dd" data-k="rows" data-ip="'+esc(r['主機IP'])+'">'+esc(v)+'</a></td>';
  if(t==='hosts'&&DATA.c1.indexOf(c)>=0&&v)return '<td><a class="dd" data-k="'+esc(c)+'" data-ip="'+esc(r['主機IP'])+'">'+esc(v)+'</a></td>';
  return '<td'+w+'>'+esc(v)+'</td>';}
build();
</script></body></html>
'''

C1_VALUES = ['有傳輸', '有其他操作', '僅登入', '期間內未觀察到活動', '證據不足']
HTML_ROW_COLS = ['項次', 'A1 列ID', 'A2 主機IP', 'A2 主機名', 'A4 舊帳號', 'A5 虛擬路徑', 'A5 目錄層級', 'B1 設定狀態', 'B4 最後成功登入', 'B4 最後成功傳輸',
                 'B5 登入成功', 'B5 登入失敗', 'B6 協定', 'B7 上傳', 'B7 下載', 'B7 其他操作', 'B7 其他明細', 'B8 傳輸天數', 'B9 期間內檔數', 'B9 最新修改', 'C1 觀察結果', 'C2 依據']


def write_html(path, hosts_rows, rows, ts, days, ad_rows=(), ad_cols=()):
    hcols = list(hosts_rows[0].keys()) if hosts_rows else ['項次']
    data = {'hosts': hosts_rows, 'rows': [OrderedDict((k, r.get(k, '')) for k in HTML_ROW_COLS) for r in rows],
            'ad': [OrderedDict((k, r.get(k, '')) for k in ad_cols) for r in ad_rows], 'adCols': list(ad_cols) or ['項次'],
            'hostCols': hcols, 'rowCols': HTML_ROW_COLS, 'c1': C1_VALUES, 'days': days, 'wide': ['C2 依據', '備註', '狀態原因', 'log 等級設定', '缺哪幾天']}
    js = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
    doc = HTML_TMPL.replace('__TS__', html.escape(ts)).replace('__DATA__', js)
    with open(lp(path), 'x', encoding='utf-8', newline='\n') as f:
        f.write(doc)


# ============================================================ 主程式

def find_runs(root):
    out = []
    for name in sorted(os.listdir(lp(root))):
        p = os.path.join(root, name)
        if name.startswith('run_local_') and os.path.isdir(lp(p)):
            out.append(p)
    return out


def norm_ip(ip):
    """192.0.2.099 與 192.0.2.99 視為同一台（人工表常補 0）"""
    ip = (ip or '').strip()
    if re.match(r'^\d+(\.\d+){3}$', ip):
        return '.'.join(str(int(x)) for x in ip.split('.'))
    return ip.lower()


def load_lookup(root):
    """選用：主機對照*.csv（欄位 ip,hostname,機房,環境,軟體,人工盤點），放在結果資料夾或本程式資料夾。用來填機房／環境、比對人工盤點。"""
    import glob
    for d in (root, os.path.dirname(os.path.abspath(__file__))):
        fs = sorted(glob.glob(os.path.join(d, '主機對照*.csv')))
        if fs:
            return {norm_ip(r.get('ip', '')): r for r in read_csv(fs[-1])}, fs[-1]
    return {}, ''


def main(argv):
    args = [a for a in argv if not a.startswith('--')]
    out_parent = None
    if '--out' in argv:
        i = argv.index('--out')
        out_parent = argv[i + 1]
        args = [a for a in args if a != out_parent]
    if args:
        root = args[0]
    else:
        try:
            ans = input('收集結果資料夾（直接按 Enter＝目前資料夾 %s）：' % os.getcwd()).strip().strip('"')
        except EOFError:
            ans = ''
        root = ans or os.getcwd()
    root = os.path.abspath(root)
    runs = find_runs(root)
    if not runs:
        print('找不到 run_local_* 資料夾：%s' % root)
        return 2
    print('FtpReport v%s：找到 %d 個主機結果資料夾' % (VERSION, len(runs)))
    ts = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    out_dir = os.path.join(os.path.abspath(out_parent) if out_parent else root, '盤點報表_' + ts)
    os.makedirs(lp(out_dir))   # 已存在就失敗，不覆蓋

    lookup, lkfile = load_lookup(root)
    print('主機對照表：%s' % (lkfile or '沒有（機房／環境留空）'))
    hosts, all_rows = [], []
    for rd in runs:
        try:
            h = load_host(rd)
        except Exception as e:   # 一台壞掉不影響其他台
            print('  [錯誤] 讀不到 %s：%s' % (os.path.basename(rd), e))
            continue
        events, st = ([], {'no_responses': False})
        if h['is_fz'] or h['is_servu']:
            try:
                events, st = parse_servu_logs(h) if h['is_servu'] else parse_logs(h)
            except Exception as e:
                h['notes'].append('log 解析失敗：%s' % e)
                h['status'] = h['status'] if h['status'] == 'FAIL' else 'PARTIAL'
        h['st'] = st
        try:
            rows = build_rows(h, events, st)   # Serv-U 的事件是邊讀邊彙總
        except Exception as e:
            h['notes'].append('log 解析失敗：%s' % e)
            h['status'] = h['status'] if h['status'] == 'FAIL' else 'PARTIAL'
            rows = build_rows(h, [], st)
        lk = lookup.get(norm_ip(h['ip']), {})
        h['site'], h['env'], h['manual'] = lk.get('機房', ''), lk.get('環境', ''), lk.get('人工盤點', '')
        h['merge_to'], h['stage'] = lk.get('合併到', ''), lk.get('階段', '')
        for r in rows:
            r['A2 機房'], r['A2 環境'] = h['site'], h['env']
        h['nrows'] = len(rows)
        hosts.append(h)
        all_rows.extend(rows)
        print('  %s %s：%s，%d 列，事件 %d' % (h['ip'], h['hostname'], h['status'], len(rows), st.get('events', 0)))

    all_rows.sort(key=lambda r: (r['A2 主機IP'], r['A4 舊帳號'].lower(), r['A5 目錄層級'] == '帳號級', r['A5 虛擬路徑']))
    for i, r in enumerate(all_rows):
        r['項次'] = 'R%d' % (i + 1)
    hrows = []
    for i, h in enumerate(hosts):
        hr = OrderedDict([('項次', 'H%d' % (i + 1))])
        hr.update(host_row(h, h['nrows']))
        for c in C1_VALUES:
            hr[c] = sum(1 for r in all_rows if r['A2 主機IP'] == h['ip'] and r['C1 觀察結果'] == c)
        used = hr['有傳輸'] + hr['有其他操作'] + hr['僅登入']
        if h.get('manual') == '無使用' and used:
            hr['人工盤點比對'] = '不符：人工寫無使用，實際有 %d 列有活動' % used
        elif h.get('manual') == '使用中' and not used and h['status'] != 'FAIL':
            hr['人工盤點比對'] = '待確認：人工寫使用中，期間內沒看到活動'
        elif h.get('manual'):
            hr['人工盤點比對'] = '相符'
        else:
            hr['人工盤點比對'] = '（無對照）'
        hrows.append(hr)

    main_cols = ['項次'] + [k for k in (all_rows[0].keys() if all_rows else []) if k != '項次']
    if not all_rows:
        main_cols = ['項次', 'A1 列ID']
    sp_header = main_cols + D_COLS
    sp_rows = [[r.get(c, '') for c in main_cols] + [''] * len(D_COLS) for r in all_rows]
    ap_cols = [c for c in main_cols if c not in AP_DROP]
    ap_rows = [[r.get(c, '') for c in ap_cols] + [''] * len(D_COLS) for r in all_rows]
    h_header = list(hrows[0].keys()) if hrows else ['項次']
    h_rows = [list(x.values()) for x in hrows]
    ap_hcols = ['項次', '主機IP', '主機名', '機房', '環境', '階段', '產品', '收集狀態', 'log 起', 'log 訖', '有 log 天數', '需要天數', '缺日數', '盤點列數']
    ap_hrows = [[x.get(c, '') for c in ap_hcols] for x in hrows]
    exp = explain_rows(hosts, ts)
    ad_rows = []
    for h in hosts:
        ad_rows.extend(h.get('ad_flagged', []))
    for i, r in enumerate(ad_rows):
        r['項次'] = 'AD%d' % (i + 1)
        r.move_to_end('項次', last=False)
    ad_cols = ['項次', '主機IP', '主機名', '帳號', '傳檔天數', '常見時段', '上傳/下載次數', '來源 IP', '說明']

    sp = os.path.join(out_dir, '盤點清單_SP_%s.xlsx' % ts)
    ap = os.path.join(out_dir, '盤點清單_AP_%s.xlsx' % ts)
    hp = os.path.join(out_dir, '總覽_%s.html' % ts)
    write_xlsx(sp, [('主表', sp_header, sp_rows), ('使用明細', USAGE_COLS, []), ('移轉對照表', MAP_COLS, []),
                    ('主機', h_header, h_rows), ('AD 帳號提醒（不轉置）', ad_cols, [[r.get(c, '') for c in ad_cols] for r in ad_rows]),
                    ('說明', ['項目', '說明'], exp)])
    write_xlsx(ap, [('主表', ap_cols + D_COLS, ap_rows), ('使用明細', USAGE_COLS, []), ('主機', ap_hcols, ap_hrows),
                    ('說明', ['項目', '說明'], exp)])
    days = max([h['days_req'] for h in hosts] or [REQUIRED_DAYS_DEFAULT])
    write_html(hp, hrows, all_rows, ts, days, ad_rows, ad_cols)
    print('完成：%s' % out_dir)
    print('  %s\n  %s\n  %s' % (os.path.basename(sp), os.path.basename(ap), os.path.basename(hp)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))

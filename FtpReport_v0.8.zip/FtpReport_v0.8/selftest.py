# -*- coding: utf-8 -*-
"""FtpReport 自我測試：產生假資料 → 跑報表兩次 → 檢查數字、AP 版遮蔽、xlsx 結構、HTML 不連外、輸入沒被改。
用法：python selftest.py [暫存資料夾]（預設在系統 TEMP 底下新建）"""
import hashlib
import inspect
import os
import re
import sys
import tempfile
import time
import zipfile
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_fixture  # noqa: E402
import ftp_report  # noqa: E402

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
FAILS = []


def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond:
        FAILS.append(msg)


def tree_hash(root):
    h = hashlib.sha256()
    for dp, dn, fn in sorted(os.walk(root)):
        dn.sort()
        if os.path.basename(dp).startswith('盤點報表_'):
            continue
        for f in sorted(fn):
            p = os.path.join(dp, f)
            if '盤點報表_' in p:
                continue
            st = os.stat(p)
            h.update(p.encode('utf-8'))
            h.update(str(st.st_mtime_ns).encode())
            with open(p, 'rb') as fh:
                h.update(fh.read())
    return h.hexdigest()


def read_sheets(path):
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in ('[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml'):
            ET.fromstring(z.read(n))   # 都要是合法 XML
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        names = [s.get('name') for s in wb.iter(NS + 'sheet')]
        for i, name in enumerate(names):
            root = ET.fromstring(z.read('xl/worksheets/sheet%d.xml' % (i + 1)))
            rows = []
            for r in root.iter(NS + 'row'):
                cells = {}
                for c in r.iter(NS + 'c'):
                    col = re.match(r'[A-Z]+', c.get('r')).group()
                    idx = 0
                    for ch in col:
                        idx = idx * 26 + (ord(ch) - 64)
                    t = c.find(NS + 'is')
                    v = ''.join(x.text or '' for x in t.iter(NS + 't')) if t is not None else (c.findtext(NS + 'v') or '')
                    cells[idx - 1] = v
                width = max(cells) + 1 if cells else 0
                rows.append([cells.get(k, '') for k in range(width)])
            hdr = rows[0] if rows else []
            out[name] = [dict(zip(hdr, r + [''] * (len(hdr) - len(r)))) for r in rows[1:]], hdr
    return out


def run_report(fx):
    rc = ftp_report.main([fx])
    outs = sorted(d for d in os.listdir(fx) if d.startswith('盤點報表_'))
    return rc, os.path.join(fx, outs[-1])


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix='ftpreport_selftest_')
    fx = os.path.join(base, 'fixture')
    make_fixture.make(fx)
    before = tree_hash(fx)
    print('== 第 1 次')
    rc, out1 = run_report(fx)
    check(rc == 0, '回傳 0')
    files = sorted(os.listdir(out1))
    check(len(files) == 3 and any(f.startswith('盤點清單_SP_') for f in files) and any(f.startswith('盤點清單_AP_') for f in files) and any(f.startswith('總覽_') for f in files), '產出 3 個檔：%s' % files)
    sp = read_sheets(os.path.join(out1, [f for f in files if f.startswith('盤點清單_SP_')][0]))
    ap = read_sheets(os.path.join(out1, [f for f in files if f.startswith('盤點清單_AP_')][0]))
    check(list(sp.keys()) == ['主表', '使用明細', '移轉對照表', '部門統計', '主機', 'AD 帳號提醒（不轉置）', '說明'], 'SP 工作表：%s' % list(sp.keys()))
    rows, hdr = sp['主表']
    check(all(c in hdr for c in ('A1 列ID', 'B10 證據品質', 'C1 觀察結果', 'D1 續用／停用／待確認', 'E1 AP主管簽認')), '主表欄位含 A1/B10/C1/D1/E1')
    dept_rows, _ = sp['部門統計']
    main_rows, _ = sp['主表']
    n_acct = len(set((x['A2 主機IP'], x['A4 舊帳號']) for x in main_rows))
    check(sum(int(x['帳號數']) for x in dept_rows) == n_acct and all(x['項次'].startswith('P') for x in dept_rows) and any(x['部門'] == ftp_report.NO_DEPT for x in dept_rows), '部門統計：各部門帳號數加總＝主表帳號數 %d，未記載部門另列' % n_acct)
    check(ftp_report.dept_summary([{'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP01', 'A4 部門': 'A部'}, {'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP01', 'A4 部門': 'A部'}, {'A2 主機IP': '192.0.2.2', 'A4 舊帳號': 'FTP15', 'A4 部門': 'A部'}])[0]['帳號數'] == 2, '同帳號多個目錄只算一次')
    dd = ftp_report.dept_summary([{'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP01', 'A4 部門': 'A部', 'A4 姓名': '李大', 'C1 觀察結果': '有傳輸'},
                                  {'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP15', 'A4 部門': 'A部', 'A4 姓名': '王二'},
                                  {'A2 主機IP': '192.0.2.2', 'A4 舊帳號': 'FTP22', 'A4 部門': 'A部', 'A4 姓名': ''}])[0]
    check(dd['部門'] == 'A部' and dd['帳號數'] == 3 and dd['有在用'] == 1 and dd['期間內沒用'] == 2 and dd['沒有姓名(NA)'] == 1 and dd['有在用帳號'] == '李大FTP01' and dd['沒在用帳號'] == '王二FTP15、FTP22(NA)', '部門統計：3 個帳號；在用 %s；沒用 %s' % (dd['有在用帳號'], dd['沒在用帳號']))

    def row(ip, acct, vpath):
        m = [r for r in rows if r['A2 主機IP'] == ip and r['A4 舊帳號'] == acct and r['A5 虛擬路徑'] == vpath]
        return m[0] if len(m) == 1 else None

    A = '192.0.2.10'
    accts = sorted(set(r['A4 舊帳號'] for r in rows if r['A2 主機IP'] == A))
    check('<system user>' not in accts and 'anonymous' not in accts, '內建 <system user> 與 anonymous 不列帳號：%s' % accts)
    r = row(A, 'ap_user1', '/in')
    check(r is not None and r['B7 上傳'] == '2' and r['B7 其他操作'] == '2' and r['A5 目錄層級'] == '第一層子目錄', 'ap_user1 /in：上傳 2（含輪替檔接續 CWD）、其他 2（LIST＋DELE），失敗的 STOR 不算')
    r = row(A, 'ap_user1', '/')
    check(r is not None and r['B7 上傳'] == '1' and r['B7 其他操作'] == '1' and r['B9 期間內檔數'] == '120', 'ap_user1 根目錄：上傳 1、建目錄 1、目錄摘要 120 檔')
    r = row(A, 'ap_user1', '/out')
    check(r is not None and r['B7 下載'] == '1', 'ap_user1 /out：下載 1')
    r = row(A, 'ap_user1', '/share')
    check(r is not None and 'group:grp1' in r['B2 權限來源'] and r['B7 上傳'] == '0', 'ap_user1 /share：群組來的掛載點，權限來源 group:grp1')
    r = row(A, 'ap_user1', '/in')
    check(r['B5 登入成功'] == '1' and r['B5 登入失敗'] == '1' and '198.51.100.5' in r['B6 成功來源IP'] and '203.0.113.9' in r['B6 失敗來源IP'], 'ap_user1 登入成功 1／失敗 1，來源 IP 分列')
    check(r['B4 最後成功登入'] == '2026-11-10 02:30' and '02時' in r['B8 傳輸時段'] and '06時' in r['B8 傳輸時段'], 'UTC→當地時間（+8）：最後登入 %s、時段 %s' % (r['B4 最後成功登入'], r['B8 傳輸時段']))
    check(r['C1 觀察結果'] == '有傳輸', 'ap_user1 /in C1＝有傳輸')
    r = row(A, 'ap_user2', '/')
    check(r is not None and r['B7 下載'] == '1' and '停用' in r['B1 設定狀態'] and '唯讀' in r['B2 權限（解讀）'], 'ap_user2：根目錄下載 1、設定停用、唯讀')
    r = row(A, 'idle_user', '/')
    check(r is not None and r['C1 觀察結果'] == '僅登入', 'idle_user C1＝僅登入')
    r = row(A, 'never_user', '/')
    check(r is not None and r['C1 觀察結果'] == '期間內未觀察到活動' and r['B9 期間外舊檔數'] == '40', 'never_user C1＝期間內未觀察到活動，期間外舊檔 40')
    r = row(A, 'grp_only', '/share')
    check(r is not None and r['B7 下載'] == '1', 'grp_only /share 下載 1')
    r = [x for x in rows if x['A2 主機IP'] == A and x['A4 舊帳號'] == 'grp_only' and x['A5 目錄層級'] == '帳號級']
    check(len(r) == 1 and r[0]['B7 下載'] == '1' and r[0]['B7 統計層級'] == '帳號級', 'grp_only 歸不到掛載點的下載 → 帳號級列')
    B = [x for x in rows if x['A2 主機IP'] == '192.0.2.11']
    check(len(B) == 1 and B[0]['A5 虛擬路徑'] == '/in' and B[0]['C1 觀察結果'] == '有傳輸' and '31 天' in B[0]['C2 依據'] and '上傳 1 次' in B[0]['C2 依據'],
          '31 天主機：有上傳仍判有傳輸，依據註記天數不足')
    C = [x for x in rows if x['A2 主機IP'] == '192.0.2.12']
    check(len(C) == 1 and C[0]['C1 觀察結果'] == '證據不足', 'Serv-U（舊 ini、沒有 log）：設定裡的帳號列出（HomeDir＋Access 同目錄合併成 1 列），C1 證據不足')
    # Serv-U 15：.Archive 帳號＋zh-TW log
    E = '192.0.2.14'
    Erows = [x for x in rows if x['A2 主機IP'] == E]
    check(sorted(set(x['A4 舊帳號'] for x in Erows)) == ['dup', 'su_a', 'su_b'], 'Serv-U 主表只有本機帳號（AD 帳號不列）：%s' % sorted(set(x['A4 舊帳號'] for x in Erows)))
    r = row(E, 'su_a', '/in')
    check(r is not None and r['B7 上傳'] == '3' and r['C1 觀察結果'] == '有傳輸' and r['B8 傳輸天數'] == '3',
          'su_a /in：上傳 3（含連線關閉後重用編號、沒有登入行、靠路徑歸戶的 1 筆）、傳輸 3 天：%s' % (r and r['B7 上傳']))
    r = row(E, 'su_a', '/out')
    check(r is not None and r['B7 下載'] == '1' and '下載失敗 1' in r['B7 其他明細'] and r['B7 其他操作'] == '0', 'su_a /out：下載 1，失敗記在其他明細、不算操作')
    check(r is not None and r['B5 登入成功'] == '2' and 'SFTP(1)' in r['B6 協定'] and 'FTP(1)' in r['B6 協定'] and '192.0.2.50' in r['B6 成功來源IP'], 'su_a 登入 2、協定 SFTP/FTP（埠 22/21）、來源 IP')
    check(r is not None and r['B4 期間內首次活動'] == '2026-11-08 04:10' and r['B4 最後成功登入'] == '2026-11-10 02:10' and '累計上傳 539' in r['C2 依據'], 'su_a 首次／最後活動（當地時間不換算）、C2 附帳號檔累計')
    check(r is not None and r.get('A4 主機記載使用者') == '測試甲' and r.get('A4 部門') == '', 'su_a A4 主機記載使用者＝帳號檔全名；非 員編-部門-姓名 格式不拆')
    check(ftp_report.split_fullname('E000000000001-測試部-王小明') == ('E000000000001', '測試部', '王小明') and ftp_report.split_fullname('1000000002-資訊部-陳一') == ('1000000002', '資訊部', '陳一'), '全名拆成 員編／部門／姓名')
    dup = {x['A3 Domain']: x for x in Erows if x['A4 舊帳號'] == 'dup' and x['A5 虛擬路徑'] in ('/', '/in')}
    check(set(dup) == {'DOM', 'DOM2'} and dup['DOM2']['A5 虛擬路徑'] == '/in' and dup['DOM2']['B7 上傳'] == '1' and dup['DOM']['B7 上傳'] == '0'
          and dup['DOM2']['B5 登入成功'] == '0', '同名帳號 dup：傳輸靠路徑歸 DOM2，登入分不出 → 不算給任何一個：%s' % {k: (v['A5 虛擬路徑'], v['B7 上傳'], v['B5 登入成功']) for k, v in dup.items()})
    check(not any(x['A4 舊帳號'] == 'ad.casual' for x in rows), '重用的連線編號、登出後的傳輸都沒有沿用舊帳號（ad.casual）')
    gen, _st = ftp_report.parse_servu_logs(ftp_report.load_host([os.path.join(fx, d) for d in os.listdir(fx) if d.startswith('run_local_192.0.2.14_')][0]))
    check(inspect.isgenerator(gen), 'Serv-U log 解析是邊讀邊交出（generator），不先存整份事件')
    r = [x for x in Erows if x['A4 舊帳號'] == 'su_a' and x['A5 目錄層級'] == '帳號級']
    check(len(r) == 1 and r[0]['B7 上傳'] == '1', 'su_a 家目錄外的上傳 → 帳號級列')
    r = row(E, 'su_b', '/')
    check(r is not None and r['C1 觀察結果'] == '僅登入' and '帳號檔' in r['C2 依據'] and '（帳號檔）' in r['B4 最後成功登入'], 'su_b：log 沒活動，但帳號檔最後登入在期間內 → 僅登入：%s' % (r and r['C2 依據']))
    adr, adh = sp['AD 帳號提醒（不轉置）']
    check(adh == ['項次', '主機IP', '主機名', '帳號', '傳檔天數', '常見時段', '上傳/下載次數', '來源 IP', '說明'], 'AD 提醒欄位：%s' % adh)
    check(len(adr) == 1 and adr[0]['帳號'] == 'ad.sched' and adr[0]['項次'] == 'AD1' and adr[0]['傳檔天數'] == '6' and adr[0]['常見時段'].startswith('03時')
          and '不列入轉置' in adr[0]['說明'] and '下載 6' in adr[0]['上傳/下載次數'], 'AD 提醒只列 ad.sched（6 天、03 時）；ad.irregular（時段不固定）、ad.casual（1 天）不列')
    hrows, hh = sp['主機']
    check(len(hrows) == 5 and [x['項次'] for x in hrows] == ['H1', 'H2', 'H3', 'H4', 'H5'], '主機頁 5 台、項次 H1..H5')
    ha = [x for x in hrows if x['主機IP'] == A][0]
    check('anonymous' in ha['備註'] and '失敗 1' in ha['備註'], '不存在帳號的嘗試記在主機備註：%s' % ha['備註'])
    he = [x for x in hrows if x['主機IP'] == E][0]
    check('另有 3 個非本機帳號登入' in he['備註'] and '其中 1 個疑似寫進排程' in he['備註'], 'Serv-U 主機備註：AD 登入只一行計數：%s' % he['備註'])
    check('未歸戶事件 2 筆' in he['備註'] and '同名帳號' in he['備註'] and '沒有登入行' in he['備註'], 'Serv-U 主機備註：未歸戶 2 筆（同名登入 1、登出後傳輸 1），不猜：%s' % he['備註'])
    check(any(x['收集狀態'] == 'FAIL' for x in hrows) and any('Serv-U 沒有收到 log' in x['備註'] for x in hrows), 'FAIL 主機與 Serv-U 沒有 log 的註記都在主機頁')
    check([x['項次'] for x in rows] == ['R%d' % (i + 1) for i in range(len(rows))], '主表項次 R1..R%d 連號' % len(rows))
    check(len(sp['使用明細'][0]) == 0 and len(sp['移轉對照表'][0]) == 0, '使用明細／移轉對照表是空白範本')
    # AP 版
    arows, ahdr = ap['主表']
    check('B6 失敗來源IP' not in ahdr and 'A3 服務實例（設定檔）' not in ahdr, 'AP 版沒有失敗來源 IP、設定檔路徑欄')
    with zipfile.ZipFile(os.path.join(out1, [f for f in files if f.startswith('盤點清單_AP_')][0])) as z:
        blob = b''.join(z.read(n) for n in z.namelist())
    check(b'203.0.113.9' not in blob, 'AP 版任何地方都沒有失敗嘗試 IP')
    check(b'ad.sched' not in blob and b'ad.casual' not in blob, 'AP 版沒有任何 AD 帳號')
    check([x['A1 列ID'] for x in arows] == [x['A1 列ID'] for x in rows], 'AP 與 SP 列 ID 相同、順序相同')
    # HTML
    hp = os.path.join(out1, [f for f in files if f.startswith('總覽_')][0])
    with open(hp, encoding='utf-8') as f:
        doc = f.read()
    check(not re.search(r'(?i)<(script|link|img)[^>]+(src|href)=|https?://', doc), 'HTML 不連任何外部資源')
    check('const DATA=' in doc and '"項次": "R1"' in doc and '"項次": "H1"' in doc and '"項次": "AD1"' in doc, 'HTML 內嵌資料含項次 R1、H1、AD1')
    time.sleep(1.1)
    print('== 第 2 次（ID 要一樣）')
    rc2, out2 = run_report(fx)
    sp2 = read_sheets(os.path.join(out2, [f for f in os.listdir(out2) if f.startswith('盤點清單_SP_')][0]))
    check(rc2 == 0 and out2 != out1 and [x['A1 列ID'] for x in sp2['主表'][0]] == [x['A1 列ID'] for x in rows], '重跑：新資料夾、列 ID 完全相同')
    check(len(set(x['A1 列ID'] for x in rows)) == len(rows), '列 ID 不重複')
    check(tree_hash(fx) == before, '輸入資料沒有被修改')
    print('結果：%s（%d 項失敗）' % ('PASS' if not FAILS else 'FAIL', len(FAILS)))
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())

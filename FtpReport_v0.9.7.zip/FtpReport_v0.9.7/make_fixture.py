# -*- coding: utf-8 -*-
"""產生假的 FtpCollect v1.1 收集結果（run_local_*），給 selftest 用。全部是虛構資料（IP 用 RFC 5737 文件用網段）。"""
import csv
import io
import os
import sys

START = '2026/11/11 02:00:00'


def w(path, text, bom=True):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8-sig' if bom else 'utf-8', newline='') as f:
        f.write(text)


def csvtext(header, rows):
    b = io.StringIO()
    cw = csv.writer(b, quoting=csv.QUOTE_ALL, lineterminator='\r\n')
    cw.writerow(header)
    for r in rows:
        cw.writerow(r)
    return b.getvalue()


def run_dir(root, ip, host):
    return os.path.join(root, 'run_local_%s_%s_20261111_020000' % (ip, host))


def common(rd, ip, host, typ, status, reasons, eq, accounts, dirs, summ, logs, version):
    w(os.path.join(rd, '_run.csv'), csvtext(
        ['#', 'IP', 'Type', '狀態', '原因', '主設定檔', '設定檔', '已遮密碼檔', '通用遮罩檔', 'log 檔', 'log 起', 'log 訖', '有資料天數', '缺日數', '有傳輸紀錄', '帳號群組數', '實體目錄數', '未收集', 'MB', 'Note'],
        [['1', ip, typ, status, reasons, '1', '1', '1', '0', str(len(logs)), eq.get('log_earliest_date', ''), eq.get('log_latest_date', ''), eq.get('days_with_entries', ''), eq.get('missing_days_count', ''), 'yes', str(len(accounts)), '1', '0', '0.1', host]]))
    w(os.path.join(rd, '_run_info.txt'), 'SOC 通知單號：TEST\r\n開始：%s\r\n收集工具：FtpCollect.ps1 1.1.1 (2026-11-11)\r\n' % START)
    hd = os.path.join(rd, ip)
    man = []
    for src, text, mtime in logs:
        rel = os.path.join(ip, src[0], src[3:])
        w(os.path.join(rd, rel), text, bom=False)
        man.append(['log', 'collected', src, str(len(text)), mtime, rel, str(len(text)), '0' * 64, 'LOG-REDACTED', ''])
    w(os.path.join(hd, 'manifest.csv'), csvtext(['kind', 'status', 'source_path', 'size', 'mtime', 'out_path', 'out_bytes', 'sha256', 'format', 'note'], man))
    w(os.path.join(hd, 'accounts.csv'), csvtext(['product', 'config_file', 'domain', 'name', 'kind', 'enabled', 'groups', 'allowed_ips', 'denied_ips', 'parse_method'], accounts))
    w(os.path.join(hd, 'dirs.csv'), csvtext(['product', 'config_file', 'domain', 'owner_kind', 'owner', 'virtual_path', 'physical_path_raw', 'physical_path', 'perm_raw', 'is_home', 'parse_method'], dirs))
    w(os.path.join(hd, 'dir_summary.csv'), csvtext(['physical_path', 'exists', 'window_days', 'files_in_window', 'bytes_in_window', 'top_patterns_in_window', 'newest_mtime_overall', 'files_older_than_window', 'dir_count', 'scan_seconds', 'truncated', 'enum_errors', 'links_skipped', 'scan_time'], summ))
    w(os.path.join(hd, 'evidence_quality.csv'), csvtext(['key', 'value'], [[k, v] for k, v in eq.items()]))
    w(os.path.join(hd, 'host_info.csv'), csvtext(['item', 'name', 'value'], [
        ['timezone', 'id', 'Taipei Standard Time'], ['timezone', 'current_utc_offset', '08:00:00'],
        ['service', 'filezilla-server' if 'FileZilla' in typ else 'Serv-U', '顯示名=x；狀態=Running；啟動=Auto；執行身分=LocalSystem；版本=%s；PID=1；C:\\x.exe' % version]]))


def eqd(days, first, last, missing=0):
    return {'days_requested': '90', 'window_start': '2026-08-13', 'log_earliest_date': first, 'log_latest_date': last,
            'days_with_entries': str(days), 'missing_days_count': str(missing), 'missing_days': '', 'parse_complete': 'yes',
            'logging_settings': 'level=3', 'host_timezone': 'Taipei Standard Time', 'host_utc_offset_now': '08:00:00'}


def fz_line(ts, d, sid, ip, user, msg):
    br = 'FTP Session %d %s%s' % (sid, ip, (' ' + user) if user else '')
    return '%sZ %s [%s] %s\n' % (ts, d, br, msg)


def make(root):
    cfg = 'C:\\ProgramData\\filezilla-server\\users.xml'
    gcfg = 'C:\\ProgramData\\filezilla-server\\groups.xml'
    # ---------------- 主機 A：FileZilla 1.x，涵蓋 92 天
    ip, host = '192.0.2.10', 'FZHOSTA'
    acc = [['FileZilla', cfg, '', '<system user>', 'user', 'false', '', '', '', 'fz1-xml'],
           ['FileZilla', cfg, '', 'ap_user1', 'user', 'true', 'grp1', '198.51.100.0/24', '', 'fz1-xml'],
           ['FileZilla', cfg, '', 'ap_user2', 'user', 'false', '', '', '', 'fz1-xml'],
           ['FileZilla', cfg, '', 'idle_user', 'user', 'true', '', '', '', 'fz1-xml'],
           ['FileZilla', cfg, '', 'never_user', 'user', 'true', '', '', '', 'fz1-xml'],
           ['FileZilla', cfg, '', 'grp_only', 'user', 'true', 'grp1', '', '', 'fz1-xml'],
           ['FileZilla', gcfg, '', 'grp1', 'group', '', '', '', '', 'fz1-xml']]
    perm = 'access=1;recursive=2;flags=0'
    dirs = [['FileZilla', cfg, '', 'user', 'ap_user1', '/', 'D:\\FTP\\ap_user1', 'D:\\FTP\\ap_user1', perm, 'yes', 'fz1-xml'],
            ['FileZilla', cfg, '', 'user', 'ap_user2', '/', 'D:\\FTP\\ap_user2', 'D:\\FTP\\ap_user2', 'access=0;recursive=2;flags=0', 'yes', 'fz1-xml'],
            ['FileZilla', cfg, '', 'user', 'idle_user', '/', 'D:\\FTP\\idle_user', 'D:\\FTP\\idle_user', perm, 'yes', 'fz1-xml'],
            ['FileZilla', cfg, '', 'user', 'never_user', '/', 'D:\\FTP\\never_user', 'D:\\FTP\\never_user', perm, 'yes', 'fz1-xml'],
            ['FileZilla', gcfg, '', 'group', 'grp1', '/share', 'D:\\FTP\\share', 'D:\\FTP\\share', perm, '', 'fz1-xml'],
            ['FileZilla', gcfg, '', 'user-via-group', 'ap_user1', '/share', 'D:\\FTP\\share', 'D:\\FTP\\share', perm, '', 'fz1-xml;via-group:grp1'],
            ['FileZilla', gcfg, '', 'user-via-group', 'grp_only', '/share', 'D:\\FTP\\share', 'D:\\FTP\\share', perm, '', 'fz1-xml;via-group:grp1']]
    summ = [['D:\\FTP\\ap_user1', 'yes', '90', '120', '5242880', 'RPT_########.csv×100 | rea*.txt×20', '2026/11/10 02:31:00', '7', '3', '0.2', '', '0', '0', '2026/11/11 02:05:00'],
            ['D:\\FTP\\never_user', 'yes', '90', '0', '0', '', '2025/01/02 10:00:00', '40', '0', '0.1', '', '0', '0', '2026/11/11 02:05:00'],
            ['D:\\FTP\\share', 'yes', '90', '3', '300', 'x.csv×3', '2026/11/09 10:00:00', '0', '0', '0.1', '', '0', '0', '2026/11/11 02:05:00']]
    s1 = ''
    s1 += fz_line('2026-11-09T18:30:00.000', '>>', 1, '198.51.100.5', '', 'USER ap_user1')
    s1 += fz_line('2026-11-09T18:30:00.010', '<<', 1, '198.51.100.5', '', '331 Please, specify the password.')
    s1 += fz_line('2026-11-09T18:30:00.020', '>>', 1, '198.51.100.5', '', 'PASS ****')
    s1 += fz_line('2026-11-09T18:30:00.030', '<<', 1, '198.51.100.5', 'ap_user1', '230 Login successful.')
    s1 += fz_line('2026-11-09T18:30:01.000', '>>', 1, '198.51.100.5', 'ap_user1', 'CWD /in')
    s1 += fz_line('2026-11-09T18:30:01.010', '<<', 1, '198.51.100.5', 'ap_user1', '250 CWD command successful')
    s1 += fz_line('2026-11-09T18:30:02.000', '>>', 1, '198.51.100.5', 'ap_user1', 'STOR a.csv')
    s1 += fz_line('2026-11-09T18:30:02.010', '<<', 1, '198.51.100.5', 'ap_user1', '150 Starting data transfer.')
    s1 += fz_line('2026-11-09T18:30:02.500', '<<', 1, '198.51.100.5', 'ap_user1', '226 Operation successful')
    s1 += fz_line('2026-11-09T18:30:03.000', '>>', 1, '198.51.100.5', 'ap_user1', 'LIST -al')
    s1 += fz_line('2026-11-09T18:30:03.100', '<<', 1, '198.51.100.5', 'ap_user1', '150 About to send')
    s1 += fz_line('2026-11-09T18:30:03.200', '<<', 1, '198.51.100.5', 'ap_user1', '226 Operation successful')
    s1 += fz_line('2026-11-09T18:30:04.000', '>>', 1, '198.51.100.5', 'ap_user1', 'DELE /in/old.csv')
    s1 += fz_line('2026-11-09T18:30:04.010', '<<', 1, '198.51.100.5', 'ap_user1', '250 File deleted successfully')
    s1 += fz_line('2026-11-09T18:30:05.000', '>>', 1, '198.51.100.5', 'ap_user1', 'STOR /in/fail.csv')
    s1 += fz_line('2026-11-09T18:30:05.010', '<<', 1, '198.51.100.5', 'ap_user1', '550 Permission denied')
    s1 += fz_line('2026-11-09T18:30:06.000', '>>', 1, '198.51.100.5', 'ap_user1', 'RETR /out/b.csv')
    s1 += fz_line('2026-11-09T18:30:06.010', '<<', 1, '198.51.100.5', 'ap_user1', '150 Starting data transfer.')
    s1 += fz_line('2026-11-09T18:30:06.200', '<<', 1, '198.51.100.5', 'ap_user1', '226 Operation successful')
    s1 += fz_line('2026-11-09T18:30:07.000', '>>', 1, '198.51.100.5', 'ap_user1', 'STOR /root.txt')
    s1 += fz_line('2026-11-09T18:30:07.100', '<<', 1, '198.51.100.5', 'ap_user1', '226 Operation successful')
    s1 += fz_line('2026-11-09T18:30:08.000', '>>', 1, '198.51.100.5', 'ap_user1', 'MKD /newdir')
    s1 += fz_line('2026-11-09T18:30:08.010', '<<', 1, '198.51.100.5', 'ap_user1', '257 "/newdir" created successfully')
    s1 += fz_line('2026-11-09T18:30:09.000', '>>', 1, '198.51.100.5', 'ap_user1', 'CWD /in')
    s1 += fz_line('2026-11-09T18:30:09.010', '<<', 1, '198.51.100.5', 'ap_user1', '250 CWD command successful')
    # 失敗登入、anonymous、其他帳號
    s1 += fz_line('2026-11-09T19:00:00.000', '>>', 2, '203.0.113.9', '', 'USER ap_user1')
    s1 += fz_line('2026-11-09T19:00:00.010', '<<', 2, '203.0.113.9', '', '331 Please, specify the password.')
    s1 += fz_line('2026-11-09T19:00:00.020', '>>', 2, '203.0.113.9', '', 'PASS ****')
    s1 += fz_line('2026-11-09T19:00:00.030', '<<', 2, '203.0.113.9', '', '530 Login incorrect.')
    s1 += fz_line('2026-11-09T19:01:00.000', '>>', 3, '203.0.113.7', '', 'USER anonymous')
    s1 += fz_line('2026-11-09T19:01:00.010', '<<', 3, '203.0.113.7', '', '331 Please, specify the password.')
    s1 += fz_line('2026-11-09T19:01:00.020', '>>', 3, '203.0.113.7', '', 'PASS ****')
    s1 += fz_line('2026-11-09T19:01:00.030', '<<', 3, '203.0.113.7', '', '530 Login incorrect.')
    s1 += '2026-11-09T19:02:00.000Z == [FTP Server] Listening on 0.0.0.0:21\n'
    # 第二個檔（輪替後）：session 1 接續，相對路徑
    s2 = ''
    s2 += fz_line('2026-11-09T22:10:00.000', '>>', 1, '198.51.100.5', 'ap_user1', 'STOR c.csv')
    s2 += fz_line('2026-11-09T22:10:00.500', '<<', 1, '198.51.100.5', 'ap_user1', '226 Operation successful')
    s2 += fz_line('2026-11-09T23:00:00.000', '>>', 4, '198.51.100.6', '', 'USER ap_user2')
    s2 += fz_line('2026-11-09T23:00:00.010', '>>', 4, '198.51.100.6', '', 'PASS ****')
    s2 += fz_line('2026-11-09T23:00:00.020', '<<', 4, '198.51.100.6', 'ap_user2', '230 Login successful.')
    s2 += fz_line('2026-11-09T23:00:01.000', '>>', 4, '198.51.100.6', 'ap_user2', 'RETR /x.csv')
    s2 += fz_line('2026-11-09T23:00:01.100', '<<', 4, '198.51.100.6', 'ap_user2', '226 Operation successful')
    s2 += fz_line('2026-11-10T01:00:00.000', '>>', 5, '198.51.100.7', '', 'USER idle_user')
    s2 += fz_line('2026-11-10T01:00:00.010', '>>', 5, '198.51.100.7', '', 'PASS ****')
    s2 += fz_line('2026-11-10T01:00:00.020', '<<', 5, '198.51.100.7', 'idle_user', '230 Login successful.')
    s2 += fz_line('2026-11-10T02:00:00.000', '>>', 6, '198.51.100.8', '', 'USER grp_only')
    s2 += fz_line('2026-11-10T02:00:00.010', '>>', 6, '198.51.100.8', '', 'PASS ****')
    s2 += fz_line('2026-11-10T02:00:00.020', '<<', 6, '198.51.100.8', 'grp_only', '230 Login successful.')
    s2 += fz_line('2026-11-10T02:00:01.000', '>>', 6, '198.51.100.8', 'grp_only', 'RETR /share/x.csv')
    s2 += fz_line('2026-11-10T02:00:01.100', '<<', 6, '198.51.100.8', 'grp_only', '226 Operation successful')
    s2 += fz_line('2026-11-10T02:00:02.000', '>>', 6, '198.51.100.8', 'grp_only', 'RETR /other/y.csv')
    s2 += fz_line('2026-11-10T02:00:02.100', '<<', 6, '198.51.100.8', 'grp_only', '226 Operation successful')
    logdir = 'C:\\Program Files\\FileZilla Server\\Logs\\'
    logs = [(logdir + 'filezilla-server.1.log', s1, '2026/11/10 05:59:59'), (logdir + 'filezilla-server.log', s2, '2026/11/11 01:00:00')]
    common(run_dir(root, ip, host), ip, host, 'FileZilla', 'OK', '', eqd(92, '2026-08-11', '2026-11-10'), acc, dirs, summ, logs, '1.8.1')

    # ---------------- 主機 B：FileZilla，只有 31 天 log
    ip, host = '192.0.2.11', 'FZHOSTB'
    acc = [['FileZilla', cfg, '', 'demo_user', 'user', 'true', '', '', '', 'fz1-xml']]
    dirs = [['FileZilla', cfg, '', 'user', 'demo_user', '/', 'D:\\FTP\\demo_user', 'D:\\FTP\\demo_user', perm, 'yes', 'fz1-xml']]
    s = fz_line('2026-11-06T22:01:18.220', '>>', 77, '198.51.100.20', '', 'USER demo_user')
    s += fz_line('2026-11-06T22:01:18.236', '>>', 77, '198.51.100.20', '', 'PASS ****')
    s += fz_line('2026-11-06T22:01:18.250', '<<', 77, '198.51.100.20', 'demo_user', '230 Login successful.')
    s += fz_line('2026-11-06T22:01:19.000', '>>', 77, '198.51.100.20', 'demo_user', 'STOR /in/d.csv')
    s += fz_line('2026-11-06T22:01:19.100', '<<', 77, '198.51.100.20', 'demo_user', '226 Operation successful')
    common(run_dir(root, ip, host), ip, host, 'FileZilla', 'OK', '', eqd(31, '2026-10-11', '2026-11-10'), acc, dirs, [],
           [('C:\\Program Files\\FileZilla Server\\Logs\\filezilla-server.log', s, '2026/11/11 01:00:00')], '1.8.1')

    # ---------------- 主機 C：Serv-U（只有設定）
    ip, host = '192.0.2.12', 'SUHOST'
    scfg = 'C:\\ProgramData\\RhinoSoft\\Serv-U\\ServUDaemon.ini'
    acc = [['ServU', scfg, '1', 'su_user', 'user', 'Enable=1', '', 'A|198.51.100.30', '', 'servu-ini']]
    dirs = [['ServU', scfg, '1', 'user', 'su_user', '/', 'E:\\SU\\su_user', 'E:\\SU\\su_user', '', 'yes', 'servu-ini'],
            ['ServU', scfg, '1', 'user', 'su_user', '', 'E:\\SU\\su_user', 'E:\\SU\\su_user', 'RWAMLCDP', '', 'servu-ini']]
    common(run_dir(root, ip, host), ip, host, 'ServU', 'PARTIAL', '1 個設定檔用通用遮罩，需人工抽看', eqd(0, '', ''), acc, dirs, [], [], '15.4')

    # ---------------- 主機 D：FAIL
    ip, host = '192.0.2.13', 'BADHOST'
    common(run_dir(root, ip, host), ip, host, 'auto', 'FAIL', '找不到 Serv-U／FileZilla 目錄', eqd(0, '', ''), [], [], [], [], '')

    # ---------------- 主機 E：Serv-U 15（.Archive 帳號檔＋zh-TW log，FtpCollect v1.1.3）
    ip, host = '192.0.2.14', 'SUHOST2'
    ucfg = 'C:\\ProgramData\\RhinoSoft\\Serv-U\\Users\\DOM\\%s.Archive'
    acc = [['ServU', ucfg % 'su_a', 'DOM', 'su_a', 'user', '', '', '', '', 'servu-archive'],
           ['ServU', ucfg % 'su_b', 'DOM', 'su_b', 'user', '', '', '', '', 'servu-archive']]
    dirs = [['ServU', ucfg % 'su_a', 'DOM', 'user', 'su_a', '/', 'D:\\SU\\su_a', 'D:\\SU\\su_a', '', 'yes', 'servu-archive'],
            ['ServU', ucfg % 'su_a', 'DOM', 'user', 'su_a', '', 'D:\\SU\\su_a', 'D:\\SU\\su_a', 'access=7967', '', 'servu-archive'],
            ['ServU', ucfg % 'su_b', 'DOM', 'user', 'su_b', '/', 'D:\\SU\\su_b', 'D:\\SU\\su_b', '', 'yes', 'servu-archive']]
    # 同名帳號在兩個 domain（dup）：登入行分不出是誰 → 未歸戶；傳輸可用路徑對家目錄分出來
    dcfg = 'C:\\ProgramData\\RhinoSoft\\Serv-U\\Users\\%s\\dup.Archive'
    acc += [['ServU', dcfg % 'DOM', 'DOM', 'dup', 'user', '', '', '', '', 'servu-archive'],
            ['ServU', dcfg % 'DOM2', 'DOM2', 'dup', 'user', '', '', '', '', 'servu-archive']]
    dirs += [['ServU', dcfg % 'DOM', 'DOM', 'user', 'dup', '/', 'D:\\SU\\dup', 'D:\\SU\\dup', '', 'yes', 'servu-archive'],
             ['ServU', dcfg % 'DOM2', 'DOM2', 'user', 'dup', '/', 'D:\\SU2\\dup', 'D:\\SU2\\dup', '', 'yes', 'servu-archive']]

    def su(day, t, sid, msg):   # day＝11 月幾號
        return '[02] Xxx %02dNov26 %s - (%06d) %s\n' % (day, t, sid, msg)
    lg = {}
    # su_a：9 號 SFTP 上傳＋下載＋下載失敗；10 號 FTP 上傳＋家目錄外的上傳（歸帳號級）
    lg[9] = (su(9, '02:10:00', 101, '已連接到 192.0.2.50 (本地位址 192.0.2.1，埠 22)') + su(9, '02:10:00', 101, 'IP-名稱： PC-0001.example.test (192.0.2.50)') + su(9, '02:10:01', 101, '使用者 "su_a" 已登入')
             + su(9, '02:10:05', 101, '已成功收到檔案 "D:\\SU\\su_a\\in\\f1.csv" (100.00 KB/秒 - 1,024 位元組)')
             + su(9, '02:10:06', 101, '已成功發送檔 "D:\\SU\\su_a\\out\\f2.csv" (10.00 KB/秒 - 512 位元組)')
             + su(9, '02:10:07', 101, '發送檔案 "D:\\SU\\su_a\\out\\f3.csv" 時發生錯誤，中斷作業')
             + su(9, '02:10:09', 101, '連線期間已關閉'))
    lg[10] = (su(10, '02:10:00', 102, '已連接到 192.0.2.51 (本地位址 192.0.2.1，埠 21)') + su(10, '02:10:00', 102, 'IP-名稱： PC-0002.example.test (192.0.2.51)') + su(10, '02:10:01', 102, '使用者 "su_a" 已登入')
              + su(10, '02:10:05', 102, '已成功收到檔案 "D:\\SU\\su_a\\in\\f4.csv" (1.00 KB/秒 - 100 位元組)')
              + su(10, '02:10:06', 102, '已成功收到檔案 "E:\\other\\x.csv" (1.00 KB/秒 - 100 位元組)')
              + su(10, '05:00:00', 103, '已連接到 192.0.2.70 (本地位址 192.0.2.1，埠 21)') + su(10, '05:00:01', 103, '使用者 "ad.casual" 已登入')
              + su(10, '05:00:02', 103, '已成功收到檔案 "D:\\FTP\\pub\\c.csv" (1.00 KB/秒 - 100 位元組)'))
    # AD 帳號：ad.sched 1～6 號每天 03 時下載（疑似排程）；ad.irregular 1～5 號每天不同時段
    for d in range(1, 7):
        lg.setdefault(d, '')
        lg[d] += (su(d, '03:0%d:00' % d, 200 + d, '已連接到 192.0.2.60 (本地位址 192.0.2.1，埠 21)') + su(d, '03:0%d:01' % d, 200 + d, '使用者 "ad.sched" 已登入')
                  + su(d, '03:0%d:02' % d, 200 + d, '已成功發送檔 "D:\\FTP\\pub\\r.csv" (1.00 KB/秒 - 100 位元組)'))
        if d <= 5:
            hh = '%02d:30:00' % (8 + d * 2)
            lg[d] += (su(d, hh, 300 + d, '已連接到 192.0.2.61 (本地位址 192.0.2.1，埠 21)') + su(d, hh, 300 + d, '使用者 "ad.irregular" 已登入')
                      + su(d, hh, 300 + d, '已成功收到檔案 "D:\\FTP\\pub\\i.csv" (1.00 KB/秒 - 100 位元組)'))
    # 8 號：連線關閉後同一個編號重用、沒有登入行 → 不能沿用舊的 ad.casual，改用路徑對到 su_a；
    #       登出後的傳輸（路徑不在任何家目錄）→ 未歸戶；dup 同名：登入未歸戶、傳輸靠路徑歸到 DOM2
    lg[8] = (su(8, '04:00:00', 700, '已連接到 192.0.2.80 (本地位址 192.0.2.1，埠 21)') + su(8, '04:00:01', 700, '使用者 "ad.casual" 已登入')
             + su(8, '04:00:02', 700, '連線期間已關閉')
             + su(8, '04:10:00', 700, '已成功收到檔案 "D:\\SU\\su_a\\in\\g.csv" (1.00 KB/秒 - 100 位元組)')
             + su(8, '04:20:00', 701, '已連接到 192.0.2.81 (本地位址 192.0.2.1，埠 21)') + su(8, '04:20:01', 701, '使用者 "ad.casual" 已登入')
             + su(8, '04:20:02', 701, '使用者 "ad.casual" 已登出')
             + su(8, '04:20:03', 701, '已成功收到檔案 "E:\\nowhere\\z.csv" (1.00 KB/秒 - 100 位元組)')
             + su(8, '04:30:00', 702, '已連接到 192.0.2.82 (本地位址 192.0.2.1，埠 22)') + su(8, '04:30:01', 702, '使用者 "dup" 已登入')
             + su(8, '04:30:02', 702, '已成功收到檔案 "D:\\SU2\\dup\\in\\d.csv" (1.00 KB/秒 - 100 位元組)')
             + su(8, '04:30:03', 702, '連線期間空閒逾時'))
    logs = [('D:\\FTP\\LOG\\2026-11-%02d.txt' % d, lg[d], '2026/11/%02d 23:59:00' % d) for d in sorted(lg)]
    rd = run_dir(root, ip, host)
    common(rd, ip, host, 'ServU', 'OK', '', eqd(92, '2026-08-11', '2026-11-10'), acc, dirs, [], logs, '15.4')
    w(os.path.join(rd, ip, 'servu_users.csv'), csvtext(
        ['domain', 'name', 'kind', 'full_name', 'home_dir', 'files_uploaded', 'files_downloaded', 'bytes_uploaded', 'bytes_downloaded', 'statistics_start', 'last_login', 'last_logout', 'config_file'],
        [['DOM', 'su_a', 'user', '測試甲', 'D:\\SU\\su_a', '539', '399', '1000', '2000', '2024/11/14 00:00:00', '2026/11/10 02:10:01', '', ucfg % 'su_a'],
         ['DOM', 'su_b', 'user', '測試乙', 'D:\\SU\\su_b', '10', '0', '100', '0', '2024/11/14 00:00:00', '2026/11/05 08:00:00', '', ucfg % 'su_b']]))


def make_acct_lookup(root):
    w(os.path.join(root, '帳號對照_test.csv'), csvtext(['ip', '帳號', '部門', '保管人'],
      [['192.0.2.010', 'AP_USER1', 'B部', '測試丙'], ['192.0.2.10', 'never_user', '待追查', '待追查']]))


if __name__ == '__main__':
    make(sys.argv[1])
    make_acct_lookup(sys.argv[1])
    print('fixture ok:', sys.argv[1])

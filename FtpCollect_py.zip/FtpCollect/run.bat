@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 ftp_collect_gui.py
) else (
  python ftp_collect_gui.py
)
if errorlevel 1 (
  echo.
  echo Could not start. Make sure Python 3.10+ is installed and on PATH.
  pause
)

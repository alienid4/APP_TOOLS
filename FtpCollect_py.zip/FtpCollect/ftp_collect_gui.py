# -*- coding: utf-8 -*-
"""ftp_collect 的視窗版：主機清單、目的目錄、帳號、密碼、天數都在畫面上設定。

雙擊執行（或 python ftp_collect_gui.py）。設定（不含密碼）存在同資料夾 ftp_collect_gui.json，下次自動帶入。
"""
import json
import os
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import ftp_collect as fc

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, 'ftp_collect_gui.json')


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('FTP 主機資料收集（唯讀）')
        self.geometry('760x560')
        self.minsize(640, 460)
        self.q, self.worker, self.stop_flag, self.run_dir = queue.Queue(), None, threading.Event(), None
        cfg = self.load_cfg()

        self.v_hosts = tk.StringVar(value=cfg.get('hosts', os.path.join(HERE, 'hosts.csv')))
        self.v_dest = tk.StringVar(value=cfg.get('dest', r'D:\collect'))
        self.v_user = tk.StringVar(value=cfg.get('user', ''))
        self.v_pwd = tk.StringVar()
        self.v_local = tk.BooleanVar(value=False)
        self.v_soc = tk.StringVar()
        self.v_maxmb = tk.StringVar(value=str(cfg.get('max_mb', 500)))
        self.v_days = tk.StringVar(value=str(cfg.get('days', 60)))

        f = ttk.Frame(self, padding=10)
        f.pack(fill='both', expand=True)
        f.columnconfigure(1, weight=1)

        r = 0
        ttk.Label(f, text='1. 主機清單').grid(row=r, column=0, sticky='w')
        ttk.Entry(f, textvariable=self.v_hosts).grid(row=r, column=1, sticky='ew', padx=4)
        b = ttk.Frame(f); b.grid(row=r, column=2, sticky='e')
        ttk.Button(b, text='選檔', command=self.pick_hosts).pack(side='left')
        ttk.Button(b, text='編輯', command=self.edit_hosts).pack(side='left')
        ttk.Button(b, text='預覽台數', command=self.preview).pack(side='left')
        r += 1
        ttk.Label(f, text='2. 存放目錄').grid(row=r, column=0, sticky='w', pady=4)
        ttk.Entry(f, textvariable=self.v_dest).grid(row=r, column=1, sticky='ew', padx=4)
        ttk.Button(f, text='選目錄', command=self.pick_dest).grid(row=r, column=2, sticky='e')
        r += 1
        ttk.Label(f, text='3. 帳號').grid(row=r, column=0, sticky='w')
        self.e_user = ttk.Entry(f, textvariable=self.v_user)
        self.e_user.grid(row=r, column=1, sticky='ew', padx=4)
        ttk.Label(f, text='例 DOMAIN\\admin', foreground='#6E6E73').grid(row=r, column=2, sticky='w')
        r += 1
        ttk.Label(f, text='4. 密碼').grid(row=r, column=0, sticky='w', pady=4)
        self.e_pwd = ttk.Entry(f, textvariable=self.v_pwd, show='*')
        self.e_pwd.grid(row=r, column=1, sticky='ew', padx=4)
        ttk.Label(f, text='不存檔', foreground='#6E6E73').grid(row=r, column=2, sticky='w')
        r += 1
        ttk.Label(f, text='5. log 收近幾天').grid(row=r, column=0, sticky='w')
        sp = ttk.Frame(f); sp.grid(row=r, column=1, sticky='w', padx=4)
        ttk.Spinbox(sp, from_=1, to=400, textvariable=self.v_days, width=6).pack(side='left')
        ttk.Label(sp, text='   單一 log 上限 MB').pack(side='left')
        ttk.Spinbox(sp, from_=10, to=20000, increment=100, textvariable=self.v_maxmb, width=7).pack(side='left')
        r += 1
        ttk.Checkbutton(f, text='6. 本機模式（把程式拷到連不到的那台主機上跑，不用帳密；清單只能 1 台）',
                        variable=self.v_local, command=self.toggle_local).grid(row=r, column=0, columnspan=3, sticky='w', pady=2)
        r += 1
        ttk.Label(f, text='7. SOC 通知單號').grid(row=r, column=0, sticky='w')
        ttk.Entry(f, textvariable=self.v_soc).grid(row=r, column=1, sticky='ew', padx=4)
        ttk.Label(f, text='先知會資安／SOC 再填', foreground='#6E6E73').grid(row=r, column=2, sticky='w')
        r += 1
        bar = ttk.Frame(f); bar.grid(row=r, column=0, columnspan=3, sticky='ew', pady=8)
        self.b_start = ttk.Button(bar, text='開始收集', command=self.start)
        self.b_start.pack(side='left')
        self.b_stop = ttk.Button(bar, text='停止', command=self.stop_flag.set, state='disabled')
        self.b_stop.pack(side='left', padx=4)
        self.b_open = ttk.Button(bar, text='開啟結果資料夾', command=self.open_result, state='disabled')
        self.b_open.pack(side='left')
        self.pb = ttk.Progressbar(bar, mode='determinate')
        self.pb.pack(side='left', fill='x', expand=True, padx=8)
        r += 1
        f.rowconfigure(r, weight=1)
        self.txt = tk.Text(f, height=12, wrap='none', font=('Consolas', 10))
        self.txt.grid(row=r, column=0, columnspan=3, sticky='nsew')
        sb = ttk.Scrollbar(f, command=self.txt.yview); sb.grid(row=r, column=3, sticky='ns')
        self.txt['yscrollcommand'] = sb.set
        self.protocol('WM_DELETE_WINDOW', self.on_close)
        self.closing = False
        self.after(200, self.poll)

    # ---- 設定檔 ----
    def load_cfg(self):
        try:
            with open(CFG, encoding='utf-8') as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def save_cfg(self):
        try:
            with open(CFG, 'w', encoding='utf-8') as f:
                json.dump(dict(hosts=self.v_hosts.get(), dest=self.v_dest.get(), user=self.v_user.get(),
                               days=self.v_days.get(), max_mb=self.v_maxmb.get()), f, ensure_ascii=False, indent=1)
        except OSError:
            pass

    # ---- 按鈕 ----
    def pick_hosts(self):
        p = filedialog.askopenfilename(filetypes=[('CSV', '*.csv')], initialdir=HERE)
        if p:
            self.v_hosts.set(p)

    def edit_hosts(self):
        p = self.v_hosts.get()
        if not os.path.exists(p):
            if not messagebox.askyesno('主機清單', f'{p} 不存在，要用範例建一份嗎？'):
                return
            with open(os.path.join(HERE, 'hosts.sample.csv'), encoding='utf-8-sig') as s, \
                    open(p, 'w', encoding='utf-8-sig') as d:
                d.write(s.read())
        os.startfile(p)

    def pick_dest(self):
        p = filedialog.askdirectory()
        if p:
            self.v_dest.set(os.path.normpath(p))

    def preview(self):
        try:
            hosts = fc.load_hosts(self.v_hosts.get())
        except (OSError, ValueError) as e:
            messagebox.showerror('主機清單', str(e)); return
        ips = [h['IP'] for h in hosts]
        messagebox.showinfo('主機清單', f'共 {len(ips)} 台\n\n' + '\n'.join(ips[:30]) + ('\n…' if len(ips) > 30 else ''))

    def toggle_local(self):
        st = 'disabled' if self.v_local.get() else 'normal'
        self.e_user['state'] = self.e_pwd['state'] = st

    def open_result(self):
        if self.run_dir and os.path.isdir(self.run_dir):
            os.startfile(self.run_dir)

    def log(self, msg):
        self.q.put(('log', msg))

    def start(self):
        local = self.v_local.get()
        try:
            days, max_mb = int(self.v_days.get()), int(self.v_maxmb.get())
            if not 1 <= days <= 400 or not 10 <= max_mb <= 20000:
                raise ValueError
        except ValueError:
            messagebox.showerror('參數', 'log 天數要 1～400，單檔上限要 10～20000 MB'); return
        try:
            hosts = fc.load_hosts(self.v_hosts.get())
        except (OSError, ValueError) as e:
            messagebox.showerror('主機清單', str(e)); return
        if not hosts:
            messagebox.showerror('主機清單', '清單裡沒有主機'); return
        if local and len(hosts) != 1:
            messagebox.showerror('本機模式', f'本機模式清單只能 1 台（現在 {len(hosts)} 台）'); return
        if not self.v_soc.get().strip():
            messagebox.showerror('資安／SOC', '請先知會資安／SOC，填通知單號'); return
        if not local and (not self.v_user.get() or not self.v_pwd.get()):
            messagebox.showerror('帳密', '請填帳號和密碼'); return
        dest = self.v_dest.get()
        if not os.path.isdir(dest):
            if not messagebox.askyesno('存放目錄', f'{dest} 不存在，要建立嗎？'):
                return
            try:
                os.makedirs(dest)
            except OSError as e:
                messagebox.showerror('存放目錄', str(e)); return
        self.save_cfg()
        args = (self.v_hosts.get(), dest, None if local else self.v_user.get(),
                None if local else self.v_pwd.get(), days, local, self.v_soc.get().strip(), max_mb)
        self.txt.delete('1.0', 'end')
        self.pb.configure(maximum=len(hosts), value=0)
        self.stop_flag.clear()
        self.b_start['state'], self.b_stop['state'], self.b_open['state'] = 'disabled', 'normal', 'disabled'
        self.log(f'開始：{len(hosts)} 台，{"本機模式" if local else "遠端模式"}，SOC 單號 {args[6]}')

        def work():
            try:
                d = fc.run(*args, log=lambda m: self.q.put(('host', m)), stop=self.stop_flag.is_set)
                self.q.put(('done', d))
            except Exception as e:  # 顯示在畫面上，不讓視窗卡住
                self.q.put(('error', str(e)))
        self.worker = threading.Thread(target=work)
        self.worker.start()

    def on_close(self):
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno('收集中', '還在收集，要停止並關閉嗎？（處理完目前的檔案、斷開連線後才會關）'):
                return
            self.stop_flag.set()
            self.closing = True
            self.txt.insert('end', '停止中，等待斷線…\n')
            return
        self.destroy()

    def poll(self):
        try:
            while True:
                kind, msg = self.q.get_nowait()
                if kind == 'host':
                    if msg.startswith('['):
                        self.pb['value'] = min(self.pb['value'] + 1, self.pb['maximum'])  # step() 到頂會歸零
                    self.txt.insert('end', msg + '\n'); self.txt.see('end')
                elif kind == 'log':
                    self.txt.insert('end', msg + '\n'); self.txt.see('end')
                else:
                    self.b_start['state'], self.b_stop['state'] = 'normal', 'disabled'
                    self.v_pwd.set('')
                    if self.closing:
                        self.destroy()
                        return
                    if kind == 'done':
                        self.run_dir = msg
                        self.b_open['state'] = 'normal'
                    else:
                        self.txt.insert('end', '錯誤：' + msg + '\n')
                        messagebox.showerror('錯誤', msg)
        except queue.Empty:
            pass
        self.after(200, self.poll)


if __name__ == '__main__':
    App().mainloop()

# -*- coding: utf-8 -*-
"""FTP 主機一對多收集：讀白名單 → 逐台用 SMB（\\\\IP\\C$）唯讀複製設定檔與近 N 天 log 到目的目錄。

用法（在跳板機上，用高權限帳號；密碼執行時輸入，不存檔）：
    python ftp_collect.py hosts.csv D:\\collect --user DOMAIN\\admin --soc-ticket SOC-123 [--days 60] [--max-mb 500]
    python ftp_collect.py hosts.csv D:\\collect --local --soc-ticket SOC-123   # 連不到的主機：拷到那台上跑，清單只能一台
視窗版：ftp_collect_gui.py

hosts.csv（白名單，UTF-8）：IP,Type,ExtraPaths,ListPaths,Note
    IP        單一 IPv4、多個用 ; 分隔、網段 192.0.2.0/24、範圍 192.0.2.30-40（展開上限 1024 台；先測 445，不通就略過）
    Type      ServU / FileZilla / Other（Other 只收 ExtraPaths）；空白＝兩種都找（網段用）
    ExtraPaths 額外要收的資料夾，; 分隔，必須是 X:\\... 完整路徑（裝在非預設路徑、log 另指定位置時填）
    ListPaths  只列檔名／大小／時間、不複製內容的資料夾，; 分隔（例 D:\\FTP）。只能當「有沒有在用」參考，不能推算傳輸次數

規則：
- 跑之前先知會資安／SOC（來源機器、帳號、時段、白名單），通知單號必填並記入結果。高權限帳號連多台 C$ 就是橫向移動的樣子。
- 正式跑用確定的 IP 清單；網段只在「找出哪些主機有裝 FTP」且 SOC 同意時用。
- 只讀不寫來源主機；每次執行另開 run_ 資料夾，不覆蓋舊資料；本次用的白名單另存一份在結果裡。
- 設定檔：只收認得格式（XML／JSON／INI）且解析成功者，依欄位名遮掉密碼／salt／hash／secret／token 後才寫入；
  格式無法確認、二進位、含私鑰的一律不落地，只記在 manifest。第一次對新版本主機跑完要人工抽看一份。
- log：只收 *.log、*.log.N、*.log.YYYYMMDD；分塊複製、單檔上限（--max-mb）、目的磁碟保留 2 GB；複製中有變動會註記。
  mtime 只是粗篩（mtime 早於期間起點的檔不會含期間內紀錄）；_run.csv 列出收到的最舊 log 檔修改日；實際涵蓋期間要解析內容才算數。
- 沒收到該軟體的主設定檔算失敗；近 N 天沒有 log 另外註記（可能 log 沒開）。
- 結果：_run_info.txt（誰、何時、SOC 單號、參數，開始就寫）、_run.csv（每台跑完就寫，中止也寫）、
  每台 manifest.csv（逐檔即時寫，含 SHA-256）。
- 只用 Python 標準函式庫；連線用 Windows WNetAddConnection2（ctypes）。執行前已存在的連線不動，只斷本程式新建的。
- 已知限制：SMB 讀取卡住時沒有硬逾時，試跑時要有人看著。
"""
import argparse
import csv
import ctypes
import datetime as dt
import getpass
import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import sys
import xml.etree.ElementTree as ET

DEFAULTS = {
    'servu': [r'C:\ProgramData\RhinoSoft\Serv-U', r'C:\Program Files\RhinoSoft\Serv-U',
              r'C:\Program Files (x86)\RhinoSoft\Serv-U'],
    'filezilla': [r'C:\Program Files (x86)\FileZilla Server', r'C:\Program Files\FileZilla Server',
                  r'C:\ProgramData\filezilla-server'],
    'other': [],
}
DEFAULTS['auto'] = DEFAULTS['servu'] + DEFAULTS['filezilla']
# 主設定檔（收到才算這台成功）
MAIN_CONFIG = {
    'servu': re.compile(r'^(serv-u\.archive|servudaemon\.ini)$', re.I),
    'filezilla': re.compile(r'^(filezilla server\.xml|users\.xml)$', re.I),
}
MAIN_CONFIG['auto'] = re.compile('|'.join(p.pattern for p in MAIN_CONFIG.values()), re.I)
MAX_HOSTS = 1024
MAX_CONFIG_MB = 20
MAX_LIST = 200000
MIN_FREE = 2 * 1024 ** 3
CHUNK = 1024 * 1024
CONFIG_EXT = {'.xml', '.ini', '.archive', '.config', '.cfg', '.json'}
LOG_NAME = re.compile(r'\.log(\.\d{1,3}|\.\d{4}-?\d{2}-?\d{2})?$', re.I)
SECRET = re.compile(r'pass|pwd|salt|hash|secret|token', re.I)
PRIVATE_KEY = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----')
INI_LINE = re.compile(r'^\s*(?:[;#].*|\[[^\]]*\]\s*|([^=]+?)\s*=(.*))?$')


# ---------- 設定檔遮罩（解析後依欄位名遮，不認得的格式不收） ----------
def _blank_subtree(el):
    """敏感元素：自己和底下所有文字、屬性值（name 以外）都遮。"""
    for e in el.iter():
        if e.text and e.text.strip():
            e.text = '***'
        if e is not el and e.tail and e.tail.strip():  # <Password><v/>明文</Password> 的「明文」在子元素 tail
            e.tail = '***'
        for k in e.attrib:
            if not (e is el and k.lower() == 'name'):
                e.attrib[k] = '***'


def mask_xml(text):
    root = ET.fromstring(text)
    for el in root.iter():
        tag = el.tag.split('}')[-1] if isinstance(el.tag, str) else ''
        if SECRET.search(tag) or any(k.lower() == 'name' and SECRET.search(v) for k, v in el.attrib.items()):
            _blank_subtree(el)
            continue
        for k in list(el.attrib):
            if SECRET.search(k):
                el.attrib[k] = '***'
    return ET.tostring(root, encoding='unicode')


def mask_json(text):
    def walk(o):
        if isinstance(o, dict):
            return {k: '***' if SECRET.search(k) else walk(v) for k, v in o.items()}  # 敏感欄位整個值都遮
        if isinstance(o, list):
            return [walk(x) for x in o]
        return o
    return json.dumps(walk(json.loads(text)), ensure_ascii=False, indent=1)


def mask_ini(text):
    out = []
    for line in text.splitlines():
        m = INI_LINE.match(line)
        if not m:
            raise ValueError('不是 INI 格式')
        if m.group(1) and SECRET.search(m.group(1)):
            line = f'{m.group(1)}=***'
        out.append(line)
    return '\n'.join(out) + '\n'


def mask_config(text):
    """回傳 (遮罩後文字, 格式)；格式無法確認丟 ValueError。"""
    t = text.lstrip()
    if t.startswith('<'):
        return mask_xml(text), 'XML'
    if t.startswith('{'):
        return mask_json(text), 'JSON'
    if t.startswith('['):  # JSON 陣列或 INI 的 [section]
        try:
            return mask_json(text), 'JSON'
        except ValueError:
            pass
    return mask_ini(text), 'INI'


# ---------- 白名單 ----------
def expand_ips(field, budget=MAX_HOSTS):
    """'192.0.2.0/24;198.51.100.7;203.0.113.30-40' -> [ip, ...]；只收 IPv4，先算數量再展開。"""
    out = []
    for tok in re.split(r'[;\s]+', field.strip()):
        if not tok:
            continue
        m = re.fullmatch(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.)(\d{1,3})-(\d{1,3})', tok)
        if m:
            a, b = int(m.group(2)), int(m.group(3))
            if a > b or b > 255:
                raise ValueError(f'範圍寫反或超出 255：{tok}')
            n, gen = b - a + 1, (ipaddress.IPv4Address(m.group(1) + str(x)) for x in range(a, b + 1))
        elif '/' in tok:
            net = ipaddress.IPv4Network(tok, strict=False)
            n = net.num_addresses if net.prefixlen >= 31 else net.num_addresses - 2
            gen = net.hosts()
        else:
            n, gen = 1, iter([ipaddress.IPv4Address(tok)])
        if len(out) + n > budget:
            raise ValueError(f'展開後超過上限 {MAX_HOSTS} 台，請縮小網段：{tok}')
        out += [str(x) for x in gen]
    return out


def check_path(p):
    """只接受 X:\\... 完整路徑；拒絕 UNC、相對路徑、..（避免繞過白名單或讀到跳板機自己）。回傳正規化路徑。"""
    q = p.replace('/', '\\')
    if not re.fullmatch(r'[A-Za-z]:\\[^<>"|?*:]*', q) or any(c in ('..', '.') for c in q[3:].split('\\')):
        raise ValueError(f'路徑必須是 X:\\ 開頭的完整路徑、不能有 . 或 ..：{p}')
    return q.rstrip('\\') if len(q) > 3 else q


def split_paths(s):
    return [check_path(p.strip()) for p in (s or '').split(';') if p.strip()]


def load_hosts(path):
    """讀白名單並展開；格式錯、Type 不認得、IP 重複、超過上限都丟 ValueError。"""
    with open(path, encoding='utf-8-sig', newline='') as f:
        rows = [r for r in csv.DictReader(f) if (r.get('IP') or '').strip() and not r['IP'].strip().startswith('#')]
    hosts, seen = [], {}
    for n, r in enumerate(rows, 2):
        typ = (r.get('Type') or '').strip().lower() or 'auto'
        if typ not in DEFAULTS:
            raise ValueError(f'第 {n} 行 Type 不認得：{r.get("Type")}（只能 ServU／FileZilla／Other／空白）')
        try:
            extra, lists = split_paths(r.get('ExtraPaths')), split_paths(r.get('ListPaths'))
            ips = expand_ips(r['IP'], MAX_HOSTS - len(hosts))
        except ValueError as e:
            raise ValueError(f'第 {n} 行：{e}')
        for ip in ips:
            if ip in seen:
                raise ValueError(f'{ip} 在第 {seen[ip]} 行和第 {n} 行都有，請合併成一行')
            seen[ip] = n
            hosts.append(dict(r, IP=ip, Type=typ, _extra=extra, _lists=lists, _multi=len(ips) > 1))
    return hosts


def port_open(ip, port=445, timeout=1.0):
    try:
        with socket.create_connection((ip, port), timeout):
            return True
    except OSError:
        return False


# ---------- SMB 連線 ----------
class NETRESOURCE(ctypes.Structure):
    _fields_ = [('dwScope', ctypes.c_ulong), ('dwType', ctypes.c_ulong), ('dwDisplayType', ctypes.c_ulong),
                ('dwUsage', ctypes.c_ulong), ('lpLocalName', ctypes.c_wchar_p), ('lpRemoteName', ctypes.c_wchar_p),
                ('lpComment', ctypes.c_wchar_p), ('lpProvider', ctypes.c_wchar_p)]


SMB_ERR = {5: '權限不足', 53: '找不到主機', 67: '找不到共用', 86: '密碼錯', 1326: '帳密錯', 1231: '網路不通',
           1219: '這台已有用別的帳號建立的連線，請先在跳板機執行 net use 查看並中斷，再重跑'}


def existing_connections():
    """目前這個登入工作階段已連著的網路資源（大寫），執行前就有的不准斷。列舉失敗回 None。"""
    mpr, h, found = ctypes.windll.mpr, ctypes.c_void_p(), set()
    if mpr.WNetOpenEnumW(1, 0, 0, None, ctypes.byref(h)):  # RESOURCE_CONNECTED, RESOURCETYPE_ANY
        return None
    try:
        buf = ctypes.create_string_buffer(64 * 1024)
        while True:
            cnt, size = ctypes.c_ulong(0xFFFFFFFF), ctypes.c_ulong(len(buf))
            rc = mpr.WNetEnumResourceW(h, ctypes.byref(cnt), buf, ctypes.byref(size))
            if rc == 259:  # ERROR_NO_MORE_ITEMS
                break
            if rc:
                return None
            for nr in (NETRESOURCE * cnt.value).from_buffer(buf):
                if nr.lpRemoteName:
                    found.add(nr.lpRemoteName.upper())
    finally:
        mpr.WNetCloseEnum(h)
    return found


def connect(share, user, pwd):
    nr = NETRESOURCE(dwType=1, lpRemoteName=share)  # RESOURCETYPE_DISK
    rc = ctypes.windll.mpr.WNetAddConnection2W(ctypes.byref(nr), pwd, user, 0)
    if rc:
        raise OSError(rc, f'連線 {share} 失敗，錯誤碼 {rc}：{SMB_ERR.get(rc, "其他")}')


def disconnect(share):
    """不強制（有開啟中的檔案就保留）。"""
    return ctypes.windll.mpr.WNetCancelConnection2W(share, 0, False)


def win_identity():
    """DOMAIN\\user（拿不到就退回登入名）。"""
    try:
        n = ctypes.c_ulong(256)
        b = ctypes.create_unicode_buffer(256)
        if ctypes.windll.secur32.GetUserNameExW(2, b, ctypes.byref(n)):  # NameSamCompatible
            return b.value
    except (AttributeError, OSError):
        pass
    return getpass.getuser()


def is_network_drive(path):
    d = os.path.splitdrive(os.path.abspath(path))[0]
    try:
        return ctypes.windll.kernel32.GetDriveTypeW(d + '\\') == 4  # DRIVE_REMOTE
    except (AttributeError, OSError):
        return False


# ---------- 收集 ----------
def to_src(ip, path, local):
    """'C:\\x\\y' -> '\\\\ip\\C$\\x\\y'（local 時原樣）"""
    if local:
        return path
    m = re.match(r'([A-Za-z]):\\(.*)', path)
    return rf'\\{ip}\{m.group(1).upper()}$\{m.group(2)}'


def lp(path):
    """加 \\\\?\\ 前綴，避開 Windows 260 字路徑上限。"""
    path = os.path.abspath(path)
    if path.startswith('\\\\?\\'):
        return path
    return '\\\\?\\UNC\\' + path[2:] if path.startswith('\\\\') else '\\\\?\\' + path


def inside(child, parent):
    """child 是否在 parent 底下（不同磁碟回 False）。"""
    try:
        return os.path.commonpath([os.path.abspath(child), os.path.abspath(parent)]) == os.path.abspath(parent)
    except ValueError:
        return False


def to_dst(hdir, path):
    m = re.match(r'([A-Za-z]):\\(.*)', path)
    dst = os.path.join(hdir, m.group(1).upper(), m.group(2))
    if not inside(dst, hdir):
        raise OSError(f'目的路徑跑出收集目錄：{path}')
    return lp(dst)


def ts(t):
    return dt.datetime.fromtimestamp(t).strftime('%Y/%m/%d %H:%M:%S')


class StopRun(Exception):
    pass


def _drop(part):
    try:
        os.remove(part)
    except OSError:
        pass


def copy_log(src, dst, st, max_bytes, stop):
    """分塊複製到 .part 再改名；回傳 (實際位元組, sha256, 註記)。"""
    if st.st_size > max_bytes:
        return 0, '', f'超過單檔上限 {max_bytes // CHUNK} MB，未收集'
    h, n, part = hashlib.sha256(), 0, dst + '.part'
    try:
        with open(src, 'rb') as fi, open(part, 'wb') as fo:  # Python 開檔不鎖對方，FTP 服務可照常寫
            while n < max_bytes:
                if stop():
                    raise StopRun()
                b = fi.read(min(CHUNK, max_bytes - n))
                if not b:
                    break
                fo.write(b); h.update(b); n += len(b)
        os.replace(part, dst)
    except BaseException:
        _drop(part)
        raise
    note = []
    try:
        after = os.stat(src)
        if (after.st_size, after.st_mtime) != (st.st_size, st.st_mtime):
            note.append('複製中檔案有變動')
        if n >= max_bytes and after.st_size > n:
            note.append('達上限，只收前段')
    except OSError:
        note.append('複製完成後來源已不在（可能被輪替）')
    return n, h.hexdigest(), '；'.join(note)


def copy_config(src, dst, st):
    """解析遮罩後寫入；不認得、二進位、含私鑰者不落地。回傳 (位元組, sha256, 註記, 是否有遮)。"""
    if st.st_size > MAX_CONFIG_MB * CHUNK:
        return 0, '', f'設定檔超過 {MAX_CONFIG_MB} MB，未收集', False
    with open(src, 'rb') as f:
        data = f.read()
    bom16 = data.startswith((b'\xff\xfe', b'\xfe\xff'))
    if b'\x00' in data and not bom16:
        return 0, '', '未收集：二進位，無法安全遮罩（請在主機上用主控台匯出）', False
    try:
        text = data.decode('utf-16' if bom16 else 'utf-8-sig')
    except UnicodeDecodeError:
        try:
            text = data.decode('cp950')
        except UnicodeDecodeError:
            return 0, '', '未收集：編碼無法辨識，無法安全遮罩', False
    if PRIVATE_KEY.search(text):
        return 0, '', '未收集：內含私鑰', False
    try:
        new, fmt = mask_config(text)
    except (ValueError, ET.ParseError) as e:
        return 0, '', f'未收集：格式無法確認，無法安全遮罩（{str(e)[:60]}）', False
    out = new.encode('utf-8')
    part = dst + '.part'
    try:
        with open(part, 'wb') as f:
            f.write(out)
        os.replace(part, dst)
    except BaseException:
        _drop(part)
        raise
    changed = '***' in new and new.count('***') > text.count('***')
    return len(out), hashlib.sha256(out).hexdigest(), f'{fmt}，' + ('已遮密碼' if changed else '無密碼欄位'), changed


def new_stat():
    return dict(found=0, denied=0, main=0, config=0, log=0, listed=0, bytes=0, masked=0, errors=0, skipped=0, oldest=None)


def collect_host(row, run_dir, cutoff, local, max_bytes, stop, stat):
    """結果累加在 stat（中止時呼叫端仍拿得到）；manifest 逐檔即時寫。"""
    ip = row['IP']
    roots = DEFAULTS[row['Type']] + row['_extra']
    main_rx = MAIN_CONFIG.get(row['Type'])
    hdir = os.path.join(run_dir, ip)
    os.makedirs(hdir, exist_ok=True)
    out_root = os.path.abspath(run_dir)
    with open(os.path.join(hdir, 'manifest.csv'), 'w', encoding='utf-8-sig', newline='') as mf:
        w = csv.writer(mf)
        w.writerow(['kind', 'source_path', 'size', 'mtime', 'sha256', 'note'])

        def rec(*r):
            w.writerow(r)
            mf.flush()

        def walk_err(e):
            stat['errors'] += 1
            rec('error', getattr(e, 'filename', ''), '', '', '', f'無法列目錄：{e.strerror or e}')

        for root in roots:
            src_root = to_src(ip, root, local)
            try:
                os.stat(src_root)
            except FileNotFoundError:
                continue
            except OSError as e:  # 權限不足等，不能當成「沒裝」
                stat['denied'] += 1
                walk_err(e)
                continue
            stat['found'] += 1
            rec('root', root, '', '', '', '找到')
            for dp, dirs, files in os.walk(src_root, onerror=walk_err):
                if local and inside(dp, out_root):
                    dirs[:] = []
                    continue
                for fn in files:
                    if stop():
                        raise StopRun()
                    ext = os.path.splitext(fn)[1].lower()
                    kind = 'config' if ext in CONFIG_EXT else 'log' if LOG_NAME.search(fn) else ''
                    if not kind:
                        continue
                    src = os.path.join(dp, fn)
                    orig = root.rstrip('\\') + src[len(src_root.rstrip('\\')):]
                    try:
                        st = os.stat(src)
                        if kind == 'log' and dt.datetime.fromtimestamp(st.st_mtime) < cutoff:
                            continue
                        if shutil.disk_usage(run_dir).free - st.st_size < MIN_FREE:
                            raise StopRun('目的磁碟剩不到 2 GB')
                        dst = to_dst(hdir, orig)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        if kind == 'log':
                            n, sha, note = copy_log(src, dst, st, max_bytes, stop)
                        else:
                            n, sha, note, m = copy_config(src, dst, st)
                            stat['masked'] += m
                        if n:
                            stat[kind] += 1
                            stat['bytes'] += n
                            if kind == 'config' and main_rx and main_rx.match(fn):
                                stat['main'] += 1
                            if kind == 'log':
                                stat['oldest'] = min(filter(None, [stat['oldest'], st.st_mtime]))
                        else:
                            stat['skipped'] += 1
                        rec(kind, orig, st.st_size, ts(st.st_mtime), sha, note)
                    except OSError as e:
                        stat['errors'] += 1
                        rec('error', orig, '', '', '', str(e))

    if row['_lists']:
        with open(os.path.join(hdir, 'filelist.csv'), 'w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(['path', 'size', 'mtime'])
            full = False
            for root in row['_lists']:
                src_root = to_src(ip, root, local)
                for dp, dirs, files in os.walk(src_root):
                    for fn in files:
                        if stop():
                            raise StopRun()
                        if stat['listed'] >= MAX_LIST:
                            full = True
                            break
                        try:
                            st = os.stat(os.path.join(dp, fn))
                        except OSError:
                            stat['errors'] += 1
                            continue
                        w.writerow([root.rstrip('\\') + os.path.join(dp, fn)[len(src_root.rstrip('\\')):], st.st_size, ts(st.st_mtime)])
                        stat['listed'] += 1
                    if full:
                        dirs[:] = []
                        break
                if full:
                    w.writerow([f'（超過 {MAX_LIST} 筆，以下未列）', '', ''])
                    break


def host_status(r, s, days):
    if not s['found'] and s['denied']:
        return f'失敗：{s["denied"]} 個安裝目錄存取被拒（看 manifest）'
    if not s['found']:
        return '略過：沒找到 FTP 軟體' if r['_multi'] else '失敗：找不到安裝目錄（裝在別處請填 ExtraPaths）'
    if r['Type'] != 'other' and not s['main']:
        return '失敗：找到目錄但沒收到主設定檔（看 manifest）'
    msg = 'OK'
    if s['errors']:
        msg = f'部分成功：{s["errors"]} 個錯誤'
    if not s['log']:
        msg += f'；近 {days} 天沒有 log（log 可能沒開或在別處）'
    if s['skipped']:
        msg += f'；{s["skipped"]} 個檔未收集（看 manifest）'
    return msg


def run(hosts_path, dest, user=None, pwd=None, days=60, local=False, soc_ticket='', max_mb=500,
        log=print, stop=lambda: False):
    """收集主流程；log(msg) 回報進度，stop() 回 True 時停止。回傳結果資料夾。"""
    if not soc_ticket.strip():
        raise ValueError('請填 SOC 通知單號')
    if not 1 <= days <= 400:
        raise ValueError('log 天數要在 1～400')
    if not 10 <= max_mb <= 20000:
        raise ValueError('單檔上限要在 10～20000 MB')
    hosts = load_hosts(hosts_path)
    if not hosts:
        raise ValueError('白名單裡沒有主機')
    if local and len(hosts) != 1:
        raise ValueError(f'本機模式白名單只能有 1 台（現在 {len(hosts)} 台）')
    if dest.startswith('\\\\') or is_network_drive(dest):
        raise ValueError('存放目錄請用本機磁碟，不要放網路共用或對應的網路磁碟')
    if local:
        for p in DEFAULTS[hosts[0]['Type']] + hosts[0]['_extra'] + hosts[0]['_lists']:
            if inside(dest, p):
                raise ValueError(f'存放目錄不能放在要收集的資料夾裡：{p}')

    pre = set() if local else existing_connections()
    if pre is None:
        raise ValueError('無法列出跳板機目前的網路連線，為避免誤斷既有連線，不執行')

    start = dt.datetime.now()
    base = os.path.join(dest, ('run_local_' if local else 'run_') + start.strftime('%Y%m%d_%H%M%S'))
    run_dir, k = base, 1
    while os.path.exists(run_dir):  # 同一秒再跑一次
        k += 1
        run_dir = f'{base}_{k}'
    os.makedirs(run_dir)
    shutil.copyfile(hosts_path, os.path.join(run_dir, '_hosts_used.csv'))
    info = os.path.join(run_dir, '_run_info.txt')
    with open(info, 'w', encoding='utf-8') as f:
        f.write(f'SOC 通知單號：{soc_ticket}\n執行者（Windows 登入）：{win_identity()}\n'
                f'連線帳號：{user or "（本機模式）"}\n執行機器：{socket.gethostname()}\n開始：{start:%Y/%m/%d %H:%M:%S}\n'
                f'白名單：{os.path.abspath(hosts_path)}（{len(hosts)} 台，副本 _hosts_used.csv）\n'
                f'log 天數：{days}\n單檔上限：{max_mb} MB\n模式：{"本機" if local else "SMB 遠端"}\n')
    csv_path = os.path.join(run_dir, '_run.csv')
    with open(csv_path, 'w', encoding='utf-8-sig', newline='') as f:
        csv.writer(f).writerow(['#', 'IP', 'Type', '狀態', '主設定檔', '設定檔', 'log 檔', '最舊 log 檔修改日', '未收集',
                                '列出檔名數', '已遮密碼檔', 'MB', 'Note'])

    cutoff = start - dt.timedelta(days=days)
    ok, end_reason = 0, '正常結束'
    for i, r in enumerate(hosts, 1):
        if stop():
            end_reason = '手動停止'
            break
        ip, owned, s = r['IP'], [], new_stat()
        try:
            if not local and not port_open(ip):
                status = '略過：445 不通（關機、防火牆或不是 Windows）'
            else:
                if not local:
                    for d in sorted({p[0].upper() for p in DEFAULTS[r['Type']] + r['_extra'] + r['_lists']}):
                        share = rf'\\{ip}\{d}$'
                        try:
                            connect(share, user, pwd)
                            if share.upper() not in pre:
                                owned.append(share)
                        except OSError as e:
                            if d == 'C' or e.errno == 1219:  # 預設路徑都在 C 槽；身分衝突整台停
                                raise
                            log(f'    {e.strerror or e}')
                collect_host(r, run_dir, cutoff, local, max_mb * CHUNK, stop, s)
                status = host_status(r, s, days)
        except StopRun as e:
            end_reason = f'中止：{str(e) or "手動停止"}'
            status = end_reason + '（本台資料不完整）'
        except OSError as e:
            status = f'失敗：{e.strerror or e}'
        finally:
            for sh in owned:
                rc = disconnect(sh)
                if rc:
                    log(f'    {sh} 斷線回傳 {rc}，請在跳板機 net use 確認')
        ok += status.startswith('OK')
        log(f'[{i}/{len(hosts)}] {ip} {status}')
        with open(csv_path, 'a', encoding='utf-8', newline='') as f:
            csv.writer(f).writerow([i, ip, r['Type'], status, s['main'], s['config'], s['log'],
                                    ts(s['oldest'])[:10] if s['oldest'] else '', s['skipped'], s['listed'],
                                    s['masked'], round(s['bytes'] / CHUNK, 1), r.get('Note', '')])
        if end_reason.startswith('中止'):
            break

    with open(info, 'a', encoding='utf-8') as f:
        f.write(f'結束：{dt.datetime.now():%Y/%m/%d %H:%M:%S}（{end_reason}）\n結果：{ok}/{len(hosts)} 台 OK\n')
    log(f'{end_reason}：{ok}/{len(hosts)} 台 OK，結果在 {run_dir}')
    return run_dir


def main():
    ap = argparse.ArgumentParser(description='FTP 主機一對多唯讀收集')
    ap.add_argument('hosts')
    ap.add_argument('dest')
    ap.add_argument('--user', help='高權限帳號，例 DOMAIN\\admin；--local 時不用')
    ap.add_argument('--soc-ticket', required=True, help='SOC 通知單號（必填）')
    ap.add_argument('--days', type=int, default=60, help='log 收近幾天（1～400，預設 60）')
    ap.add_argument('--max-mb', type=int, default=500, help='單一 log 檔上限 MB（10～20000，預設 500）')
    ap.add_argument('--local', action='store_true', help='在主機本機上跑（連不到的主機用；白名單只能 1 台）')
    a = ap.parse_args()
    if not a.local and not a.user:
        sys.exit('請給 --user，或用 --local 在主機本機跑')
    try:
        load_hosts(a.hosts)
        pwd = None if a.local else getpass.getpass(f'{a.user} 密碼（不顯示、不存檔）：')
        run(a.hosts, a.dest, a.user, pwd, a.days, a.local, a.soc_ticket, a.max_mb)
    except ValueError as e:
        sys.exit(str(e))


if __name__ == '__main__':
    main()

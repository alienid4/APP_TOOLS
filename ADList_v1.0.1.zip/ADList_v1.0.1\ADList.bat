@echo off
chcp 65001 >nul
setlocal
rem ADList v1.0.1 - AD account list (read-only). Double-click, pick a scope, get a CSV next to this file.
set "PSModuleAnalysisCachePath=NUL"
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ADList.ps1" %*
echo.
pause

# -*- coding: utf-8 -*-
"""
BinMailPacker — 純標準庫版（零依賴，不用裝任何東西）。

把檔案（含 .ps1 / .sh / .exe 等 Gmail 會擋的）壓縮 + 加密 + 切割成 .bin，
用 Gmail 寄得出去；抓回來後用同一支程式還原。

只要有 Python 3 就能跑，不需要 pip 裝任何套件，也不打包成 exe
（純文字腳本，防毒不會誤判）。

加密：PBKDF2-HMAC-SHA256 導出金鑰 → SHA256 keystream（CTR 模式）XOR
      → 另附 HMAC-SHA256 驗證（偵測密碼錯誤 / 檔案毀損）。全部來自標準庫。
      強度定位：足以閃過 Gmail、擋一般人看你的檔；不是銀行級對稱加密。
"""

import io
import os
import time
import hmac
import hashlib
import zipfile
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# ---------------------------------------------------------------------------
# .bin 檔格式
#   加密：  MAGIC_ENC(8) + salt(16) + mac(32) + ciphertext
#   未加密：MAGIC_RAW(8) + zip 位元組
# ---------------------------------------------------------------------------
MAGIC_ENC = b"CLBINv3\n"   # 加密檔檔頭（金鑰分離＋MAC 蓋 salt/檔頭）
MAGIC_RAW = b"CLBINr3\n"   # 未加密檔檔頭（後面直接是 zip 位元組）
SALT_LEN = 16
MAC_LEN = 32
KDF_ITERS = 200_000

# 密碼欄預設帶入值；方便起見，使用者可在畫面上當場改成別組。
# 注意：這是弱密碼且形同公開，敏感內容請自行改密碼。
DEFAULT_PASSWORD = "1qaz@WSX"


def _derive_keys(password: str, salt: bytes):
    """導出兩把獨立金鑰：加密用 enc_key、驗證用 mac_key（金鑰分離）。"""
    km = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, KDF_ITERS, dklen=64)
    return km[:32], km[32:]


def _keystream(key: bytes, salt: bytes, n: int) -> bytes:
    """SHA256 計數器模式產生 n 位元組 keystream。"""
    out = bytearray()
    counter = 0
    while len(out) < n:
        out += hashlib.sha256(key + salt + counter.to_bytes(8, "big")).digest()
        counter += 1
    return bytes(out[:n])


def _xor(data: bytes, ks: bytes) -> bytes:
    if not data:
        return b""
    return (int.from_bytes(data, "big") ^ int.from_bytes(ks, "big")).to_bytes(len(data), "big")


def _encrypt(payload: bytes, password: str) -> bytes:
    salt = os.urandom(SALT_LEN)
    enc_key, mac_key = _derive_keys(password, salt)
    ct = _xor(payload, _keystream(enc_key, salt, len(payload)))
    mac = hmac.new(mac_key, MAGIC_ENC + salt + ct, hashlib.sha256).digest()
    return salt + mac + ct


def _decrypt(body: bytes, password: str) -> bytes:
    salt = body[:SALT_LEN]
    mac = body[SALT_LEN:SALT_LEN + MAC_LEN]
    ct = body[SALT_LEN + MAC_LEN:]
    enc_key, mac_key = _derive_keys(password, salt)
    expect = hmac.new(mac_key, MAGIC_ENC + salt + ct, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expect):
        raise ValueError("密碼錯誤，或檔案已毀損 / 不完整（分割塊沒湊齊？）。")
    return _xor(ct, _keystream(enc_key, salt, len(ct)))


def _zip_paths(paths) -> bytes:
    """把多個檔案/資料夾壓成一包 zip 位元組，保留資料夾結構。"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in paths:
            p = os.path.abspath(p)
            if os.path.isdir(p):
                base = os.path.dirname(p)
                for dirpath, _dirs, files in os.walk(p):
                    for fn in files:
                        full = os.path.join(dirpath, fn)
                        z.write(full, os.path.relpath(full, base))
            else:
                z.write(p, os.path.basename(p))
    return buf.getvalue()


def _split_sizes(total: int, chunk: int):
    if chunk <= 0 or total <= chunk:
        return [total]
    sizes = []
    left = total
    while left > 0:
        take = min(chunk, left)
        sizes.append(take)
        left -= take
    return sizes


def pack(paths, password, out_path, chunk_bytes, encrypt=True, progress=lambda s: None):
    progress("壓縮中…")
    payload = _zip_paths(paths)

    if encrypt:
        progress("加密中…")
        blob = MAGIC_ENC + _encrypt(payload, password)
    else:
        blob = MAGIC_RAW + payload

    base, ext = os.path.splitext(out_path)
    if ext.lower() != ".bin":
        out_path = out_path + ".bin"

    sizes = _split_sizes(len(blob), chunk_bytes)
    written = []
    if len(sizes) == 1:
        with open(out_path, "wb") as f:
            f.write(blob)
        written.append(out_path)
    else:
        progress(f"切割成 {len(sizes)} 塊…")
        pos = 0
        for i, sz in enumerate(sizes, 1):
            part = f"{out_path}.{i:03d}"
            with open(part, "wb") as f:
                f.write(blob[pos:pos + sz])
            pos += sz
            written.append(part)
    return written


def _gather_parts(path):
    """使用者選了某個檔，自動把它的所有分割塊依序湊齊並接起來。"""
    path = os.path.abspath(path)
    if ".bin." in os.path.basename(path).lower() and path.lower()[-4:-1] != "bin":
        base = path.rsplit(".", 1)[0]
    else:
        base = path
    part1 = f"{base}.001"
    if os.path.exists(part1):
        parts, i = [], 1
        while True:
            p = f"{base}.{i:03d}"
            if not os.path.exists(p):
                break
            parts.append(p)
            i += 1
        data = b"".join(open(p, "rb").read() for p in parts)
        return data, parts
    else:
        return open(base, "rb").read(), [base]


def unpack(path, password, out_dir, progress=lambda s: None):
    progress("讀取 / 合併分割塊…")
    blob, parts = _gather_parts(path)

    head = blob[:len(MAGIC_ENC)]
    if head == MAGIC_ENC:
        if not password:
            raise ValueError("這是加密檔，請輸入密碼。")
        progress("解密中…")
        payload = _decrypt(blob[len(MAGIC_ENC):], password)
    elif head == MAGIC_RAW:
        progress("讀取（此檔未加密）…")
        payload = blob[len(MAGIC_RAW):]
    else:
        raise ValueError("這不是本程式產生的 .bin 檔（檔頭不符）。")

    progress("解壓並還原檔案…")
    # 為避免蓋到既有檔，一律還原到新建的時間戳子資料夾
    dest = os.path.join(out_dir, "還原_" + time.strftime("%Y%m%d_%H%M%S"))
    os.makedirs(dest, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        z.extractall(dest)
        names = z.namelist()
    return names, parts, dest


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------
class App(ttk.Frame):
    def __init__(self, root):
        super().__init__(root, padding=12)
        self.root = root
        self.grid(sticky="nsew")
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        nb = ttk.Notebook(self)
        nb.grid(row=0, column=0, sticky="nsew")
        self.rowconfigure(0, weight=1)
        self._build_pack(nb)
        self._build_unpack(nb)

        self.status = ttk.Label(self, text="就緒", anchor="w", relief="sunken")
        self.status.grid(row=1, column=0, sticky="ew", pady=(10, 0))

    def set_status(self, text):
        self.root.after(0, lambda: self.status.config(text=text))

    def _run(self, fn):
        threading.Thread(target=fn, daemon=True).start()

    # ========================= 打包頁 =========================
    def _build_pack(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="  打包（要寄出去）  ")
        f.columnconfigure(0, weight=1)

        ttk.Label(f, text="要寄的檔案 / 資料夾：").grid(row=0, column=0, sticky="w")
        self.lb = tk.Listbox(f, height=8)
        self.lb.grid(row=1, column=0, sticky="nsew", pady=4)
        f.rowconfigure(1, weight=1)

        btns = ttk.Frame(f); btns.grid(row=1, column=1, sticky="n", padx=(8, 0))
        ttk.Button(btns, text="加檔案", command=self._add_files).pack(fill="x", pady=2)
        ttk.Button(btns, text="加資料夾", command=self._add_dir).pack(fill="x", pady=2)
        ttk.Button(btns, text="移除選取", command=self._remove_sel).pack(fill="x", pady=2)
        ttk.Button(btns, text="清空", command=lambda: self.lb.delete(0, "end")).pack(fill="x", pady=2)

        opt = ttk.Frame(f); opt.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))

        self.encrypt_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(opt, text="加密（建議）", variable=self.encrypt_var,
                        command=self._toggle_encrypt).grid(row=0, column=0, columnspan=2, sticky="w")
        self.enc_hint = ttk.Label(opt, text="", foreground="#a00")
        self.enc_hint.grid(row=0, column=2, columnspan=3, sticky="w", padx=(8, 0))

        ttk.Label(opt, text="密碼：").grid(row=1, column=0, sticky="w", pady=(4, 0))
        self.pw_pack = ttk.Entry(opt, show="•", width=24)
        self.pw_pack.insert(0, DEFAULT_PASSWORD)   # 預設帶入，可當場改掉
        self.pw_pack.grid(row=1, column=1, sticky="w", padx=(4, 16), pady=(4, 0))

        ttk.Label(opt, text="分割大小：").grid(row=1, column=2, sticky="w", pady=(4, 0))
        self.chunk = ttk.Entry(opt, width=8)
        self.chunk.insert(0, "10")
        self.chunk.grid(row=1, column=3, sticky="w", padx=(4, 2), pady=(4, 0))
        ttk.Label(opt, text="MB（填 0 = 不切割）").grid(row=1, column=4, sticky="w", pady=(4, 0))

        ttk.Button(f, text="▶  產生 .bin",
                   command=self._do_pack).grid(row=3, column=0, columnspan=2,
                                               sticky="ew", pady=(12, 0))

    def _add_files(self):
        for p in filedialog.askopenfilenames(title="選要寄的檔案"):
            self.lb.insert("end", p)

    def _add_dir(self):
        d = filedialog.askdirectory(title="選要寄的資料夾")
        if d:
            self.lb.insert("end", d)

    def _remove_sel(self):
        for i in reversed(self.lb.curselection()):
            self.lb.delete(i)

    def _toggle_encrypt(self):
        if self.encrypt_var.get():
            self.pw_pack.config(state="normal")
            self.enc_hint.config(text="")
        else:
            self.pw_pack.config(state="disabled")
            self.enc_hint.config(text="← 不加密：Gmail 會擋，只適合 USB／內網")

    def _do_pack(self):
        paths = list(self.lb.get(0, "end"))
        enc = self.encrypt_var.get()
        pw = self.pw_pack.get()
        if not paths:
            messagebox.showwarning("沒有檔案", "請先加入要寄的檔案或資料夾。"); return
        if enc and not pw:
            messagebox.showwarning("沒有密碼", "勾了加密就要設一組密碼；或取消勾選做不加密。"); return
        try:
            chunk_mb = float(self.chunk.get() or "0")
        except ValueError:
            messagebox.showwarning("分割大小", "分割大小請填數字（MB）。"); return
        chunk_bytes = int(chunk_mb * 1024 * 1024)

        out = filedialog.asksaveasfilename(
            title="輸出 .bin 存到哪", defaultextension=".bin",
            filetypes=[("BIN 檔", "*.bin")], initialfile="package.bin")
        if not out:
            return

        def work():
            try:
                written = pack(paths, pw, out, chunk_bytes, encrypt=enc,
                               progress=self.set_status)
                self.set_status(f"完成：產生 {len(written)} 個檔")
                msg = ("已產生：\n\n" + "\n".join(os.path.basename(w) for w in written) +
                       "\n\n位置：\n" + os.path.dirname(written[0]))
                if len(written) > 1:
                    msg += "\n\n分割塊要全部一起寄、一個都不能少。"
                if not enc:
                    msg += "\n\n⚠ 這個檔沒有加密，Gmail 會擋，只適合 USB／內網傳。"
                self.root.after(0, lambda: messagebox.showinfo("打包完成", msg))
            except Exception as e:
                self.set_status("打包失敗")
                self.root.after(0, lambda: messagebox.showerror("打包失敗", str(e)))

        self.set_status("開始打包…")
        self._run(work)

    # ========================= 還原頁 =========================
    def _build_unpack(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="  還原（抓回來）  ")
        f.columnconfigure(1, weight=1)

        ttk.Label(f, text=".bin 檔：").grid(row=0, column=0, sticky="w")
        self.in_path = ttk.Entry(f)
        self.in_path.grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(f, text="選…", command=self._pick_bin).grid(row=0, column=2)

        ttk.Label(f, text="密碼：").grid(row=1, column=0, sticky="w", pady=6)
        self.pw_unpack = ttk.Entry(f, show="•")
        self.pw_unpack.insert(0, DEFAULT_PASSWORD)   # 預設帶入，可當場改掉
        self.pw_unpack.grid(row=1, column=1, sticky="ew", padx=4)

        ttk.Label(f, text="還原到：").grid(row=2, column=0, sticky="w")
        self.out_dir = ttk.Entry(f)
        self.out_dir.grid(row=2, column=1, sticky="ew", padx=4)
        ttk.Button(f, text="選…", command=self._pick_out).grid(row=2, column=2)

        ttk.Button(f, text="▶  還原檔案",
                   command=self._do_unpack).grid(row=3, column=0, columnspan=3,
                                                 sticky="ew", pady=(14, 0))
        ttk.Label(f, text="提示：若是分割塊，選第一塊（.bin.001）即可，程式會自動湊齊。",
                  foreground="#666").grid(row=4, column=0, columnspan=3, sticky="w", pady=(8, 0))

    def _pick_bin(self):
        p = filedialog.askopenfilename(
            title="選 .bin 檔（或第一個分割塊）",
            filetypes=[("BIN / 分割塊", "*.bin *.001 *.*")])
        if p:
            self.in_path.delete(0, "end"); self.in_path.insert(0, p)
            if not self.out_dir.get():
                self.out_dir.insert(0, os.path.dirname(p))

    def _pick_out(self):
        d = filedialog.askdirectory(title="還原到哪個資料夾")
        if d:
            self.out_dir.delete(0, "end"); self.out_dir.insert(0, d)

    def _do_unpack(self):
        path = self.in_path.get().strip()
        pw = self.pw_unpack.get()
        out = self.out_dir.get().strip()
        if not path or not os.path.exists(path):
            messagebox.showwarning("沒選檔", "請選要還原的 .bin 檔。"); return
        if not out:
            messagebox.showwarning("沒選位置", "請選要還原到哪個資料夾。"); return

        def work():
            try:
                names, parts, dest = unpack(path, pw, out, self.set_status)
                self.set_status(f"完成：還原 {len(names)} 個檔")
                self.root.after(0, lambda: messagebox.showinfo(
                    "還原完成",
                    f"已還原 {len(names)} 個檔到：\n{dest}\n\n"
                    f"（為避免蓋到既有檔，放在新建的子資料夾裡；合併了 {len(parts)} 個分割塊）"))
            except Exception as e:
                self.set_status("還原失敗")
                self.root.after(0, lambda: messagebox.showerror("還原失敗", str(e)))

        self.set_status("開始還原…")
        self._run(work)


def main():
    root = tk.Tk()
    root.title("BinMailPacker — 寄腳本不被 Gmail 擋")
    root.geometry("560x430")
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""回歸測試（FtpReport v0.9.15）：log 從連線中途開始（抽樣／視窗起點）時，相對路徑不可猜成根目錄。
用法：python test_cwd_boundary.py  （假資料，IP 用 192.0.2.x）"""
import datetime as dt
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ftp_report as R  # noqa: E402

LOG = """(000001)2026/11/10 10:00:00 - u1 (192.0.2.1)> STOR mid.csv
(000001)2026/11/10 10:00:01 - u1 (192.0.2.1)> 226 Successfully transferred "/in/mid.csv"
(000001)2026/11/10 10:00:02 - u1 (192.0.2.1)> STOR /abs/a.csv
(000001)2026/11/10 10:00:03 - u1 (192.0.2.1)> 226 ok
(000001)2026/11/10 10:00:04 - u1 (192.0.2.1)> CWD /in
(000001)2026/11/10 10:00:05 - u1 (192.0.2.1)> 250 CWD successful
(000001)2026/11/10 10:00:06 - u1 (192.0.2.1)> RETR b.csv
(000001)2026/11/10 10:00:07 - u1 (192.0.2.1)> 226 ok
(000002)2026/11/10 11:00:00 - (not logged in) (192.0.2.2)> USER u2
(000002)2026/11/10 11:00:01 - (not logged in) (192.0.2.2)> 331 Password required
(000002)2026/11/10 11:00:02 - (not logged in) (192.0.2.2)> PASS ****
(000002)2026/11/10 11:00:03 - u2 (192.0.2.2)> 230 Logged on
(000002)2026/11/10 11:00:04 - u2 (192.0.2.2)> STOR c.csv
(000002)2026/11/10 11:00:05 - u2 (192.0.2.2)> 226 ok
"""

fails = 0


def check(cond, msg):
    global fails
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond:
        fails += 1


d = tempfile.mkdtemp(prefix='cwdb_')
with open(os.path.join(d, 'x.log'), 'w', encoding='utf-8', newline='\n') as f:
    f.write(LOG)
h = {'run_dir': d, 'offset': None, 'start': dt.datetime(2026, 11, 12), 'days_req': 90,
     'manifest': [{'kind': 'log', 'status': 'collected', 'out_path': 'x.log', 'mtime': '2026/11/10 12:00:00', 'source_path': 'C:/x.log'}]}
ev, st = R.parse_logs(h)
got = sorted(((e['user'], e['verb'], e['vpath']) for e in ev if e['kind'] in ('up', 'down')), key=lambda x: (x[0], x[1], str(x[2])))
print(got)
check(('u1', 'STOR', None) in got, '連線中途開始、目錄不明的相對 STOR → 帳號級（vpath None），不猜成 /mid.csv')
check(('u1', 'STOR', '/abs/a.csv') in got, '絕對路徑照常歸目錄')
check(('u1', 'RETR', '/in/b.csv') in got, 'CWD 到絕對路徑後，相對路徑恢復歸目錄')
check(('u2', 'STOR', '/c.csv') in got, '有看到 USER 的連線從 / 開始，照舊')
check(not any(v == '/mid.csv' for _, _, v in got), '沒有猜成根目錄的 /mid.csv')
print('結果：%s（%d 項失敗）' % ('FAIL' if fails else 'PASS', fails))
sys.exit(1 if fails else 0)

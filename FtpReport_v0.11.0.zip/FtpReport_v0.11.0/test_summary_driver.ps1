﻿<#
  test_summary_equiv.py 用的驅動程式（維護用，不用帶去主機）：
  從 FtpCollect.ps1 原文抽出「log 摘要」的 C# 引擎與 PowerShell 函式（不另外複製一份，測的就是正式版的程式），
  對已經存在的 run_local_* 資料夾產生 log_events_agg.csv／log_parse_stats.csv。
  用法：
    powershell -NoProfile -ExecutionPolicy Bypass -File test_summary_driver.ps1 -Collector ..\ftp_collect_ps\FtpCollect.ps1 -Root <資料夾>
    -DecodeIn <檔> -DecodeOut <檔>：把每行（\n 分隔、hex）用引擎的 UTF-8 解碼器解碼，寫出每行 hex(UTF-16LE)，給 Python 比對
    -Patterns <檔>：把引擎裡抄自報表的比對式原文寫出（JSON），給 Python 核對跟 ftp_report.py 一字不差
    -MaxRows／-MaxStrings／-MaxSessions／-LimitSec／-MaxLine：覆蓋摘要上限（測上限用；預設＝正式版的值）
#>
param([string]$Collector = '', [string]$Root = '', [string]$DecodeIn = '', [string]$DecodeOut = '', [string]$Patterns = '',
    [int]$MaxRows = 3000000, [int]$MaxStrings = 2000000, [int]$MaxSessions = 8000000, [int]$LimitSec = 21600, [int]$MaxLine = 16777216)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
if (-not $Collector) { $Collector = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) '..\ftp_collect_ps\FtpCollect.ps1' }
$ast = [Management.Automation.Language.Parser]::ParseFile((Resolve-Path $Collector).Path, [ref]$null, [ref]$null)
$want = @('Get-Sha256File', 'ConvertFrom-LongPath', 'ConvertTo-LongPath', 'Test-Inside', 'Assert-InRun', 'New-RunSubDir', 'New-OutFile', 'Open-Source',
    'Read-CsvRows', 'Get-CsvCell', 'Get-PyOffsetMin', 'Get-LogSummaryPlan', 'Write-LogSummary')
$funcs = @($ast.FindAll({ param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] }, $true) | Where-Object { $want -contains $_.Name })
foreach ($w in $want) { if (-not ($funcs | Where-Object { $_.Name -eq $w })) { throw "FtpCollect.ps1 找不到函式 $w" } }
$asg = @($ast.FindAll({ param($n) $n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -eq '$SUM_CS' }, $true))
if ($asg.Count -ne 1) { throw 'FtpCollect.ps1 找不到 $SUM_CS' }
Invoke-Expression $asg[0].Extent.Text
foreach ($f in $funcs) { Invoke-Expression $f.Extent.Text }
if (-not ('FtpCollectSumV130' -as [type])) { Add-Type -TypeDefinition $SUM_CS }
$script:SumReady = $true; $script:SumErr = ''
$script:LongOK = $false
$script:Created = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$U8 = New-Object Text.UTF8Encoding($false)

if ($Patterns) {
    $t = [FtpCollectSumV130]
    $o = [ordered]@{ RX_FZ1 = $t::PY_FZ1; RX_BRACKET = $t::PY_BRACKET; RX_FZ09 = $t::PY_FZ09; RX_CODE = $t::PY_CODE; LOGIN_FAIL_TEXT = $t::PY_LOGIN_FAIL
        RX_SU = $t::PY_SU; SU_CONN = $t::PY_SU_CONN; SU_LOGIN = $t::PY_SU_LOGIN; SU_LOGOUT = $t::PY_SU_LOGOUT; SU_CLOSE = $t::PY_SU_CLOSE; SU_HOST = $t::PY_SU_HOST
        SU_MSGS = @($t::PY_SU_MSGS) }
    [IO.File]::WriteAllText($Patterns, (ConvertTo-Json $o -Depth 3), $U8)
}
if ($DecodeIn) {
    $sb = New-Object Text.StringBuilder
    foreach ($ln in [IO.File]::ReadAllLines($DecodeIn)) {
        $b = New-Object byte[] ($ln.Length / 2)
        for ($i = 0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($ln.Substring($i * 2, 2), 16) }
        $s = [FtpCollectSumV130]::DecodeForTest($b)
        [void]$sb.Append(([BitConverter]::ToString([Text.Encoding]::Unicode.GetBytes($s)) -replace '-', '')).Append("`n")
    }
    [IO.File]::WriteAllText($DecodeOut, $sb.ToString(), $U8)
}
if ($Root) {
    foreach ($rd in @(Get-ChildItem -LiteralPath $Root -Directory | Where-Object { $_.Name -like 'run_local_*' } | Sort-Object Name)) {
        $hd = @(Get-ChildItem -LiteralPath $rd.FullName -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'manifest.csv') } | Sort-Object Name | Select-Object -First 1)
        if (-not $hd) { Write-Host "SKIP $($rd.Name)：沒有主機資料夾"; continue }
        $script:RunDir = $rd.FullName
        $r = Write-LogSummary $rd.FullName $hd[0].FullName 'test_summary_driver' $LimitSec $MaxRows $MaxStrings $MaxSessions $MaxLine
        if ($r.Ok) { Write-Host ("SUMMARY {0} rows={1} events={2} bytes={3}" -f $rd.Name, $r.Rows, $r.Events, $r.Bytes) }
        else { Write-Host "SKIP $($rd.Name)：$($r.Msg)" }
    }
}

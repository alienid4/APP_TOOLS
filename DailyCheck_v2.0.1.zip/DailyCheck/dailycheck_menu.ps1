﻿# DailyCheck 選單 v1.3.0 (2026-11-18)：仿 AIX SMIT 的全螢幕選單；執行中滑鼠／鍵盤不會讓它暫停，標題列與畫面持續顯示進度
#   操作只有兩個：↑↓ 移動、Enter 執行。離開／回上一層都是選單裡的一個項目。
#   「0 全部檢查」跑完會另外產生一份總覽報告（照紙本 1～4 分頁），只開總覽，不開四份。
param([switch]$NoOpen, [switch]$All)   # -All＝排程用：不用按鍵，跑完全部並產生總覽
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
if (-not $All -and ([Console]::IsInputRedirected -or $Host.Name -ne 'ConsoleHost')) {
  Write-Host '這個選單要在一般命令視窗（雙擊「每日檢查選單.bat」）執行；排程請用「0_全部檢查_排程.bat」。'
  exit 3
}
. (Join-Path $here 'devlist.ps1')
try { $Host.UI.RawUI.WindowTitle = 'DailyCheck 每日檢查' } catch {}

$ITEMS = @(
  @{ Key = '1'; Text = 'WhatsUp 監控檢查'; Script = 'whatsup_daily.ps1'; Cat = '1'; Pick = $false; Out = 'whatsup_out' },
  @{ Key = '2'; Text = 'VMware 系統檢查'; Script = 'vmware_daily.ps1'; Cat = '2'; Pick = $true; Out = 'vmware_out' },
  @{ Key = '3'; Text = 'Storage/San Switch 檢查（Unity）'; Script = 'unity_daily.ps1'; Cat = '3'; Pick = $true; Out = 'unity_out'; Mm = ''; Mn = '(?i)^ME4' },
  @{ Key = '3'; Text = 'Storage/San Switch 檢查（ME4）'; Script = 'me4_daily.ps1'; Cat = '3'; Pick = $false; Out = 'me4_out'; Mm = '(?i)^ME4'; Mn = '' },
  @{ Key = '4'; Text = '其他：AD net time'; Script = 'ad_time.ps1'; Cat = '4'; Pick = $false; Out = 'ad_out' },
  @{ Key = '0'; Text = '全部檢查（1～4 依序執行，產生總覽報告）'; Script = ''; Cat = ''; Pick = $false; Out = '' },
  @{ Key = 'Q'; Text = '離開'; Script = ''; Cat = ''; Pick = $false; Out = '' }
)
$CODE = @{ 0 = '正常'; 1 = '注意'; 2 = '須回報'; 3 = '查不到或不完整'; 4 = '須記錄（維護中裝置，或硬碟 80～85%）' }

# ---- 防暫停：關掉命令視窗的「快速編輯」（滑鼠一點就整個暫停），Ctrl+C 不會中斷；要停只能關視窗
function Set-NoPause([bool]$on) {
  try {
    if (-not ('DcNs.Con' -as [type])) { Add-Type -Namespace DcNs -Name Con -MemberDefinition '[DllImport("kernel32.dll")] public static extern IntPtr GetStdHandle(int h); [DllImport("kernel32.dll")] public static extern bool GetConsoleMode(IntPtr h, out uint m); [DllImport("kernel32.dll")] public static extern bool SetConsoleMode(IntPtr h, uint m);' }
    $h = [DcNs.Con]::GetStdHandle(-10); $m = [uint32]0
    if ([DcNs.Con]::GetConsoleMode($h, [ref]$m)) {
      if ($on) { if ($null -eq $global:DCConMode) { $global:DCConMode = $m }; [void][DcNs.Con]::SetConsoleMode($h, [uint32](([long]$m -bor 0x80) -band [long]4294967231)) }   # 0x80＝延伸旗標，清掉 0x40＝快速編輯
      elseif ($null -ne $global:DCConMode) { [void][DcNs.Con]::SetConsoleMode($h, [uint32]$global:DCConMode) }
    }
  } catch {}
  try { [Console]::TreatControlCAsInput = $on } catch {}
}
# ---- 執行中提示：另一個執行緒每秒更新標題列（百分比、已幾秒、目前步驟），每 15 秒在畫面印一行「還在執行」
function Start-Beat([string]$what, [int]$no, [int]$tot) {
  $global:DCProg = [hashtable]::Synchronized(@{ What = $what; No = $no; Tot = $tot; Step = ''; T0 = [DateTime]::Now; Stop = $false; Wait = $false })
  try {
    $rs = [runspacefactory]::CreateRunspace(); $rs.Open(); $rs.SessionStateProxy.SetVariable('P', $global:DCProg)
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript({
      $n = 0
      while (-not $P.Stop) {
        Start-Sleep -Milliseconds 1000; $n++
        $sec = [int]([DateTime]::Now - $P.T0).TotalSeconds
        $pct = if ($P.Tot -gt 0) { [int](100 * ($P.No - 1) / $P.Tot) } else { 0 }
        $t = "整體 $pct%｜第 $($P.No)/$($P.Tot) 項 $($P.What)｜這一項已 $([int]($sec / 60)) 分 $($sec % 60) 秒" + $(if ($P.Step) { '｜' + $P.Step } else { '' })
        if ($P.Wait) { try { [Console]::Title = 'DailyCheck 等你輸入｜' + $t } catch {}; $n = 0; continue }
        try { [Console]::Title = 'DailyCheck 執行中 ' + @('|', '/', '-', '\')[$n % 4] + ' ' + $t } catch {}
        if ($n % 15 -eq 0) { try { [Console]::WriteLine('  … 還在執行，沒有當掉（' + $t + '）') } catch {} }
      }
    })
    $global:DCBeat = @{ PS = $ps; RS = $rs; H = $ps.BeginInvoke() }
  } catch { $global:DCBeat = $null }
}
function Stop-Beat {
  if ($global:DCProg) { $global:DCProg.Stop = $true }
  if ($global:DCBeat) { try { [void]$global:DCBeat.PS.EndInvoke($global:DCBeat.H) } catch {}; try { $global:DCBeat.PS.Dispose(); $global:DCBeat.RS.Close() } catch {}; $global:DCBeat = $null }
  $global:DCProg = $null
  try { $Host.UI.RawUI.WindowTitle = 'DailyCheck 每日檢查' } catch {}
}

function W([string]$t) { $n = 0; foreach ($ch in $t.ToCharArray()) { $n += $(if ([int]$ch -ge 0x1100) { 2 } else { 1 }) }; return $n }
function Cut([string]$t, [int]$w) { $o = ''; $n = 0; foreach ($ch in $t.ToCharArray()) { $c = $(if ([int]$ch -ge 0x1100) { 2 } else { 1 }); if ($n + $c -gt $w) { break }; $o += $ch; $n += $c }; return $o }
function Width { $w = 78; try { $w = [Math]::Max([Console]::WindowWidth - 2, 20) } catch {}; return $w }
function Line([string]$t = '', [string]$fg = '', [string]$bg = '') {
  $w = Width; $t = Cut $t $w; $len = W $t; if ($len -lt $w) { $t = $t + (' ' * ($w - $len)) }
  $p = @{ Object = $t }; if ($fg) { $p.ForegroundColor = $fg }; if ($bg) { $p.BackgroundColor = $bg }
  Write-Host @p
}
# 全部檢查：一開始與每一步都印一行帶時間的進度，避免前面幾分鐘畫面全黑讓人以為當掉
function Say([string]$msg, [string]$fg = 'Cyan') { Write-Host ('[' + (Get-Date).ToString('HH:mm:ss') + '] ' + $msg) -ForegroundColor $fg }
# 共用：SMIT 樣式畫面，↑↓ 選、Enter 回傳選到的索引；項目太多時自動捲動
function Choose([string]$title, [string[]]$lines, [int]$start = 0) {
  $i = $start
  while ($true) {
    Clear-Host
    $w = Width; $h = 25; try { $h = [Console]::WindowHeight } catch {}
    $room = [Math]::Max($h - 9, 3)
    $top = [Math]::Min([Math]::Max($i - [int]($room / 2), 0), [Math]::Max($lines.Count - $room, 0))
    Line ((' ' * [Math]::Max([int](($w - (W $title)) / 2), 0)) + $title) 'White' 'DarkBlue'
    Line ''
    Line '將游標移到要執行的項目，按 Enter。' 'Gray'
    Line $(if ($top -gt 0) { '  ↑ 上面還有' } else { '' }) 'DarkGray'
    for ($k = $top; $k -lt [Math]::Min($top + $room, $lines.Count); $k++) { if ($k -eq $i) { Line ('  ' + $lines[$k]) 'Black' 'Gray' } else { Line ('  ' + $lines[$k]) } }
    Line $(if ($top + $room -lt $lines.Count) { '  ↓ 下面還有' } else { '' }) 'DarkGray'
    Line ('-' * [Math]::Min($w, 60)) 'DarkGray'
    Line '↑↓ 移動　　Enter 執行' 'Yellow'
    $key = [Console]::ReadKey($true)
    switch ($key.Key) {
      'UpArrow' { $i = ($i - 1 + $lines.Count) % $lines.Count }
      'DownArrow' { $i = ($i + 1) % $lines.Count }
      'Enter' { return $i }
    }
  }
}

# 跑一支檢查；回傳 結束代碼、報告資料夾、錯誤
function RunOne($item, [string]$only, [bool]$quiet, [int]$no = 1, [int]$tot = 1) {
  Line ("==== 執行：$($item.Key). $($item.Text)" + $(if ($only) { "（第 $only 號）" } else { '（全部）' })) 'White' 'DarkBlue'
  $t0 = Get-Date
  $sp = @{ NoOpen = ($NoOpen -or $quiet) }
  if ($only) { $sp.Only = $only }
  if ($All) { try { if ((Get-Command (Join-Path $here $item.Script)).Parameters.ContainsKey('NonInteractive')) { $sp.NonInteractive = $true } } catch {} }   # 排程沒人輸入密碼
  $global:LASTEXITCODE = $null; $err = ''
  Start-Beat ($item.Key + '. ' + $item.Text) $no $tot
  try { & (Join-Path $here $item.Script) @sp | Out-Host } catch { $err = $_.Exception.Message; Write-Host ('執行失敗：' + $err) -ForegroundColor Red } finally { Stop-Beat }
  $xc = if ($err) { 3 } elseif ($null -eq $LASTEXITCODE) { 3 } else { [int]$LASTEXITCODE }
  $dir = $null
  $od = Join-Path $here $item.Out
  if (Test-Path $od) { $dir = Get-ChildItem $od -Directory | Where-Object { $_.LastWriteTime -ge $t0.AddSeconds(-2) -and (Test-Path (Join-Path $_.FullName 'report.html')) } | Sort-Object LastWriteTime | Select-Object -Last 1 }
  return [pscustomobject]@{ Item = $item; Code = $xc; Dir = $(if ($dir) { $dir.FullName } else { '' }); Err = $err }
}

function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
. (Join-Path $here 'overview.ps1')   # 總覽：馬上處理／天天發生／備查

# ---------------- 排程模式
if ($All) {
  $logDir = Join-Path $here 'daily_out'; New-Item -ItemType Directory -Force -Path $logDir | Out-Null
  $log = Join-Path $logDir ('排程_' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.log')
  try { Start-Transcript -Path $log | Out-Null } catch {}
  Set-NoPause $true
  $res = @()
  try {
    $global:DailyCheckAclDone = $null
    Say ('全部檢查開始：最多 ' + @($ITEMS | Where-Object { $_.Script }).Count + ' 項，依序執行並顯示進度；WhatsUp 通常最久（約 2～3 分鐘）。標題列每秒更新進度，畫面每 15 秒印一行「還在執行」；滑鼠點、按鍵都不會讓它暫停，要中止請直接關視窗。')
    $todo = @($ITEMS | Where-Object { $_.Script }); $xi = 0
    foreach ($x in $todo) { $xi++
      Say ("準備：$($x.Key). $($x.Text)（讀設備清單）"); $n = 0; try { $dl = Read-DevList $here $x.Cat $x.Mm $x.Mn 6>$null; if ($null -ne $dl) { $n = $dl.Count } } catch { $n = 1; Say ('讀設備清單失敗，仍嘗試執行（錯誤會由該項顯示）：' + $_.Exception.Message) 'Yellow' }
      if ($n -eq 0) { Write-Host ("略過：$($x.Key). $($x.Text)（這台的設備清單沒有設定）"); continue }
      $sw = [Diagnostics.Stopwatch]::StartNew(); Say ("開始：$($x.Key). $($x.Text)")
      $one = RunOne $x '' $true $xi $todo.Count; $res += $one
      Say ("結束：$($x.Key). $($x.Text)，結果：$($CODE[$one.Code])，用時 $([int]$sw.Elapsed.TotalSeconds) 秒") $(if ($one.Code -eq 0) { 'Green' } elseif ($one.Code -eq 3) { 'Yellow' } else { 'Red' })
    }
    try { Overview $res } catch { Write-Host ('總覽報告產生失敗：' + $_.Exception.Message) }
    foreach ($r in $res) { Write-Host ("$($r.Item.Key). $($r.Item.Text)：" + $CODE[$r.Code]) }
  } finally { try { Stop-Transcript | Out-Null } catch {}; Set-NoPause $false }
  $codes = @($res | ForEach-Object { $_.Code })
  exit $(if (-not $codes.Count) { 3 } elseif ($codes -contains 2) { 2 } elseif ($codes -contains 3) { 3 } elseif (@($codes | Where-Object { $_ -ne 0 }).Count) { 1 } else { 0 })
}

Set-NoPause $true
$pos = 0
while ($true) {
  $pos = Choose 'DailyCheck 每日檢查（唯讀，不改任何設定）' @($ITEMS | ForEach-Object { $_.Key + '. ' + $_.Text }) $pos
  $it = $ITEMS[$pos]
  if ($it.Key -eq 'Q') { Clear-Host; Set-NoPause $false; exit 0 }
  Clear-Host
  $res = @()
  if ($it.Key -eq '0') {
    # 這台電腦的設備清單裡沒有的類別就略過（例如 WhatsUp 只在能連到它的電腦上設定）
    $global:DailyCheckAclDone = $null
    Say ('全部檢查開始：最多 ' + @($ITEMS | Where-Object { $_.Script }).Count + ' 項，依序執行並顯示進度；WhatsUp 通常最久（約 2～3 分鐘）。標題列每秒更新進度，畫面每 15 秒印一行「還在執行」；滑鼠點、按鍵都不會讓它暫停，要中止請直接關視窗。')
    $todo = @($ITEMS | Where-Object { $_.Script }); $xi = 0
    foreach ($x in $todo) { $xi++
      Say ("準備：$($x.Key). $($x.Text)（讀設備清單）"); $n = 0; try { $dl = Read-DevList $here $x.Cat $x.Mm $x.Mn 6>$null; if ($null -ne $dl) { $n = $dl.Count } } catch { $n = 1; Say ('讀設備清單失敗，仍嘗試執行（錯誤會由該項顯示）：' + $_.Exception.Message) 'Yellow' }
      if ($n -eq 0) { Line ("==== 略過：$($x.Key). $($x.Text)（這台的設備清單沒有設定）") 'DarkGray'; continue }
      $sw = [Diagnostics.Stopwatch]::StartNew(); Say ("開始：$($x.Key). $($x.Text)")
      $one = RunOne $x '' $true $xi $todo.Count; $res += $one
      Say ("結束：$($x.Key). $($x.Text)，結果：$($CODE[$one.Code])，用時 $([int]$sw.Elapsed.TotalSeconds) 秒") $(if ($one.Code -eq 0) { 'Green' } elseif ($one.Code -eq 3) { 'Yellow' } else { 'Red' })
    }
    try { Overview $res } catch { Write-Host ('總覽報告產生失敗：' + $_.Exception.Message) -ForegroundColor Red }
  } else {
    $only = ''
    if ($it.Pick) {
      $devs = Read-DevList $here $it.Cat $it.Mm $it.Mn   # 不要用 @()：PS5.1 對 List 會出錯
      if ($null -ne $devs -and $devs.Count -gt 1) {
        $opts = @("全部（$($devs.Count) 台）") + @($devs | ForEach-Object { ('{0}. {1}' -f $_.No, (Label $_ '')) + $(if ($_.Reject) { '（' + $_.Reject + '）' } else { '' }) }) + @('回上一層')
        $c = Choose "$($it.Key). $($it.Text)：選設備" $opts 0
        if ($c -eq $opts.Count - 1) { continue }
        if ($c -gt 0) { $only = [string]$devs[$c - 1].No }
        Clear-Host
      }
    }
    $res += (RunOne $it $only $false)
  }
  Write-Host ''
  foreach ($r in $res) { Write-Host ("$($r.Item.Key). $($r.Item.Text)：" + $CODE[$r.Code]) }
  Write-Host '按 Enter 回到選單…'
  try { $Host.UI.RawUI.FlushInputBuffer() } catch {}   # 執行中誤按的 Enter 不算
  do { $k = [Console]::ReadKey($true) } until ($k.Key -eq 'Enter')
}

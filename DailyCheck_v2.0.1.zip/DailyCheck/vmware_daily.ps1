﻿# VmwareDaily v1.1.0 (2026-11-17)
# 每日檢查「2. VMware 系統檢查」（唯讀）：對 設備清單.csv 裡類別 2 的每座 vCenter，
#   ESXi 連線狀態（依叢集）、每個 Datastore（LUN）容量／剩餘／是否本機碟、目前觸發中的警示（Alarms）。
# 只讀，不改任何設定、不確認警示。帳號預設 webit3sc@vsphere.local（vCenter 唯讀角色）。
# 判定：共用 Datastore 剩餘 < LunFreeGB（預設 600）＝立即處理（⚠影響營運）；ESXi 本機碟不套用。
#       本機碟＝只掛在一台主機上（vCenter 回報 multiple_host_access=false），或名稱像 esxiXXX_Datastore。
#       ESXi 不是 CONNECTED＝立即處理（⚠影響營運）；紅色警示＝立即處理、黃色＝本週追蹤。
param(
  [ValidateRange(1, 100000)][double]$LunFreeGB = 600,
  [string]$Only = '',
  [switch]$NonInteractive,
  [switch]$Menu,
  [ValidateRange(1, 65535)][int]$Port = 443,
  [ValidateRange(1, 365)][int]$WarnDays = 30,
  [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
$ToolVersion = 'VmwareDaily v1.1.2'
$here = $PSScriptRoot
. (Join-Path $here 'devlist.ps1')
$targets = Read-DevList $here '2'
if ($null -eq $targets) { exit 3 }
if ($targets.Count -eq 0) { Write-Host '設備清單.csv 裡沒有類別 2（VMware／vCenter）的設備。'; exit 3 }
foreach ($tg in $targets) { if (-not $tg.User) { $tg.User = 'webit3sc@vsphere.local' } }
if ($Menu -and -not $Only) {
  Write-Host ''
  Write-Host '==== 2. VMware 系統檢查：選 vCenter ===='
  foreach ($tg in $targets) { Write-Host ('{0,3}. {1,-6} {2,-16} {3}' -f $tg.No, $tg.Loc, $tg.Host, $(if ($tg.Reject) { '（' + $tg.Reject + '）' } else { '' })) }
  $allNo = $targets.Count + 1
  Write-Host ('{0,3}. 全部' -f $allNo)
  $Only = (Ask-In '請選（可多選，例如 1,3；直接 Enter＝全部）').Trim()
  if ($Only -eq "$allNo") { $Only = '' }
}
if ($Only) {
  $want = @($Only -split '[,，\s]+' | Where-Object { $_ } | ForEach-Object { $n = 0; if ([int]::TryParse($_, [ref]$n)) { $n } else { Write-Host "看不懂的選項：$_"; exit 3 } })
  $bad = @($want | Where-Object { $_ -lt 1 -or $_ -gt $targets.Count })
  if ($bad.Count) { Write-Host ('沒有這幾號：' + ($bad -join ',')); exit 3 }
  $targets = [System.Collections.Generic.List[object]]@($targets | Where-Object { $want -contains $_.No })
}
# A8 位址只接受 IP／主機名（避免把奇怪字元帶進 curl 參數）
foreach ($tg in $targets) { if (-not $tg.Reject -and $tg.Host -notmatch '^[A-Za-z0-9][A-Za-z0-9.\-]*(:\d{1,5})?$') { $tg.Reject = 'IP 格式不對' } }
$needAsk = @($targets | Where-Object { -not $_.Reject -and $null -eq $_.Sec })
if ($needAsk.Count) {
  if ($NonInteractive) { foreach ($tg in $needAsk) { $tg.Reject = '沒有可用的密碼（非互動模式不詢問）' } }
  else { $sh = Ask-In ("有 " + $needAsk.Count + " 座沒有可用的密碼，請輸入共用密碼（不會顯示）") -Secure; if ($null -eq $sh -or $sh.Length -eq 0) { foreach ($tg in $needAsk) { $tg.Reject = '沒有輸入密碼，這座略過' }; Write-Host '沒有輸入密碼，這幾座略過（總覽會列出是哪幾座）。' -ForegroundColor Yellow } else { foreach ($tg in $needAsk) { $tg.Sec = $sh }; $remember = ConvertFrom-SecureString -SecureString $sh; $rememberLines = @($needAsk | ForEach-Object { $_.Line }) }; $sh = $null }
}

$curl = Join-Path $env:SystemRoot 'System32\curl.exe'
if (-not (Test-Path $curl)) { Write-Host '找不到 Windows 內建 curl.exe，結束。'; exit 3 }
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$jarDir = Join-Path $env:TEMP ('vmwaredaily_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $jarDir | Out-Null
& icacls.exe $jarDir /inheritance:r /grant:r ("*{0}:(OI)(CI)F" -f $sid) | Out-Null
if ($LASTEXITCODE -ne 0) { Remove-Item -Recurse -Force $jarDir -ErrorAction SilentlyContinue; Write-Host '暫存資料夾權限收不緊，為避免密碼外洩，停止執行。'; exit 3 }

class AuthFail : System.Exception { AuthFail([string]$m) : base($m) {} }
function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
function XmlEsc([string]$v) { return [System.Security.SecurityElement]::Escape($v) }
function GB([object]$b) { if ($null -eq $b -or "$b" -eq '') { return $null }; return [math]::Round([double]$b / 1073741824, 2) }   # 跟 vSphere 畫面一樣（1 GB＝1024³）

# 一次 HTTP 呼叫。$cfg＝要經標準輸入給 curl 的設定（帳密／token 不上命令列）；$bodyFile＝POST 內容檔
function Http($dev, [string]$method, [string]$path, [string[]]$cfg, [string]$bodyFile, [string[]]$hdr) {
  $dev.Calls++
  $url = 'https://' + $dev.Host + $(if ($Port -ne 443) { ":$Port" } else { '' }) + $path
  $a = '-q -s -S -k --max-redirs 0 --proto "=https" --noproxy "*" --connect-timeout 15 --max-time 120 -K - -X ' + $method + ' -b "' + $dev.Jar + '" -c "' + $dev.Jar + '" -w "\n%{http_code}"'
  foreach ($h in $hdr) { $a += ' -H "' + $h + '"' }
  if ($bodyFile) { $a += ' --data-binary "@' + $bodyFile + '"' }
  $a += ' "' + $url + '"'
  $psi = New-Object Diagnostics.ProcessStartInfo; $psi.FileName = $curl; $psi.Arguments = $a; $psi.UseShellExecute = $false
  $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
  $ie = [Console]::InputEncoding
  try { if ($ie.GetPreamble().Length) { [Console]::InputEncoding = New-Object Text.UTF8Encoding($false) } } catch {}   # 主控台若是 UTF-8 含 BOM，curl 會讀到 BOM
  try { $pr = [Diagnostics.Process]::Start($psi) } finally { try { if ([Console]::InputEncoding -ne $ie) { [Console]::InputEncoding = $ie } } catch {} }
  try {
    $bin = [Text.Encoding]::ASCII.GetBytes((($cfg | ForEach-Object { $_ + "`n" }) -join ''))   # 直接寫位元組：避免主控台編碼加 BOM
    $pr.StandardInput.BaseStream.Write($bin, 0, $bin.Length); $pr.StandardInput.BaseStream.Flush(); $pr.StandardInput.Close(); $bin = $null
    $et = $pr.StandardError.ReadToEndAsync(); $ot = $pr.StandardOutput.ReadToEndAsync()
    if (-not $pr.WaitForExit(150000)) { try { $pr.Kill() } catch {}; throw '單次呼叫超過 150 秒，已中止' }
    $out = $ot.Result; $er = $et.Result; $xc = $pr.ExitCode
  } finally { $pr.Dispose() }
  $i = $out.LastIndexOf("`n"); $code = $out.Substring($i + 1).Trim(); $body = $out.Substring(0, [Math]::Max($i, 0))
  if ($code -eq '401') { throw [AuthFail]::new('HTTP 401：帳號或密碼被拒（為避免鎖帳號，整批停止、不重試）') }
  if ($xc -ne 0) { $m = ($er -replace '\s+', ' ').Trim(); if ($m.Length -gt 160) { $m = $m.Substring(0, 160) }; throw ("連線失敗（curl 代碼 $xc）：" + $m) }
  return @{ Code = $code; Body = $body }
}
function RestGet($dev, [string]$p) {
  $path = if ($dev.Legacy) { '/rest' + ($p -replace '^/api', '') -replace '\?clusters=', '?filter.clusters=' } else { $p }
  $resp = Http $dev 'GET' $path @('header = "vmware-api-session-id: ' + $dev.Token + '"') '' @('Accept: application/json')
  if ($resp.Code -eq '403') { throw "HTTP 403：這個帳號沒有權限讀 $p" }
  if ($resp.Code -ne '200') { throw "HTTP $($resp.Code)：讀 $p 失敗" }
  $j = $resp.Body | ConvertFrom-Json
  if ($dev.Legacy) { return $j.value }
  return $j
}
function Soap($dev, [string]$inner) {
  $f = Join-Path $jarDir ('s' + [guid]::NewGuid().ToString('N') + '.xml')
  [IO.File]::WriteAllText($f, '<?xml version="1.0" encoding="UTF-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:vim25" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><soapenv:Body>' + $inner + '</soapenv:Body></soapenv:Envelope>', (New-Object Text.UTF8Encoding($false)))
  try { $resp = Http $dev 'POST' '/sdk' @() $f @('Content-Type: text/xml; charset=utf-8', 'SOAPAction: urn:vim25/6.5') }
  finally { Remove-Item -Force $f -ErrorAction SilentlyContinue }
  if ($resp.Body -match 'InvalidLogin') { throw [AuthFail]::new('vCenter SOAP 登入被拒（帳號或密碼錯，整批停止）') }
  if ($resp.Body -match '<faultstring>([^<]*)') { throw ('SOAP 錯誤：' + $Matches[1]) }
  if ($resp.Code -ne '200') { throw "SOAP HTTP $($resp.Code)" }
  return [xml]$resp.Body
}

$runStart = Get-Date
$R = @{}; foreach ($k in 'Summary', 'Hosts', 'Ds', 'Alarms', 'Gaps', 'Focus', 'Sheet') { $R[$k] = New-Object System.Collections.Generic.List[object] }
$abort = $null
$SV = @{ '正常' = 0; '注意' = 1; '不知道' = 2; '異常' = 3 }
function Worse([string]$x, [string]$y) { if ($SV[$y] -gt $SV[$x]) { return $y } else { return $x } }

try {
foreach ($tg in $targets) {
  $label = Label $tg ''
  Write-Host ("──── " + $tg.No + " / " + $targets.Count + "：" + $label); Set-Step ("第 " + $tg.No + "/" + $targets.Count + " 台 " + $tg.Host)
  $sum = [ordered]@{ 項次 = $tg.No; 項目 = $label; 設備 = $tg.Host; 版本 = ''; ESXi正常 = $null; ESXi總數 = $null; 共用LUN數 = $null; LUN低於門檻 = $null; 本機碟數 = $null; 紅色警示 = $null; 黃色警示 = $null; 設備狀態 = '不知道'; 完整度 = '查不到'; 處置 = '須補查'; 說明 = '' }
  if ($abort) { $sum.完整度 = '沒檢查'; $sum.說明 = '前面的設備帳密被拒，整批停止'; $R.Summary.Add([pscustomobject]$sum); $R.Gaps.Add([pscustomobject]@{ 設備 = $label; 項目 = '沒檢查'; 原因 = '前面的設備帳密被拒（' + $abort + '），整批停止，這座沒查' }); $R.Focus.Add([pscustomobject]@{ 等級 = '立即處理'; 影響營運 = ''; 設備 = $label; 物件 = '收集缺口 沒檢查'; 現況 = '前面的設備帳密被拒，整批停止，這座沒查'; 建議 = '修正設備清單的帳號密碼後重跑' }); continue }
  if ($tg.Reject) { $sum.說明 = $tg.Reject; $R.Summary.Add([pscustomobject]$sum); $R.Gaps.Add([pscustomobject]@{ 設備 = $label; 項目 = '登入'; 原因 = $tg.Reject }); $R.Focus.Add([pscustomobject]@{ 等級 = '立即處理'; 影響營運 = ''; 設備 = $label; 物件 = '收集缺口 登入'; 現況 = $tg.Reject; 建議 = '人工登入 vSphere 確認' }); continue }
  $dev = [pscustomobject]@{ Host = $tg.Host; Jar = (Join-Path $jarDir ("v" + $tg.No + ".cookie")); Calls = 0; Token = ''; Legacy = $false }
  $notes = New-Object System.Collections.Generic.List[string]
  $status = '正常'; $req = @{ 登入 = $false; ESXi = $false; LUN = $false; 警示 = $false }
  function Gap([string]$item, [string]$why) { $R.Gaps.Add([pscustomobject]@{ 設備 = $label; 項目 = $item; 原因 = $why }) }
  $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($tg.Sec)
  try {
    $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)
    $basic = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($tg.User + ':' + $plain))
    # 1) 登入（REST；7.0 以上用 /api，舊版用 /rest）
    Write-Host '  [1/4] 登入'
    $resp = Http $dev 'POST' '/api/session' @('header = "Authorization: Basic ' + $basic + '"') '' @('Accept: application/json')
    if ($resp.Code -eq '404') { $dev.Legacy = $true; $resp = Http $dev 'POST' '/rest/com/vmware/cis/session' @('header = "Authorization: Basic ' + $basic + '"') '' @('Accept: application/json') }
    if ($resp.Code -notin '200', '201') { throw "登入失敗：HTTP $($resp.Code)" }
    $tok = $resp.Body | ConvertFrom-Json
    $dev.Token = if ($dev.Legacy) { $tok.value } else { [string]$tok }
    $req.登入 = $true
    # 2) ESXi（依叢集）
    Write-Host '  [2/4] ESXi 主機'
    try {
      $clMap = @{}
      foreach ($c in @(RestGet $dev '/api/vcenter/cluster')) { foreach ($h in @(RestGet $dev ('/api/vcenter/host?clusters=' + $c.cluster))) { $clMap[[string]$h.host] = $c.name } }
      $hosts = @(RestGet $dev '/api/vcenter/host')
      $ok = 0
      foreach ($h in $hosts) {
        $cs = [string]$h.connection_state; $ps = [string]$h.power_state
        $lv = if ($cs -eq 'CONNECTED' -and $ps -in 'POWERED_ON', '') { '正常' } elseif ($cs -eq 'CONNECTED') { '注意' } else { '異常' }
        if ($lv -eq '正常') { $ok++ }
        $status = Worse $status $lv
        $R.Hosts.Add([pscustomobject]@{ 設備 = $label; 叢集 = $(if ($clMap.ContainsKey([string]$h.host)) { $clMap[[string]$h.host] } else { '（不在叢集）' }); ESXi = $h.name; 連線 = $cs; 電源 = $ps; 判定 = $lv })
      }
      $sum.ESXi正常 = $ok; $sum.ESXi總數 = $hosts.Count
      if ($hosts.Count -eq 0) { Gap 'ESXi' '讀到 0 台 ESXi，可能是帳號權限沒往下傳播' } else { $req.ESXi = $true }
    } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap 'ESXi' $_.Exception.Message }
    # 3) Datastore（LUN）
    Write-Host '  [3/4] Datastore（LUN）'
    try {
      $dsl = @(RestGet $dev '/api/vcenter/datastore')
      $low = 0; $shN = 0; $loc = 0; $detFail = 0
      foreach ($d in $dsl) {
        $det = $null; try { $det = RestGet $dev ('/api/vcenter/datastore/' + $d.datastore) } catch { if ($_.Exception -is [AuthFail]) { throw }; $detFail++ }
        $multi = if ($det -and $null -ne $det.multiple_host_access) { [bool]$det.multiple_host_access } else { $null }
        $nameLocal = ([string]$d.name -match '(?i)^esxi[\w-]*_datastore\d*$') -or ([string]$d.name -match '(?i)^datastore\d*( \(\d+\))?$')
        # 本機碟：只掛一台主機且是 VMFS；名稱像本機碟但 vCenter 說多台共用 → 當共用、照規則判
        $isLocal = ($multi -eq $false -and [string]$d.type -eq 'VMFS') -or ($nameLocal -and $multi -ne $true)
        $basis = if ($multi -eq $false) { '只掛 1 台主機' } elseif ($multi -eq $true) { '多台主機共用' } else { '共用與否讀不到' }
        if ($nameLocal) { $basis += '；名稱像本機碟' }
        if ($nameLocal -and $multi -eq $true) { $basis += '（名稱與實際不符，照共用 LUN 判）' }
        $cap = GB $d.capacity; $free = GB $d.free_space; $used = if ($null -ne $cap -and $null -ne $free) { [math]::Round($cap - $free, 2) } else { $null }
        $acc = if ($det -and $null -ne $det.accessible) { [bool]$det.accessible } else { $null }
        if ($isLocal) { $loc++; $lv = if ($acc -eq $false) { '注意' } else { '正常' }; $why = '本機碟（不套 ' + $LunFreeGB + ' GB 規則）' + $(if ($acc -eq $false) { '，無法存取' } else { '' }) }
        else {
          $shN++
          if ($acc -eq $false) { $lv = '異常'; $why = '無法存取' }
          elseif ($null -eq $free) { $lv = '不知道'; $why = '剩餘空間讀不到' }
          elseif ([double]$d.free_space -lt $LunFreeGB * 1073741824) { $lv = '異常'; $why = "剩餘低於 $LunFreeGB GB"; $low++ }
          elseif ($null -eq $acc) { $lv = '不知道'; $why = '能否存取讀不到' }
          else { $lv = '正常'; $why = '' }
        }
        $status = Worse $status $lv
        $R.Ds.Add([pscustomobject]@{ 設備 = $label; ID = [string]$d.datastore; Datastore = $d.name; 類型 = $d.type; 本機碟 = $(if ($isLocal) { '是' } else { '否' }); CapacityGB = $cap; FreeGB = $free; UsedGB = $used; 使用率 = $(if ($cap) { [math]::Round(100 * $used / $cap, 1) } else { $null }); 判定 = $lv; 說明 = $why; 分類依據 = $basis })
      }
      $sum.共用LUN數 = $shN; $sum.LUN低於門檻 = $low; $sum.本機碟數 = $loc
      if ($detFail) { Gap 'Datastore' "$detFail 顆的詳細資料（是否共用、能否存取）讀不到" }
      if ($dsl.Count -eq 0) { Gap 'Datastore' '讀到 0 顆 Datastore，可能是帳號權限沒往下傳播' } else { $req.LUN = (-not $detFail) }
    } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap 'Datastore' $_.Exception.Message }
    # 4) 觸發中的警示（SOAP：rootFolder.triggeredAlarmState）
    Write-Host '  [4/4] 警示（Alarms）'
    try {
      $sc = Soap $dev '<urn:RetrieveServiceContent><urn:_this type="ServiceInstance">ServiceInstance</urn:_this></urn:RetrieveServiceContent>'
      $rv = $sc.GetElementsByTagName('returnval')[0]
      $root = $rv.rootFolder.'#text'; $pc = $rv.propertyCollector.'#text'; $smg = $rv.sessionManager.'#text'
      $sum.版本 = [string]$rv.about.fullName
      [void](Soap $dev ('<urn:Login><urn:_this type="SessionManager">' + (XmlEsc $smg) + '</urn:_this><urn:userName>' + (XmlEsc $tg.User) + '</urn:userName><urn:password>' + (XmlEsc $plain) + '</urn:password></urn:Login>'))
      $plain = $null
      $x = Soap $dev ('<urn:RetrievePropertiesEx><urn:_this type="PropertyCollector">' + (XmlEsc $pc) + '</urn:_this><urn:specSet><urn:propSet><urn:type>Folder</urn:type><urn:pathSet>triggeredAlarmState</urn:pathSet></urn:propSet><urn:objectSet><urn:obj type="Folder">' + (XmlEsc $root) + '</urn:obj></urn:objectSet></urn:specSet><urn:options/></urn:RetrievePropertiesEx>')
      if ($x.GetElementsByTagName('RetrievePropertiesExResponse').Count -ne 1) { throw '警示回應格式不對' }
      if ($x.GetElementsByTagName('missingSet').Count) { throw '沒有權限讀警示（missingSet）' }
      if ($x.GetElementsByTagName('token').Count) { Gap '警示' '警示太多沒讀完（有續讀 token）' }
      $states = @($x.GetElementsByTagName('AlarmState'))
      $needNames = @{}
      $alarms = foreach ($st in $states) {
        $o = [pscustomobject]@{ Alarm = $st.alarm.'#text'; EntType = $st.entity.type; Ent = $st.entity.'#text'; Status = [string]$st.overallStatus; Time = [string]$st.time; Ack = ([string]$st.acknowledged -eq 'true') }
        $needNames['Alarm|' + $o.Alarm] = 1; $needNames[$o.EntType + '|' + $o.Ent] = 1; $o
      }
      $nm = @{}
      if ($needNames.Count) {
        $types = @($needNames.Keys | ForEach-Object { ($_ -split '\|', 2)[0] } | Sort-Object -Unique)
        $ps = ($types | ForEach-Object { '<urn:propSet><urn:type>' + $_ + '</urn:type><urn:pathSet>' + $(if ($_ -eq 'Alarm') { 'info.name' } else { 'name' }) + '</urn:pathSet></urn:propSet>' }) -join ''
        $os = ($needNames.Keys | ForEach-Object { $p = $_ -split '\|', 2; '<urn:objectSet><urn:obj type="' + (XmlEsc $p[0]) + '">' + (XmlEsc $p[1]) + '</urn:obj></urn:objectSet>' }) -join ''
        $nx = Soap $dev ('<urn:RetrievePropertiesEx><urn:_this type="PropertyCollector">' + (XmlEsc $pc) + '</urn:_this><urn:specSet>' + $ps + $os + '</urn:specSet><urn:options/></urn:RetrievePropertiesEx>')
        foreach ($oc in @($nx.GetElementsByTagName('objects'))) { $nm[$oc.obj.type + '|' + $oc.obj.'#text'] = [string]$oc.propSet.val.'#text' }
      }
      $red = 0; $yel = 0
      foreach ($a in $alarms) {
        $infra = $a.EntType -in 'HostSystem', 'Datastore', 'ClusterComputeResource', 'StoragePod', 'Datacenter', 'Folder'
        $lv = switch ($a.Status) { 'red' { if ($a.Ack -and -not $infra) { '注意' } else { '異常' } } 'yellow' { '注意' } default { '正常' } }
        if ($a.Status -eq 'red') { $red++ } elseif ($a.Status -eq 'yellow') { $yel++ }
        $status = Worse $status $lv
        $t = $null; try { $t = ([datetime]$a.Time).ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss') } catch { $t = $a.Time }
        $R.Alarms.Add([pscustomobject]@{ 設備 = $label; 時間 = $t; 顏色 = $a.Status; 已確認 = $(if ($a.Ack) { '是' } else { '否' }); 警示 = $(if ($nm['Alarm|' + $a.Alarm]) { $nm['Alarm|' + $a.Alarm] } else { $a.Alarm }); 對象類型 = $a.EntType; 對象 = $(if ($nm[$a.EntType + '|' + $a.Ent]) { $nm[$a.EntType + '|' + $a.Ent] } else { $a.Ent }); 判定 = $lv })
      }
      $sum.紅色警示 = $red; $sum.黃色警示 = $yel; $req.警示 = $true
      try { [void](Soap $dev ('<urn:Logout><urn:_this type="SessionManager">' + (XmlEsc $smg) + '</urn:_this></urn:Logout>')) } catch {}
    } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '警示' $_.Exception.Message }
  } catch {
    if ($_.Exception -is [AuthFail]) { $abort = $label + '：' + $_.Exception.Message }
    $notes.Add($_.Exception.Message)
    if (-not $req.登入) { Gap '登入' $_.Exception.Message }
  } finally {
    if ($dev.Token) { try { [void](Http $dev 'DELETE' $(if ($dev.Legacy) { '/rest/com/vmware/cis/session' } else { '/api/session' }) @('header = "vmware-api-session-id: ' + $dev.Token + '"') '' @()) } catch {} }
    $dev.Token = $null; Remove-Item -Force $dev.Jar -ErrorAction SilentlyContinue
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b); $plain = $null; $basic = $null; $tg.Sec = $null
  }
  $miss = @($req.Keys | Where-Object { -not $req[$_] })
  $sum.設備狀態 = if ($req.登入) { $status } else { '不知道' }
  $sum.完整度 = if (-not $req.登入) { '查不到' } elseif ($miss.Count) { '不完整（缺 ' + ($miss -join '、') + '）' } else { '完整' }
  $sum.處置 = if ($sum.設備狀態 -eq '異常') { '須回報' } elseif ($sum.完整度 -ne '完整' -or $sum.設備狀態 -eq '不知道') { '須補查' } elseif ($sum.設備狀態 -eq '注意') { '可結案（有注意事項）' } else { '可結案' }
  $sum.說明 = ($notes -join '；')
  $R.Summary.Add([pscustomobject]$sum)
  Write-Host ("  結論：" + $sum.處置 + "｜" + $sum.完整度)
}
} finally { Remove-Item -Recurse -Force $jarDir -ErrorAction SilentlyContinue }

# ---------------- 空間歷史與預估（每天一筆；存在 %LOCALAPPDATA%\DailyCheck，換新版不會不見）
# 預估出任何錯都不能讓報告消失：整段包在 try 裡，失敗就在預估欄寫原因。
$histDir = Join-Path $env:LOCALAPPDATA 'DailyCheck'
$histFile = Join-Path $histDir 'vmware_history.csv'
$histNote = ''
$IC = [Globalization.CultureInfo]::InvariantCulture
foreach ($d in $R.Ds) { $d | Add-Member -NotePropertyName 每日變化GB -NotePropertyValue $null -Force; $d | Add-Member -NotePropertyName 空間預估 -NotePropertyValue '' -Force }
function PDate([string]$t) { $o = [datetime]::MinValue; if ([datetime]::TryParseExact($t, 'yyyy-MM-dd', $IC, 'None', [ref]$o)) { return $o }; return $null }
function PNum([string]$t) { $o = 0.0; if ([double]::TryParse($t, [Globalization.NumberStyles]::Float, $IC, [ref]$o) -and -not [double]::IsNaN($o) -and -not [double]::IsInfinity($o)) { return $o }; return $null }
$mtx = $null
try {
  $mtx = New-Object Threading.Mutex($false, 'Local\DailyCheck_vmware_history')
  $got = $false; try { $got = $mtx.WaitOne(30000) } catch [Threading.AbandonedMutexException] { $got = $true }
  if (-not $got) { throw '另一個 VMware 檢查正在寫空間歷史，這次不做預估' }
  $hist = New-Object System.Collections.Generic.List[object]; $bad = 0
  if (Test-Path $histFile) {
    foreach ($h in @(Import-Csv $histFile -Encoding UTF8)) {
      $dt = PDate $h.日期; $cp = PNum $h.CapacityGB; $fr = PNum $h.FreeGB
      if ($null -eq $dt -or $null -eq $cp -or $null -eq $fr -or -not $h.vCenter -or -not $h.Key -or $fr -lt 0 -or $fr -gt $cp + 1) { $bad++; continue }
      $hist.Add([pscustomobject]@{ 日期 = $h.日期; D = $dt; vCenter = $h.vCenter; Key = $h.Key; Datastore = $h.Datastore; CapacityGB = $cp; FreeGB = $fr })
    }
  }
  if ($bad) { $histNote = "空間歷史有 $bad 筆格式不對，已略過" }
  $today = $runStart.ToString('yyyy-MM-dd')
  foreach ($d in @($R.Ds | Where-Object { $null -ne $_.FreeGB -and $null -ne $_.CapacityGB })) {
    $vc = ($R.Summary | Where-Object { $_.項目 -eq $d.設備 } | Select-Object -First 1).設備
    $key = if ($d.ID) { $d.ID } else { 'name:' + $d.Datastore }   # 用 vCenter 內部編號當識別，改名不會斷、同名不會混
    foreach ($o in @($hist | Where-Object { $_.日期 -eq $today -and $_.vCenter -eq $vc -and $_.Key -eq $key })) { [void]$hist.Remove($o) }
    $hist.Add([pscustomobject]@{ 日期 = $today; D = $runStart.Date; vCenter = $vc; Key = $key; Datastore = $d.Datastore; CapacityGB = [double]$d.CapacityGB; FreeGB = [double]$d.FreeGB })
  }
  $keep = @($hist | Where-Object { $_.D -ge $runStart.Date.AddDays(-180) } | Sort-Object D, vCenter, Key)
  try {
    New-Item -ItemType Directory -Force -Path $histDir | Out-Null
    $tmpH = $histFile + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $sbH = New-Object Text.StringBuilder
    [void]$sbH.AppendLine('"日期","vCenter","Key","Datastore","CapacityGB","FreeGB"')
    foreach ($h in $keep) { [void]$sbH.AppendLine(('"{0}","{1}","{2}","{3}","{4}","{5}"' -f $h.日期, ($h.vCenter -replace '"', '""'), ($h.Key -replace '"', '""'), ($h.Datastore -replace '"', '""'), $h.CapacityGB.ToString('R', $IC), $h.FreeGB.ToString('R', $IC))) }
    [IO.File]::WriteAllText($tmpH, $sbH.ToString(), (New-Object Text.UTF8Encoding($true)))
    Move-Item -Force $tmpH $histFile
  } catch { Remove-Item -Force $tmpH -ErrorAction SilentlyContinue; $histNote = (($histNote, ('今天的空間紀錄沒存進去（' + $_.Exception.Message + '）')) | Where-Object { $_ }) -join '；' }
  foreach ($d in $R.Ds) {
    try {
      if ($null -eq $d.FreeGB) { $d.空間預估 = '剩餘空間讀不到'; continue }
      if ($d.本機碟 -eq '是') { $d.空間預估 = '本機碟不預估'; continue }
      if ([double]$d.FreeGB -lt $LunFreeGB) { $d.空間預估 = "已低於 $LunFreeGB GB"; continue }
      $vc = ($R.Summary | Where-Object { $_.項目 -eq $d.設備 } | Select-Object -First 1).設備
      $key = if ($d.ID) { $d.ID } else { 'name:' + $d.Datastore }
      $pts = @($keep | Where-Object { $_.vCenter -eq $vc -and $_.Key -eq $key } | Sort-Object D)
      # 容量變動超過 1%，或剩餘空間一天內回升超過容量 5%（清理／搬移），之前的趨勢不再適用
      $start = 0; $why = ''
      for ($i = 1; $i -lt $pts.Count; $i++) {
        if ([math]::Abs($pts[$i].CapacityGB - $pts[$i - 1].CapacityGB) -gt [math]::Max(1, $pts[$i - 1].CapacityGB * 0.01)) { $start = $i; $why = "$($pts[$i].日期) 容量有變動" }
        elseif ($pts[$i].FreeGB - $pts[$i - 1].FreeGB -gt $pts[$i].CapacityGB * 0.05) { $start = $i; $why = "$($pts[$i].日期) 有大量釋放空間" }
      }
      $pts = @($pts | Select-Object -Skip $start | Where-Object { $_.D -ge $runStart.Date.AddDays(-30) })
      $span = if ($pts.Count) { ($pts[-1].D - $pts[0].D).TotalDays } else { 0 }
      if ($pts.Count -lt 5 -or $span -lt 7) { $d.空間預估 = "資料累積中（已有 $($pts.Count) 天，需 7 天以上）" + $(if ($why) { "；$why，重新累積" } else { '' }); continue }
      $xs = @($pts | ForEach-Object { ($_.D - $pts[0].D).TotalDays }); $ys = @($pts | ForEach-Object { $_.FreeGB })
      $mx = ($xs | Measure-Object -Average).Average; $my = ($ys | Measure-Object -Average).Average
      $num = 0.0; $den = 0.0; for ($i = 0; $i -lt $xs.Count; $i++) { $num += ($xs[$i] - $mx) * ($ys[$i] - $my); $den += [math]::Pow($xs[$i] - $mx, 2) }
      $slope = if ($den) { $num / $den } else { 0 }
      $d.每日變化GB = [math]::Round($slope, 2)
      $basis = "依近 $([int]$span + 1) 天、$($pts.Count) 筆" + $(if ($pts.Count -lt $span * 0.7) { '，資料有缺日，僅供參考' } else { '' })
      if ($slope -ge -0.05) { $d.空間預估 = "未觀察到明顯減少（$basis）"; continue }
      $days = [math]::Floor(([double]$d.FreeGB - $LunFreeGB) / (-$slope))
      if ($days -gt 3650) { $d.空間預估 = "超過 10 年才會低於 $LunFreeGB GB（$basis）"; continue }
      $d.空間預估 = "約 $days 天後低於 $LunFreeGB GB（" + $runStart.AddDays($days).ToString('yyyy-MM-dd') + "），每天少 " + [math]::Round(-$slope, 1) + " GB（$basis）"
      if ($days -le $WarnDays) {
        $d | Add-Member -NotePropertyName 預估不足 -NotePropertyValue $true -Force
        if ($d.判定 -eq '正常') { $d.判定 = '注意'; $d.說明 = "預估 $days 天內低於 $LunFreeGB GB" }
      }
    } catch { $d.空間預估 = '預估失敗：' + $_.Exception.Message }
  }
  foreach ($s in $R.Summary) {
    if ($s.設備狀態 -eq '正常' -and @($R.Ds | Where-Object { $_.設備 -eq $s.項目 -and $_.判定 -eq '注意' }).Count) {
      $s.設備狀態 = '注意'; if ($s.處置 -eq '可結案') { $s.處置 = '可結案（有注意事項）' }
    }
  }
} catch {
  $histNote = '空間預估這次沒做（' + $_.Exception.Message + '）'
} finally { if ($mtx) { if ($got) { try { $mtx.ReleaseMutex() } catch {} }; $mtx.Dispose() } }
if ($histNote) { Write-Host ('⚠ ' + $histNote) }

# ---------------- 自動判讀＋檢查表文字
foreach ($s in $R.Summary) {
  $dv = $s.項目
  $rows = New-Object System.Collections.Generic.List[object]
  foreach ($h in @($R.Hosts | Where-Object { $_.設備 -eq $dv -and $_.判定 -ne '正常' })) { $rows.Add([pscustomobject]@{ 等級 = $(if ($h.判定 -eq '異常') { '立即處理' } else { '本週追蹤' }); 影響營運 = $(if ($h.判定 -eq '異常') { '⚠可能影響營運：ESXi 失聯（若非維護中），上面的 VM 可能停擺或被 HA 搬走' } else { '' }); 設備 = $dv; 物件 = "ESXi $($h.ESXi)"; 現況 = "連線 $($h.連線)、電源 $($h.電源)（叢集 $($h.叢集)）"; 建議 = '登入 vSphere 檢查主機' }) }
  foreach ($d in @($R.Ds | Where-Object { $_.設備 -eq $dv -and $_.判定 -ne '正常' })) { $rows.Add([pscustomobject]@{ 等級 = $(if ($d.判定 -eq '異常') { '立即處理' } else { '本週追蹤' }); 影響營運 = $(if ($d.判定 -eq '異常') { '⚠影響營運：LUN 空間不足或無法存取，VM 可能寫不進去、快照失敗而當機' } else { '' }); 設備 = $dv; 物件 = "Datastore $($d.Datastore)"; 現況 = "剩 $($d.FreeGB) GB／共 $($d.CapacityGB) GB（$($d.說明)）"; 建議 = $(if ($d.說明 -like '預估*') { '提早規劃擴充或搬移' } else { '擴充 LUN、搬移 VM 或清理快照' }) }) }
  foreach ($g in @($R.Alarms | Where-Object { $_.設備 -eq $dv -and $_.判定 -ne '正常' } | Group-Object 警示, 顏色, 判定)) {
    $f = $g.Group[0]; $ents = (($g.Group | ForEach-Object { $_.對象 } | Select-Object -Unique -First 5) -join '、')
    $imp = if ($f.顏色 -eq 'red' -and $f.對象類型 -in 'HostSystem', 'Datastore', 'ClusterComputeResource') { '⚠影響營運：主機／儲存／叢集紅色警示' } else { '' }
    $rows.Add([pscustomobject]@{ 等級 = $(if ($f.判定 -eq '異常') { '立即處理' } else { '本週追蹤' }); 影響營運 = $imp; 設備 = $dv; 物件 = "警示 $($f.警示)"; 現況 = "$($f.顏色)，$($g.Count) 個對象：$ents"; 建議 = '登入 vSphere 查看警示原因' })
  }
  foreach ($x in @($R.Gaps | Where-Object { $_.設備 -eq $dv })) { $rows.Add([pscustomobject]@{ 等級 = '立即處理'; 影響營運 = ''; 設備 = $dv; 物件 = "收集缺口 $($x.項目)"; 現況 = $x.原因; 建議 = '人工登入 vSphere 確認' }) }
  foreach ($it in ($rows | Sort-Object @{ Expression = { if ($_.等級 -eq '立即處理') { 0 } else { 1 } } }, @{ Expression = { -not $_.影響營運 } })) { $R.Focus.Add($it) }
  $imp = @($rows | Where-Object { $_.影響營運 }); $now1 = @($rows | Where-Object { $_.等級 -eq '立即處理' })
  $concl = if ($s.完整度 -in '查不到', '沒檢查') { "結論：無法檢查（$($s.說明)），請人工登入 vSphere 確認。" }
           elseif ($rows.Count) { '結論：' + $(if ($imp.Count) { "【⚠影響營運 $($imp.Count) 件】" } else { '' }) + "$($now1.Count) 件要處理" + $(if ($now1.Count) { '：' + (($now1 | ForEach-Object { $_.物件 + ' ' + $_.現況 }) -join '；') } else { '' }) + $(if ($rows.Count -gt $now1.Count) { "；另 $($rows.Count - $now1.Count) 件本週追蹤" } else { '' }) + '。' }
           else { '結論：沒有要處理的事項。' }
  $tight = @($R.Ds | Where-Object { $_.設備 -eq $dv -and $_.本機碟 -eq '否' -and $null -ne $_.FreeGB } | Sort-Object { [double]$_.FreeGB })
  $show = @($tight | Where-Object { $_.判定 -ne '正常' }); if (-not $show.Count) { $show = @($tight | Select-Object -First 3) }
  $L = New-Object System.Collections.Generic.List[string]
  if ($s.完整度 -in '查不到', '沒檢查') { $L.Add("結論：無法檢查（$($s.說明)），請人工登入 vSphere 確認。") }
  else {
    $L.Add('結論：' + $s.處置 + $(if ($imp.Count) { "（⚠影響營運 $($imp.Count) 件）" } else { '' }))
    $k = 0; foreach ($it in @($now1)) { $k++; $L.Add("$k. " + $(if ($it.影響營運) { '⚠' } else { '' }) + $it.物件 + '：' + $it.現況) }
    $later = @($rows | Where-Object { $_.等級 -ne '立即處理' })
    if ($later.Count) { $L.Add("本週追蹤 $($later.Count) 件：" + (($later | ForEach-Object { $_.物件 }) -join '、')) }
    if (-not $rows.Count) { $L.Add('沒有要處理的事項') }
    $L.Add('ESXi：' + $(if ($null -ne $s.ESXi總數) { "$($s.ESXi正常)/$($s.ESXi總數) 台連線正常" } else { '不知道' }))
    $L.Add('LUN：共 ' + $s.共用LUN數 + ' 顆（不含本機碟 ' + $s.本機碟數 + ' 顆），剩餘低於 ' + $LunFreeGB + ' GB：' + $s.LUN低於門檻 + ' 顆')
    $soon = @($R.Ds | Where-Object { $_.設備 -eq $dv -and $_.預估不足 })
    if ($soon.Count) { $L.Add("預估 $WarnDays 天內不足：" + (($soon | ForEach-Object { $_.Datastore + ' ' + $_.空間預估 }) -join '；')) }
    $L.Add('警示：' + $(if ($null -ne $s.紅色警示) { "紅 $($s.紅色警示)、黃 $($s.黃色警示)" } else { '不知道' }))
    if ($show.Count) { $L.Add('Datastore | CapacityGB | FreeGB | UsedGB'); foreach ($x in $show) { $L.Add("$($x.Datastore) | $($x.CapacityGB) | $($x.FreeGB) | $($x.UsedGB)") } }
  }
  if ($histNote) { $L.Add('註：' + $histNote) }
  $L.Add('VmwareDaily ' + $runStart.ToString('MM-dd HH:mm'))
  $R.Sheet.Add([pscustomobject]@{ 項目 = $dv; 處置 = $s.處置; 檢查表文字 = ($L -join "`n") })
}

# ---------------- 輸出
$outDir = Join-Path (Join-Path $here 'vmware_out') ($runStart.ToString('yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0, 6))
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$COLS = @{ Sheet = @('項目', '處置', '檢查表文字'); Focus = @('等級', '影響營運', '設備', '物件', '現況', '建議')
  Summary = @('項次', '項目', '版本', 'ESXi正常', 'ESXi總數', '共用LUN數', 'LUN低於門檻', '本機碟數', '紅色警示', '黃色警示', '設備狀態', '完整度', '處置', '說明')
  Hosts = @('設備', '叢集', 'ESXi', '連線', '電源', '判定'); Ds = @('設備', 'Datastore', '類型', '本機碟', 'CapacityGB', 'FreeGB', 'UsedGB', '使用率', '判定', '說明', '每日變化GB', '空間預估', '分類依據')
  Alarms = @('設備', '時間', '顏色', '已確認', '警示', '對象類型', '對象', '判定'); Gaps = @('設備', '項目', '原因') }
function CsvV([object]$v) { if ($null -eq $v) { return '""' }; $t = [string]$v; if ($v -is [string]) { $t = $t -replace '^[\x00-\x1F]+', ''; if ($t -match '^[=+\-@]') { $t = "'" + $t } }; return '"' + ($t -replace '"', '""') + '"' }
foreach ($k in 'Sheet', 'Focus', 'Summary', 'Hosts', 'Ds', 'Alarms', 'Gaps') {
  $sb = New-Object Text.StringBuilder
  [void]$sb.AppendLine((($COLS[$k] | ForEach-Object { CsvV $_ }) -join ','))
  foreach ($r0 in $R[$k]) { [void]$sb.AppendLine((($COLS[$k] | ForEach-Object { CsvV $r0.$_ }) -join ',')) }
  [IO.File]::WriteAllText((Join-Path $outDir ("$k.csv")), $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
}
function Cls([string]$v) { switch -Wildcard ($v) { '⚠*' { 'bad' } '立即處理' { 'bad' } '異常' { 'bad' } '須回報' { 'bad' } '本週追蹤' { 'warn' } '注意' { 'warn' } '不知道' { 'unk' } '須補查' { 'unk' } default { '' } } }
function Tbl([string]$k, [string]$pre, [string]$st) {
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<table class='t'><thead><tr><th>項次</th>" + (($COLS[$k] | ForEach-Object { '<th>' + (Esc $_) + '</th>' }) -join '') + '</tr></thead><tbody>')
  $n = 0
  foreach ($r0 in $R[$k]) {
    $n++; $c = Cls $(if ($k -eq 'Focus' -and $r0.影響營運) { '⚠' } else { [string]$r0.$st })
    [void]$sb.Append("<tr class='$c'><td data-v='$n'>$pre$n</td>")
    foreach ($col in $COLS[$k]) { $v = $r0.$col; $num = ($v -is [int] -or $v -is [double]); [void]$sb.Append($(if ($num) { "<td class=n data-v='$v'>" } else { '<td' + $(if ($col -eq '檢查表文字') { " class='cp'" } else { '' }) + '>' }) + $(if ($null -eq $v -or "$v" -eq '') { '<span class=u>—</span>' } else { Esc $v }) + '</td>') }
    if ($k -eq 'Sheet') { [void]$sb.Append("<td><button class='copy'>複製</button><br><button class='copy1'>複製成一行</button></td>") }
    [void]$sb.Append('</tr>')
  }
  if ($n -eq 0) { [void]$sb.Append("<tr class='empty'><td colspan='20'>沒有資料</td></tr>") }
  [void]$sb.Append('</tbody></table>'); return $sb.ToString()
}
$overall = if (@($R.Summary | Where-Object { $_.處置 -eq '須回報' }).Count) { '須回報' } elseif (@($R.Summary | Where-Object { $_.處置 -eq '須補查' }).Count -or $abort) { '須補查' } elseif (@($R.Summary | Where-Object { $_.處置 -ne '可結案' }).Count) { '可結案（有注意事項）' } else { '可結案' }
$color = switch ($overall) { '須回報' { '#B3261E' } '須補查' { '#6B5E00' } default { '#0C6B37' } }
$html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>VMware 每日檢查 $($runStart.ToString('yyyy-MM-dd HH:mm'))</title>
<style>body{font-family:"Microsoft JhengHei",sans-serif;margin:0;background:#f6f7f9}header{background:$color;color:#fff;padding:12px 16px}h1{margin:0;font-size:20px}.m{font-size:13px}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:8px 16px;background:#fff;border-bottom:1px solid #ddd}nav button{border:1px solid #ccc;background:#fff;padding:6px 10px;cursor:pointer;border-radius:4px}nav button.on{background:#0C6B37;color:#fff}
section{display:none;padding:12px 16px}section.on{display:block}table.t{border-collapse:collapse;background:#fff;width:100%;font-size:13px}th{background:#eef2ef;cursor:pointer}td,th{border:1px solid #ddd;padding:4px 6px;vertical-align:top}td.n{text-align:right}
.cpt{white-space:pre-wrap;line-height:1.6}.cpt.fold{display:none}button.more{display:inline-block;margin:2px 0;padding:4px 10px;border:1px solid #9AA5A0;border-radius:12px;background:#F4F6F5;cursor:pointer;font-weight:700}tr.bad td{background:#fde8e8}tr.warn td{background:#fff6dc}tr.unk td{background:#efefef}.u{color:#999}.note{font-size:13px;color:#444}</style></head><body>
<header><h1>VMware 每日檢查　結論：$(Esc $overall)</h1><div class="m">執行 $($runStart.ToString('yyyy-MM-dd HH:mm:ss'))｜執行人 $(Esc "$env:USERDOMAIN\$env:USERNAME")｜$ToolVersion｜LUN 門檻：共用 Datastore 剩餘 &lt; $LunFreeGB GB＝立即處理（本機碟不套用）$(if ($abort) { '｜⚠ 整批中止：' + (Esc $abort) })$(if ($histNote) { '｜⚠ ' + (Esc $histNote) })</div></header>
<nav id="nav"></nav>
<section id="s1" data-n="1 結論與檢查表文字"><p class="note">按「複製」後，在每日檢查表點一下那一格再貼上（Ctrl+V），多行會留在同一格。要一行版本按「複製成一行」。</p>$(Tbl 'Sheet' 'T' '處置')<h3>總表</h3>$(Tbl 'Summary' 'S' '處置')</section>
<section id="s2" data-n="2 重點整理"><p class="note">工具自動判讀；⚠影響營運＝ESXi 斷線、LUN 空間不足或無法存取、主機／儲存／叢集紅色警示。</p>$(Tbl 'Focus' 'K' '等級')</section>
<section id="s3" data-n="3 Datastore（LUN）"><p class="note">單位 GB（與 vSphere 畫面相同，1 GB＝1024³ bytes）。本機碟＝只掛在一台主機上，或名稱像 esxiXXX_Datastore，不套 $LunFreeGB GB 規則。空間預估用近 30 天每天一筆的剩餘空間算趨勢（需 7 天以上），預估 $WarnDays 天內低於門檻列本週追蹤；歷史存在 $(Esc $histFile)。</p>$(Tbl 'Ds' 'D' '判定')</section>
<section id="s4" data-n="4 ESXi">$(Tbl 'Hosts' 'H' '判定')</section>
<section id="s5" data-n="5 警示">$(Tbl 'Alarms' 'A' '判定')</section>
<section id="s6" data-n="6 收集缺口"><p class="note">沒讀到的項目，不可當成正常。</p>$(Tbl 'Gaps' 'G' '')</section>
<script>(function(){var secs=document.querySelectorAll('section'),nav=document.getElementById('nav');
function show(id){secs.forEach(function(s){s.classList.toggle('on',s.id==id)});nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-for')==id)})}
secs.forEach(function(s){var b=document.createElement('button');b.textContent=s.getAttribute('data-n');b.setAttribute('data-for',s.id);b.addEventListener('click',function(){show(s.id)});nav.appendChild(b)});
document.querySelectorAll('td.cp').forEach(function(td){var t=td.textContent,n=t.split('\n').filter(function(x){return x.trim()}).length;td.textContent='';var d=document.createElement('div');d.className='cpt';d.textContent=t;if(n>3){d.classList.add('fold');var b=document.createElement('button');b.type='button';b.className='more';var lb=function(f){b.textContent=f?'共 '+n+' 行，點開看':'收合（共 '+n+' 行）'};lb(true);td.appendChild(b);b.addEventListener('click',function(){lb(d.classList.toggle('fold'))})}td.appendChild(d)});
function cp(t){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(a);if(!ok)alert('複製失敗，請直接用滑鼠選取文字後按 Ctrl+C');return ok}
document.querySelectorAll('button.copy1').forEach(function(b){b.addEventListener('click',function(){if(!cp(b.closest('tr').querySelector('td.cp .cpt').textContent.split('\n').join('｜')))return;b.textContent='已複製';setTimeout(function(){b.textContent='複製成一行'},1500)})});
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t='"'+b.closest('tr').querySelector('td.cp .cpt').textContent.split('"').join('""')+'"';if(!cp(t))return;b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)})});
document.querySelectorAll('table.t th').forEach(function(th){th.addEventListener('click',function(){var tb=th.closest('table').tBodies[0],i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');var rows=Array.prototype.slice.call(tb.rows).filter(function(r){return !r.classList.contains('empty')});
rows.sort(function(a,b){var x=a.cells[i],y=b.cells[i];if(!x||!y)return 0;var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var r=(p!==null&&q!==null)?parseFloat(p)-parseFloat(q):x.textContent.localeCompare(y.textContent,'zh-Hant',{numeric:true});return asc?r:-r});rows.forEach(function(r){tb.appendChild(r)})})});
show('s1');})();</script></body></html>
"@
[IO.File]::WriteAllText((Join-Path $outDir 'report.html'), $html, (New-Object Text.UTF8Encoding($true)))
Write-Host ''
foreach ($x in $R.Sheet) { Write-Host ($x.項目 + '：' + $x.檢查表文字) }
Write-Host ("結論：" + $overall)
Write-Host ("報告：" + (Join-Path $outDir 'report.html'))
if (-not $NoOpen) { try { Start-Process (Join-Path $outDir 'report.html') } catch {} }
if ($remember -and -not $abort -and @($R.Summary | Where-Object { $_.完整度 -ne '查不到' }).Count) { Ask-Remember $here $rememberLines $remember 'vCenter' }
$remember = $null
exit $(switch ($overall) { '可結案' { 0 } '可結案（有注意事項）' { 1 } '須回報' { 2 } default { 3 } })

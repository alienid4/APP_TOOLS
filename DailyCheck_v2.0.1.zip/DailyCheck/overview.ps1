﻿# DailyCheck 總覽 v2.2.0 (2026-11-18)：營運一眼看「馬上處理」；天天發生的另外記錄，不混在一起
#   第一級：重要群組設備離線、ESXi 失聯、硬體壞、空間 ≥95%、WhatsUp 硬碟 ≥85%（列進硬碟例外.txt 的除外）、LUN 無法存取、查不到
#   第二級：檔案系統／Pool／LUN ≥90%、非 CPU 的紅色警示、AD 時間差異常、其他立即處理
#   備查：CPU、記憶體、維護中、黃色警示等（照樣進檢查表文字，不上「馬上處理」）；備查依種類分 6 頁
#   跟過去 7 天比：7 天內出現過＝天天發生（時好時壞也算）；等級比 7 天內任何一天都嚴重＝變嚴重，回到「馬上處理」
#   硬碟例外：只在「不再變滿」時有效；比登記時多漲超過 3 個百分點、或過了到期日，自動回第一級並上「馬上處理」
# 由 dailycheck_menu.ps1 dot-source；需要 $here、$CODE、Esc

function Csv-In([string]$dir, [string]$name, [switch]$Must) {
  $f = Join-Path $dir $name
  if (Test-Path $f) { try { return @(Import-Csv $f -Encoding UTF8 -ErrorAction Stop) } catch {} }
  if ($Must) { $script:readFail += $name }
  return @()
}
function Pct-Of([string]$t) { if ($t -match '(\d+(?:\.\d+)?)\s*%') { return [double]$Matches[1] }; return $null }
function Gb-Left([string]$t) { if ($t -match '剩\s*([\d.]+)\s*GB') { return [double]$Matches[1] }; return $null }
function New-Issue($src, [string]$key, [int]$tier, [string]$cat, [string]$what, [string]$now, [string]$todo, $metric, [string]$dirn) {
  return [pscustomobject]@{ Src = $src; Key = $key; Tier = $tier; Cat = $cat; What = $what; Now = $now; Todo = $todo; Metric = $metric; Dir = $dirn; Status = ''; Days = 1; Prev = ''; Ex = ''; Force = '' }
}
function Num-Of($v) { $x = 0.0; if ([double]::TryParse([string]$v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$x)) { return $x }; return $null }
# 硬碟例外清單：程式資料夾「硬碟例外.txt」，一行一顆（總覽「列例外」按鈕會複製好一行）：
#   裝置ID｜裝置｜磁碟｜登記時%｜到期日 yyyy-MM-dd｜原因
function Read-DiskEx {
  $script:diskEx = @{}; $script:diskExBad = @()
  $f = Join-Path $here '硬碟例外.txt'
  if (-not (Test-Path $f)) { return }
  $ln = 0
  try { $txt = Read-TextAuto $f } catch { $script:diskExBad += ('讀不到：' + $_.Exception.Message); return }
  foreach ($l in ($txt -split "`r?`n")) {
    $ln++; $t = $l.Trim(); if (-not $t -or $t.StartsWith('#')) { continue }
    $p = @($t -split '[｜|]' | ForEach-Object { $_.Trim() })
    $pct = if ($p.Count -ge 4) { Num-Of ($p[3] -replace '[%％]', '') } else { $null }
    $exp = [datetime]::MinValue
    if ($p.Count -lt 5 -or -not $p[0] -or $null -eq $pct -or $pct -lt 0 -or $pct -gt 100 -or -not [datetime]::TryParseExact($p[4], 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$exp)) { $script:diskExBad += "第 $ln 行（格式不對）"; continue }
    if ($exp -gt (Get-Date).Date.AddDays(366)) { $script:diskExBad += "第 $ln 行（到期日超過一年）"; continue }
    $why = if ($p.Count -ge 6) { ((($p[5..($p.Count - 1)]) -join '｜') -replace '^原因[:：]\s*', '').Trim() } else { '' }
    if (-not $why) { $script:diskExBad += "第 $ln 行（沒寫原因）"; continue }
    $ek = $p[0] + '|' + $p[2]
    if ($script:diskEx.ContainsKey($ek)) { $script:diskExBad += "第 $ln 行（同一顆重複，只用第一筆）"; continue }
    $script:diskEx[$ek] = @{ Pct = $pct; Exp = $exp; Why = $why }
  }
}
function Disk-Issue($s, $x) {
  $v = Num-Of $x.上次輪詢值; $hi = ([string]$x.級別 -eq '異常')
  $t = if ($hi) { 1 } else { 3 }
  $now = '上次輪詢 ' + $x.輪詢時間 + $(if ($x.PSObject.Properties['前次'] -and [string]$x.前次) { '｜前次 ' + $x.前次 + $(if ([string]$x.成長) { '（' + (([string]$x.成長) -replace "^'", '') + '）' } else { '' }) } else { '' })
  $todo = if ($hi) { '截圖發信（紙本）；確定先不處理，按「列例外」貼進 硬碟例外.txt' } else { '備查（參考）' }
  $force = ''
  $ex = if ($script:diskEx) { $script:diskEx[([string]$x.裝置ID + '|' + [string]$x.磁碟)] } else { $null }
  if ($hi -and $ex) {
    if ($null -eq $v) { $now += '｜這次讀值無效，例外不套用' }
    elseif ($ex.Exp.Date -lt (Get-Date).Date) { $now += '｜例外已到期（' + $ex.Exp.ToString('yyyy-MM-dd') + '）'; $force = '例外到期' }
    elseif ($null -ne $v -and ($v - $ex.Pct) -gt 3) { $now += '｜例外失效：登記時 ' + $ex.Pct + '%，已漲 ' + [math]::Round($v - $ex.Pct, 2) + ' 個百分點（超過 3）'; $force = '例外失效' }
    else { $t = 3; $now += '｜例外到 ' + $ex.Exp.ToString('yyyy-MM-dd') + $(if ($ex.Why) { '：' + $ex.Why } else { '' }); $todo = '例外（登記時 ' + $ex.Pct + '%；多漲超過 3 個百分點或到期，自動回第一級）' }
  }
  $i = New-Issue $s ('1|disk|' + $x.裝置ID + '|' + $x.磁碟) $t 'disk' ($x.裝置 + $(if ($x.磁碟) { ' ' + $x.磁碟 } else { '' }) + ' 硬碟 ' + $x.上次輪詢值 + '%') $now $todo $null ''
  $i.Force = $force
  if ($hi -and "$($x.裝置ID)" -ne '' -and -not ($ex -and -not $force)) { $i.Ex = (([string]$x.裝置ID), ([string]$x.裝置 -replace '[｜|]', '/'), ([string]$x.磁碟), ([string]$x.上次輪詢值 + '%'), (Get-Date).AddDays(90).ToString('yyyy-MM-dd'), '原因：') -join '｜' }
  return $i
}

function Get-Issues($r) {
  $out = New-Object System.Collections.Generic.List[object]
  $s = $r.Item.Key; $d = $r.Dir; $script:readFail = @()
  if ($d) {
    switch ($s) {
      '1' {
        foreach ($x in (Csv-In $d '01_離線裝置.csv' -Must)) { $t = if ([string]$x.重要 -eq '否') { 3 } else { 1 }; $out.Add((New-Issue $s ("1|down|" + $(if ($x.裝置ID) { $x.裝置ID } else { $x.裝置 })) $t 'down' ($x.裝置 + ' 離線') ('Device Down' + $(if (([string]$x.停擺監控).Trim()) { '｜停擺監控 ' + $x.停擺監控 } else { '' })) '發信通知負責人，確認是否停機' $null '')) }
        foreach ($x in (Csv-In $d '03_CPU.csv' | Where-Object { $_.判定 -like '超過*' })) { $out.Add((New-Issue $s ("1|cpu|" + $x.裝置ID) 3 'cpu' ($x.裝置 + ' CPU ' + $x.上次輪詢值 + '%') ('上次輪詢 ' + $x.輪詢時間) '截圖發信（紙本）' $null '')) }
        foreach ($x in (Csv-In $d '04_記憶體.csv' | Where-Object { $_.判定 -like '超過*' })) { $out.Add((New-Issue $s ("1|mem|" + $x.裝置ID) 3 'mem' ($x.裝置 + ' 記憶體 ' + $x.上次輪詢值 + '%') ('上次輪詢 ' + $x.輪詢時間) '截圖發信（紙本）' $null '')) }
        foreach ($x in (Csv-In $d '07_硬碟.csv' -Must | Where-Object { $_.判定 -like '超過*' })) { $out.Add((Disk-Issue $s $x)) }
        foreach ($x in (Csv-In $d '02_維護裝置.csv')) { $hrs = Num-Of $x.已維護小時; $long = ($null -ne $hrs -and $hrs -gt 720)
          $out.Add((New-Issue $s ("1|maint|" + $x.裝置ID) 3 'maint' ($(if ($long) { '【長期維護 ' + [math]::Floor($hrs / 24) + ' 天】' } else { '' }) + $x.裝置 + ' 維護中') ('自 ' + $x.開始 + ' ' + $x.原因) $(if ($long) { '維護超過 30 天，請確認是不是忘了解除' } else { '照紙本記錄' }) $null '')) }
      }
      '2' {
        foreach ($x in (Csv-In $d 'Focus.csv' -Must)) {
          $o = [string]$x.物件; $now = [string]$x.現況; $lv = [string]$x.等級; $k = "2|$($x.設備)|$o"
          if ($o -like '收集缺口*') { $out.Add((New-Issue $s $k 1 'gap' ($o -replace '^收集缺口', '查不到：') $now '人工登入 vSphere 確認' $null '')); continue }
          if ($o -like 'ESXi*' -and $lv -eq '立即處理') { $out.Add((New-Issue $s $k 1 'down' ($o + ' 失聯') $now $x.建議 $null '')); continue }
          if ($o -like 'Datastore*') {
            $used = $null; if ($now -match '剩\s*([\d.]+)\s*GB／共\s*([\d.]+)\s*GB' -and [double]$Matches[2] -gt 0) { $used = 100 * (1 - [double]$Matches[1] / [double]$Matches[2]) }
            $t = if ($now -match '無法存取') { 1 } elseif ($null -ne $used -and $used -ge 95) { 1 } elseif ($null -ne $used -and $used -ge 90) { 2 } else { 3 }
            if ($null -ne $used) { $now += "，用量 $([math]::Round($used, 1))%" }
            $out.Add((New-Issue $s $k $t 'space' $o $now $x.建議 $used 'up')); continue
          }
          if ($o -like '警示*') { $t = if ($o -match '(?i)CPU|memory|記憶體') { 3 } elseif ($lv -eq '立即處理') { 2 } else { 3 }; $out.Add((New-Issue $s $k $t $(if ($o -match '(?i)CPU|memory|記憶體') { 'cpu' } else { 'alarm' }) $o $now $x.建議 $null '')); continue }
          $out.Add((New-Issue $s $k $(if ($lv -eq '立即處理') { 2 } else { 3 }) 'other' $o $now $x.建議 $null ''))
        }
      }
      '3' {
        foreach ($x in (Csv-In $d '00_重點整理.csv' -Must | Where-Object { $_.等級 -notin '已恢復', '可忽略' })) {
          $o = [string]$x.物件; $now = [string]$x.現況; $lv = [string]$x.等級; $k = "3|$($x.設備)|$o"
          if ($o -like '收集缺口*') { $out.Add((New-Issue $s $k 1 'gap' ($o -replace '^收集缺口', '查不到：') $now '人工登入 Unisphere 確認' $null '')); continue }
          if ($o -like '硬體*' -and $lv -eq '立即處理') { $out.Add((New-Issue $s $k 1 'hw' $o $now $x.建議 $null '')); continue }
          $p = Pct-Of $now
          if ($o -match '^(檔案系統|Pool|LUN)' -and $null -ne $p) {
            $t = if ($p -ge 95) { 1 } elseif ($p -ge 90 -or $lv -eq '立即處理') { 2 } else { 3 }
            $out.Add((New-Issue $s $k $t 'space' $o $now $x.建議 $p 'up')); continue
          }
          $out.Add((New-Issue $s $k $(if ($lv -eq '立即處理') { 2 } else { 3 }) 'other' $o $now $x.建議 $null ''))
        }
      }
      '4' {
        foreach ($x in (Csv-In $d 'AD_net_time.csv' -Must | Where-Object { $_.判定 -ne '正常' })) {
          $t = switch ($x.判定) { '查不到' { 1 } '異常' { 2 } default { 3 } }
          $out.Add((New-Issue $s ("4|" + $x.IP) $t 'time' ("DC $($x.IP) 時間差 $($x.時間差秒) 秒") ([string]$x.說明) '確認 DC 與本機時間同步' $null ''))
        }
      }
    }
  }
  if ($s -in '2', '3') { foreach ($i in $out) { $dv = ($i.Key -split '\|')[1]; if ($dv) { $i.What = $dv + '：' + $i.What } } }
  if ($script:readFail.Count) { $out.Add((New-Issue $s "$s|gap|read" 1 'gap' ("查不到：$($r.Item.Text) 結果檔讀不到") ($script:readFail -join '、') '開詳細報告或重跑這一項' $null '')) }
  if (($r.Code -eq 3 -or -not $d) -and -not @($out | Where-Object { $_.Cat -eq 'gap' }).Count) {
    $hs = ''; try { $dl = Read-DevList $here $r.Item.Cat $r.Item.Mm $r.Item.Mn 6>$null; if ($null -ne $dl) { $hs = (($dl | ForEach-Object { Label $_ '' }) -join '、') } } catch {}   # 不要用 @()：PS5.1 對 List 會出錯
    $out.Add((New-Issue $s "$s|gap|tool" 1 'gap' ("查不到：$($r.Item.Text)" + $(if ($hs) { "（這次要查：$hs）" } else { '' })) $(if ($r.Err) { $r.Err } else { '工具查不到或資料不完整，請開詳細報告' }) '人工檢查這一項' $null ''))
  }
  return , $out
}

function Overview($res) {
  $ts = Get-Date
  $od = Join-Path (Join-Path $here 'daily_out') $ts.ToString('yyyyMMdd_HHmmss')
  New-Item -ItemType Directory -Force -Path $od | Out-Null
  if (-not $res.Count) { Write-Host '設備清單沒有任何設備，沒有產生總覽。'; return }
  $today = $ts.ToString('yyyy-MM-dd')
  Read-DiskEx
  $all = New-Object System.Collections.Generic.List[object]
  $complete = @{}
  foreach ($r in $res) { foreach ($i in (Get-Issues $r)) { $all.Add($i) }; $complete[$r.Item.Key] = ($complete[$r.Item.Key] -ne $false) -and ($r.Code -ne 3)
    # WhatsUp 硬碟有收集缺口時，不能宣稱「已恢復」（API 查不到的那幾台不知道有沒有好）
    if ($r.Item.Key -eq '1' -and $r.Dir) { $gp = @(Csv-In $r.Dir '09_收集缺口.csv'); if (@($gp | Where-Object { [string]$_.項目 -like '硬碟*' }).Count) { $complete['1'] = $false } } }

  # ---- 跟過去比（歷史存在 %LOCALAPPDATA%\DailyCheck\issues_history.json，每台電腦各自一份）
  $histNote = ''
  $hf = Join-Path (Join-Path $env:LOCALAPPDATA 'DailyCheck') 'issues_history.json'
  $runs = @()
  $mtx = New-Object Threading.Mutex($false, 'Local\DailyCheck_issues_history'); $got = $false
  try { $got = $mtx.WaitOne(60000) } catch [Threading.AbandonedMutexException] { $got = $true }
  if (-not $got) { $histNote = '另一個總覽正在寫比對紀錄，這次不比對' }
  try {
    if ($got -and (Test-Path $hf)) {
      $parsed = Get-Content $hf -Raw -Encoding UTF8 | ConvertFrom-Json
      foreach ($x in $parsed) { if ([string]$x.date -match '^\d{4}-\d{2}-\d{2}$' -and [string]$x.date -lt $today) { $runs += $x } }   # foreach 會攤平 PS5.1 的單一陣列物件
    }
  } catch { $histNote = '比對紀錄壞了，今天全部當新增（舊紀錄已另存 .bad）'; try { Copy-Item -Force $hf ($hf + '.bad') } catch {}; $runs = @() }
  $runs = @($runs | Sort-Object date)
  $seen = @{}   # key → 最近一次 {t,m,date} 與第一次出現日
  $since7 = $ts.Date.AddDays(-7).ToString('yyyy-MM-dd')
  foreach ($run in $runs) {
    foreach ($it in @($run.items)) {
      $k = [string]$it.k
      $tt = 3; [void][int]::TryParse([string]$it.t, [ref]$tt)
      if (-not $seen.ContainsKey($k)) { $seen[$k] = @{ t = $tt; m = $it.m; first = [string]$run.date; last = [string]$run.date; min7 = 9; n7 = 0 } }
      $e = $seen[$k]; $e.t = $tt; $e.m = $it.m; $e.last = [string]$run.date
      if ([string]$run.date -ge $since7) { $e.n7++; if ($tt -lt $e.min7) { $e.min7 = $tt } }
    }
  }
  foreach ($i in $all) {
    $p = $seen[$i.Key]
    if ($null -eq $p -or $p.last -lt $since7) { $i.Status = '今天新增'; $i.Days = 1; continue }
    $i.Days = $p.n7 + 1
    # 只有「升級」才算變嚴重（備查→第二級、第二級→第一級…）；數字小變化只當參考寫在紀錄表，不推上「馬上處理」（避免狼來了）
    $worse = ($i.Tier -le 2 -and $i.Tier -lt $p.min7)   # 比 7 天內任何一天都嚴重（時好時壞不會反覆跳）
    if ($null -ne $i.Metric -and $null -ne $p.m -and "$($p.m)" -ne '') {
      $pm = [double]$p.m
      if ($i.Dir -eq 'up' -and $i.Metric -ne $pm) { $i.Prev = "上次 $pm%" }
      if ($i.Dir -eq 'down' -and $i.Metric -ne $pm) { $i.Prev = "上次剩 $pm GB" }
    }
    if ($worse) { $i.Prev = (('上次' + $(switch ($p.t) { 1 { '第一級' } 2 { '第二級' } default { '備查' } })), $i.Prev | Where-Object { $_ }) -join '，' }
    $i.Status = if ($worse) { '變嚴重' } else { "近 7 天第 $($i.Days) 天出現（首次 $($p.first.Substring(5))）" }
  }
  foreach ($i in $all) { if ($i.Force) { $p = $seen[$i.Key]; if ($p -and $p.last -ge $since7 -and $p.t -le 2) { $i.Force = '' } else { $i.Status = $i.Force } } }   # 硬碟例外失效／到期：轉換那一次回到馬上處理；之後留在「第一級未解決」，不天天重報
  $lastRun = if ($runs.Count) { $runs[-1] } else { $null }
  $recovered = @()
  if ($lastRun) {
    $nowKeys = @{}; foreach ($i in $all) { $nowKeys[$i.Key] = 1 }
    $recovered = @($lastRun.items | Where-Object { [string]$_.k -notmatch '^1\|disk\|[^|]*$' -and -not $nowKeys.ContainsKey([string]$_.k) -and $complete[([string]$_.k).Split('|')[0]] -and [int]$_.t -le 2 } | ForEach-Object { [string]$_.w })
  }
  try {
    $keep = @($runs | Where-Object { [string]$_.date -ge $ts.Date.AddDays(-30).ToString('yyyy-MM-dd') })
    $keep += [pscustomobject]@{ date = $today; items = @($all | ForEach-Object { [pscustomobject]@{ k = $_.Key; t = $_.Tier; m = $_.Metric;  w = $_.What } }) }
    New-Item -ItemType Directory -Force -Path (Split-Path $hf) | Out-Null
    $tmp = $hf + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject @($keep) -Depth 5 -Compress), (New-Object Text.UTF8Encoding($false)))
    if ($got) { Move-Item -Force $tmp $hf } else { Remove-Item -Force $tmp }
  } catch { $histNote = (($histNote, ('今天的比對紀錄沒存進去：' + $_.Exception.Message)) | Where-Object { $_ }) -join '；' }
  if ($got) { try { $mtx.ReleaseMutex() } catch {} }; $mtx.Dispose()
  if (-not $runs.Count -and -not $histNote) { $histNote = '第一次執行，沒有前幾天可以比，全部當今天新增；明天起才準' }
  foreach ($r in $res) { if ($r.Item.Key -eq '1' -and $r.Dir) { try { $mf = Get-Content (Join-Path $r.Dir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json; if ($null -ne $mf.params.DiskPct -and [double]$mf.params.DiskPct -ne 85) { $histNote = (($histNote, ('注意：這次 WhatsUp 硬碟門檻是 ' + $mf.params.DiskPct + '%（不是預設 85%），分級照 ' + $mf.params.DiskPct + '% 判')) | Where-Object { $_ }) -join '；' } } catch {} } }
  if ($script:diskExBad.Count) { $histNote = (($histNote, ('硬碟例外.txt 有看不懂的行，沒套用：' + ($script:diskExBad -join '、'))) | Where-Object { $_ }) -join '；' }

  # ---- 分組
  $srcName = @{ '1' = '1 WhatsUp'; '2' = '2 VMware'; '3' = '3 Storage'; '4' = '4 AD' }
  $tierTxt = @{ 1 = '第一級'; 2 = '第二級'; 3 = '備查' }
  $urgent = @($all | Where-Object { $_.Tier -le 2 -and ($_.Status -in '今天新增', '變嚴重' -or $_.Force) } | Sort-Object Tier, @{ Expression = { if ($_.Status -ne '今天新增') { 0 } else { 1 } } }, Src)
  foreach ($i in $urgent) { if ($i.Status -eq '今天新增') { $i.Prev = '' } }   # 新增的不用附比較
  # 備查依種類分頁（順序固定，項次 R 依這個順序編，重排表格後號碼不變）
  $grpOf = @{ alarm = 0; space = 1; disk = 1; down = 2; maint = 3; cpu = 4; mem = 4 }
  $grpName = @('警示', '空間', '離線', '維護中', '效能（CPU／記憶體）', '其他')
  $other = @($all | Where-Object { $urgent -notcontains $_ } | Sort-Object @{ Expression = { if ($grpOf.ContainsKey($_.Cat)) { $grpOf[$_.Cat] } else { 5 } } }, Tier, @{ Expression = { -$_.Days } }, Src, What)
  $exBtn = { param($i) if ($i.Ex) { " <button type='button' class='exb' data-ex='" + (Esc $i.Ex) + "'>列例外</button>" } else { '' } }

  $u = New-Object Text.StringBuilder; $n = 0
  foreach ($i in $urgent) {
    $n++
    [void]$u.Append("<div class='it t$($i.Tier)'><span class='no'>★$n</span><div class='bd'><div class='hd'><span class='tg t$($i.Tier)'>$($tierTxt[$i.Tier])</span><span class='st $(if ($i.Status -ne '今天新增') { 'w' } else { 'n' })'>$(Esc $i.Status)</span><span class='src'>$(Esc $srcName[$i.Src])</span><b>$(Esc $i.What)</b>$(& $exBtn $i)</div><div class='now'>$(Esc $i.Now)$(if ($i.Prev) { '（' + (Esc $i.Prev) + '）' })</div><div class='todo'>建議：$(Esc $i.Todo)</div></div></div>")
  }
  if (-not $n) { [void]$u.Append("<div class='none'>今天沒有新發生或變嚴重的第一、二級事項。天天發生的事記在下方。</div>") }
  $gsb = @(); foreach ($g in $grpName) { $gsb += New-Object Text.StringBuilder }; $gcnt = @(0, 0, 0, 0, 0, 0); $m = 0
  foreach ($i in $other) { $m++; $g = if ($grpOf.ContainsKey($i.Cat)) { $grpOf[$i.Cat] } else { 5 }; $gcnt[$g]++
    [void]$gsb[$g].Append("<tr class='t$($i.Tier)'$(if ($i.Status -like '近 7 天*') { " data-d='1'" })><td data-v='$m'>R$m</td><td>$(Esc $srcName[$i.Src])</td><td data-v='$($i.Tier)'>$($tierTxt[$i.Tier])</td><td>$(Esc $i.What)$(& $exBtn $i)</td><td>$(Esc $i.Now)$(if ($i.Prev) { "<span class=u>（$(Esc $i.Prev)）</span>" })</td><td data-v='$($i.Days)' class='$(if ($i.Status -like '近 7 天*') { 'sd' } else { 'sn' })'>$(Esc $i.Status)</td></tr>") }
  $o = New-Object Text.StringBuilder; $firstG = -1
  [void]$o.Append("<div id='onav'><button type='button' data-g='all'>全部（$m）</button>")
  for ($g = 0; $g -lt $grpName.Count; $g++) { if ($gcnt[$g] -and $firstG -lt 0) { $firstG = $g }; [void]$o.Append("<button type='button' data-g='g$g'$(if (-not $gcnt[$g]) { ' disabled' })>$($g + 1) $(Esc $grpName[$g])（$($gcnt[$g])）</button>") }
  [void]$o.Append('</div>')
  for ($g = 0; $g -lt $grpName.Count; $g++) { if (-not $gcnt[$g]) { continue }; [void]$o.Append("<div class='bp' data-g='g$g'><h4>$($g + 1) $(Esc $grpName[$g])（$($gcnt[$g]) 件）</h4><table class='t'><thead><tr><th>項次</th><th>來源</th><th>級別</th><th>事項</th><th>現況</th><th>狀態</th></tr></thead><tbody>$($gsb[$g].ToString())</tbody></table></div>") }
  if (-not $m) { [void]$o.Append("<p class='u'>沒有</p>") }
  $firstGid = if ($firstG -ge 0) { "g$firstG" } else { 'all' }
  $rec = if ($recovered.Count) { "<p class='rec'>上次有、今天沒再出現 $($recovered.Count) 件（上次 $($lastRun.date)）：" + (($recovered | ForEach-Object { Esc $_ }) -join '、') + '</p>' } else { '' }

  # ---- 備查：各項結果與檢查表文字
  $sum = New-Object Text.StringBuilder; $tabs = New-Object Text.StringBuilder; $k = 0
  foreach ($r in $res) {
    $k++; $id = 's' + $k
    $cls = switch ($r.Code) { 2 { 'bad' } 3 { 'unk' } 0 { '' } default { 'warn' } }
    $link = if ($r.Dir) { "<a href='" + (Esc ([Uri](Join-Path $r.Dir 'report.html')).AbsoluteUri) + "' target='_blank'>開詳細報告</a>" } else { '<span class=u>沒有報告</span>' }
    [void]$sum.Append("<tr class='$cls'><td data-v='$k'>S$k</td><td><a href='#' data-go='$id'>$($r.Item.Key). $(Esc $r.Item.Text)</a></td><td>$(Esc $CODE[$r.Code])</td><td>$link</td><td>$(Esc $r.Err)</td></tr>")
    $rows = @()
    if ($r.Dir) {
      $f = @('00_檢查表文字.csv', 'Sheet.csv') | ForEach-Object { Join-Path $r.Dir $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
      if ($f) { try { $rows = @(Import-Csv $f -Encoding UTF8) } catch {} } else { $rows = Csv-In $r.Dir 'AD_net_time.csv' }
    }
    $tb = New-Object Text.StringBuilder
    if ($rows.Count) {
      $cols = @($rows[0].PSObject.Properties.Name)
      [void]$tb.Append("<table class='t'><thead><tr><th>項次</th>" + (($cols | ForEach-Object { '<th>' + (Esc $_) + '</th>' }) -join '') + $(if ($cols -contains '檢查表文字') { '<th></th>' } else { '' }) + '</tr></thead><tbody>')
      $j = 0
      foreach ($x in $rows) {
        $j++
        [void]$tb.Append("<tr><td data-v='$j'>$($r.Item.Key)-$j</td>")
        foreach ($c in $cols) { [void]$tb.Append($(if ($c -eq '檢查表文字') { "<td class='cp'>" } else { '<td>' }) + (Esc $x.$c) + '</td>') }
        if ($cols -contains '檢查表文字') { [void]$tb.Append("<td><button class='copy'>複製</button></td>") }
        [void]$tb.Append('</tr>')
      }
      [void]$tb.Append('</tbody></table>')
    } else { [void]$tb.Append('<p class=u>這一項沒有讀到檢查表文字，請開詳細報告。</p>') }
    [void]$tabs.Append("<section id='$id' data-n='$($r.Item.Key) $(Esc $r.Item.Text)'><p>結果：<b>$(Esc $CODE[$r.Code])</b>　$link</p>" + $tb.ToString() + '</section>')
  }
  $nNew = @($all | Where-Object { $_.Status -eq '今天新增' }).Count
  $nDaily = @($all | Where-Object { $_.Status -like '近 7 天*' }).Count
  $nT1 = @($all | Where-Object { $_.Tier -eq 1 }).Count
  $recHtml = "<div id='dRec'>" + $(if ($rec) { $rec } else { "<p class='rec'>上次有、今天沒再出現的事項：沒有。</p>" }) + '</div>'
  $t1Rows = New-Object Text.StringBuilder; $q = 0
  foreach ($i in @($all | Where-Object { $_.Tier -eq 1 } | Sort-Object Src)) { $q++; [void]$t1Rows.Append("<tr class='t1'><td data-v='$q'>T$q</td><td>$(Esc $srcName[$i.Src])</td><td>$(Esc $i.What)$(& $exBtn $i)</td><td>$(Esc $i.Now)</td><td>$(Esc $i.Status)</td></tr>") }
  if (-not $q) { [void]$t1Rows.Append("<tr><td colspan='5' class='u'>沒有</td></tr>") }
  $t1Html = "<details id='dT1'><summary>第一級未解決 $q 件（點開看）</summary><p class='m'>第一級＝重要群組的設備離線、ESXi 失聯、硬體壞、空間 ≥95%、WhatsUp 硬碟 ≥85%、查不到；只要還在就算在這裡，不管是不是今天才發生。硬碟確定先不處理，按「列例外」把那一行貼進程式資料夾的「硬碟例外.txt」（預設 90 天到期；多漲超過 3 個百分點會自動回來）。</p><table class='t'><thead><tr><th>項次</th><th>來源</th><th>事項</th><th>現況</th><th>狀態</th></tr></thead><tbody>$($t1Rows.ToString())</tbody></table></details>"
  $head = if ($urgent.Count) { '#A1271B' } elseif ($nT1) { '#8A5A00' } else { '#0C6B37' }
  $html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>每日檢查總覽 $($ts.ToString('yyyy-MM-dd HH:mm'))</title>
<style>
body{font-family:"Microsoft JhengHei","Noto Sans TC",sans-serif;margin:0;background:#F4F6F5;color:#1B1F1D}
.wrap{max-width:1280px;margin:0 auto;padding:16px 24px 48px}
header{background:#fff;border-bottom:1px solid #DDE3E0}header .wrap{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding-bottom:16px}
h1{margin:0;font-size:24px}.m{font-size:13px;color:#5B6460}.cnt{display:flex;gap:8px;flex-wrap:wrap}.c{display:flex;flex-direction:column;padding:8px 14px;border-radius:8px;min-width:84px;font-size:12px}.c b{font-size:24px}
.c1{background:$head;color:#fff}.c2{background:#ECEDEE;color:#3E4642}.c3{background:#E6F2EA;color:#0C6B37}.c4{background:#FFF4D6;color:#6E4A00}
.urg{background:#fff;border:2px solid $head;border-radius:12px;padding:18px;display:flex;flex-direction:column;gap:10px;margin-top:16px}.urg h2{margin:0;font-size:22px;color:$head}
.it{display:flex;gap:14px;padding:14px;border-radius:8px;background:#FAFBFA;border:1px solid #E6EAE8}.it.t1{background:#FDF1EF;border-color:#E8B4AD}
.no{font-weight:700;color:#A1271B;min-width:30px}.bd{display:flex;flex-direction:column;gap:6px;min-width:0}.hd{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.hd b{font-size:16px}
.tg{font-size:12px;font-weight:700;padding:2px 8px;border-radius:4px}.tg.t1{background:#5E120B;color:#fff}.tg.t2{background:#FBE9E7;color:#A1271B}
.st{font-size:12px;padding:2px 8px;border-radius:4px}.st.n{background:#A1271B;color:#fff}.st.w{background:#6E4A00;color:#fff}.src{font-size:13px;color:#5B6460}
.now{font-size:14px;color:#3E4642;line-height:1.6}.todo{font-size:13px;color:#0C6B37}.none{padding:14px;background:#E6F2EA;border-radius:8px;color:#0C6B37;font-weight:700}.rec{font-size:13px;color:#0C6B37;margin:0}.c[data-card]{cursor:pointer}.c[data-card]:hover{outline:2px solid #0C6B37}.c[data-card]:focus{outline:2px solid #0C6B37}details#dT1{margin-top:12px}button.exb{margin-left:8px;font-size:12px;padding:2px 8px;border:1px solid #9AA5A0;border-radius:4px;background:#fff;cursor:pointer;font-weight:400}#onav{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}#onav button{border:1px solid #CBD3CF;background:#fff;padding:8px 12px;border-radius:16px;cursor:pointer;font-size:14px;min-height:36px}#onav button.on{background:#0C6B37;color:#fff;border-color:#0C6B37}#onav button:disabled{color:#AAB2AE;cursor:default}.bp h4{margin:12px 0 6px}td.sn{color:#A1271B;font-weight:700}td.sd{color:#5B6460}
.div{display:flex;align-items:center;gap:12px;margin:28px 0 12px}.div h2{margin:0;font-size:18px;color:#3E4642;white-space:nowrap}.div i{flex:1;height:1px;background:#CBD3CF}
details{background:#fff;border:1px dashed #B9C1BD;border-radius:12px;padding:12px 18px;margin-bottom:12px}summary{cursor:pointer;font-weight:700;font-size:16px;padding:6px 0}
nav{display:flex;flex-wrap:wrap;gap:4px;border-bottom:1px solid #DDE3E0;margin-top:8px}nav button{border:1px solid transparent;background:transparent;padding:10px 16px;cursor:pointer;font-size:15px;border-radius:8px 8px 0 0;min-height:44px}nav button.on{background:#fff;border-color:#DDE3E0;border-bottom:2px solid #0C6B37;color:#0C6B37;font-weight:700}
section{display:none;padding:12px 0}section.on{display:block}table.t{border-collapse:collapse;background:#fff;width:100%;font-size:14px}th{background:#EEF2EF;cursor:pointer;text-align:left}td,th{border-bottom:1px solid #E3E8E5;padding:8px 10px;vertical-align:top}
tr.t1 td{background:#FDF3F1}tr.bad td{background:#FDF3F1}tr.warn td{background:#FFF8E6}tr.unk td{background:#F0F1F2}.u{color:#888}
.cpt{white-space:pre-wrap;line-height:1.6}.cpt.fold{display:none}button.more{display:inline-block;margin:2px 0;padding:4px 10px;border:1px solid #9AA5A0;border-radius:12px;background:#F4F6F5;cursor:pointer;font-weight:700}
</style></head><body>
<header><div class="wrap"><div><div class="m">DailyCheck 每日檢查</div><h1>$($ts.ToString('yyyy-MM-dd HH:mm')) 總覽</h1><div class="m">執行人 $(Esc "$env:USERDOMAIN\$env:USERNAME")｜跟過去 7 天比對｜唯讀$(if ($histNote) { '｜⚠ ' + (Esc $histNote) })</div></div>
<div class="cnt"><div class="c c1" data-card="urg" tabindex="0" title="點下去看明細">馬上處理<b>$($urgent.Count)</b></div><div class="c c4" data-card="t1" tabindex="0" title="點下去看明細">第一級未解決<b>$nT1</b></div><div class="c c2" data-card="daily" tabindex="0" title="點下去看明細">天天發生<b>$nDaily</b></div><div class="c c3" data-card="rec" tabindex="0" title="點下去看明細">已恢復<b>$($recovered.Count)</b></div></div></div></header>
<div class="wrap">
<div class="urg"><h2>馬上處理 $($urgent.Count) 件</h2><div class="m">只列今天新發生、變嚴重、或硬碟例外失效的第一、二級（第一級：重要群組的設備離線、ESXi 失聯、硬體壞、空間 ≥95%、WhatsUp 硬碟 ≥85%、查不到；第二級：檔案系統／Pool／LUN 用量 ≥90%、非 CPU 紅色警示）。天天發生的另外記在下面。</div>$($u.ToString())$recHtml</div>
$t1Html
<details><summary>各項執行結果與詳細報告</summary><table class="t"><thead><tr><th>項次</th><th>檢查項目</th><th>結果</th><th>詳細報告</th><th>錯誤</th></tr></thead><tbody>$($sum.ToString())</tbody></table></details>
<h3 style="margin:16px 0 0">檢查表文字（照紙本 1～4，按「複製」貼進檢查表）</h3>
<nav id="nav"></nav>
$($tabs.ToString())
<div class="div"><h2>備查（紙本與稽核用）</h2><i></i></div>
<details id="dOther"><summary>天天發生與其他紀錄 $m 件（點開看）</summary><p class="m" id="fbar" style="display:none">目前只顯示「天天發生」（近 7 天出現過的）：<b id="fcnt">0</b> 件。<a href="#" id="fall">顯示全部</a></p><p class="m">7 天內出現過的算天天發生（灰字，時好時壞也算），只記錄天數；今天第一次出現的狀態是紅字。變嚴重會自動回到「馬上處理」。CPU、記憶體、維護中、黃色警示、非重要設備離線、LUN 剩不到 600 GB（用量未達 90%）、WhatsUp 硬碟 ≥80%、<85%、列進例外的硬碟只備查。</p>
$($o.ToString())</details>
</div>
<script>(function(){var secs=document.querySelectorAll('section'),nav=document.getElementById('nav');
function show(id){secs.forEach(function(s){s.classList.toggle('on',s.id==id)});nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-for')==id)})}
secs.forEach(function(s){var b=document.createElement('button');b.textContent=s.getAttribute('data-n');b.setAttribute('data-for',s.id);b.addEventListener('click',function(){show(s.id)});nav.appendChild(b)});
document.querySelectorAll('a[data-go]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();show(a.getAttribute('data-go'));nav.scrollIntoView()})});
document.querySelectorAll('td.cp').forEach(function(td){var t=td.textContent,n=t.split('\n').filter(function(x){return x.trim()}).length;td.textContent='';var d=document.createElement('div');d.className='cpt';d.textContent=t;if(n>3){d.classList.add('fold');var b=document.createElement('button');b.type='button';b.className='more';var lb=function(f){b.textContent=f?'共 '+n+' 行，點開看':'收合（共 '+n+' 行）'};lb(true);td.appendChild(b);b.addEventListener('click',function(){lb(d.classList.toggle('fold'))})}td.appendChild(d)});
function cp(t){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(a);if(!ok)alert('複製失敗，請直接用滑鼠選取文字後按 Ctrl+C');return ok}
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t=b.closest('tr').querySelector('td.cp .cpt').textContent;if(t.indexOf('\n')>=0)t='"'+t.split('"').join('""')+'"';if(!cp(t))return;b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)})});
document.querySelectorAll('table.t th').forEach(function(th){th.addEventListener('click',function(){var tb=th.closest('table').tBodies[0],i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');var rows=Array.prototype.slice.call(tb.rows);
rows.sort(function(a,b){var x=a.cells[i],y=b.cells[i];if(!x||!y)return 0;var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var r=(p!==null&&q!==null)?parseFloat(p)-parseFloat(q):x.textContent.localeCompare(y.textContent,'zh-Hant',{numeric:true});return asc?r:-r});rows.forEach(function(r){tb.appendChild(r)})})});
function openGo(id){var e=document.getElementById(id);if(!e)return;if(e.tagName==='DETAILS')e.open=true;e.scrollIntoView({behavior:'smooth',block:'start'})}
var bts=document.querySelectorAll('#onav button'),bps=document.querySelectorAll('#dOther .bp');
function bshow(g){bps.forEach(function(p){p.style.display=(g==='all'||p.getAttribute('data-g')===g)?'':'none'});bts.forEach(function(b){b.classList.toggle('on',b.getAttribute('data-g')===g)})}
bts.forEach(function(b){b.addEventListener('click',function(){filterDaily(false);bshow(b.getAttribute('data-g'))})});bshow('$firstGid');
function filterDaily(on){var n=0;document.querySelectorAll('#dOther table.t tbody tr').forEach(function(r){var isD=r.getAttribute('data-d')==='1';r.style.display=(on&&!isD)?'none':'';if(isD)n++});if(on)bshow('all');var fc=document.getElementById('fcnt');if(fc)fc.textContent=n;var b=document.getElementById('fbar');if(b)b.style.display=on?'':'none'}
document.querySelectorAll('button.exb').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();if(!cp(b.getAttribute('data-ex')))return;b.textContent='已複製：貼進 硬碟例外.txt，最後補原因';clearTimeout(b._t);b._t=setTimeout(function(){b.textContent='列例外'},4000)})});
document.querySelectorAll('.c[data-card]').forEach(function(c){function go(){var k=c.getAttribute('data-card');if(k==='urg'){var u=document.querySelector('.urg');if(u)u.scrollIntoView({behavior:'smooth',block:'start'})}else if(k==='t1'){openGo('dT1')}else if(k==='daily'){filterDaily(true);openGo('dOther')}else if(k==='rec'){openGo('dRec')}}
 c.addEventListener('click',go);c.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}})});
var fa=document.getElementById('fall');if(fa)fa.addEventListener('click',function(e){e.preventDefault();filterDaily(false)});
if(secs.length)show(secs[0].id);})();</script></body></html>
"@
  $p = Join-Path $od '總覽.html'
  [IO.File]::WriteAllText($p, $html, (New-Object Text.UTF8Encoding($true)))
  try { Copy-Item -Force $p (Join-Path (Join-Path $here 'daily_out') '最新總覽.html') } catch {}
  Write-Host ("總覽：馬上處理 $($urgent.Count) 件、天天發生 $nDaily 件、已恢復 $($recovered.Count) 件")
  Write-Host ('總覽報告：' + $p)
  if (-not $NoOpen) { try { Start-Process $p } catch {} }
}

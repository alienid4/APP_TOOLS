@echo off
chcp 65001 >nul
setlocal
rem FtpCollect v1.1 (read-only). Exit code: 0=OK 1=PARTIAL 2=FAIL 3=not started
rem Disable PowerShell module-analysis cache file, so nothing is written to the user profile.
set "PSModuleAnalysisCachePath=NUL"
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0FtpCollect.ps1" %*
set "RC=%ERRORLEVEL%"
echo.
echo Exit code: %RC%  (0=OK 1=PARTIAL 2=FAIL 3=not started)
if "%~1"=="" pause
exit /b %RC%

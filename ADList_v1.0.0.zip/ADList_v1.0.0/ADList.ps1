﻿#requires -Version 5.1
<#
  ADList v1.0.0 (2026-11-12) -- AD 帳號清單（唯讀）
  點 ADList.bat 兩下：選範圍 → 產出 AD清單_<範圍>_<日期時間>.csv（存在本程式同一個資料夾）。
  只用 .NET 內建的 LDAP 查詢（不需要裝 RSAT／ActiveDirectory 模組），只讀不改。
#>
param([string]$Scope = '', [string]$Keyword = '')
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$VERSION = '1.0.0 (2026-11-12)'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

Write-Host "AD 帳號清單 ADList $VERSION（只讀，不改 AD）" -ForegroundColor Green
Write-Host ''

# ---- 範圍 ----
if (-not $Scope) {
    Write-Host '  1. 證券（整個網域的使用者帳號）'
    Write-Host '  2. 證券資訊處（部門欄位含「資訊處」）'
    Write-Host '  3. 自己輸入部門關鍵字'
    $Scope = (Read-Host '請選 1、2 或 3（直接 Enter＝1）').Trim()
    if (-not $Scope) { $Scope = '1' }
}
switch ($Scope) {
    '1' { $label = '證券'; $dept = '' }
    '2' { $label = '證券資訊處'; $dept = '資訊處' }
    '3' {
        if (-not $Keyword) { $Keyword = (Read-Host '部門關鍵字（例如：資訊處、交易部）').Trim() }
        if (-not $Keyword) { Write-Host '沒有輸入關鍵字，結束。' -ForegroundColor Yellow; exit 3 }
        $label = "部門含$Keyword"; $dept = $Keyword
    }
    default { Write-Host "看不懂的選項：$Scope" -ForegroundColor Yellow; exit 3 }
}

# ---- 連網域 ----
try {
    $root = New-Object DirectoryServices.DirectoryEntry('LDAP://RootDSE')
    $nc = [string]$root.Properties['defaultNamingContext'].Value
    if (-not $nc) { throw '讀不到網域名稱' }
} catch {
    Write-Host "連不到 AD：$($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host '請在已加入公司網域、用網域帳號登入的電腦上執行。' -ForegroundColor Yellow
    exit 2
}

function Esc-Ldap([string]$v) {   # LDAP 篩選值跳脫（* ( ) \ NUL）
    $sb = New-Object Text.StringBuilder
    foreach ($ch in $v.ToCharArray()) {
        switch ($ch) { '*' { [void]$sb.Append('\2a') } '(' { [void]$sb.Append('\28') } ')' { [void]$sb.Append('\29') } '\' { [void]$sb.Append('\5c') } ([char]0) { [void]$sb.Append('\00') } default { [void]$sb.Append($ch) } }
    }
    return $sb.ToString()
}
$filter = '(&(objectCategory=person)(objectClass=user)'
if ($dept) { $filter += "(department=*$(Esc-Ldap $dept)*)" }
$filter += ')'

$props = @('sAMAccountName', 'displayName', 'department', 'title', 'employeeID', 'mail', 'userAccountControl', 'lastLogonTimestamp', 'whenCreated', 'pwdLastSet', 'distinguishedName')
$ds = New-Object DirectoryServices.DirectorySearcher((New-Object DirectoryServices.DirectoryEntry("LDAP://$nc")), $filter)
$ds.PageSize = 500
$ds.SearchScope = 'Subtree'
foreach ($p in $props) { [void]$ds.PropertiesToLoad.Add($p) }

Write-Host "查詢中：$nc，範圍＝$label …"
$sw = [Diagnostics.Stopwatch]::StartNew()
function V($r, [string]$n) { if ($r.Properties.Contains($n.ToLower()) -and $r.Properties[$n.ToLower()].Count) { return $r.Properties[$n.ToLower()][0] } return $null }
function FT($v) {   # FileTime（lastLogonTimestamp、pwdLastSet）→ 日期；0 或空＝空白
    if ($null -eq $v) { return '' }
    try { $n = [long]$v; if ($n -le 0 -or $n -ge [DateTime]::MaxValue.ToFileTimeUtc()) { return '' }; return [DateTime]::FromFileTime($n).ToString('yyyy/MM/dd HH:mm') } catch { return '' }
}
$rows = New-Object System.Collections.Generic.List[object]
$res = $ds.FindAll()
try {
    foreach ($r in $res) {
        $uac = V $r 'userAccountControl'; $disabled = ($null -ne $uac) -and (([int]$uac -band 2) -ne 0)
        $dn = [string](V $r 'distinguishedName')
        $ou = (($dn -split '(?<!\\),') | Where-Object { $_ -like 'OU=*' } | ForEach-Object { $_.Substring(3) }) -join ' / '
        $wc = V $r 'whenCreated'
        $rows.Add([pscustomobject]@{
            '帳號' = [string](V $r 'sAMAccountName'); '姓名' = [string](V $r 'displayName'); '部門' = [string](V $r 'department'); '職稱' = [string](V $r 'title')
            '員編' = [string](V $r 'employeeID'); 'Email' = [string](V $r 'mail'); '狀態' = $(if ($disabled) { '停用' } else { '啟用' })
            '最後登入' = (FT (V $r 'lastLogonTimestamp')); '建立日期' = $(if ($wc) { ([datetime]$wc).ToLocalTime().ToString('yyyy/MM/dd') } else { '' })
            '密碼最後變更' = (FT (V $r 'pwdLastSet')); 'OU' = $ou })
    }
} finally { $res.Dispose() }

# 預設排序：部門、帳號；項次照這個順序編（固定不變）
$sorted = @($rows | Sort-Object '部門', '帳號')
$i = 0; $out = foreach ($x in $sorted) { $i++; $o = [ordered]@{ '項次' = $i }; foreach ($pp in $x.PSObject.Properties) { $o[$pp.Name] = $pp.Value }; [pscustomobject]$o }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$file = Join-Path $here ("AD清單_{0}_{1}.csv" -f ($label -replace '[\\/:*?"<>|]', '_'), (Get-Date).ToString('yyyyMMdd_HHmm'))
if ($i -gt 0) { $out | Export-Csv -LiteralPath $file -NoTypeInformation -Encoding UTF8 }
else { Set-Content -LiteralPath $file -Value '項次,帳號,姓名,部門,職稱,員編,Email,狀態,最後登入,建立日期,密碼最後變更,OU' -Encoding UTF8 }

$en = @($sorted | Where-Object { $_.'狀態' -eq '啟用' }).Count
Write-Host ''
Write-Host ("完成：{0} 個帳號（啟用 {1}、停用 {2}），花 {3:N0} 秒" -f $i, $en, ($i - $en), $sw.Elapsed.TotalSeconds) -ForegroundColor Green
Write-Host "檔案：$file" -ForegroundColor Green
if ($i -eq 0 -and $dept) { Write-Host "沒有部門含「$dept」的帳號；可能部門欄位沒填，或是用 OU 分部門（請告訴維護的人改成用 OU 篩）。" -ForegroundColor Yellow }
exit 0

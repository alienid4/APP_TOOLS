@echo off
rem ScreenAnytime daily job (for Task Scheduler on the central host). No prompts.
rem Layout: this file is in SA_Collect; SA_Report is the sibling folder (..\SA_Report).
rem 1) collect this host + every host in hosts.txt straight into ..\SA_Report\collect
rem 2) build the report; ..\SA_Report\report\latest.html is always the newest one
rem Log: daily_log.txt next to this file.
set "HERE=%~dp0"
set "REP=%~dp0..\SA_Report"
echo ===== %date% %time% start >> "%HERE%daily_log.txt"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%HERE%SA_Collect.ps1" -OutDir "%REP%\collect" -NoPause >> "%HERE%daily_log.txt" 2>&1
echo collect exit %errorlevel% >> "%HERE%daily_log.txt"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%REP%\SA_Report.ps1" -NoOpen >> "%HERE%daily_log.txt" 2>&1
echo report exit %errorlevel% >> "%HERE%daily_log.txt"
echo ===== %date% %time% end >> "%HERE%daily_log.txt"

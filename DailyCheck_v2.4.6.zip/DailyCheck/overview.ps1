﻿# DailyCheck 總覽 v2.4.0 (2026-11-18)：正式報告版型——頁首資訊列＋分頁（一、結論／二、須處理事項／三、追蹤事項／四、例外清單／五、檢查明細／六、檢核紀錄）
#   第一級：重要群組設備離線、ESXi 失聯、硬體壞、空間 ≥95%、WhatsUp 硬碟 ≥85%（列進硬碟例外.txt 的除外）、LUN 無法存取、查不到
#   第二級（v2.4.6 起 Storage 檔案系統／Pool ≥90% 改第一級，升降都算）：LUN ≥90%、非 CPU 的紅色警示、AD 時間差異常、其他立即處理
#   備查：CPU、記憶體、維護中、黃色警示等（照樣進檢查表文字，不上「馬上處理」）；備查依種類分 6 頁
#   跟過去 7 天比：7 天內出現過＝天天發生（時好時壞也算）；等級比 7 天內任何一天都嚴重＝變嚴重，回到「馬上處理」
#   硬碟例外：只在「不再變滿」時有效；比登記時多漲超過 3 個百分點、或過了到期日，自動回第一級並上「馬上處理」
# 由 dailycheck_menu.ps1 dot-source；需要 $here、$CODE、Esc

function Csv-In([string]$dir, [string]$name, [switch]$Must) {
  $f = Join-Path $dir $name
  if (Test-Path $f) { try { return @(Import-Csv $f -Encoding UTF8 -ErrorAction Stop) } catch {} }
  if ($Must) { $script:readFail += $name }
  return @()
}
function Pct-Of([string]$t) { if ($t -match '(\d+(?:\.\d+)?)\s*%') { return [double]$Matches[1] }; return $null }
function Gb-Left([string]$t) { if ($t -match '剩\s*([\d.]+)\s*GB') { return [double]$Matches[1] }; return $null }
function New-Issue($src, [string]$key, [int]$tier, [string]$cat, [string]$what, [string]$now, [string]$todo, $metric, [string]$dirn) {
  return [pscustomobject]@{ Src = $src; Key = $key; Tier = $tier; Cat = $cat; What = $what; Now = $now; Todo = $todo; Metric = $metric; Dir = $dirn; Status = ''; Days = 1; Prev = ''; Ex = ''; Force = '' }
}
$DcVer = 'DailyCheck v2.4.6'   # 打包時跟著改
function DaysN([string]$t) {   # 估計滿載 → 排序用天數（越快滿越小；不會滿／不知道排最後）
  if ($t -match '^已滿') { return 0 } elseif ($t -match '^1 天內') { return 0.5 } elseif ($t -match '^約 (\d+) 天') { return [double]$Matches[1] }
  elseif ($t -match '^一年以上') { return 400 } elseif ($t -match '^(無異動|下降中)') { return 9999 } else { return 99999 }
}
function Est-Show([string]$t) {   # v2.4.6：下降中也要看得出仍危險（只改顯示，排序照估計天數）
  if ($t -match '^下降中') { $s = '下降中'; if ($t -match '仍 (\d+(?:\.\d+)?)%' -and [double]$Matches[1] -ge 90) { $s += '，仍≥90%' }; if ($t -match '近 7 天最高 (\d+(?:\.\d+)?)%') { $s += '（7 天最高 ' + $Matches[1] + '%）' }; return $s }
  return (($t -replace '（.*$', '') -replace '，不估算$', '')
}
function Disk-Tbl($dir) {   # 硬碟超標明細表：≥90% 在前，再依估計滿載天數，再依使用率
  $rows = @(Csv-In $dir '07_硬碟.csv' | Where-Object { [string]$_.判定 -like '超過*' })
  if (-not $rows.Count) { return '' }
  $rows = @($rows | Sort-Object @{ e = { if ((Num-Of $_.上次輪詢值) -ge 90) { 0 } else { 1 } } }, @{ e = { DaysN ([string]$_.估計滿載) } }, @{ e = { Num-Of $_.上次輪詢值 }; Descending = $true })
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<div class='dkx'><button type='button' class='dkpop'>開新視窗看全表</button><div class='dkw'><table class='t dk'><thead><tr><th>項次</th><th>級別</th><th>設備</th><th>磁碟</th><th class='n'>使用率</th><th>前次</th><th class='n'>每日成長（百分點）</th><th class='n'>估計滿載</th></tr></thead><tbody>")
  $n = 0
  foreach ($x in $rows) { $n++
    $v = Num-Of $x.上次輪詢值; $dn = DaysN ([string]$x.估計滿載)
    $lv = if ($null -ne $v -and $v -ge 90) { '≥90%' } elseif ([string]$x.級別 -eq '異常') { '85～89%' } else { '參考' }
    $cls = if ($lv -eq '≥90%') { 'bad' } elseif ($lv -eq '85～89%') { 'warn' } else { '' }
    $est = [string]$x.估計滿載; $gv = $null
    if ($est -match '平均每天 \+?<?([\d.]+)') { $gv = $(if ($est -match '平均每天 \+?<') { 0.005 } else { Num-Of $Matches[1] }) } elseif ($est -match '^下降中（近 (\d+) 天 ([+-]?[\d.]+)') { $gv = (Num-Of $Matches[2]) / [math]::Max(1, [int]$Matches[1]) } elseif ($est -match '^無異動') { $gv = 0.0 }
    $gr = if ($null -ne $gv) { ([double]$gv).ToString('+0.00;-0.00;0.00', [Globalization.CultureInfo]::InvariantCulture) } else { '—' }
    [void]$sb.Append("<tr class='$cls'><td class='id' data-v='$n'>D$n</td><td data-v='" + $(if ($lv -eq '≥90%') { 0 } elseif ($lv -eq '85～89%') { 1 } else { 2 }) + "'>$lv</td><td>" + (Esc $x.裝置) + '</td><td>' + (Esc $x.磁碟) + "</td><td class='n' data-v='" + $(if ($null -ne $v) { $v } else { -1 }) + "'>" + $(if ($null -ne $v) { (Esc $x.上次輪詢值) + '%' } else { '—' }) + '</td><td>' + (Esc $x.前次) + "</td><td class='n' data-v='" + $(if ($null -ne $gv) { $gv } else { 0 }) + "'>" + (Esc $gr) + "</td><td class='n' data-v='$dn'>" + (Esc (Est-Show ([string]$x.估計滿載))) + '</td></tr>')
  }
  [void]$sb.Append('</tbody></table></div></div>'); return $sb.ToString()
}
function Read-Notes() {   # 備註.csv：事項代碼,設備,對象,備註,日期,登記人；同一事項以最後一列為準
  $m = @{}; $f = Join-Path $here '備註.csv'
  if (-not (Test-Path -LiteralPath $f)) { return $m }
  try { foreach ($r in @((Read-TextAuto $f) | ConvertFrom-Csv)) { $k = [string]$r.事項代碼; if (-not $k) { continue }; $r.備註 = ([string]$r.備註 -replace "^'(?=[=+\-@])", ''); if ([string]$r.備註) { $m[$k] = $r } else { $m.Remove($k) } } } catch {}
  return $m
}
function CpLine($i) {   # 一筆事項的複製文字（貼進每日檢查表）
  $p = @(@($i.IP, $i.DevN, $i.Obj) | Where-Object { $_ -and [string]$_ -ne '—' -and [string]$_ -ne '設備' }) -join ' '
  return ($p + '｜' + [string]$i.Prob + $(if ($i.ValT -and [string]$i.ValT -ne '—') { ' ' + [string]$i.ValT } else { '' }) + $(if ($i.Now) { '｜' + [string]$i.Now } else { '' }))
}
function Num-Of($v) { $x = 0.0; if ([double]::TryParse([string]$v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$x) -and -not [double]::IsNaN($x) -and -not [double]::IsInfinity($x)) { return $x }; return $null }
function Disk-Issue($s, $x) {
  $v = Num-Of $x.上次輪詢值; $hi = ([string]$x.級別 -eq '異常')
  $t = if ($hi) { 1 } else { 3 }
  $now = '上次輪詢 ' + $x.輪詢時間 + $(if ($x.PSObject.Properties['前次'] -and [string]$x.前次) { '｜前次 ' + $x.前次 + $(if ([string]$x.成長) { '（' + (([string]$x.成長) -replace "^'", '') + '）' } else { '' }) } else { '' }) + $(if ($x.PSObject.Properties['估計滿載'] -and [string]$x.估計滿載) { '｜估計滿載 ' + $x.估計滿載 } else { '' })
  $todo = if ($hi) { '截圖發信（紙本）；確定先不處理，按「列例外」貼進 硬碟例外.txt' } else { '備查（參考）' }
  $force = ''
  $ex = if ($script:diskEx) { $script:diskEx[([string]$x.裝置ID + '|' + [string]$x.磁碟)] } else { $null }
  if ($hi -and $ex) {
    if ($null -eq $v) { $now += '｜這次讀值無效，例外不套用' }
    elseif ($v -ge 98) { $now += '｜≥98%，不能例外（例外不套用）'; $force = '例外失效' }
    elseif ($ex.Exp.Date -lt (Get-Date).Date) { $now += '｜例外已到期（' + $ex.Exp.ToString('yyyy-MM-dd') + '）'; $force = '例外到期' }
    elseif ($null -ne $v -and ($v - $ex.Pct) -gt 3) { $now += '｜例外失效：登記時 ' + $ex.Pct + '%，已漲 ' + [math]::Round($v - $ex.Pct, 2) + ' 個百分點（超過 3）'; $force = '例外失效' }
    else { $t = 3; $now += '｜例外到 ' + $ex.Exp.ToString('yyyy-MM-dd') + $(if ($ex.Why) { '：' + $ex.Why } else { '' }); $todo = '例外（登記時 ' + $ex.Pct + '%；多漲超過 3 個百分點或到期，自動回第一級）' }
  }
  $i = New-Issue $s ('1|disk|' + $x.裝置ID + '|' + $x.磁碟) $t 'disk' ($x.裝置 + $(if ($x.磁碟) { ' ' + $x.磁碟 } else { '' }) + ' 硬碟 ' + $x.上次輪詢值 + '%') $now $todo $null ''
  $i.Force = $force
  $est = [string]$x.估計滿載; $gpd = $null
  if ($est -match '平均每天 \+?<?([\d.]+)') { $gpd = $(if ($est -match '平均每天 \+?<') { 0.005 } else { Num-Of $Matches[1] }) } elseif ($est -match '^下降中（近 (\d+) 天 ([+-]?[\d.]+)') { $gpd = (Num-Of $Matches[2]) / [math]::Max(1, [int]$Matches[1]) } elseif ($est -match '^無異動') { $gpd = 0.0 }
  $i | Add-Member -NotePropertyName Grow -NotePropertyValue $gpd -Force
  $i | Add-Member -NotePropertyName Est -NotePropertyValue (Est-Show $est) -Force
  $i | Add-Member -NotePropertyName EstN -NotePropertyValue (DaysN $est) -Force
  if ($hi -and "$($x.裝置ID)" -ne '' -and -not ($ex -and -not $force)) { $i.Ex = (([string]$x.裝置ID), ([string]$x.裝置 -replace '[｜|]', '/'), ([string]$x.磁碟), ([string]$x.上次輪詢值 + '%'), (Get-Date).AddDays(90).ToString('yyyy-MM-dd'), '原因：') -join '｜' }
  return $i
}

# 例外檔（v2.4.0 總覽「四、例外清單」用，只讀不改）：硬碟例外.txt 有 6 欄（裝置ID｜裝置｜磁碟｜登記%｜到期｜原因），
#   Datastore例外.txt／Storage例外.txt 有 5 欄（IP｜名稱｜登記%｜到期｜原因）；Storage 名稱前須標 Pool 或 檔案系統
function Read-ExList([string]$file, [string]$sys) {
  $out = New-Object System.Collections.Generic.List[object]
  $f = Join-Path $here $file
  if (-not (Test-Path -LiteralPath $f)) { return $out.ToArray() }
  try { $txt = Read-TextAuto $f } catch { $out.Add([pscustomobject]@{ Sys = $sys; File = $file; K1 = ''; K2 = ''; Dev = $file; Pct = $null; Exp = $null; Why = ''; Bad = '檔案讀不到' }); return $out.ToArray() }
  $isDisk = ($file -eq '硬碟例外.txt'); $ln = 0; $seenK = @{}
  foreach ($l in ($txt -split "`r?`n")) {
    $ln++; $t = $l.Trim(); if (-not $t -or $t.StartsWith('#')) { continue }
    $p = @($t -split '[｜|]' | ForEach-Object { $_.Trim() })
    $o = $(if ($isDisk) { 1 } else { 0 })   # 硬碟例外多一欄「裝置」
    $pct = if ($p.Count -ge (3 + $o)) { Num-Of ($p[2 + $o] -replace '[%％]', '') } else { $null }
    $exp = [datetime]::MinValue; $bad = ''
    $k1 = if ($p.Count -ge 1) { $p[0] } else { '' }
    $k2 = if ($isDisk) { if ($p.Count -ge 3) { $p[2] } else { '' } } elseif ($p.Count -ge 2) { $p[1] } else { '' }
    $dev = if ($isDisk) { $(if ($p.Count -ge 2) { $p[1] } else { $k1 }) + ' ' + $k2 } else { $k1 + '／' + $k2 }
    if ($p.Count -lt (4 + $o) -or -not $k1 -or -not $k2 -or $null -eq $pct -or $pct -lt 0 -or $pct -gt 100 -or -not [datetime]::TryParseExact($p[3 + $o], 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$exp)) { $bad = "第 $ln 行格式不符" }
    elseif ($exp -gt (Get-Date).Date.AddDays(366)) { $bad = "第 $ln 行到期日超過一年" }
    $why = if ($p.Count -ge (5 + $o)) { ((($p[(4 + $o)..($p.Count - 1)]) -join '｜') -replace '^原因[:：]\s*', '').Trim() } else { '' }
    if (-not $bad -and -not $why) { $bad = "第 $ln 行未填原因" }
    if (-not $bad -and $sys -eq 'Storage' -and $k2 -notmatch '^(Pool|檔案系統)\s+\S') { $bad = "第 $ln 行名稱前須標明 Pool 或 檔案系統" }
    $kk = $k1.ToLowerInvariant() + '|' + $k2
    if (-not $bad -and $seenK.ContainsKey($kk)) { $bad = "第 $ln 行重複" }
    if (-not $bad) { $seenK[$kk] = 1 }
    $out.Add([pscustomobject]@{ Sys = $sys; File = $file; K1 = $k1; K2 = $k2; Dev = $(if ($bad -and $p.Count -lt 2) { $t } else { $dev }); Pct = $pct; Exp = $(if ($exp -ne [datetime]::MinValue) { $exp } else { $null }); Why = $why; Bad = $bad })
  }
  return $out.ToArray()
}

# 例外清單（v2.4.0 起正本）：程式資料夾「例外清單.csv」，UTF-8 with BOM（Excel 另存的 ANSI／cp950 也讀得懂）
#   欄位：類別,地點,IP,設備名稱,對象,裝置ID,登記使用率,到期日,原因,登記日,登記人,簽呈文號,核准日
#   類別＝硬碟／Datastore／Storage；硬碟用 裝置ID＋對象（磁碟）比對；Datastore 用 IP（vCenter）＋對象（「Datastore 名稱」或只寫名稱）；
#   Storage 用 IP＋對象（「Pool 名稱」或「檔案系統 名稱」）。舊的 硬碟例外.txt／Datastore例外.txt／Storage例外.txt 仍會讀（CSV 沒有同一筆才用）
$ExCols = @('類別', '地點', 'IP', '設備名稱', '對象', '裝置ID', '登記使用率', '到期日', '原因', '登記日', '登記人', '簽呈文號', '核准日')
function Parse-ExDate([string]$t) {
  $d = [datetime]::MinValue; $t = ([string]$t).Trim()
  foreach ($f in 'yyyy-MM-dd', 'yyyy/MM/dd', 'yyyy/M/d', 'yyyy-M-d') { if ([datetime]::TryParseExact($t, $f, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$d)) { return $d } }
  return $null
}
# 比對鍵：類別｜IP 或裝置ID｜對象，一律 ToLowerInvariant（與報告 JS、採集器約定一致）；Datastore 的「Datastore 」前綴在讀檔時去一次，這裡不再去
function Ex-Key([string]$sys, [string]$k1, [string]$k2) { return ($sys + '|' + ([string]$k1).Trim() + '|' + ([string]$k2).Trim()).ToLowerInvariant() }
function Read-ExCsv {
  $out = New-Object System.Collections.Generic.List[object]
  $f = Join-Path $here '例外清單.csv'
  if (-not (Test-Path -LiteralPath $f)) { return $out.ToArray() }
  $rows = @()
  try { $rows = @((Read-TextAuto $f) | ConvertFrom-Csv) } catch { $out.Add([pscustomobject]@{ Sys = ''; File = '例外清單.csv'; K1 = ''; K2 = ''; Dev = '例外清單.csv'; Pct = $null; Exp = $null; Why = ''; Bad = '檔案讀不到（' + $_.Exception.Message + '）'; Sup = ''; Csv = $true; Loc = ''; IPx = ''; DevN = ''; Obj = ''; Reg = ''; RegD = ''; Doc = ''; AppD = ''; AppOk = $false }); return $out.ToArray() }
  $ln = 1; $lastOf = @{}
  foreach ($x in $rows) {
    $ln++
    $g = { param($n) if ($x.PSObject.Properties[$n]) { ([string]$x.$n).Trim() } else { '' } }
    $cat = & $g '類別'; $sys = switch ($cat) { '硬碟' { 'WhatsUp' } 'Datastore' { 'VMware' } 'Storage' { 'Storage' } default { '' } }
    $ip = & $g 'IP'; $obj = & $g '對象'; $id = & $g '裝置ID'
    if (-not ($cat + $ip + $obj + $id + (& $g '原因'))) { continue }   # 整列空白
    $k1 = if ($sys -eq 'WhatsUp') { $id } else { $ip }
    $k2 = if ($sys -eq 'VMware') { $obj -creplace '^Datastore ', '' } else { $obj }   # 只去開頭一次
    $pct = Num-Of ((& $g '登記使用率') -replace '[%％]', '')
    $exp = Parse-ExDate (& $g '到期日')
    $why = (& $g '原因') -replace '^原因[:：]\s*', ''
    $doc = & $g '簽呈文號'; $appD = & $g '核准日'; $appDt = Parse-ExDate $appD
    $bad = ''
    if (-not $sys) { $bad = "第 $ln 列類別不符（應為 硬碟／Datastore／Storage）" }
    elseif (-not $k1 -or -not $k2) { $bad = "第 $ln 列缺 " + $(if ($sys -eq 'WhatsUp') { '裝置ID' } else { 'IP' }) + ' 或對象' }
    elseif ($null -eq $pct -or $pct -lt 0 -or $pct -gt 100) { $bad = "第 $ln 列登記使用率不符" }
    elseif (-not $exp) { $bad = "第 $ln 列到期日不符（yyyy-MM-dd）" }
    elseif ($exp -gt (Get-Date).Date.AddDays(366)) { $bad = "第 $ln 列到期日超過一年" }
    elseif (-not $why) { $bad = "第 $ln 列未填原因" }
    elseif ($sys -eq 'Storage' -and $k2 -notmatch '^(Pool|檔案系統)\s+\S') { $bad = "第 $ln 列對象須以 Pool 或 檔案系統 開頭" }
    $o = [pscustomobject]@{ Sys = $sys; File = '例外清單.csv'; K1 = $k1; K2 = $k2; Dev = $(if ($obj) { $obj } else { "第 $ln 列" }); Pct = $pct; Exp = $exp; Why = $why; Bad = $bad; Sup = ''; Csv = $true; Line = $ln
      Loc = (& $g '地點'); IPx = $ip; DevN = (& $g '設備名稱'); Obj = $obj; Reg = (& $g '登記人'); RegD = (& $g '登記日'); Doc = $doc; AppD = $appD
      AppOk = [bool]($doc -and $appDt -and $appDt -le (Get-Date).Date) }   # 已核准＝有簽呈文號＋有效核准日（不晚於今天）
    if (-not $bad) { $ek = Ex-Key $sys $k1 $k2; if ($lastOf.ContainsKey($ek)) { $prev = $lastOf[$ek]; $prev.Sup = "被第 $ln 列取代" }; $lastOf[$ek] = $o }   # 同一對象以最後一筆有效列為準（與採集器一致）
    $out.Add($o)
  }
  return $out.ToArray()
}
# 例外清單.csv 不存在、但有舊 txt 例外檔：本次自動轉成 例外清單.csv 一次，舊檔改名 .已轉換_日期 保留
function Convert-OldEx {
  $script:exConvNote = ''
  $csv = Join-Path $here '例外清單.csv'
  if (Test-Path -LiteralPath $csv) { return }
  $olds = @(@('硬碟例外.txt', 'WhatsUp', '硬碟'), @('Datastore例外.txt', 'VMware', 'Datastore'), @('Storage例外.txt', 'Storage', 'Storage') | Where-Object { Test-Path -LiteralPath (Join-Path $here $_[0]) })
  if (-not $olds.Count) { return }
  $q = { param($v) $v = ([string]$v) -replace '[\r\n\t]', ' '; if ($v -match '[",]') { '"' + ($v -replace '"', '""') + '"' } else { $v } }
  $sb = New-Object Text.StringBuilder; [void]$sb.Append(($ExCols -join ',') + "`r`n"); $nOk = 0; $nBad = 0
  foreach ($o in $olds) {
    foreach ($e in @(Read-ExList $o[0] $o[1])) {
      if ($e.Bad) { $nBad++; continue }
      $nOk++
      $dn = if ($o[1] -eq 'WhatsUp') { ([string]$e.Dev).Substring(0, [math]::Max(0, ([string]$e.Dev).Length - ([string]$e.K2).Length - 1)) } else { '' }
      $vals = @($o[2], '', $(if ($o[1] -eq 'WhatsUp') { '' } else { $e.K1 }), $dn, $(if ($o[1] -eq 'VMware') { 'Datastore ' + $e.K2 } else { $e.K2 }), $(if ($o[1] -eq 'WhatsUp') { $e.K1 } else { '' }), ([string]$e.Pct + '%'), $e.Exp.ToString('yyyy-MM-dd'), $e.Why, '', '舊例外檔轉入', '', '')
      [void]$sb.Append((($vals | ForEach-Object { & $q $_ }) -join ',') + "`r`n")
    }
  }
  try {
    $tmp = $csv + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($tmp, $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
    Move-Item -LiteralPath $tmp -Destination $csv -ErrorAction Stop
    $sfx = '.已轉換_' + (Get-Date).ToString('yyyyMMdd')
    foreach ($o in $olds) { $src = Join-Path $here $o[0]; $dst = $src + $sfx; if (Test-Path -LiteralPath $dst) { $dst = $src + $sfx + '_' + (Get-Date).ToString('HHmmss') }; Move-Item -LiteralPath $src -Destination $dst -ErrorAction Stop }
    $script:exConvNote = "已將舊例外檔（" + (($olds | ForEach-Object { $_[0] }) -join '、') + "）轉入 例外清單.csv：$nOk 筆" + $(if ($nBad) { "；格式不符未轉入 $nBad 行" } else { '' }) + "；舊檔改名為 *$sfx 保留"
  } catch {
    if ($tmp -and (Test-Path -LiteralPath $tmp)) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    $script:exConvNote = '舊例外檔轉入 例外清單.csv 失敗：' + $_.Exception.Message
  }
}
function Read-AllEx { return @(Read-ExCsv) }
# 硬碟例外（判定用）：例外清單.csv 的「硬碟」列，同一顆以最後一筆有效列為準
function Read-DiskEx {
  Convert-OldEx
  $script:diskEx = @{}; $script:diskExBad = @()
  foreach ($e in @(Read-AllEx)) {
    if ($e.Bad) { $script:diskExBad += ($e.File + ' ' + $e.Bad); continue }
    if ($e.Sys -ne 'WhatsUp' -or $e.Sup) { continue }
    $script:diskEx[([string]$e.K1 + '|' + [string]$e.K2)] = @{ Pct = $e.Pct; Exp = $e.Exp; Why = $e.Why }
  }
}
# 例外簽呈附件：自己組 OpenXML（不靠 Excel COM、不靠外部模組）
function Xml-Esc([string]$s) {
  # 只留 XML 1.0 合法字元（成對代理字元保留；孤立代理、U+FFFE/U+FFFF、控制字元去掉）；字面上的 _xHHHH_ 先跳脫，避免 Excel 誤解
  $sb0 = New-Object Text.StringBuilder; $t = [string]$s
  for ($k = 0; $k -lt $t.Length; $k++) { $c = [int]$t[$k]
    if ($c -ge 0xD800 -and $c -le 0xDBFF) { if ($k + 1 -lt $t.Length -and [int]$t[$k + 1] -ge 0xDC00 -and [int]$t[$k + 1] -le 0xDFFF) { [void]$sb0.Append($t[$k]).Append($t[$k + 1]); $k++ }; continue }
    if ($c -ge 0xDC00 -and $c -le 0xDFFF) { continue }
    if ($c -eq 9 -or $c -eq 10 -or $c -eq 13 -or ($c -ge 0x20 -and $c -le 0xFFFD)) { [void]$sb0.Append($t[$k]) } }
  $t = $sb0.ToString() -replace '_(x[0-9A-Fa-f]{4}_)', '_x005F_$1'
  return [Security.SecurityElement]::Escape($t)
}
function Write-ExXlsx([string]$path, $rowsAll, [string]$today) {
  Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
  $hdr = @('項次', '類別', '地點', 'IP', '設備名稱', '對象', '登記使用率', '目前使用率', '到期日', '原因', '登記人', '登記日', '簽呈文號')
  $wid = @(6, 10, 8, 15, 28, 26, 11, 11, 12, 30, 14, 12, 16)
  $colL = { param($c) [string][char](65 + $c) }
  $sheetXml = {
    param($rows)
    $sb = New-Object Text.StringBuilder
    [void]$sb.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
    [void]$sb.Append('<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>')
    for ($c = 0; $c -lt $wid.Count; $c++) { [void]$sb.Append("<col min=""$($c + 1)"" max=""$($c + 1)"" width=""$($wid[$c])"" customWidth=""1""/>") }
    [void]$sb.Append('</cols><sheetData>')
    $cell = { param($ref, $v, $st) "<c r=""$ref"" s=""$st"" t=""inlineStr""><is><t xml:space=""preserve"">" + (Xml-Esc $v) + '</t></is></c>' }
    [void]$sb.Append('<row r="1">' + (& $cell 'A1' 'DailyCheck 例外（暫不處理）申請清單' 1) + '</row>')
    [void]$sb.Append('<row r="2">' + (& $cell 'A2' ('產出日期 ' + $today + '　申請單位：＿＿＿＿') 0) + '</row>')
    [void]$sb.Append('<row r="4">'); for ($c = 0; $c -lt $hdr.Count; $c++) { [void]$sb.Append((& $cell ((& $colL $c) + '4') $hdr[$c] 2)) }; [void]$sb.Append('</row>')
    $r = 4; $n = 0
    foreach ($x in $rows) { $r++; $n++
      $vals = @([string]$n, $x.Cat, $x.Loc, $x.IP, $x.DevN, $x.Obj, $x.Pct, $x.Cur, $x.Exp, $x.Why, $x.Reg, $x.RegD, $x.Doc)
      [void]$sb.Append("<row r=""$r"">"); for ($c = 0; $c -lt $vals.Count; $c++) { [void]$sb.Append((& $cell ((& $colL $c) + $r) $vals[$c] 3)) }; [void]$sb.Append('</row>') }
    if (-not $n) { $r++; [void]$sb.Append("<row r=""$r"">" + (& $cell "A$r" '（無）' 3) + '</row>') }
    $r += 3; [void]$sb.Append("<row r=""$r"">" + (& $cell "A$r" '申請人＿＿＿＿　科主管＿＿＿＿　部門主管＿＿＿＿' 0) + '</row>')
    [void]$sb.Append('</sheetData><pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/></worksheet>')
    $sb.ToString()
  }
  $pend = @($rowsAll | Where-Object { $_.Pending })
  $files = [ordered]@{
    '[Content_Types].xml' = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'
    '_rels/.rels' = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    'xl/workbook.xml' = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="12300"/></bookViews><sheets><sheet name="待簽核" sheetId="1" r:id="rId1"/><sheet name="全部例外" sheetId="2" r:id="rId2"/></sheets></workbook>'
    'xl/_rels/workbook.xml.rels' = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
    'xl/styles.xml' = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="微軟正黑體"/></font><font><b/><sz val="14"/><name val="微軟正黑體"/></font><font><b/><sz val="11"/><name val="微軟正黑體"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7F2EC"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
    'xl/worksheets/sheet1.xml' = (& $sheetXml $pend)
    'xl/worksheets/sheet2.xml' = (& $sheetXml @($rowsAll))
  }
  $tmp = $path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  try {
  $fs = [IO.File]::Open($tmp, [IO.FileMode]::CreateNew)
  try {
    $zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
    try { foreach ($k in $files.Keys) { $en = $zip.CreateEntry($k); $w = New-Object IO.StreamWriter($en.Open(), (New-Object Text.UTF8Encoding($false))); try { $w.Write($files[$k]) } finally { $w.Dispose() } } } finally { $zip.Dispose() }
  } finally { $fs.Dispose() }
  Move-Item -Force -LiteralPath $tmp -Destination $path -ErrorAction Stop
  } finally { if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } }
}

function Get-Issues($r) {
  $out = New-Object System.Collections.Generic.List[object]
  $s = $r.Item.Key; $d = $r.Dir; $script:readFail = @()
  if ($d) {
    switch ($s) {
      '1' {
        foreach ($x in (Csv-In $d '01_離線裝置.csv' -Must)) { $t = if ([string]$x.重要 -eq '否') { 3 } else { 1 }; $out.Add((New-Issue $s ("1|down|" + $(if ($x.裝置ID) { $x.裝置ID } else { $x.裝置 })) $t 'down' ($x.裝置 + ' 離線') ('Device Down' + $(if (([string]$x.停擺監控).Trim()) { '｜停擺監控 ' + $x.停擺監控 } else { '' })) '發信通知負責人，確認是否停機' $null '')) }
        foreach ($x in (Csv-In $d '03_CPU.csv' | Where-Object { $_.判定 -like '超過*' })) { $out.Add((New-Issue $s ("1|cpu|" + $x.裝置ID) 3 'cpu' ($x.裝置 + ' CPU ' + $x.上次輪詢值 + '%') ('上次輪詢 ' + $x.輪詢時間) '截圖發信（紙本）' $null '')) }
        foreach ($x in (Csv-In $d '04_記憶體.csv' | Where-Object { $_.判定 -like '超過*' })) { $out.Add((New-Issue $s ("1|mem|" + $x.裝置ID) 3 'mem' ($x.裝置 + ' 記憶體 ' + $x.上次輪詢值 + '%') ('上次輪詢 ' + $x.輪詢時間) '截圖發信（紙本）' $null '')) }
        foreach ($x in @(Csv-In $d '00_檢查表文字.csv' | Where-Object { [string]$_.項次 -eq '5' -and [string]$_.判定 -eq '人工' })) { $out.Add((New-Issue $s '1|gap|swap' 1 'gap' ('查不到：Linux_SWAP 沒有自動讀到，須人工檢查') ([string]$x.檢查表文字) '照紙本人工檢查 SWAP' $null '')) }
        foreach ($x in (Csv-In $d '08_SWAP.csv' | Where-Object { $_.判定 -like '超過*' })) { $out.Add((New-Issue $s ("1|swap|" + $x.裝置ID) 3 'swap' ($x.裝置 + ' SWAP ' + $x.上次輪詢值 + '%') ('上次輪詢 ' + $x.輪詢時間) '截圖發信（紙本）' $null '')) }
        foreach ($x in (Csv-In $d '07_硬碟.csv' -Must | Where-Object { $_.判定 -like '超過*' })) { $out.Add((Disk-Issue $s $x)) }
        foreach ($x in (Csv-In $d '02_維護裝置.csv')) { $hrs = Num-Of $x.已維護小時; $long = ($null -ne $hrs -and $hrs -gt 720)
          $out.Add((New-Issue $s ("1|maint|" + $x.裝置ID) 3 'maint' ($(if ($long) { '【長期維護 ' + [math]::Floor($hrs / 24) + ' 天】' } else { '' }) + $x.裝置 + ' 維護中') ('自 ' + $x.開始 + ' ' + $x.原因) $(if ($long) { '維護超過 30 天，請確認是不是忘了解除' } else { '照紙本記錄' }) $null '')) }
      }
      '2' {
        foreach ($x in (Csv-In $d 'Focus.csv' -Must)) {
          $o = [string]$x.物件; $now = [string]$x.現況; $lv = [string]$x.等級; $k = "2|$($x.設備)|$o"
          if ($o -like '收集缺口*') { $out.Add((New-Issue $s $k 1 'gap' ($o -replace '^收集缺口', '查不到：') $now '人工登入 vSphere 確認' $null '')); continue }
          if ($o -like 'ESXi*' -and $lv -eq '立即處理') { $out.Add((New-Issue $s $k 1 'down' ($o + ' 失聯') $now $x.建議 $null '')); continue }
          if ($o -like 'Datastore*') {
            $used = $null
            if ($now -match '使用率\s*([\d.]+)%') { $used = [double]$Matches[1] }
            elseif ($now -match '剩\s*([\d.]+)\s*GB／共\s*([\d.]+)\s*GB' -and [double]$Matches[2] -gt 0) { $used = 100 * (1 - [double]$Matches[1] / [double]$Matches[2]) }
            $t = if ($now -match '無法存取') { 1 } elseif ($null -ne $used -and $used -ge 95) { 1 } elseif ($null -ne $used -and $used -ge 90) { 2 } else { 3 }
            if ($null -ne $used -and $now -notmatch '使用率') { $now += "，用量 $([math]::Round($used, 1))%" }
            $dsi = New-Issue $s $k $t 'space' $o $now $x.建議 $used 'up'
            if ($now -notmatch '無法存取' -and $null -ne $used) { $dsi.Ex = ((([string]$x.設備) -split '_')[-1] + '｜' + ($o -replace '^Datastore\s+', '') + '｜' + [math]::Round($used, 1) + '%｜' + (Get-Date).AddDays(90).ToString('yyyy-MM-dd') + '｜原因：') }
            $out.Add($dsi); continue
          }
          if ($o -like '警示*') { $t = if ($o -match '(?i)CPU|memory|記憶體') { 3 } elseif ($lv -eq '立即處理') { 2 } else { 3 }; $out.Add((New-Issue $s $k $t $(if ($o -match '(?i)CPU|memory|記憶體') { 'cpu' } else { 'alarm' }) $o $now $x.建議 $null '')); continue }
          $out.Add((New-Issue $s $k $(if ($lv -eq '立即處理') { 2 } else { 3 }) 'other' $o $now $x.建議 $null ''))
        }
      }
      '3' {
        $stG = @{}; foreach ($g in @(Csv-In $d '04_Pool.csv')) { $stG[([string]$g.設備 + '|Pool ' + [string]$g.Pool).ToLowerInvariant()] = $g }; foreach ($g in @(Csv-In $d '06_檔案系統.csv')) { $stG[([string]$g.設備 + '|檔案系統 ' + [string]$g.檔案系統).ToLowerInvariant()] = $g }   # v2.4.6
        foreach ($x in (Csv-In $d '00_重點整理.csv' -Must | Where-Object { $_.等級 -notin '已恢復', '可忽略' })) {
          $o = [string]$x.物件; $now = [string]$x.現況; $lv = [string]$x.等級; $k = "3|$($x.設備)|$o"
          if ($o -like '收集缺口*') { $out.Add((New-Issue $s $k 1 'gap' ($o -replace '^收集缺口', '查不到：') $now '人工登入 Unisphere 確認' $null '')); continue }
          if ($o -like '硬體*' -and $lv -eq '立即處理') { $out.Add((New-Issue $s $k 1 'hw' $o $now $x.建議 $null '')); continue }
          $p = Pct-Of $now
          if ($o -match '^(檔案系統|Pool|LUN)' -and $null -ne $p) {
            $t = if ($o -match '^(檔案系統|Pool)' -and $p -ge 90) { 1 } elseif ($p -ge 95) { 1 } elseif ($p -ge 90 -or $lv -eq '立即處理') { 2 } else { 3 }   # v2.4.6：檔案系統／Pool ≥90% 第一級
            $sti = New-Issue $s $k $t 'space' $o $now $x.建議 $p 'up'
            $sg = $stG[([string]$x.設備 + '|' + $o).ToLowerInvariant()]
            if ($sg -and $sg.PSObject.Properties['估計滿載'] -and [string]$sg.估計滿載) { $sti | Add-Member -NotePropertyName Grow -NotePropertyValue $(if ($sg.PSObject.Properties['每日成長']) { Num-Of $sg.每日成長 } else { $null }) -Force; $sti | Add-Member -NotePropertyName Est -NotePropertyValue (Est-Show ([string]$sg.估計滿載)) -Force; $sti | Add-Member -NotePropertyName EstN -NotePropertyValue (DaysN ([string]$sg.估計滿載)) -Force }
            if ($o -match '^(檔案系統|Pool)\s+(.+)$') { $sti.Ex = ([string]$x.設備 + '｜' + $Matches[1] + ' ' + $Matches[2] + '｜' + $p + '%｜' + (Get-Date).AddDays(90).ToString('yyyy-MM-dd') + '｜原因：') }
            $out.Add($sti); continue
          }
          $out.Add((New-Issue $s $k $(if ($lv -eq '立即處理') { 2 } else { 3 }) 'other' $o $now $x.建議 $null ''))
        }
      }
      '4' {
        foreach ($x in (Csv-In $d 'AD_net_time.csv' -Must | Where-Object { $_.判定 -ne '正常' })) {
          $t = switch ($x.判定) { '查不到' { 1 } '異常' { 2 } default { 3 } }
          $out.Add((New-Issue $s ("4|" + $x.IP) $t 'time' ("DC $($x.IP) 時間差 $($x.時間差秒) 秒") ([string]$x.說明) '確認 DC 與本機時間同步' $null ''))
        }
      }
    }
  }
  if ($s -in '2', '3') { foreach ($i in $out) { $dv = ($i.Key -split '\|')[1]; if ($dv) { $i.What = $dv + '：' + $i.What } } }
  if ($script:readFail.Count) { $out.Add((New-Issue $s "$s|gap|read" 1 'gap' ("查不到：$($r.Item.Text) 結果檔讀不到") ($script:readFail -join '、') '開詳細報告或重跑這一項' $null '')) }
  if (($r.Code -eq 3 -or -not $d) -and -not @($out | Where-Object { $_.Cat -eq 'gap' }).Count) {
    $hs = ''; try { $dl = Read-DevList $here $r.Item.Cat $r.Item.Mm $r.Item.Mn 6>$null; if ($null -ne $dl) { $hs = (($dl | ForEach-Object { Label $_ '' }) -join '、') } } catch {}   # 不要用 @()：PS5.1 對 List 會出錯
    $out.Add((New-Issue $s "$s|gap|tool" 1 'gap' ("查不到：$($r.Item.Text)" + $(if ($hs) { "（這次要查：$hs）" } else { '' })) $(if ($r.Err) { $r.Err } else { '工具查不到或資料不完整，請開詳細報告' }) '人工檢查這一項' $null ''))
  }
  return , $out
}

function Overview($res) {
  $ts = Get-Date
  $od = Join-Path (Join-Path $here 'daily_out') $ts.ToString('yyyyMMdd_HHmmss')
  New-Item -ItemType Directory -Force -Path $od | Out-Null
  if (-not $res.Count) { Write-Host '設備清單沒有任何設備，沒有產生總覽。'; return }
  $today = $ts.ToString('yyyy-MM-dd')
  Read-DiskEx
  $all = New-Object System.Collections.Generic.List[object]
  $complete = @{}
  foreach ($r in $res) { foreach ($i in (Get-Issues $r)) { $all.Add($i) }; $complete[$r.Item.Key] = ($complete[$r.Item.Key] -ne $false) -and ($r.Code -ne 3)
    # WhatsUp 硬碟有收集缺口時，不能宣稱「已恢復」（API 查不到的那幾台不知道有沒有好）
    if ($r.Item.Key -eq '1' -and $r.Dir) { $gp = @(Csv-In $r.Dir '09_收集缺口.csv'); if (@($gp | Where-Object { [string]$_.項目 -like '硬碟*' }).Count) { $complete['1'] = $false } } }

  foreach ($i in $all) { if ($i.Cat -eq 'gap' -or ([string]$i.Src -eq '4' -and $i.Tier -eq 1)) { $complete[[string]$i.Src] = $false } }   # 有任何查不到，這一區就不能宣稱「已恢復」
  # ---- 跟過去比（歷史存在 %LOCALAPPDATA%\DailyCheck\issues_history.json，每台電腦各自一份）
  $histNote = ''
  $hf = Join-Path (Join-Path $env:LOCALAPPDATA 'DailyCheck') 'issues_history.json'
  $runs = @()
  $mtx = New-Object Threading.Mutex($false, 'Local\DailyCheck_issues_history'); $got = $false
  try { $got = $mtx.WaitOne(60000) } catch [Threading.AbandonedMutexException] { $got = $true }
  if (-not $got) { $histNote = '另一個總覽正在寫比對紀錄，這次不比對' }
  try {
    if ($got -and (Test-Path $hf)) {
      $parsed = Get-Content $hf -Raw -Encoding UTF8 | ConvertFrom-Json
      foreach ($x in $parsed) { if ([string]$x.date -match '^\d{4}-\d{2}-\d{2}$' -and [string]$x.date -lt $today) { $runs += $x } }   # foreach 會攤平 PS5.1 的單一陣列物件
    }
  } catch { $histNote = '比對紀錄壞了，今天全部當新增（舊紀錄已另存 .bad）'; try { Copy-Item -Force $hf ($hf + '.bad') } catch {}; $runs = @() }
  $runs = @($runs | Sort-Object date)
  $seen = @{}   # key → 最近一次 {t,m,date} 與第一次出現日
  $since7 = $ts.Date.AddDays(-7).ToString('yyyy-MM-dd')
  foreach ($run in $runs) {
    foreach ($it in @($run.items)) {
      $k = [string]$it.k
      $tt = 3; [void][int]::TryParse([string]$it.t, [ref]$tt)
      if (-not $seen.ContainsKey($k)) { $seen[$k] = @{ t = $tt; m = $it.m; first = [string]$run.date; last = [string]$run.date; min7 = 9; n7 = 0 } }
      $e = $seen[$k]; $e.t = $tt; $e.m = $it.m; $e.last = [string]$run.date
      if ([string]$run.date -ge $since7) { $e.n7++; if ($tt -lt $e.min7) { $e.min7 = $tt } }
    }
  }
  foreach ($i in $all) {
    $p = $seen[$i.Key]
    if ($null -eq $p -or $p.last -lt $since7) { $i.Status = '今天新增'; $i.Days = 1; continue }
    $i.Days = $p.n7 + 1
    # 只有「升級」才算變嚴重（備查→第二級、第二級→第一級…）；數字小變化只當參考寫在紀錄表，不推上「馬上處理」（避免狼來了）
    $worse = ($i.Tier -le 2 -and $i.Tier -lt $p.min7)   # 比 7 天內任何一天都嚴重（時好時壞不會反覆跳）
    if ($null -ne $i.Metric -and $null -ne $p.m -and "$($p.m)" -ne '') {
      $pm = [double]$p.m
      if ($i.Dir -eq 'up' -and $i.Metric -ne $pm) { $i.Prev = "上次 $pm%" }
      if ($i.Dir -eq 'down' -and $i.Metric -ne $pm) { $i.Prev = "上次剩 $pm GB" }
    }
    if ($worse) { $i.Prev = (('上次' + $(switch ($p.t) { 1 { '第一級' } 2 { '第二級' } default { '備查' } })), $i.Prev | Where-Object { $_ }) -join '，' }
    $i.Status = if ($worse) { '變嚴重' } else { "近 7 天第 $($i.Days) 天出現（首次 $($p.first.Substring(5))）" }
  }
  foreach ($i in $all) { if ($i.Force) { $p = $seen[$i.Key]; if ($p -and $p.last -ge $since7 -and $p.t -le 2) { $i.Force = '' } else { $i.Status = $i.Force } } }   # 硬碟例外失效／到期：轉換那一次回到馬上處理；之後留在「第一級未解決」，不天天重報
  $lastRun = if ($runs.Count) { $runs[-1] } else { $null }
  $recovered = @()
  if ($lastRun) {
    $nowKeys = @{}; foreach ($i in $all) { $nowKeys[$i.Key] = 1 }
    $recovered = @($lastRun.items | Where-Object { [string]$_.k -notmatch '^1\|disk\|[^|]*$' -and -not $nowKeys.ContainsKey([string]$_.k) -and $complete[([string]$_.k).Split('|')[0]] -and [int]$_.t -le 2 } | ForEach-Object { [string]$_.w })
  }
  try {
    $keep = @($runs | Where-Object { [string]$_.date -ge $ts.Date.AddDays(-30).ToString('yyyy-MM-dd') })
    $keep += [pscustomobject]@{ date = $today; items = @($all | ForEach-Object { [pscustomobject]@{ k = $_.Key; t = $_.Tier; m = $_.Metric;  w = $_.What } }) }
    New-Item -ItemType Directory -Force -Path (Split-Path $hf) | Out-Null
    $tmp = $hf + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject @($keep) -Depth 5 -Compress), (New-Object Text.UTF8Encoding($false)))
    if ($got) { Move-Item -Force $tmp $hf } else { Remove-Item -Force $tmp }
  } catch { $histNote = (($histNote, ('今天的比對紀錄沒存進去：' + $_.Exception.Message)) | Where-Object { $_ }) -join '；' }
  if ($got) { try { $mtx.ReleaseMutex() } catch {} }; $mtx.Dispose()
  if (-not $runs.Count -and -not $histNote) { $histNote = '第一次執行，沒有前幾天可以比，全部當今天新增；明天起才準' }
  foreach ($r in $res) { if ($r.Item.Key -eq '1' -and $r.Dir) { try { $mf = Get-Content (Join-Path $r.Dir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json; if ($null -ne $mf.params.DiskPct -and [double]$mf.params.DiskPct -ne 85) { $histNote = (($histNote, ('注意：這次 WhatsUp 硬碟門檻是 ' + $mf.params.DiskPct + '%（不是預設 85%），分級照 ' + $mf.params.DiskPct + '% 判')) | Where-Object { $_ }) -join '；' } } catch {} } }
  if ($script:diskExBad.Count) { $histNote = (($histNote, ('例外檔有看不懂的列，沒套用：' + ($script:diskExBad -join '、'))) | Where-Object { $_ }) -join '；' }

  # ---- v2.4.0 正式報告版型：頁首資訊列＋分頁（一、結論／二、須處理事項／三、追蹤事項／四、例外清單／五、檢查明細／六、檢核紀錄）
  $srcName = @{ '1' = '1 WhatsUp'; '2' = '2 VMware'; '3' = '3 Storage'; '4' = '4 AD' }
  $sysName = @{ '1' = 'WhatsUp'; '2' = 'VMware'; '3' = 'Storage'; '4' = 'AD' }
  $sysItem = @{ '1' = 'WhatsUp 監控'; '2' = 'VMware'; '3' = 'Storage'; '4' = 'AD 時間同步' }
  $tierTxt = @{ 1 = '第一級'; 2 = '第二級'; 3 = '追蹤' }
  $urgent = @($all | Where-Object { $_.Tier -le 2 -and ($_.Status -in '今天新增', '變嚴重' -or $_.Force) })
  $sysKeys = @($res | ForEach-Object { [string]$_.Item.Key } | Where-Object { $_ -in '1', '2', '3', '4' } | Select-Object -Unique | Sort-Object)
  # 資料完整度分母＝這台電腦設備清單裡有設定的類別（＋本次有跑的）；有設定但這次沒跑＝未執行
  $cfgKeys = @(); $cfgNote = ''
  try { $dlp0 = Join-Path $here '設備清單.csv'; if (Test-Path -LiteralPath $dlp0) { $cfgKeys = @(@((Read-TextAuto $dlp0) | ConvertFrom-Csv) | ForEach-Object { ([string]$_.類別).Trim() } | Where-Object { $_ -in '1', '2', '3', '4' } | Select-Object -Unique) } else { $cfgNote = '找不到 設備清單.csv，分母以本次有執行的項目計' } } catch { $cfgNote = '設備清單.csv 讀不到，分母以本次有執行的項目計' }
  $allKeys = @(@($sysKeys) + @($cfgKeys) | Select-Object -Unique | Sort-Object)
  $notRun = @($allKeys | Where-Object { $sysKeys -notcontains $_ })
  $diskThr = 85; $diskWarn = 80
  foreach ($r in @($res | Where-Object { $_.Item.Key -eq '1' -and $_.Dir })) { try { $mf = Get-Content (Join-Path $r.Dir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json; if ($null -ne $mf.params.DiskPct) { $diskThr = [double]$mf.params.DiskPct }; if ($null -ne $mf.params.DiskWarnPct) { $diskWarn = [double]$mf.params.DiskWarnPct } } catch {} }
  $shortDev = { param($lab) $pp = @(([string]$lab) -split '_'); if ($pp.Count -ge 2) { $pp[0] + ' ' + $pp[-1] } else { [string]$lab } }
  $stName = @{}   # Storage 設備 IP → 名稱
  $vcLoc = @{}; $locOf = @{}   # IP → 地點：設備清單.csv 為底，再以結果檔（VMware 項目第一段、Storage 01_總表 地點）補
  try { $dlp = Join-Path $here '設備清單.csv'; if (Test-Path -LiteralPath $dlp) { foreach ($x in @((Read-TextAuto $dlp) | ConvertFrom-Csv)) { if ("$($x.IP)".Trim() -and "$($x.地點)".Trim()) { $locOf[([string]$x.IP).Trim().ToLowerInvariant()] = ([string]$x.地點).Trim() } } } } catch {}
  foreach ($r in @($res | Where-Object { $_.Item.Key -eq '2' -and $_.Dir })) { foreach ($x in (Csv-In $r.Dir 'Summary.csv')) { $sg = @(([string]$x.項目) -split '_'); if ($sg.Count -ge 3 -and $sg[0]) { $locOf[$sg[-1].ToLowerInvariant()] = $sg[0]; $vcLoc[$sg[-1].ToLowerInvariant()] = $sg[0] } } }
  foreach ($r in @($res | Where-Object { $_.Item.Key -eq '3' -and $_.Dir })) { foreach ($x in (Csv-In $r.Dir '01_總表.csv')) { $ip0 = [string]$x.設備; if (-not $ip0) { continue }
    $nm0 = if ("$($x.名稱)" -ne '') { [string]$x.名稱 } else { $ip0 }; if ("$($x.型號)" -ne '') { $nm0 += '（' + $x.型號 + '）' }; $stName[$ip0] = $nm0
    if ("$($x.地點)" -ne '') { $locOf[$ip0.ToLowerInvariant()] = [string]$x.地點 } } }
  $locIp = { param($ip) if ($ip -and $locOf.ContainsKey(([string]$ip).ToLowerInvariant())) { $locOf[([string]$ip).ToLowerInvariant()] } else { '—' } }
  $ipName = { param($t) $t = ([string]$t).Trim(); if ($t -match '^(\d{1,3}(?:\.\d{1,3}){3})\s*\((.*)\)$') { , @($Matches[1], $Matches[2].Trim()) } elseif ($t -match '^\d{1,3}(?:\.\d{1,3}){3}$') { , @($t, $t) } else { , @('—', $t) } }

  foreach ($sk in $sysKeys) {
    if ($complete[$sk] -ne $false) { continue }
    if (@($all | Where-Object { [string]$_.Src -eq $sk -and ($_.Cat -eq 'gap' -or ($sk -eq '4' -and $_.Tier -eq 1)) }).Count) { continue }
    $gtx = ''; foreach ($r in @($res | Where-Object { [string]$_.Item.Key -eq $sk -and $_.Dir })) { $gtx += ((@(Csv-In $r.Dir '09_收集缺口.csv') + @(Csv-In $r.Dir '10_收集缺口.csv') | ForEach-Object { [string]$_.項目 } | Where-Object { $_ } | Select-Object -Unique) -join '、') }
    $all.Add((New-Issue $sk "$sk|gap|partial" 1 'gap' ('查不到：部分資料未取得' + $(if ($gtx) { '（' + $gtx + '）' } else { '' })) '本次結果不完整' '人工確認未取得的部分' $null ''))
  }
  # 每一筆補上報告欄位：Sys 系統、Dev 設備、Prob 問題、Grp 結論用分類、Unit 單位、ValN／ValT 數值、First 首次發現、Unk 是否查不到
  foreach ($i in $all) {
    $objN = ''; $dv0 = ''; $rawN = $null; $s = [string]$i.Src; $kp = @(([string]$i.Key) -split '\|'); $w = [string]$i.What; $dev = $sysName[$s]; $prob = $w; $grp = ''; $unit = '項'; $valN = $null; $valT = ''
    if ($s -in '2', '3' -and $kp.Count -ge 2) { $pre = $kp[1] + '：'; if ($w.StartsWith($pre)) { $w = $w.Substring($pre.Length) }; $prob = $w }
    $unk = ($i.Cat -eq 'gap')
    if ($unk) { $prob = $w -replace '^查不到：', ''; $grp = '查不到' }
    elseif ($s -eq '1') {
      switch ($i.Cat) {
        'disk' { $dev = $w -replace '\s*硬碟\s+[\d.]+%$', ''; $prob = $(if ($i.Tier -le 2) { "硬碟使用率逾 $diskThr%" } else { "硬碟使用率 $diskWarn～$diskThr%" }); $grp = "主機硬碟使用率逾 $diskThr%"; $unit = '顆'
          if ($i.Tier -le 2 -and $i.Now -match '不能例外') { $prob += '（≥98%，不能例外）' } elseif ($i.Tier -le 2 -and $i.Now -match '例外失效') { $prob += '（例外失效）' } elseif ($i.Tier -le 2 -and $i.Now -match '例外已到期') { $prob += '（例外到期）' } }
        'down' { $dev = $w -replace ' 離線$', ''; $prob = $(if ($i.Tier -le 2) { '設備離線（重要群組）' } else { '設備離線' }); $grp = '重要群組設備離線'; $unit = '台' }
        'cpu' { $dev = $w -replace ' CPU .*$', ''; $prob = 'CPU 使用率超標' }
        'mem' { $dev = $w -replace ' 記憶體 .*$', ''; $prob = '記憶體使用率超標' }
        'swap' { $dev = $w -replace ' SWAP .*$', ''; $prob = 'SWAP 使用率超標' }
        'maint' { $dev = ($w -replace '^【[^】]*】', '') -replace ' 維護中$', ''; $prob = $(if ($w -match '^【長期維護 (\d+) 天】') { "維護中（逾 30 天，已 $($Matches[1]) 天）" } else { '維護中' }) }
        default { $grp = 'WhatsUp 其他異常' }
      }
    }
    elseif ($s -in '2', '3') {
      $dv0 = if ($kp.Count -ge 2) { $kp[1] } else { '' }
      $dev = if ($s -eq '3') { if ($stName.ContainsKey($dv0)) { $stName[$dv0] } else { $dv0 } } else { & $shortDev $dv0 }
      if ($i.Cat -eq 'space' -and $w -match '^(Datastore|Pool|檔案系統|LUN)\s+(.+)$') {
        $typ = $Matches[1]; $dev = $dev + '／' + $Matches[2]; $objN = $typ + ' ' + $Matches[2]
        if ($i.Now -match '無法存取') { $prob = "$typ 無法存取"; $grp = $sysName[$s] + " $typ 無法存取" }
        elseif ($i.Tier -le 2) { $prob = "$typ 使用率逾 90%"; $grp = $sysName[$s] + " $typ 使用率逾 90%" }
        elseif ($i.Now -match '剩餘低於\s*(\d+)\s*GB') { $prob = "$typ 剩餘空間低於 $($Matches[1]) GB"; $grp = "$typ 容量" }
        else { $prob = "$typ 使用率注意"; $grp = "$typ 容量" }
        $unit = $(if ($typ -eq 'Datastore') { '顆' } else { '項' })
      }
      elseif ($i.Cat -eq 'down') { $prob = $w; $grp = 'ESXi 失聯'; $unit = '台' }
      elseif ($i.Cat -eq 'hw') { $grp = 'Storage 硬體異常' }
      elseif ($i.Cat -eq 'alarm') { $grp = 'VMware 警示' }
      else { $grp = $sysName[$s] + ' 其他異常' }
    }
    elseif ($s -eq '4') {
      $dev = 'DC ' + $(if ($kp.Count -ge 2) { $kp[1] } else { '' }); $unit = '台'
      if ($i.Tier -eq 1) { $unk = $true; $prob = '時間查不到'; $grp = '查不到' } else { $prob = $(if ($i.Tier -eq 2) { '時間差異常' } else { '時間差注意' }); $grp = 'AD 時間差異常' }
      if ($i.What -match '時間差\s+(\S+)\s+秒') { $valT = $Matches[1] + ' 秒'; $valN = Num-Of $Matches[1]; if ($null -ne $valN) { $valN = [math]::Abs($valN) } }
    }
    if (-not $valT) {
      $pv = $null
      if ($null -ne $i.Metric) { $pv = [double]$i.Metric } elseif ($i.Cat -ne 'gap' -and $w -match '(\d+(?:\.\d+)?)\s*%') { $pv = [double]$Matches[1] } elseif ($s -eq '3' -and $i.Cat -eq 'space') { $pv = Pct-Of ([string]$i.Now) }
      if ($null -ne $pv) { $valN = [math]::Round($pv, 1); $rawN = [math]::Round($pv, 2); $valT = ('{0:0.0}%' -f $valN) } else { $valT = '—' }
    }
    $ps = $seen[$i.Key]
    $first = if ($i.Status -eq '今天新增' -or $null -eq $ps) { $today } else { [string]$ps.first }
    $days = 1; try { $days = ([datetime]::ParseExact($today, 'yyyy-MM-dd', $null) - [datetime]::ParseExact($first, 'yyyy-MM-dd', $null)).Days + 1 } catch {}
    $todoT = [string]$i.Todo
    if ($s -eq '1' -and $i.Cat -eq 'disk' -and $i.Tier -le 2) { $todoT = '清理或擴充；通知系統負責人' + $(if ($i.Now -match '例外失效|例外已到期') { '；例外已失效，重新評估' } else { '' }) }
    $isEx = ($i.Cat -eq 'disk' -and $i.Tier -eq 3 -and [string]$i.Now -like '*例外到*')
    # 地點｜IP｜設備名稱｜對象
    $loc = '—'; $ipv = '—'; $dnm = $sysName[$s]; $obj = '—'
    if ($i.Cat -eq 'gap' -or ($kp.Count -ge 2 -and $kp[1] -eq 'gap')) { $obj = '資料' }
    elseif ($s -eq '1') {
      $dt = [string]$dev; if ($i.Cat -eq 'disk' -and $kp.Count -ge 4 -and $kp[3]) { $obj = $kp[3]; if ($dt.EndsWith(' ' + $kp[3])) { $dt = $dt.Substring(0, $dt.Length - $kp[3].Length - 1) }; $prob = $prob -replace '^硬碟', ('硬碟 ' + $kp[3] + ' ') }
      elseif ($i.Cat -eq 'cpu') { $obj = 'CPU' } elseif ($i.Cat -eq 'mem') { $obj = '記憶體' } elseif ($i.Cat -in 'down', 'maint') { $obj = '設備' }
      $sp = & $ipName $dt; $ipv = $sp[0]; $dnm = $sp[1]; $loc = & $locIp $ipv
    }
    elseif ($s -in '2', '3') {
      $sg = @(([string]$dv0) -split '_'); $ipv = $sg[-1]; $loc = $(if ($s -eq '2' -and $sg.Count -ge 3 -and $sg[0]) { $sg[0] } else { & $locIp $ipv })
      $dnm = if ($s -eq '3') { if ($stName.ContainsKey($ipv)) { $stName[$ipv] } else { $ipv } } else { $(if ($loc -ne '—') { "$loc " } else { '' }) + 'vCenter（VMware）' }
      if ($objN) { $obj = $objN }
      elseif ($i.Cat -eq 'down') { $obj = $w -replace '\s*失聯$', ''; $prob = 'ESXi 失聯' }
      elseif ($i.Cat -in 'alarm', 'cpu' -and $w -like '警示*') { $obj = ($w -replace '^警示\s*', ''); $prob = $(if ($i.Now -match '^(red|yellow)') { $(if ($Matches[1] -eq 'red') { '紅色警示' } else { '黃色警示' }) } else { '警示' }) }
      elseif ($i.Cat -eq 'hw') { $obj = ($w -replace '^硬體\s*', ''); $prob = '硬體異常' }
      elseif ($w -like '硬體*') { $obj = ($w -replace '^硬體\s*', ''); $prob = '硬體注意' }
      else { $obj = $w; $prob = $(if ($i.Tier -le 2) { '須處理' } else { '注意' }) }
      if ($s -eq '2' -and $vcLoc.ContainsKey($ipv.ToLowerInvariant())) { $loc = $vcLoc[$ipv.ToLowerInvariant()] }
    }
    elseif ($s -eq '4') { $ipv = $(if ($kp.Count -ge 2) { $kp[1] } else { '—' }); $loc = & $locIp $ipv; $dnm = 'DC'; $obj = '系統時間' }
    foreach ($pr in @(@('Loc', [string]$loc), @('IP', [string]$ipv), @('DevN', [string]$dnm), @('Obj', [string]$obj))) { $i | Add-Member -NotePropertyName $pr[0] -NotePropertyValue $pr[1] -Force }
    foreach ($pr in @(@('Sys', $sysName[$s]), @('Dev', [string]$dev), @('Prob', [string]$prob), @('Grp', [string]$grp), @('Unit', $unit), @('ValN', $valN), @('RawN', $rawN), @('ValT', $valT), @('First', $first), @('Dur', $days), @('Unk', $unk), @('TodoT', $todoT), @('IsEx', $isEx))) { $i | Add-Member -NotePropertyName $pr[0] -NotePropertyValue $pr[1] -Force }
  }
  $notes = Read-Notes
  $act = @($all | Where-Object { $_.Tier -le 2 -or $_.Unk } | Sort-Object Src, @{ Expression = { if ($_.Unk) { 0 } else { $_.Tier } } }, @{ Expression = { if ($_.Cat -eq 'disk' -and $null -ne $_.RawN -and $_.RawN -lt 90) { 1 } else { 0 } } }, @{ Expression = { if ($_.PSObject.Properties['EstN']) { $_.EstN } else { 0 } } }, @{ Expression = { if ($null -ne $_.ValN) { - $_.ValN } else { 0 } } }, Dev)   # 硬碟：≥90% 在前，再依估計滿載天數（快滿的在前）
  $fol = @($all | Where-Object { $_.Tier -eq 3 -and -not $_.Unk -and -not $_.IsEx } | Sort-Object Src, Cat, @{ Expression = { if ($null -ne $_.ValN) { - $_.ValN } else { 0 } } }, Dev)

  # ---- 設備牆（v2.1.0）：每台設備一格，紅＝有第一、二級的事、橘＝只有備查或已列例外、灰虛線＝查不到、綠＝正常
  #      WhatsUp 只列有事的（設備太多），其他區每台都列，位置固定，天天看同一個地方
  $tiles = New-Object System.Collections.Generic.List[object]
  $stOf = { param($iss) if (@($iss | Where-Object { $_.Tier -le 2 -and $_.Cat -ne 'gap' }).Count) { 'red' } elseif (@($iss | Where-Object { $_.Cat -eq 'gap' }).Count) { 'unk' } elseif (@($iss).Count) { 'amb' } else { 'ok' } }
  $lnOf = { param($iss) @($iss | Sort-Object Tier | Select-Object -First 6 | ForEach-Object { $_.What + '｜' + $_.Now + $(if ($_.Todo) { '｜要做：' + $_.Todo } else { '' }) }) }
  $pctOf = { param($t) if ($t -match '(\d+(?:\.\d+)?)\s*%') { $Matches[1] + '%' } else { '' } }
  $short = { param($lab) $pp = @(([string]$lab) -split '_'); if ($pp.Count -ge 2) { $pp[0] + ' ' + $pp[-1] } else { [string]$lab } }
  $dispOf = { param($t) switch -Wildcard ([string]$t) { '可結案（有注意事項）' { '待追蹤' } '可結案' { '正常' } '須回報*' { '須回報' } default { [string]$t } } }
  $addT = { param($area, $name, $val, $hint, $st, $lines) $tiles.Add([pscustomobject]@{ A = $area; Name = [string]$name; Val = [string]$val; Hint = [string]$hint; S = $st; Lines = @($lines) }) }
  $areaDone = @{}
  foreach ($r in $res) {
    $s0 = $r.Item.Key; $iss0 = @($all | Where-Object { $_.Src -eq $s0 })
    if (-not $r.Dir) {   # 整項沒有產出結果：這一項放一格灰色（同一區兩項時各自一格）
      & $addT $s0 ($r.Item.Text) '查不到' '整項沒跑完' 'unk' @(@($iss0 | Where-Object { $_.Key -like "$s0|gap|*" } | Select-Object -First 1 | ForEach-Object { $_.Now }) + @($(if ($r.Err) { $r.Err } else { '工具沒有產出結果' })))
      continue }
    switch ($s0) {
      '1' {
        if ($areaDone['1']) { break }; $areaDone['1'] = 1
        foreach ($i in @($iss0 | Where-Object { $_.Cat -eq 'gap' })) { & $addT '1' 'WhatsUp' '查不到' '部分沒讀到' 'unk' @($i.What + '｜' + $i.Now) }
        # 離線、維護：跟 WhatsUp 首頁一樣各一個數字格，點開看是哪幾台（有編號）
        $dn = @($iss0 | Where-Object { $_.Cat -eq 'down' } | Sort-Object Tier, What)
        if ($dn.Count) { $dnImp = @($dn | Where-Object { $_.Tier -le 2 }).Count; $n = 0
          & $addT '1' '離線' "$($dn.Count) 台" $(if ($dnImp) { "重要群組 $dnImp 台" } else { '非重要群組' }) $(if ($dnImp) { 'red' } else { 'amb' }) @($dn | ForEach-Object { $n++; "$n. " + $(if ($_.Tier -le 2) { '【重要】' } else { '' }) + ($_.What -replace ' 離線$', '') + '｜' + $_.Status + '｜' + $_.Now }) }
        $mt = @($iss0 | Where-Object { $_.Cat -eq 'maint' } | Sort-Object What)
        if ($mt.Count) { $mtLong = @($mt | Where-Object { $_.What -like '*長期維護*' }).Count; $n = 0
          & $addT '1' '維護中' "$($mt.Count) 台" $(if ($mtLong) { "逾 30 天 $mtLong 台" } else { '' }) 'amb' @($mt | ForEach-Object { $n++; "$n. " + ($_.What -replace ' 維護中$', '') + '｜' + $_.Now }) }
        # 主機硬碟：合成一格「≥85% 顆數／全部顆數」，點進去看是哪幾顆（依使用率由高到低、編號）
        $dkAll = @(Csv-In $r.Dir '07_硬碟.csv').Count
        $dkPct = { param($i) $v = 0.0; if ($i.What -match '(\d+(?:\.\d+)?)\s*%$') { $v = [double]$Matches[1] }; $v }
        $dkNo = { param($list) $n = 0; @($list | Sort-Object @{ Expression = { & $dkPct $_ }; Descending = $true } | ForEach-Object { $n++; "$n. " + $_.What + '｜' + $_.Status + $(if ($_.Now -like '*例外到*') { '｜' + ($_.Now -replace '^.*?(例外到)', '$1') } else { '' }) }) }
        $dkRed = @($iss0 | Where-Object { $_.Cat -eq 'disk' -and $_.Tier -le 2 })
        if ($dkRed.Count) {   # 明細分兩段：≥90%、85～89%（編號連續）
          $d90 = @($dkRed | Where-Object { (& $dkPct $_) -ge 90 }); $d85 = @($dkRed | Where-Object { (& $dkPct $_) -lt 90 })
          $l90 = @(& $dkNo $d90); $l85 = @(& $dkNo $d85 | ForEach-Object { if ($_ -match '^(\d+)\. (.*)$') { ([int]$Matches[1] + $d90.Count).ToString() + '. ' + $Matches[2] } else { $_ } })
          $dl = @(); if ($d90.Count) { $dl += "【≥90%】$($d90.Count) 顆"; $dl += $l90 }; if ($d85.Count) { $dl += "【85～89%】$($d85.Count) 顆"; $dl += $l85 }
          & $addT '1' '主機硬碟 ≥85%' ("$($dkRed.Count)/$dkAll") "≥90%：$($d90.Count) 顆　85～89%：$($d85.Count) 顆" 'red' $dl }
        # 硬碟資料過期（不含維護中、離線）：一格，點開看是哪幾台、最後一次輪詢時間
        $dkOld = @(Csv-In $r.Dir '07_硬碟.csv' | Where-Object { [string]$_.判定 -eq '資料過期' } | Group-Object 裝置 | Sort-Object Name)
        if ($dkOld.Count) { $n = 0
          & $addT '1' '硬碟資料過期' "$($dkOld.Count) 台" '逾 60 分鐘未輪詢' 'unk' @($dkOld | ForEach-Object { $n++; $g0 = @($_.Group | Sort-Object { [double]("0" + $_.距上次輪詢分) } -Descending); "$n. " + $_.Name + '｜' + $_.Count + ' 顆｜最後輪詢 ' + $g0[0].輪詢時間 + $(if ("$($g0[0].距上次輪詢分)" -ne '') { '（' + [math]::Round([double]$g0[0].距上次輪詢分 / 60, 1) + ' 小時前）' } else { '（沒有輪詢時間）' }) }) }
        $dkEx = @($iss0 | Where-Object { $_.Cat -eq 'disk' -and $_.Tier -eq 3 -and $_.Now -like '*例外到*' })
        if ($dkEx.Count) { & $addT '1' '主機硬碟 已列例外' ("$($dkEx.Count) 顆") '' 'amb' (& $dkNo $dkEx) }
        $rest = @($iss0 | Where-Object { $_.Tier -eq 3 -and $_.Cat -notin 'down', 'maint' -and -not ($_.Cat -eq 'disk' -and $_.Now -like '*例外到*') })
        if ($rest.Count) { $byc = @{ down = '非重要設備離線'; disk = '硬碟 80～85%'; cpu = 'CPU'; mem = '記憶體'; maint = '維護中' }
          & $addT '1' '其他紀錄' "$($rest.Count) 項" '' 'amb' @($rest | Group-Object Cat | ForEach-Object { $(if ($byc.ContainsKey($_.Name)) { $byc[$_.Name] } else { $_.Name }) + ' ' + $_.Count + ' 項' }) }
        if (-not @($iss0).Count -and -not @(Csv-In $r.Dir '07_硬碟.csv').Count -and -not (Test-Path (Join-Path $r.Dir '00_檢查表文字.csv'))) { & $addT '1' 'WhatsUp' '查不到' '沒有結果檔' 'unk' @('結果檔讀不到') }
        elseif (-not @($iss0).Count) { & $addT '1' 'WhatsUp' '正常' '' 'ok' @('離線、維護、CPU、記憶體、SWAP、硬碟都沒有超標') }
      }
      '2' {
        $rows2 = @(Csv-In $r.Dir 'Summary.csv'); if (-not $rows2.Count) { & $addT '2' ($r.Item.Text) '查不到' '結果檔沒有設備' 'unk' @('Summary.csv 讀不到或沒有資料') }
        foreach ($x in $rows2) { $lab = [string]$x.項目
          $iss = @($iss0 | Where-Object { ($_.Key -split '\|')[1] -eq $lab }); $st = & $stOf $iss
          if ($st -ne 'red' -and (@($iss0 | Where-Object { $_.Key -like '2|gap|*' }).Count -or [string]$x.處置 -eq '須補查' -or [string]$x.完整度 -notlike '完整*')) { $st = 'unk' }   # 結果不完整就不能亮綠
          $v = if ($st -eq 'unk') { '查不到' } elseif ($st -eq 'red') { "$(@($iss | Where-Object { $_.Tier -le 2 }).Count) 件" } elseif ("$($x.ESXi總數)" -ne '') { "$($x.ESXi正常)/$($x.ESXi總數)" } else { [string]$x.處置 }
          & $addT '2' (& $short $lab) $v $(if ($st -eq 'ok') { '正常' } elseif ($st -eq 'red') { "須處理（共檢查 ESXi $($x.ESXi總數) 台、Datastore $($x.共用LUN數) 顆）" + $(if (@($iss | Where-Object { $_.Cat -eq 'gap' }).Count) { '；部分資料未取得' } else { '' }) } else { & $dispOf $x.處置 }) $st $(if ($iss.Count) { & $lnOf $iss } else { @('ESXi ' + $x.ESXi正常 + '/' + $x.ESXi總數 + '、LUN ' + $x.共用LUN數 + ' 顆、紅色警示 ' + $x.紅色警示) }) }
      }
      '3' {
        $rows3 = @(Csv-In $r.Dir '01_總表.csv'); if (-not $rows3.Count) { & $addT '3' ($r.Item.Text) '查不到' '結果檔沒有設備' 'unk' @('01_總表.csv 讀不到或沒有資料') }
        foreach ($x in $rows3) { $ip = [string]$x.設備
          $iss = @($iss0 | Where-Object { ($_.Key -split '\|')[1] -eq $ip }); $st = & $stOf $iss
          if ($st -ne 'red' -and (@($iss0 | Where-Object { $_.Key -like '3|gap|*' }).Count -or [string]$x.處置 -like '*須補查*' -or ("$($x.完整度)" -ne '' -and [string]$x.完整度 -notlike '完整*'))) { $st = 'unk' }
          $red = @($iss | Where-Object { $_.Tier -le 2 })
          $v = if ($st -eq 'unk') { '查不到' } elseif ($st -eq 'red') { $pv = & $pctOf ($red[0].What + ' ' + $red[0].Now); if ($pv -and $red.Count -eq 1) { $pv } else { "$($red.Count) 件" } } elseif ($st -eq 'amb') { "追蹤 $($iss.Count) 件" } else { '正常' }
          $nm = if ("$($x.名稱)" -ne '') { [string]$x.名稱 } else { & $short ([string]$x.項目) }
          & $addT '3' $nm $v $(if ($st -eq 'red') { $red[0].What -replace '^[^：]*：', '' } elseif ($st -eq 'ok') { '' } else { & $dispOf $x.處置 }) $st $(if ($iss.Count) { & $lnOf $iss } else { @('正常') }) }
      }
      '4' {
        $rows4 = @(Csv-In $r.Dir 'AD_net_time.csv'); if (-not $rows4.Count) { & $addT '4' ($r.Item.Text) '查不到' '結果檔沒有設備' 'unk' @('AD_net_time.csv 讀不到或沒有資料') }
        if ($rows4.Count) { $adL = @(); $adBad = 0; $adUnk = 0; $adSt = 'ok'; $n = 0
          foreach ($x in @($rows4 | Sort-Object @{ Expression = { if ([string]$_.判定 -eq '正常') { 1 } else { 0 } } }, IP)) { $ip = [string]$x.IP; $n++
            $iss = @($iss0 | Where-Object { $_.Key -eq "4|$ip" }); $s1 = if ([string]$x.判定 -eq '查不到') { 'unk' } else { & $stOf $iss }
            if ($s1 -eq 'red') { $adBad++; $adSt = 'red' } elseif ($s1 -eq 'unk') { $adUnk++; if ($adSt -ne 'red') { $adSt = 'unk' } } elseif ($s1 -eq 'amb' -and $adSt -eq 'ok') { $adSt = 'amb' }
            $adL += "$n. DC $ip｜時間差 " + $(if ("$($x.時間差秒)" -ne '') { "$($x.時間差秒) 秒" } else { '—' }) + '｜' + [string]$x.判定 }
          & $addT '4' 'AD 時間同步' $(if ($adBad) { "異常 $adBad 台" } elseif ($adUnk) { "查不到 $adUnk 台" } else { '正常' }) "DC 共 $($rows4.Count) 台" $adSt $adL }
      }
    }
  }
  $zoneName = @{ '1' = '1 WhatsUp'; '2' = '2 VMware'; '3' = '3 Storage'; '4' = '4 AD' }
  $zoneSub = @{ '1' = ''; '2' = ''; '3' = ''; '4' = '' }
  $wz = New-Object Text.StringBuilder; $ti = 0
  foreach ($z in '1', '2', '3', '4') {
    $zt = @($tiles | Where-Object { $_.A -eq $z }); if (-not $zt.Count) { continue }
    [void]$wz.Append("<div class='zone'><div class='zh'><b>$($zoneName[$z])</b><span class='m'>$(Esc $zoneSub[$z])</span></div><div class='tiles'>")
    foreach ($t in $zt) { $ti++
      [void]$wz.Append("<button type='button' class='tile $($t.S)' data-n='" + (Esc $t.Name) + "' data-v='" + (Esc $t.Val) + "' data-d='" + (Esc (@($t.Lines) -join "`n")) + "' aria-label='" + (Esc ($t.Name + ' ' + $t.Val)) + "'><span class='tn'>" + (Esc $t.Name) + "</span><span class='tv'>" + (Esc $t.Val) + "</span><span class='th'>" + (Esc $t.Hint) + '</span></button>') }
    [void]$wz.Append('</div></div>')
  }
  if (-not $ti) { [void]$wz.Append("<div class='zone'><p class='m'>這次沒有任何設備結果（設備清單沒設定，或每一項都沒跑）。</p></div>") }
  $redN = @($tiles | Where-Object { $_.S -eq 'red' }).Count; $unkN = @($tiles | Where-Object { $_.S -eq 'unk' }).Count
  $ambN = @($tiles | Where-Object { $_.S -eq 'amb' }).Count; $okN = @($tiles | Where-Object { $_.S -eq 'ok' }).Count
  $wallHtml = "<div class='wall'><div class='wl'><div class='lg'><span><i class='dot red'></i>須處理 $redN</span><span><i class='dot amb'></i>追蹤／例外 $ambN</span><span><i class='dot unk'></i>查不到 $unkN</span><span><i class='dot ok'></i>正常 $okN</span></div>" + $wz.ToString() + "</div>" +
    "<aside class='wr'><div class='det'><b id='detN'>—</b><span id='detV' class='dv'></span><div id='detL'></div></div></aside></div>"

  # ---- 例外清單：讀三個例外檔，比對本次結果的目前使用率
  $staleKey = @{}; $dsCnt = @{}; $devTxt = @{}; $curDisk = @{}; $curDs = @{}; $curSt = @{}; $have = @{ WhatsUp = $false; VMware = $false; Storage = $false }
  foreach ($r in @($res | Where-Object { $_.Dir })) {
    switch ([string]$r.Item.Key) {
      '1' { $rows = @(Csv-In $r.Dir '07_硬碟.csv'); if ($rows.Count) { $have.WhatsUp = $true }; foreach ($x in $rows) { $ck = ([string]$x.裝置ID + '|' + [string]$x.磁碟).ToLowerInvariant(); $curDisk[$ck] = Num-Of $x.上次輪詢值; if ([string]$x.判定 -eq '資料過期') { $staleKey[$ck] = 1 }; $devTxt[([string]$x.裝置ID).ToLowerInvariant()] = [string]$x.裝置 } }
      '2' { $rows = @(Csv-In $r.Dir 'Ds.csv'); if ($rows.Count) { $have.VMware = $true }; foreach ($x in $rows) { $ck = (([string](([string]$x.設備 -split '_')[-1])) + '|' + [string]$x.Datastore).ToLowerInvariant(); $curDs[$ck] = Num-Of $x.使用率; $dsCnt[$ck] = 1 + [int]$dsCnt[$ck] } }
      '3' { $rp = @(Csv-In $r.Dir '04_Pool.csv'); $rf = @(Csv-In $r.Dir '06_檔案系統.csv'); if ($rp.Count -or $rf.Count) { $have.Storage = $true }
        foreach ($x in $rp) { $curSt[([string]$x.設備 + '|Pool ' + [string]$x.Pool).ToLowerInvariant()] = Num-Of $x.使用率 }
        foreach ($x in $rf) { $curSt[([string]$x.設備 + '|檔案系統 ' + [string]$x.檔案系統).ToLowerInvariant()] = Num-Of $x.使用率 } }
    }
  }
  $exRows = @(Read-AllEx); $xlRows = New-Object System.Collections.Generic.List[object]; $pendN = 0
  $catOf = @{ WhatsUp = '硬碟'; VMware = 'Datastore'; Storage = 'Storage' }
  $exSb = New-Object Text.StringBuilder; $xn = 0; $exCnt = @{}
  foreach ($e in $exRows) {
    $xn++; $kk = ([string]$e.K1 + '|' + [string]$e.K2).ToLowerInvariant()
    $map = switch ($e.Sys) { 'WhatsUp' { $curDisk } 'VMware' { $curDs } default { $curSt } }
    $found = $map.ContainsKey($kk); $cur = if ($found) { $map[$kk] } else { $null }
    $stc = ''; $stt = ''; $pc = ''
    if ($e.Bad) { $stc = '格式不符'; $stt = $e.Bad; $pc = 'p-bad' }
    elseif ($e.Sup) { $stc = '已取代'; $stt = '已取代（' + $e.Sup + '）'; $pc = 'p-unk' }
    elseif ($e.Exp.Date -lt $ts.Date) { $stc = '失效'; $stt = '失效（已到期）'; $pc = 'p-bad' }
    elseif (-not $have[$e.Sys]) { $stc = '本次未檢查'; $stt = '本次未檢查'; $pc = 'p-unk' }
    elseif (-not $found) { $stc = '找不到對象'; $stt = '找不到對象'; $pc = 'p-unk' }
    elseif ($e.Sys -eq 'VMware' -and [int]$dsCnt[$kk] -gt 1) { $stc = '同名多顆'; $stt = '同名多顆，未套用'; $pc = 'p-unk' }
    elseif ($null -eq $cur -or $staleKey.ContainsKey($kk)) { $stc = '待驗證'; $stt = '待驗證（目前讀值無效或過期）'; $pc = 'p-unk' }
    elseif ($cur -ge 98) { $stc = '失效'; $stt = '≥98%，不能例外'; $pc = 'p-bad' }
    elseif ($null -ne $cur -and ($cur - $e.Pct) -gt 3) { $stc = '失效'; $stt = '失效（增加 ' + [math]::Round($cur - $e.Pct, 1) + ' 點）'; $pc = 'p-bad' }
    elseif ($e.Exp.Date -le $ts.Date.AddDays(7)) { $stc = '即將到期'; $stt = '即將到期（' + ($e.Exp.Date - $ts.Date).Days + ' 天）'; $pc = 'p-warn' }
    else { $stc = '有效'; $stt = '有效'; $pc = 'p-ok' }
    $exCnt[$stc] = 1 + [int]$exCnt[$stc]
    $pctT = if ($null -ne $e.Pct) { ('{0:0.0}%' -f [double]$e.Pct) } else { '—' }; $curT = if ($null -ne $cur) { ('{0:0.0}%' -f [double]$cur) } else { '—' }
    $eLoc = '—'; $eIp = '—'; $eNm = [string]$e.Dev; $eObj = '—'
    if ($e.K1 -and -not ($e.Bad -and -not $e.K2)) {
      switch ($e.Sys) {
        'WhatsUp' { $raw = [string]$e.Dev; if ($e.K2 -and $raw.EndsWith(' ' + $e.K2)) { $raw = $raw.Substring(0, $raw.Length - $e.K2.Length - 1) }; $sp = & $ipName $raw
          if ($sp[0] -eq '—' -and $devTxt.ContainsKey(([string]$e.K1).ToLowerInvariant())) { $sp = & $ipName $devTxt[([string]$e.K1).ToLowerInvariant()] }
          $eIp = $sp[0]; $eNm = $sp[1]; $eObj = [string]$e.K2 }
        'VMware' { $eIp = [string]$e.K1; $eObj = 'Datastore ' + $e.K2 }
        default { $eIp = [string]$e.K1; $eObj = [string]$e.K2 }
      }
      $eLoc = & $locIp $eIp; if ($e.Sys -eq 'VMware' -and $vcLoc.ContainsKey($eIp.ToLowerInvariant())) { $eLoc = $vcLoc[$eIp.ToLowerInvariant()] }
      if ($e.Sys -eq 'VMware') { $eNm = $(if ($eLoc -ne '—') { "$eLoc " } else { '' }) + 'vCenter（VMware）' } elseif ($e.Sys -eq 'Storage') { $eNm = $(if ($stName.ContainsKey($eIp)) { $stName[$eIp] } else { $eIp }) }
    }
    if ($e.Csv -and -not $e.Bad) { if ($e.Loc) { $eLoc = $e.Loc }; if ($e.IPx) { $eIp = $e.IPx }; if ($e.DevN) { $eNm = $e.DevN }; if ($e.Obj) { $eObj = $(if ($e.Sys -eq 'VMware' -and $e.Obj -notmatch '^Datastore\s') { 'Datastore ' + $e.Obj } else { $e.Obj }) } }
    $expT = if ($e.Exp) { $e.Exp.ToString('yyyy-MM-dd') } else { '—' }
    $pend = (-not $e.Bad -and -not $e.Sup -and $stc -ne '失效' -and -not $e.AppOk)
    if ($pend) { $pendN++ }
    $sign = if ($e.Bad -or $e.Sup -or $stc -eq '失效') { '' } elseif ($e.Doc -and -not $e.AppOk) { "<span class='pill p-warn'>待簽核</span><div class='nt'>" + (Esc ($e.Doc + '｜核准日未填或無效')) + '</div>' } elseif ($e.AppOk) { "<span class='pill p-ok'>已核准</span><div class='nt'>" + (Esc ($e.Doc + $(if ($e.AppD) { '｜' + $e.AppD } else { '' }))) + '</div>' } else { "<span class='pill p-warn'>待簽核</span>" }
    if (-not $e.Bad -and -not $e.Sup) { $xlRows.Add([pscustomobject]@{ Cat = $catOf[$e.Sys]; Loc = $(if ($eLoc -ne '—') { $eLoc } else { '' }); IP = $(if ($eIp -ne '—') { $eIp } else { '' }); DevN = $eNm; Obj = $eObj; Pct = $pctT; Cur = $(if ($curT -ne '—') { $curT } else { '' }); Exp = $expT; Why = $e.Why; Reg = [string]$e.Reg; RegD = [string]$e.RegD; Doc = [string]$e.Doc; Pending = $pend }) }
    [void]$exSb.Append("<tr data-sys='" + (Esc $stc) + "' data-sign='" + $(if ($pend) { '待簽核' } else { '' }) + "'><td class='id' data-v='$xn'>X$xn</td><td>" + (Esc $e.Sys) + '</td><td>' + (Esc $eLoc) + '</td><td>' + (Esc $eIp) + '</td><td>' + (Esc $eNm) + '</td><td>' + (Esc $eObj) + "</td><td class='n' data-v='" + $(if ($null -ne $e.Pct) { $e.Pct } else { -1 }) + "'>$pctT</td><td class='n' data-v='" + $(if ($null -ne $cur) { $cur } else { -1 }) + "'>$curT</td><td class='dt' data-v='" + $(if ($e.Exp) { $e.Exp.ToString('yyyyMMdd') } else { 0 }) + "'>$expT</td><td><span class='pill $pc'>" + (Esc $stt) + '</span></td><td>' + $sign + '</td><td>' + (Esc $e.Why) + '</td><td>' + (Esc $e.File) + '</td></tr>')
  }
  if (-not $xn) { [void]$exSb.Append("<tr><td colspan='13' class='none'>未登記任何例外。</td></tr>") }
  $exOrder = @('有效', '即將到期', '待驗證', '失效', '找不到對象', '同名多顆', '本次未檢查', '已取代', '格式不符')
  $exBar = "<div class='sub' data-for='tx'><button type='button' aria-pressed='true' data-f=''>全部（$xn）</button>" + (($exOrder | Where-Object { $exCnt[$_] } | ForEach-Object { "<button type='button' aria-pressed='false' data-f='$_'>$_（$($exCnt[$_])）</button>" }) -join '') + $(if ($pendN) { "<button type='button' aria-pressed='false' data-f='待簽核'>待簽核（$pendN）</button>" } else { '' }) + '</div>'
  $exStat = (($exOrder | Where-Object { $exCnt[$_] } | ForEach-Object { "$_ $($exCnt[$_]) 項" }) -join '、'); if (-not $exStat) { $exStat = '未登記任何例外' } elseif ($pendN) { $exStat += "；待簽核 $pendN 項" }
  # 例外簽呈附件（Excel）：每次都產生在這次的輸出資料夾
  $xlName = '例外簽呈附件_' + $ts.ToString('yyyyMMdd') + '.xlsx'; $xlOk = $false
  try { $xlp = Join-Path $od $xlName; Write-ExXlsx $xlp ($xlRows.ToArray()) $today; $xlOk = (Test-Path -LiteralPath $xlp) } catch { $histNote = (($histNote, ('例外簽呈附件沒產生：' + $_.Exception.Message)) | Where-Object { $_ }) -join '；' }
  $xlLink = if ($xlOk) { "<a href='" + [Uri]::EscapeDataString($xlName) + "'>簽呈附件（Excel）</a>" } else { '' }

  # ---- 二、須處理事項
  $exBtn = { param($i) if ($i.Ex -and $null -ne $i.RawN -and $i.RawN -lt 98) { $kq = @(([string]$i.Key) -split '\|'); $ca = if ($i.Cat -eq 'disk') { '硬碟' } elseif ($i.Src -eq '3') { 'Storage' } else { 'Datastore' }
    "<button type='button' class='exb' data-cat='$ca' data-loc='" + (Esc $(if ($i.Loc -ne '—') { $i.Loc } else { '' })) + "' data-ip='" + (Esc $(if ($i.IP -ne '—') { $i.IP } else { '' })) + "' data-dn='" + (Esc $i.DevN) + "' data-obj='" + (Esc $i.Obj) + "' data-id='" + (Esc $(if ($i.Cat -eq 'disk' -and $kq.Count -ge 3) { $kq[2] } else { '' })) + "' data-pct='" + $(if ($null -ne $i.RawN) { $i.RawN } else { '' }) + "'>列例外</button>" } else { '' } }
  $aSb = New-Object Text.StringBuilder; $pn = 0
  foreach ($i in $act) { $pn++
    $lvP = if ($i.Unk) { "<span class='pill p-unk'>查不到</span>" } elseif ($i.Tier -eq 1) { "<span class='pill p-bad'>第一級</span>" } else { "<span class='pill p-warn'>第二級</span>" }
    $tag = if ($i.Status -eq '變嚴重') { "<span class='tag'>變嚴重</span>" } elseif ($i.Status -eq '今天新增') { "<span class='tag'>今日新增</span>" } else { '' }
    [void]$aSb.Append("<tr data-sys='$($i.Sys)'><td data-v='0'><input type='checkbox' class='dn' id='dn$pn' data-k='" + (Esc $i.Key) + "' aria-label='P$pn 已處理'></td><td class='id' data-v='$pn'>P$pn</td><td>$($i.Sys)</td><td data-v='" + $(if ($i.Unk) { 0 } else { $i.Tier }) + "'>$lvP</td><td>" + (Esc $i.Loc) + '</td><td>' + (Esc $i.IP) + '</td><td>' + (Esc $i.DevN) + '</td><td>' + (Esc $i.Obj) + '</td><td>' + (Esc $i.Prob) + $tag + "<div class='nt'>" + (Esc $i.Now) + $(if ($i.Prev) { '（' + (Esc $i.Prev) + '）' } else { '' }) + "</div><button type='button' class='cpr' data-c='" + (Esc (CpLine $i)) + "'>複製</button></td><td class='n' data-v='" + $(if ($null -ne $i.ValN) { $i.ValN } else { -1 }) + "'>" + (Esc $i.ValT) + "</td>" + $(if ($i.PSObject.Properties['Grow'] -and $null -ne $i.Grow) { "<td class='n' data-v='" + $i.Grow + "'>" + ([double]$i.Grow).ToString('+0.00;-0.00;0.00', [Globalization.CultureInfo]::InvariantCulture) + '</td>' } else { "<td class='n' data-v='-999'>—</td>" }) + $(if ($i.PSObject.Properties['Est'] -and $i.Est) { "<td class='n' data-v='" + $i.EstN + "'>" + (Esc $i.Est) + '</td>' } else { "<td class='n' data-v='999999'>—</td>" }) + "<td class='dt' data-v='" + ($i.First -replace '-', '') + "'>" + (Esc $i.First) + '</td><td>' + (Esc $i.TodoT) + '</td><td>' + (& $exBtn $i) + "</td><td class='nb'>" + $(if ($i.Cat -eq 'gap') { '—' } elseif ($notes.ContainsKey([string]$i.Key)) { $nr = $notes[[string]$i.Key]; "<div class='nbt'>" + (Esc $nr.備註) + "</div><div class='nt'>" + (Esc ([string]$nr.日期 + ' ' + [string]$nr.登記人)) + '</div>' } else { "<div class='nbt'></div>" }) + $(if ($i.Cat -ne 'gap') { "<button type='button' class='nbb' data-k='" + (Esc $i.Key) + "' data-dn='" + (Esc $i.DevN) + "' data-obj='" + (Esc $i.Obj) + "'>寫備註</button>" } else { '' }) + '</td></tr>') }
  if (-not $pn) { [void]$aSb.Append("<tr><td colspan='17' class='none'>本日無須處理事項。</td></tr>") }

  # ---- 三、追蹤事項：WhatsUp 依種類彙總一列（明細可展開），其他系統逐筆
  $fDisp = New-Object System.Collections.Generic.List[object]
  foreach ($g in @($fol | Where-Object { $_.Src -eq '1' } | Group-Object Cat)) {
    $gi = @($g.Group | Sort-Object @{ Expression = { if ($null -ne $_.ValN) { - $_.ValN } else { 0 } } }, DevN); $hn = @($gi | ForEach-Object { $_.IP + '|' + $_.DevN } | Select-Object -Unique).Count
    switch ($g.Name) {
      'disk' { $dn = "主機 $hn 台"; $ob = "硬碟 $($gi.Count) 顆"; $pb = "使用率 $diskWarn～$diskThr%" }
      'maint' { $dn = "設備 $($gi.Count) 台"; $ob = '維護中'; $lg = @($gi | Where-Object { $_.Prob -like '*逾 30 天*' }).Count; $pb = $(if ($lg) { "其中逾 30 天 $lg 台" } else { '均未逾 30 天' }) }
      'down' { $dn = "設備 $($gi.Count) 台"; $ob = '離線'; $pb = '均非重要群組' }
      'cpu' { $dn = "主機 $hn 台"; $ob = 'CPU'; $pb = 'CPU 使用率超標' }
      'mem' { $dn = "主機 $hn 台"; $ob = '記憶體'; $pb = '記憶體使用率超標' }
      'swap' { $dn = "主機 $hn 台"; $ob = 'SWAP'; $pb = 'SWAP 使用率超標' }
      default { $dn = "設備 $hn 台"; $ob = [string]$g.Name; $pb = '其他' }
    }
    $vs = @($gi | Where-Object { $null -ne $_.ValN } | ForEach-Object { [double]$_.ValN } | Sort-Object)
    if ($vs.Count) { $vN = $vs[-1]; $vT = $(if ($vs[0] -eq $vs[-1]) { '{0:0.0}%' -f $vs[0] } else { ('{0:0.0}' -f $vs[0]) + '～' + ('{0:0.0}%' -f $vs[-1]) }) } else { $vN = $gi.Count; $vT = [string]$gi.Count }
    $q = 0; $lst = @($gi | ForEach-Object { $q++; "$q. " + $(if ($_.IP -ne '—') { $_.IP + ' ' } else { '' }) + $_.DevN + $(if ($_.Obj -notin '設備', '—') { ' ' + $_.Obj } else { '' }) + '｜' + $_.Prob + $(if ($_.ValT -ne '—') { ' ' + $_.ValT } else { '' }) + '｜' + $_.Now })
    $fDisp.Add([pscustomobject]@{ Sys = 'WhatsUp'; Loc = '—'; IP = '—'; DevN = $dn; Obj = $ob; Prob = $pb; Now = ''; ValN = $vN; ValT = $vT; Dur = (@($gi | ForEach-Object { [int]$_.Dur } | Sort-Object)[-1]); List = $lst })
  }
  foreach ($i in @($fol | Where-Object { $_.Src -ne '1' })) { $fDisp.Add([pscustomobject]@{ Sys = $i.Sys; Loc = $i.Loc; IP = $i.IP; DevN = $i.DevN; Obj = $i.Obj; Prob = $i.Prob; Now = $i.Now; ValN = $i.ValN; ValT = $i.ValT; Dur = $i.Dur; List = @() }) }
  $fSb = New-Object Text.StringBuilder; $fn = 0
  foreach ($i in $fDisp) { $fn++
    $sub = if (@($i.List).Count) { "<details class='dl'><summary>明細（" + @($i.List).Count + " 筆）</summary><button type='button' class='cpr' data-c='" + (Esc ((@($i.List) | ForEach-Object { $_ -replace '^\d+\. ', '' }) -join "`n")) + "'>複製明細</button><ol>" + ((@($i.List) | ForEach-Object { '<li>' + (Esc ($_ -replace '^\d+\. ', '')) + '</li>' }) -join '') + '</ol></details>' } else { "<div class='nt'>" + (Esc $i.Now) + "</div><button type='button' class='cpr' data-c='" + (Esc (CpLine $i)) + "'>複製</button>" }
    [void]$fSb.Append("<tr data-sys='$($i.Sys)'><td class='id' data-v='$fn'>F$fn</td><td>$($i.Sys)</td><td>" + (Esc $i.Loc) + '</td><td>' + (Esc $i.IP) + '</td><td>' + (Esc $i.DevN) + '</td><td>' + (Esc $i.Obj) + '</td><td>' + (Esc $i.Prob) + $sub + "</td><td class='n' data-v='" + $(if ($null -ne $i.ValN) { $i.ValN } else { -1 }) + "'>" + (Esc $i.ValT) + "</td><td class='n' data-v='$($i.Dur)'>$($i.Dur)</td></tr>") }
  if (-not $fn) { [void]$fSb.Append("<tr><td colspan='9' class='none'>本日無追蹤事項。</td></tr>") }
  $sysBar = { param($pnl, $list) $b = "<div class='sub' data-for='$pnl'><button type='button' aria-pressed='true' data-f=''>全部（$(@($list).Count)）</button>"; foreach ($sk in $sysKeys) { $c = @($list | Where-Object { $_.Sys -eq $sysName[$sk] }).Count; if ($c) { $b += "<button type='button' aria-pressed='false' data-f='$($sysName[$sk])'>$($sysName[$sk])（$c）</button>" } }; $b + '</div>' }

  # ---- 一、結論
  $actRed = @($act | Where-Object { -not $_.Unk }); $actUnk = @($act | Where-Object { $_.Unk })
  $parts = @($actRed | Group-Object Grp | ForEach-Object { $_.Name + ' ' + $_.Count + ' ' + $_.Group[0].Unit })
  $unkSys = @($actUnk | ForEach-Object { $_.Sys } | Select-Object -Unique)
  $vText = ''
  $nrTxt = if ($notRun.Count) { '未執行 ' + (($notRun | ForEach-Object { $sysName[$_] }) -join '、') + '，須補跑' } else { '' }
  if ($act.Count) {
    $vText = (@($parts) + @($(if ($actUnk.Count) { '資料查不到 ' + $actUnk.Count + ' 項（' + ($unkSys -join '、') + '），須人工確認' }))) -join '、'
    if ($nrTxt) { $vText += '；' + $nrTxt }
    if ($fn) { $vText += "；追蹤 $fn 項" }
    $vText += '。'
    $vHead = "須處理 $($act.Count) 項"; $vCls = $(if ($actRed.Count) { 'bad' } else { 'unk' })
  } elseif ($nrTxt) { $vHead = '未完成'; $vText = '無須處理事項；' + $nrTxt + $(if ($fn) { "；追蹤 $fn 項" } else { '' }) + '。'; $vCls = 'unk' }
  elseif ($fn) { $vHead = '無須處理'; $vText = "無須處理事項；追蹤 $fn 項。"; $vCls = 'ok' }
  else { $vHead = '正常'; $vText = '本日檢查全部正常。'; $vCls = 'ok' }
  if ($pendN) { $vText = $vText.TrimEnd('。') + "；例外待簽核 $pendN 項。" }
  $firstSec = @{}; $kk2 = 0; foreach ($r in $res) { $kk2++; if (-not $firstSec.ContainsKey([string]$r.Item.Key)) { $firstSec[[string]$r.Item.Key] = 's' + $kk2 } }
  $sumSb = New-Object Text.StringBuilder; $sn = 0; $doneN = 0
  foreach ($sk in $allKeys) { $sn++
    if ($notRun -contains $sk) { [void]$sumSb.Append("<tr tabindex='0'><td class='id' data-v='$sn'>$sn</td><td>" + (Esc $sysItem[$sk]) + "</td><td>設備清單已設定</td><td data-v='2'><span class='pill p-unk'>未執行</span></td><td class='n' data-v='0'>0</td><td class='n' data-v='0'>0</td><td>本次未執行，須補跑</td></tr>"); continue }
    $rs = @($res | Where-Object { [string]$_.Item.Key -eq $sk }); $ok = ($complete[$sk] -ne $false); if ($ok) { $doneN++ }
    # 檢查對象
    $tg = @()
    switch ($sk) {
      '1' { $dk = @(); foreach ($r in @($rs | Where-Object { $_.Dir })) { $dk += @(Csv-In $r.Dir '07_硬碟.csv') }; if ($dk.Count) { $tg += ('主機 ' + @($dk | ForEach-Object { [string]$_.裝置ID } | Select-Object -Unique).Count + ' 台／磁碟 ' + $dk.Count + ' 顆') } }
      '2' { $sm = @(); $dsn = 0; foreach ($r in @($rs | Where-Object { $_.Dir })) { $sm += @(Csv-In $r.Dir 'Summary.csv'); $dsn += @(Csv-In $r.Dir 'Ds.csv').Count }; if ($sm.Count) { $esx = 0; foreach ($x in $sm) { $v0 = Num-Of $x.ESXi總數; if ($null -ne $v0) { $esx += $v0 } }; $tg += "vCenter $($sm.Count) 座／ESXi $esx 台／Datastore $dsn 顆" } }
      '3' { foreach ($r in @($rs | Where-Object { $_.Dir })) { $c = @(Csv-In $r.Dir '01_總表.csv').Count; $nm = if ([string]$r.Item.Text -match '（([^）]+)）') { $Matches[1] } else { 'Storage' }; if ($c) { $tg += "$nm $c 台" } } }
      '4' { $c = 0; foreach ($r in @($rs | Where-Object { $_.Dir })) { $c += @(Csv-In $r.Dir 'AD_net_time.csv').Count }; if ($c) { $tg += "DC $c 台" } }
    }
    $tgT = if ($tg.Count) { $tg -join '／' } else { '未取得' }
    $aS = @($act | Where-Object { $_.Src -eq $sk }); $fS = @($fDisp.ToArray() | Where-Object { $_.Sys -eq $sysName[$sk] })
    $aR = @($aS | Where-Object { -not $_.Unk }); $aU = @($aS | Where-Object { $_.Unk })
    $pl = if ($aR.Count) { "<span class='pill p-bad'>須處理</span>" } elseif ($aU.Count -or -not $ok) { "<span class='pill p-unk'>查不到</span>" } elseif ($fS.Count) { "<span class='pill p-warn'>追蹤</span>" } else { "<span class='pill p-ok'>正常</span>" }
    $pv = if ($aR.Count) { 1 } elseif ($aU.Count -or -not $ok) { 2 } elseif ($fS.Count) { 3 } else { 4 }
    $sumTx = @($aR | Group-Object Grp | ForEach-Object { $_.Name + '：' + $_.Count + ' ' + $_.Group[0].Unit })
    if ($aU.Count) { $sumTx += "查不到：$($aU.Count) 項" }
    if ($fS.Count) { $sumTx += "追蹤：$($fS.Count) 項" }
    $sumT = if ($sumTx.Count) { $sumTx -join '；' } else { '正常' }
    $sysN = $sysName[$sk]
    $aLink = if ($aS.Count) { "<a class='drill' href='#' data-go2='t2' data-f='$sysN'>$($aS.Count)</a>" } else { '0' }
    $fLink = if ($fS.Count) { "<a class='drill' href='#' data-go2='t3' data-f='$sysN'>$($fS.Count)</a>" } else { '0' }
    [void]$sumSb.Append("<tr tabindex='0'" + $(if ($firstSec[$sk]) { " data-sec='$($firstSec[$sk])'" } else { '' }) + "><td class='id' data-v='$sn'>$sn</td><td>" + (Esc $sysItem[$sk]) + '</td><td>' + (Esc $tgT) + "</td><td data-v='$pv'>$pl</td><td class='n' data-v='$($aS.Count)'>$aLink</td><td class='n' data-v='$($fS.Count)'>$fLink</td><td>" + (Esc $sumT) + '</td></tr>')
  }
  if (-not $sn) { [void]$sumSb.Append("<tr><td colspan='7' class='none'>本次未執行任何檢查項目。</td></tr>") }

  # ---- 五、檢查明細：各項結果與檢查表文字
  $sum = New-Object Text.StringBuilder; $tabs = New-Object Text.StringBuilder; $secNav = New-Object Text.StringBuilder; $k = 0; $verL = @()
  foreach ($r in $res) {
    $k++; $id = 's' + $k
    $cls = switch ($r.Code) { 2 { 'bad' } 3 { 'unk' } 0 { '' } default { 'warn' } }
    $rpt = if ($r.Dir) { Join-Path $r.Dir 'report.html' } else { '' }
    $link = if ($rpt -and (Test-Path -LiteralPath $rpt)) { $u0 = ''; try { $u0 = ([Uri]$rpt).AbsoluteUri } catch {}; if ($u0) { "<a href='" + (Esc $u0) + "' target='_blank' rel='noopener'>詳細報告</a>" } else { "<span class='u'>無報告</span>" } } else { "<span class='u'>無報告</span>" }
    $vr = ''
    if ($r.Dir) { try { $mf = Get-Content (Join-Path $r.Dir 'manifest.json') -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json; if ($mf.tool) { $vr = [string]$mf.tool } } catch {}
      if (-not $vr) { try { $rh = Join-Path $r.Dir 'report.html'; if (Test-Path -LiteralPath $rh) { $m0 = [regex]::Match([IO.File]::ReadAllText($rh), '\b([A-Za-z0-9]+(?:Daily|Time)) v\d+\.\d+\.\d+'); if ($m0.Success) { $vr = $m0.Value } } } catch {} } }
    $verL += ($r.Item.Text + '：' + $(if ($vr) { $vr } else { '未取得' }))
    [void]$sum.Append("<tr class='$cls'><td class='id' data-v='$k'>S$k</td><td><a href='#' data-sec='$id'>$($r.Item.Key). $(Esc $r.Item.Text)</a></td><td>$(Esc $CODE[$r.Code])</td><td>$link</td><td>$(Esc $r.Err)</td></tr>")
    [void]$secNav.Append("<button type='button' aria-pressed='false' data-sec='$id'>$($r.Item.Key). $(Esc $r.Item.Text)</button>")
    $rows = @()
    if ($r.Dir) {
      $f = @('00_檢查表文字.csv', 'Sheet.csv') | ForEach-Object { Join-Path $r.Dir $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
      if ($f) { try { $rows = @(Import-Csv $f -Encoding UTF8) } catch {} } else { $rows = @(Csv-In $r.Dir 'AD_net_time.csv') }
    }
    $tb = New-Object Text.StringBuilder
    if ($rows.Count) {
      $cols = @($rows[0].PSObject.Properties.Name)
      [void]$tb.Append("<div class='tw'><table class='t'><thead><tr><th>項次</th>" + (($cols | Where-Object { $_ -ne '項次' } | ForEach-Object { '<th>' + (Esc $_) + '</th>' }) -join '') + $(if ($cols -contains '檢查表文字') { '<th>複製</th>' } else { '' }) + '</tr></thead><tbody>')
      $j = 0
      foreach ($x in $rows) {
        $j++
        [void]$tb.Append("<tr><td class='id' data-v='$j'>$($r.Item.Key)-$j</td>")
        foreach ($c in @($cols | Where-Object { $_ -ne '項次' })) { [void]$tb.Append($(if ($c -eq '檢查表文字') { "<td class='cp'>" + $(if ($r.Item.Key -eq '1' -and [string]$x.項次 -eq '6') { Disk-Tbl $r.Dir } else { '' }) } else { '<td>' }) + (Esc $x.$c) + '</td>') }
        if ($cols -contains '檢查表文字') { [void]$tb.Append("<td><button type='button' class='copy'>複製</button></td>") }
        [void]$tb.Append('</tr>')
      }
      [void]$tb.Append('</tbody></table></div>')
    } else { [void]$tb.Append("<p class='note'>本項未取得檢查表文字，請參閱詳細報告。</p>") }
    [void]$tabs.Append("<div class='tsec' id='$id' hidden><p class='note'>結果：<b>$(Esc $CODE[$r.Code])</b>　$link</p>" + $tb.ToString() + '</div>')
  }

  # ---- 六、檢核紀錄
  $recLines = @()
  $cmpL = @()
  foreach ($sk in $allKeys) { $cmpL += ($sysName[$sk] + '：' + $(if ($notRun -contains $sk) { '未執行' } elseif ($complete[$sk] -ne $false) { '完成' } else { '資料不完整（' + (@($act | Where-Object { $_.Src -eq $sk -and $_.Unk } | ForEach-Object { $_.Prob }) -join '、') + '）' })) }
  $recLines += , @('資料完整度', ("$doneN／$($allKeys.Count) 項完成。" + ($cmpL -join '；') + $(if ($cfgNote) { '。' + $cfgNote } else { '' })))
  $recLines += , @('例外清單', ($exStat + $(if ($script:diskExBad.Count) { '；未套用：' + ($script:diskExBad -join '、') } else { '' }) + $(if ($script:exConvNote) { '；' + $script:exConvNote } else { '' })))
  $recLines += , @('判定門檻', "WhatsUp 主機硬碟 ≥$diskThr% 須處理、$diskWarn～$diskThr% 追蹤；Datastore／Pool／檔案系統／LUN ≥90% 須處理（≥95% 列第一級）；重要群組設備離線、ESXi 失聯、硬體異常、查不到列第一級；例外到期或使用率較登記時增加逾 3 個百分點即失效")
  $recLines += , @('工具版本', ($DcVer + '；' + ($verL -join '；')))
  $nNew = @($all | Where-Object { $_.Status -eq '今天新增' }).Count; $nWorse = @($all | Where-Object { $_.Status -eq '變嚴重' }).Count
  $recLines += , @('歷史比對', ('與過去 7 天比對：須處理中今日新增 ' + @($act | Where-Object { $_.Status -eq '今天新增' }).Count + ' 項、變嚴重 ' + $nWorse + ' 項、持續 ' + @($act | Where-Object { $_.Status -like '近 7 天*' }).Count + ' 項' + $(if ($lastRun) { '；上次（' + $lastRun.date + '）列第一、二級而本日未出現 ' + $recovered.Count + ' 項' + $(if ($recovered.Count) { '：' + ($recovered -join '、') } else { '' }) } else { '' }) + $(if ($histNote) { '；' + $histNote } else { '' })))
  $rSb = New-Object Text.StringBuilder; $rn = 0
  foreach ($rl in $recLines) { $rn++; [void]$rSb.Append("<tr><td class='id' data-v='$rn'>R$rn</td><td>" + (Esc $rl[0]) + '</td><td>' + (Esc $rl[1]) + '</td></tr>') }

  $scope = (@($allKeys | ForEach-Object { $sysName[$_] }) -join '、'); if (-not $scope) { $scope = '無' }
  $runner = "$env:USERDOMAIN\$env:USERNAME"
  $css = @'
:root{--bg:#F6F8F7;--paper:#FFFFFF;--ink:#1E2622;--sub:#55625C;--line:#DCE3DF;--brand:#0C6B37;--brand-soft:#E7F2EC;
--bad:#B3261E;--bad-soft:#FBEAE8;--warn:#8A5A00;--warn-soft:#FDF3DD;--unk:#5B6670;--unk-soft:#EEF1F3;--ok:#1F7A45;--ok-soft:#E6F4EC;
--f-body:"Microsoft JhengHei","微軟正黑體","Noto Sans TC",system-ui,sans-serif;--f-num:Calibri,"Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}[hidden]{display:none!important}td.dt{white-space:nowrap}
body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--f-body);font-size:14px;line-height:1.6}
.wrap{max-width:1800px;margin:0 auto;padding:20px 16px 40px;display:flex;flex-direction:column;gap:16px}
header.doc{background:var(--paper);border:1px solid var(--line);border-top:4px solid var(--brand);border-radius:8px;padding:16px 20px;display:flex;flex-wrap:wrap;gap:8px 32px;align-items:flex-end;justify-content:space-between}
header.doc h1{margin:0;font-size:22px;letter-spacing:.02em}
header.doc dl{display:grid;grid-template-columns:auto auto auto auto;gap:2px 12px;margin:0;font-size:13px}
header.doc dt{color:var(--sub)}header.doc dd{margin:0;font-family:var(--f-num)}
nav.tabs{display:flex;gap:4px;border-bottom:2px solid var(--line);overflow-x:auto}
nav.tabs button{font:inherit;border:0;background:none;padding:10px 16px;color:var(--sub);cursor:pointer;border-bottom:3px solid transparent;margin-bottom:-2px;white-space:nowrap}
nav.tabs button[aria-selected="true"]{color:var(--brand);border-bottom-color:var(--brand);font-weight:700}
nav.tabs button:focus-visible,.sum tbody tr:focus-visible,th:focus-visible{outline:2px solid var(--brand);outline-offset:2px}
.cnt{font-family:var(--f-num);margin-left:4px;font-size:12px;padding:0 6px;border-radius:9px;background:var(--line);color:var(--ink)}
section.panel{background:var(--paper);border:1px solid var(--line);border-radius:8px;padding:20px;display:flex;flex-direction:column;gap:16px;min-width:0}
.verdict{display:flex;gap:16px;align-items:center;flex-wrap:wrap;padding:14px 16px;border-radius:6px}
.verdict .lv{font-weight:700;font-size:18px;white-space:nowrap}.verdict p{margin:0;font-size:16px;max-width:80ch}
.verdict.bad{background:var(--bad-soft);border-left:6px solid var(--bad)}.verdict.bad .lv{color:var(--bad)}
.verdict.unk{background:var(--unk-soft);border-left:6px solid var(--unk)}.verdict.unk .lv{color:var(--unk)}
.verdict.ok{background:var(--ok-soft);border-left:6px solid var(--ok)}.verdict.ok .lv{color:var(--ok)}
h2{margin:0;font-size:16px;color:var(--brand)}.h2r{display:flex;gap:12px;align-items:baseline;flex-wrap:wrap}.h2r span{font-size:13px;color:var(--sub);font-family:var(--f-num)}
.tw{overflow-x:auto;min-width:0}
table{border-collapse:collapse;width:100%;font-size:13.5px;background:var(--paper)}
th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{background:var(--brand-soft);color:var(--ink);font-weight:700;white-space:nowrap;cursor:pointer;user-select:none}
th[aria-sort="ascending"]::after{content:" ▲";font-size:10px}th[aria-sort="descending"]::after{content:" ▼";font-size:10px}
td.n,th.n{font-family:var(--f-num);font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}
td.id{font-family:var(--f-num);color:var(--sub);white-space:nowrap}
details.dl{margin-top:2px;font-size:12.5px}details.dl summary{cursor:pointer;color:var(--brand)}details.dl ol{margin:4px 0 0;padding-left:22px;color:var(--sub)}
tr.exrow td{background:var(--brand-soft)}.exbox{display:flex;flex-direction:column;gap:8px;position:sticky;left:12px;width:max-content;max-width:min(860px,calc(100vw - 96px))}.exh{font-weight:700}.exl{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.exl>span{min-width:52px;color:var(--sub)}
.exl button.rb,.exc{font:inherit;font-size:13px;border:1px solid var(--line);background:var(--paper);border-radius:14px;padding:2px 12px;cursor:pointer}.exl button.rb[aria-pressed="true"]{background:var(--brand);border-color:var(--brand);color:#fff}
.exok{font:inherit;font-size:13px;border:1px solid var(--brand);background:var(--brand);color:#fff;border-radius:4px;padding:3px 16px;cursor:pointer}.exl input{font:inherit;font-size:13px;padding:2px 6px;border:1px solid var(--line);border-radius:4px}.exm{font-size:13px;color:var(--bad)}.exm .exline{display:block;width:100%;margin-top:4px;font-family:var(--f-num)}
td.none{color:var(--sub);text-align:center;padding:18px}
.pill{display:inline-block;padding:1px 10px;border-radius:10px;font-size:12.5px;font-weight:700;white-space:nowrap}
.p-bad{background:var(--bad-soft);color:var(--bad)}.p-warn{background:var(--warn-soft);color:var(--warn)}.p-ok{background:var(--ok-soft);color:var(--ok)}.p-unk{background:var(--unk-soft);color:var(--unk)}
.tag{display:inline-block;margin-left:6px;font-size:11.5px;padding:0 6px;border-radius:4px;background:var(--bad);color:#fff;vertical-align:1px}
.nt{font-size:12px;color:var(--sub);margin-top:2px}
.sum tbody tr{cursor:pointer}.sum tbody tr:hover{background:var(--brand-soft)}
a.drill{color:var(--brand);font-family:var(--f-num);font-weight:700;text-decoration:underline;cursor:pointer}
a{color:var(--brand)}
.note{font-size:12.5px;color:var(--sub);margin:0}
.sub,.secnav{display:flex;gap:6px;flex-wrap:wrap}.sub button,.secnav button{font:inherit;font-size:13px;border:1px solid var(--line);background:var(--paper);color:var(--ink);border-radius:14px;padding:3px 12px;cursor:pointer}
.sub button[aria-pressed="true"],.secnav button[aria-pressed="true"]{background:var(--brand);border-color:var(--brand);color:#fff}
.exb{font:inherit;font-size:12px;border:1px solid var(--brand);color:var(--brand);background:var(--paper);border-radius:4px;padding:1px 8px;cursor:pointer;white-space:nowrap}
input.dn{width:18px;height:18px;accent-color:var(--brand);cursor:pointer;margin:2px 0 0}
tr.done td{opacity:.55}
tr.bad td{background:#FDF3F1}tr.warn td{background:#FFF8E6}tr.unk td{background:#F0F1F2}.u{color:#888}
button.copy,button.cpr{font:inherit;font-size:12px;border:1px solid var(--brand);color:var(--brand);background:var(--paper);border-radius:4px;padding:1px 8px;cursor:pointer;white-space:nowrap}
button.cpr{margin:4px 0 2px;display:inline-block}
button.nbb{font:inherit;font-size:12px;border:1px solid var(--line);background:var(--paper);border-radius:4px;padding:1px 8px;cursor:pointer;white-space:nowrap}.nbt{font-size:13px;color:#0C6B37;max-width:220px}
.dkw{max-height:520px;overflow:auto}.dkpop{font:inherit;font-size:12px;border:1px solid var(--brand);color:var(--brand);background:var(--paper);border-radius:4px;padding:2px 10px;margin:0 0 6px;cursor:pointer}table.act td:nth-child(9){min-width:240px}table.act td:nth-child(14){min-width:120px}.dk td,.dk th{font-size:13px;padding:4px 8px}.dk tr.bad td{color:#B3261E}.dk tr.warn td{color:#8A6D00}
.cpt{white-space:pre-wrap;line-height:1.6}.cpt.fold{display:none}.cpt .al{color:#B3261E;font-weight:700}.cpt .am{color:#8A6D00;font-weight:700}
button.more{font:inherit;font-size:12px;padding:1px 10px;border:1px solid var(--line);border-radius:12px;background:var(--bg);cursor:pointer}
.wall{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:16px;align-items:start}@media (max-width:960px){.wall{grid-template-columns:1fr}}
.lg{display:flex;flex-wrap:wrap;gap:14px;margin-bottom:10px;font-size:13px;color:var(--sub);align-items:center}.dot{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.dot.red{background:#C9473A}.dot.amb{background:#E3C27A}.dot.unk{border:1px dashed #8C9590}.dot.ok{background:#CFE5D7}
.zone{border:1px solid var(--line);border-radius:8px;padding:10px 12px;margin-bottom:10px}.zh{margin-bottom:8px;font-size:13px}.zh .m{color:var(--sub)}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:8px}
.tile{text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:2px;padding:8px 10px;min-height:70px;border-radius:6px;font-family:inherit;color:var(--ink)}
.tile .tn{font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.tile .tv{font-size:20px;font-weight:700;font-family:var(--f-num)}.tile .th{font-size:11px;color:var(--sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tile.red{background:#FDF1EF;border:1px solid #C9473A}.tile.red .tv{color:var(--bad)}
.tile.amb{background:#FFF8E6;border:1px solid #E3C27A}.tile.amb .tv{color:var(--warn)}
.tile.unk{background:#F0F1F2;border:1px dashed #8C9590}.tile.unk .tv{color:var(--unk)}
.tile.ok{background:#F2F8F4;border:1px solid #CFE5D7}.tile.ok .tv{color:var(--ok)}
.tile.on{outline:3px solid var(--brand);outline-offset:2px}
.wr{position:sticky;top:12px}
.det{border:1px solid var(--line);border-radius:8px;padding:12px 14px;display:flex;flex-direction:column;gap:6px;max-height:80vh;overflow:auto}.det b{font-size:16px}.det .dv{font-size:24px;font-weight:700;font-family:var(--f-num)}
#detL div{font-size:13px;line-height:1.6;border-top:1px solid var(--line);padding-top:4px}#detL div.hd{font-weight:700;color:var(--brand);margin-top:6px;border-top:2px solid var(--brand)}
footer{font-size:12px;color:var(--sub);text-align:right}
'@
  $js = @'
(function(){
var tabs=document.querySelectorAll('nav.tabs button');
function show(id,filter){tabs.forEach(function(b){b.setAttribute('aria-selected',b.getAttribute('data-tab')===id?'true':'false')});document.querySelectorAll('section.panel').forEach(function(p){p.hidden=p.id!==id});
 if(filter!==undefined&&filter!==null){var bar=document.querySelector('.sub[data-for="'+id+'"]');if(bar){var b=bar.querySelector('button[data-f="'+filter+'"]')||bar.querySelector('button[data-f=""]');if(b)b.click()}}window.scrollTo(0,0)}
tabs.forEach(function(b){b.addEventListener('click',function(){show(b.getAttribute('data-tab'))})});
document.querySelectorAll('a.drill').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();show(a.getAttribute('data-go2'),a.getAttribute('data-f'))})});
document.querySelectorAll('.sub').forEach(function(bar){bar.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;bar.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')});
 var f=b.getAttribute('data-f');document.querySelectorAll('#'+bar.getAttribute('data-for')+' tbody tr[data-sys]').forEach(function(r){r.hidden=!!f&&r.getAttribute('data-sys')!==f&&r.getAttribute('data-sign')!==f});bar.closest('section').querySelectorAll('tr.exrow').forEach(function(x){x.remove()})})});
var secBtns=document.querySelectorAll('.secnav button');
function showSec(id){document.querySelectorAll('.tsec').forEach(function(s){s.hidden=s.id!==id});secBtns.forEach(function(b){b.setAttribute('aria-pressed',b.getAttribute('data-sec')===id?'true':'false')})}
secBtns.forEach(function(b){b.addEventListener('click',function(){showSec(b.getAttribute('data-sec'))})});
document.querySelectorAll('a[data-sec]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();showSec(a.getAttribute('data-sec'));var n=document.querySelector('.secnav');if(n)n.scrollIntoView({block:'start'})})});
document.querySelectorAll('.sum tbody tr[data-sec]').forEach(function(r){function go(){show('t4');showSec(r.getAttribute('data-sec'));var n=document.querySelector('.secnav');if(n)n.scrollIntoView({block:'start'})}r.addEventListener('click',go);r.addEventListener('keydown',function(e){if(e.key==='Enter')go()})});
if(secBtns.length)showSec(secBtns[0].getAttribute('data-sec'));
document.querySelectorAll('section.panel table').forEach(function(t){var hr=t.tHead&&t.tHead.rows[0];if(!hr)return;
 Array.prototype.forEach.call(hr.cells,function(th,ci){th.tabIndex=0;function srt(){var asc=th.getAttribute('aria-sort')!=='ascending';Array.prototype.forEach.call(hr.cells,function(x){x.removeAttribute('aria-sort')});th.setAttribute('aria-sort',asc?'ascending':'descending');
  t.querySelectorAll('tr.exrow').forEach(function(x){x.remove()});var tb=t.tBodies[0];var rows=Array.prototype.slice.call(tb.rows).filter(function(r){return r.cells.length===hr.cells.length});
  rows.sort(function(a,b){var x=a.cells[ci],y=b.cells[ci];var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var d=(p!==null&&q!==null)?((parseFloat(p)||0)-(parseFloat(q)||0)):x.textContent.trim().localeCompare(y.textContent.trim(),'zh-Hant',{numeric:true});if(d===0){var ia=a.querySelector('td.id'),ib=b.querySelector('td.id');if(ia&&ib)return (parseFloat(ia.getAttribute('data-v'))||0)-(parseFloat(ib.getAttribute('data-v'))||0)}return asc?d:-d});
  rows.forEach(function(r){tb.appendChild(r)})}
  th.addEventListener('click',srt);th.addEventListener('keydown',function(e){if(e.key==='Enter')srt()})})});
document.querySelectorAll('td.cp').forEach(function(td){var tb=td.querySelector('.dkx');if(tb)tb.remove();var t=td.textContent,n=t.split('\n').filter(function(x){return x.trim()}).length;td.textContent='';var d=document.createElement('div');d.className='cpt';var rx=/⚠|（異常）|[：:]\s*red\b|查不到|^\s*\d+\.\s/;
 t.split('\n').forEach(function(l,i,a){var s=document.createElement('span');s.textContent=l+(i<a.length-1?'\n':'');if(rx.test(l))s.className='al';else if(l.indexOf('△')>=0)s.className='am';d.appendChild(s)});
 if(n>3&&!tb){d.classList.add('fold');var b=document.createElement('button');b.type='button';b.className='more';var lb=function(f){b.textContent=f?'展開（共 '+n+' 行）':'收合（共 '+n+' 行）'};lb(true);td.appendChild(b);b.addEventListener('click',function(){lb(d.classList.toggle('fold'))})}td.appendChild(d);if(tb){d.style.display='none';td.appendChild(tb);t.split('\n').filter(function(l){return /^\s*（/.test(l)}).forEach(function(l){var q=document.createElement('div');q.className='nt';q.textContent=l.trim();td.appendChild(q)});var q2=document.createElement('div');q2.className='nt';q2.textContent='「複製」依固定順序（≥90% 在前、快滿的在前），不跟表頭排序。';td.appendChild(q2)}});
function cp(t){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(a);if(!ok)alert('複製失敗，請以滑鼠選取文字後按 Ctrl+C');return ok}
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t=b.closest('tr').querySelector('td.cp .cpt').textContent;if(t.indexOf('\n')>=0)t='"'+t.split('"').join('""')+'"';if(!cp(t))return;b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)})});
document.querySelectorAll('button.cpr').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();var t=b.getAttribute('data-c')||'';if(t.indexOf('\n')>=0)t='"'+t.split('"').join('""')+'"';if(!cp(t))return;var o=b.textContent;b.textContent='已複製';setTimeout(function(){b.textContent=o},1500)})});
var EXF='例外清單.csv',EXH=['類別','地點','IP','設備名稱','對象','裝置ID','登記使用率','到期日','原因','登記日','登記人','簽呈文號','核准日'];
function clean(v){return String(v==null?'':v).replace(/[\r\n\t|｜]/g,'').trim()}
function cleanWhy(v){return String(v==null?'':v).replace(/[\r\n\t|｜]+/g,' ').trim()}
function csvF(v){v=String(v==null?'':v);if(/^[=+\-@]/.test(v))v="'"+v;return /[",\r\n]/.test(v)?'"'+v.split('"').join('""')+'"':v}
function parseCsv(t){var rows=[],row=[],f='',q=false,i,c;for(i=0;i<t.length;i++){c=t.charAt(i);if(q){if(c==='"'){if(t.charAt(i+1)==='"'){f+='"';i++}else q=false}else f+=c}else if(c==='"')q=true;else if(c===','){row.push(f);f=''}else if(c==='\n'){row.push(f.replace(/\r$/,''));rows.push(row);row=[];f=''}else f+=c}if(f!==''||row.length){row.push(f.replace(/\r$/,''));rows.push(row)}return rows}
function exKey(cat,ip,obj,id){cat=String(cat||'').trim();obj=String(obj||'').trim();if(cat==='Datastore'&&obj.indexOf('Datastore ')===0)obj=obj.substring(10);var sys={'硬碟':'whatsup','Datastore':'vmware','Storage':'storage'}[cat]||cat;return (sys+'|'+String(cat==='硬碟'?(id||''):(ip||'')).trim()+'|'+obj).toLowerCase()}
function ymd(d){function p(n){return (n<10?'0':'')+n}return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())}
function addDays(n){var d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()+n);return d}
function encErr(m){var e=new Error(m);e.name='Encoding';return e}
function decodeBuf(u){if(u.length>=2&&((u[0]===0xFF&&u[1]===0xFE)||(u[0]===0xFE&&u[1]===0xFF)))throw encErr('UTF-16 編碼');var t;
 if(u.length>=3&&u[0]===0xEF&&u[1]===0xBB&&u[2]===0xBF){try{t=new TextDecoder('utf-8',{fatal:true}).decode(u.subarray(3))}catch(x){throw encErr('UTF-8 內容損毀')}}
 else{try{t=new TextDecoder('utf-8',{fatal:true}).decode(u)}catch(x){try{t=new TextDecoder('big5',{fatal:true}).decode(u)}catch(y){throw encErr('無法辨識的編碼')}}}
 if(t.indexOf(String.fromCharCode(0xFFFD))>=0)throw encErr('含無法辨識的字元');return t}
function idb(){return new Promise(function(res,rej){var r=indexedDB.open('dailycheck',1);r.onupgradeneeded=function(){r.result.createObjectStore('kv')};r.onsuccess=function(){res(r.result)};r.onerror=function(){rej(r.error)}})}
function idbGet(){return idb().then(function(db){return new Promise(function(res){var q=db.transaction('kv').objectStore('kv').get('dir');q.onsuccess=function(){res(q.result||null)};q.onerror=function(){res(null)}})}).catch(function(){return null})}
function idbPut(h){return idb().then(function(db){return new Promise(function(res){var tx=db.transaction('kv','readwrite');tx.objectStore('kv').put(h,'dir');tx.oncomplete=function(){res()};tx.onerror=function(){res()}})}).catch(function(){})}
// 資料夾要是「產生這份報告的那一版」：比對 overview.ps1 裡的版本字串（升版後瀏覽器記住的舊資料夾不算，會請你重選）
async function isApp(h){try{var ver=((document.querySelector('header.doc')||document.body).textContent.match(/DailyCheck v[\d.]+/)||[''])[0];var f=await (await h.getFileHandle('overview.ps1')).getFile();var t=await f.text();return !!ver&&t.indexOf("$DcVer = '"+ver+"'")>=0}catch(e){return false}}
async function getDir(){var h=await idbGet();if(h){try{var q=await h.queryPermission({mode:'readwrite'});if(q!=='granted')q=await h.requestPermission({mode:'readwrite'});if(q==='granted'&&await isApp(h))return h}catch(e){}}
 h=await window.showDirectoryPicker({id:'dailycheck',mode:'readwrite'});if(!await isApp(h)){var er=new Error('wrongdir');er.name='WrongDir';throw er}await idbPut(h);return h}
function exDate(s){var m=/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/.exec(String(s||'').trim());if(!m)return '';function p(n){n=parseInt(n,10);return (n<10?'0':'')+n}return m[1]+'-'+p(m[2])+'-'+p(m[3])}
function exPct(s){var v=parseFloat(String(s||'').replace(/[%％]/g,''));return (isFinite(v)&&v>=0&&v<=100)?v:null}
// 同一對象最後一列「目前有效」才算已在清單：格式完整、未到期、未增加逾 3 點、未達 98%
function exActive(r,ci,cur){var d=exDate(r[ci('到期日')]),p=exPct(r[ci('登記使用率')]),why=String(r[ci('原因')]||'').trim();if(!d||p===null||!why)return false;if(d<ymd(addDays(0)))return false;if(cur!==null&&(cur-p>3||cur>=98))return false;return true}
function exCell(v){v=String(v==null?'':v);return /^[=+\-@]/.test(v)?"'"+v:v}
async function appendEx(dir,rec,cur){
 var fh=null,txt='';
 try{fh=await dir.getFileHandle(EXF)}catch(e){if(!e||e.name!=='NotFoundError')throw e}
 if(fh)txt=decodeBuf(new Uint8Array(await (await fh.getFile()).arrayBuffer()));
 var rows=parseCsv(txt).filter(function(r){return r.some(function(x){return x.trim()})});var hdr=EXH.slice();
 if(rows.length){hdr=rows[0].map(function(x){return x.replace(/^[\s\uFEFF]+/,'').trim()});
  var miss=EXH.filter(function(x){return hdr.indexOf(x)<0}),dupc=hdr.filter(function(x,i){return x&&hdr.indexOf(x)!==i});
  if(miss.length||dupc.length){var e1=new Error((miss.length?'缺欄位 '+miss.join('、'):'')+(dupc.length?' 重複欄位 '+dupc.join('、'):''));e1.name='BadHeader';throw e1}
  var ci=function(n){return hdr.indexOf(n)},k=exKey(rec['類別'],rec['IP'],rec['對象'],rec['裝置ID']),last=null;
  for(var i=1;i<rows.length;i++){var r=rows[i];if(exKey(r[ci('類別')],r[ci('IP')],r[ci('對象')],r[ci('裝置ID')])===k)last=r}
  if(last&&exActive(last,ci,cur))return 'dup'}
 else txt=EXH.join(',')+'\r\n';
 var line=hdr.map(function(h){return csvF(rec[h]||'')}).join(',');
 if(txt&&!/\n$/.test(txt))txt+='\r\n';txt+=line+'\r\n';
 if(!fh)fh=await dir.getFileHandle(EXF,{create:true});
 var w=await fh.createWritable();
 try{await w.write(new Blob([new Uint8Array([0xEF,0xBB,0xBF]),txt],{type:'text/csv'}));await w.close()}catch(e){try{await w.abort()}catch(e2){}throw e}
 // 已提交；以下只做讀回確認，失敗也不能說「沒寫入」
 try{var back=parseCsv(decodeBuf(new Uint8Array(await (await fh.getFile()).arrayBuffer())));var bh=back[0].map(function(x){return x.replace(/^[\s\uFEFF]+/,'').trim()});
  var okRow=back.slice(1).some(function(r){return EXH.every(function(h){var j=bh.indexOf(h);return j>=0&&String(r[j]||'')===exCell(rec[h]||'')})});
  if(!okRow)throw new Error('讀回找不到剛寫入的那一列')}catch(e){var e3=new Error(e&&e.message||'');e3.name='Unverified';throw e3}
 return 'ok'}
function recLine(rec){return EXH.map(function(h){return csvF(rec[h]||'')}).join(',')}
function addTxRow(b,rec,curT){var tb=document.querySelector('#tx tbody');if(!tb)return;var none=tb.querySelector('td.none');if(none)none.parentNode.remove();
 var n=tb.querySelectorAll('tr[data-sys]').length+1,tr=document.createElement('tr');tr.setAttribute('data-sys','新登記');tr.setAttribute('data-sign','待簽核');
 var sysOf={'硬碟':'WhatsUp','Datastore':'VMware','Storage':'Storage'};
 var vals=[['X'+n,n,'id'],[sysOf[rec['類別']]||''],[rec['地點']||'—'],[rec['IP']||'—'],[rec['設備名稱']],[rec['類別']==='Datastore'&&!/^Datastore\s/.test(rec['對象'])?'Datastore '+rec['對象']:rec['對象']],[rec['登記使用率'],parseFloat(rec['登記使用率'])||-1,'n'],[curT||rec['登記使用率'],parseFloat(curT||rec['登記使用率'])||-1,'n'],[rec['到期日'],rec['到期日'].replace(/-/g,''),'dt'],['新登記',null,null,'p-ok'],['待簽核',null,null,'p-warn'],[rec['原因']],[EXF]];
 vals.forEach(function(v){var td=document.createElement('td');if(v[2])td.className=v[2];if(v[1]!=null)td.setAttribute('data-v',v[1]);if(v[3]){var s=document.createElement('span');s.className='pill '+v[3];s.textContent=v[0];td.appendChild(s)}else td.textContent=v[0];tr.appendChild(td)});tb.appendChild(tr);
 var bar=document.querySelector('.sub[data-for=tx]');if(bar&&!bar.querySelector('button[data-f="新登記"]')){var nb=document.createElement('button');nb.type='button';nb.setAttribute('aria-pressed','false');nb.setAttribute('data-f','新登記');nb.textContent='新登記';bar.appendChild(nb)}
 var c=document.querySelector('nav.tabs [data-tab=tx] .cnt');if(c)c.textContent=String(tb.querySelectorAll('tr[data-sys]').length)}
function openExBox(b){var tr=b.closest('tr');var nx=tr.nextElementSibling;if(nx&&nx.classList.contains('exrow')){nx.remove();return}
 document.querySelectorAll('tr.exrow').forEach(function(x){x.remove()});
 var row=document.createElement('tr');row.className='exrow';var td=document.createElement('td');td.colSpan=tr.cells.length;row.appendChild(td);tr.parentNode.insertBefore(row,tr.nextSibling);
 var box=document.createElement('div');box.className='exbox';td.appendChild(box);var tw0=tr.closest('.tw');if(tw0)box.style.maxWidth=Math.max(280,tw0.clientWidth-32)+'px';
 var h=document.createElement('div');h.className='exh';h.textContent='登記例外：'+clean(b.getAttribute('data-dn'))+' '+clean(b.getAttribute('data-obj'))+'（目前 '+clean(b.getAttribute('data-pct'))+'%）';box.appendChild(h);
 var l1=document.createElement('div');l1.className='exl';var lb=document.createElement('span');lb.textContent='原因';l1.appendChild(lb);var reason='';
 var other=document.createElement('input');other.type='text';other.maxLength=100;other.placeholder='請輸入原因';other.hidden=true;
 ['已排擴充','容量固定（如 ISO 碟）','待清理','其他'].forEach(function(t){var x=document.createElement('button');x.type='button';x.className='rb';x.textContent=t;x.setAttribute('aria-pressed','false');x.addEventListener('click',function(){l1.querySelectorAll('button.rb').forEach(function(y){y.setAttribute('aria-pressed',y===x?'true':'false')});reason=t;other.hidden=(t!=='其他');if(t==='其他')other.focus()});l1.appendChild(x)});
 l1.appendChild(other);box.appendChild(l1);
 var l2=document.createElement('div');l2.className='exl';var lb2=document.createElement('span');lb2.textContent='到期日';l2.appendChild(lb2);var dt=document.createElement('input');dt.type='date';dt.value=ymd(addDays(90));dt.min=ymd(addDays(0));dt.max=ymd(addDays(365));l2.appendChild(dt);box.appendChild(l2);
 setTimeout(function(){try{box.scrollIntoView({block:'nearest',inline:'nearest'})}catch(e){}},0);
 var l3=document.createElement('div');l3.className='exl';var ok=document.createElement('button');ok.type='button';ok.className='exok';ok.textContent='確定';var cc=document.createElement('button');cc.type='button';cc.className='exc';cc.textContent='取消';var msg=document.createElement('div');msg.className='exm';l3.appendChild(ok);l3.appendChild(cc);box.appendChild(l3);box.appendChild(msg);
 cc.addEventListener('click',function(){row.remove()});
 ok.addEventListener('click',async function(){
  var why=cleanWhy(reason==='其他'?other.value:reason);msg.textContent='';
  if(!why){msg.textContent='請選擇原因';return}
  var d=dt.value;if(!/^\d{4}-\d{2}-\d{2}$/.test(d)||d<dt.min||d>dt.max){msg.textContent='到期日須在今天到一年內';return}
  var cur=exPct(b.getAttribute('data-pct'));if(cur===null){msg.textContent='目前使用率無效，無法登記例外';return}
  if(cur>=98){msg.textContent='使用率已達 98%，不能列例外';return}
  var body=document.body,rec={'類別':clean(b.getAttribute('data-cat')),'地點':clean(b.getAttribute('data-loc')),'IP':clean(b.getAttribute('data-ip')),'設備名稱':clean(b.getAttribute('data-dn')),'對象':clean(b.getAttribute('data-obj')),'裝置ID':clean(b.getAttribute('data-id')),'登記使用率':cur+'%','到期日':d,'原因':why,'登記日':ymd(addDays(0)),'登記人':clean(body.getAttribute('data-runner')),'簽呈文號':'','核准日':''};
  if(!rec['類別']||!rec['對象']||(rec['類別']==='硬碟'?!rec['裝置ID']:!rec['IP'])){msg.textContent='缺少識別資料，無法登記例外';return}
  var line=recLine(rec);ok.disabled=true;
  function fallback(r){var c=cp(line);msg.textContent='沒寫入：'+r+'。'+(c?'已改為複製，請貼進 '+EXF+'（新增一列）。':'請手動複製下列文字，貼進 '+EXF+'（新增一列）。');var inp=document.createElement('input');inp.type='text';inp.readOnly=true;inp.className='exline';inp.value=line;msg.appendChild(inp);inp.select();ok.disabled=false}
  if(!window.showDirectoryPicker||!window.indexedDB){fallback('此瀏覽器不支援直接寫檔');return}
  var r;
  try{msg.textContent='寫入中…';var dir=await getDir();r=await appendEx(dir,rec,cur)}
  catch(e){var n=e&&e.name||'';
   if(n==='Unverified'){msg.textContent='已寫入但無法確認，請開啟 '+EXF+' 檢查最後一列。';b.textContent='已寫入（待確認）';b.disabled=true;return}
   if(n==='AbortError')fallback('未選擇資料夾或已取消');
   else if(n==='WrongDir')fallback('所選資料夾不是這一版 DailyCheck 的程式資料夾（請選產生這份報告的那個資料夾）');
   else if(n==='BadHeader')fallback(EXF+' 的欄位不符（'+e.message+'）');
   else if(n==='Encoding')fallback(EXF+' 的編碼無法安全辨識（'+e.message+'），為避免破壞內容未寫入');
   else if(/NotReadable|NoModificationAllowed|InvalidState|InvalidModification/.test(n))fallback(EXF+' 正被其他程式開啟，請先關閉 Excel 再按一次');
   else fallback('寫入失敗（'+(n||'')+(e&&e.message?'：'+e.message:'')+'）');
   return}
  if(r==='dup'){msg.textContent='已在例外清單（目前有效），未重複寫入。';b.textContent='已在例外清單';b.disabled=true;return}
  b.textContent='已列例外（下次執行生效）';b.disabled=true;row.remove();
  try{addTxRow(b,rec,cur+'%')}catch(e){}});}
var NBF='備註.csv',NBH=['事項代碼','設備','對象','備註','日期','登記人'];
async function appendNote(dir,rec){var fh=null,txt='';
 try{fh=await dir.getFileHandle(NBF)}catch(e){if(!e||e.name!=='NotFoundError')throw e}
 if(fh)txt=decodeBuf(new Uint8Array(await (await fh.getFile()).arrayBuffer()));
 if(!txt.replace(/^﻿/,'').trim())txt=NBH.join(',')+'\r\n';else{var h0=(parseCsv(txt)[0]||[]).map(function(x){return x.replace(/^[\s﻿]+/,'').trim()});if(h0.join(',')!==NBH.join(',')){var eh=new Error('欄位不符');eh.name='BadHeader';throw eh}if(!/\n$/.test(txt))txt+='\r\n'}
 txt+=NBH.map(function(h){return csvF(rec[h]||'')}).join(',')+'\r\n';
 if(!fh)fh=await dir.getFileHandle(NBF,{create:true});
 var w=await fh.createWritable();try{await w.write(new Blob([new Uint8Array([0xEF,0xBB,0xBF]),txt.replace(/^﻿/,'')],{type:'text/csv'}));await w.close()}catch(e){try{await w.abort()}catch(e2){}throw e}}
document.querySelectorAll('button.nbb').forEach(function(b){b.addEventListener('click',async function(e){e.stopPropagation();
 var td=b.closest('td'),cur=td.querySelector('.nbt').textContent;
 var v=window.prompt('備註（例：已通知 AP，下週一處理）；清空＝刪除備註',cur);if(v===null)return;v=String(v).replace(/[\r\n\t]/g,' ').trim().slice(0,200);
 var rec={'事項代碼':b.getAttribute('data-k'),'設備':clean(b.getAttribute('data-dn')),'對象':clean(b.getAttribute('data-obj')),'備註':v,'日期':ymd(addDays(0)),'登記人':clean(document.body.getAttribute('data-runner')||'')};
 var line=NBH.map(function(h){return csvF(rec[h]||'')}).join(',');
 var hl=NBH.join(',')+'\r\n'+line;
 if(!window.showDirectoryPicker||!window.indexedDB){alert('此瀏覽器不能直接寫檔。'+(cp(hl)?'已複製（含表頭），請把第二行貼進 '+NBF+'；檔案不存在就整段貼上。':'請手動輸入到 '+NBF));return}
 try{b.disabled=true;var dir=await getDir();await appendNote(dir,rec);td.querySelector('.nbt').textContent=v;var nt=td.querySelector('.nt');if(!nt){nt=document.createElement('div');nt.className='nt';td.insertBefore(nt,b)}nt.textContent=v?(rec['日期']+' '+rec['登記人']):'';b.textContent=v?'已存（改備註）':'已清除';}
 catch(x){var n=x&&x.name||'';if(n==='AbortError')return;var c2=cp(hl);alert((/NotReadable|NoModificationAllowed|InvalidState|InvalidModification/.test(n)?NBF+' 正被其他程式開啟，請先關閉再試。':n==='WrongDir'?'所選資料夾不是這一版 DailyCheck 的程式資料夾。':n==='BadHeader'?NBF+' 的欄位不對，為避免寫壞未寫入。':'沒寫入（'+(n||x)+'）。')+(c2?'已複製（含表頭），可手動貼進 '+NBF:''))}
 finally{b.disabled=false}})});
document.querySelectorAll('button.dkpop').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();var t=b.parentNode.querySelector('table');if(!t)return;var inPage=function(){var w2=b.parentNode.querySelector('.dkw');if(w2)w2.style.maxHeight='none';b.textContent='已在本頁展開全表'};var w=window.open('','_blank');if(!w){inPage();return}try{var css=Array.prototype.map.call(document.querySelectorAll('style'),function(s){return s.outerHTML}).join('');var sj='document.querySelectorAll("th").forEach(function(th,i){th.style.cursor="pointer";th.addEventListener("click",function(){var tb=th.closest("table").tBodies[0],rs=[].slice.call(tb.rows),d=th.getAttribute("data-d")==="1"?-1:1;th.setAttribute("data-d",d===1?"1":"0");rs.sort(function(a,b){var p=a.cells[i].getAttribute("data-v"),q=b.cells[i].getAttribute("data-v"),x=parseFloat(p),y=parseFloat(q);if(p!==null&&q!==null&&!isNaN(x)&&!isNaN(y))return(x-y)*d;return a.cells[i].textContent.localeCompare(b.cells[i].textContent,"zh-Hant",{numeric:true})*d});rs.forEach(function(r){tb.appendChild(r)})})})';var ttl='硬碟明細｜'+document.title;w.document.open();w.document.write('<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title></title>'+css+'<style>body{padding:16px}.dkw{max-height:none}</style></head><body><h2></h2><p class="nt">點欄位標題可排序；這是開啟當下的副本。</p><div class="dkw">'+t.outerHTML+'</div><scr'+'ipt>'+sj+'</scr'+'ipt></body></html>');w.document.close();w.document.title=ttl;w.document.querySelector('h2').textContent=ttl;try{w.opener=null}catch(e2){}}catch(e){try{w.close()}catch(e3){}inPage()}})});
document.querySelectorAll('button.exb').forEach(function(b){b.addEventListener('click',function(e){e.stopPropagation();openExBox(b)})});
document.querySelectorAll('.tile').forEach(function(t){t.addEventListener('click',function(){document.querySelectorAll('.tile.on').forEach(function(x){x.classList.remove('on');x.setAttribute('aria-pressed','false')});t.classList.add('on');t.setAttribute('aria-pressed','true');
 document.getElementById('detN').textContent=t.getAttribute('data-n');var v=document.getElementById('detV');v.textContent=t.getAttribute('data-v');v.style.color=getComputedStyle(t.querySelector('.tv')).color;
 var L=document.getElementById('detL');L.textContent='';(t.getAttribute('data-d')||'').split('\n').forEach(function(s){if(!s)return;var d=document.createElement('div');d.textContent=s;if(s.charAt(0)==='【')d.className='hd';L.appendChild(d)})})});
var fr=document.querySelector('.tile.red')||document.querySelector('.tile.unk')||document.querySelector('.tile');if(fr)fr.click();
var dkey='dailycheck-done-'+((document.title.match(/\d{4}-\d{2}-\d{2}/)||[''])[0]);function rd(){try{var o=JSON.parse(localStorage.getItem(dkey)||'{}');return (o&&typeof o==='object')?o:{}}catch(e){return {}}}function wr(o){try{localStorage.setItem(dkey,JSON.stringify(o))}catch(e){}}
function cnt(){var a=document.querySelectorAll('input.dn'),n=0;a.forEach(function(c){if(c.checked)n++});var e=document.getElementById('dnc');if(e)e.textContent=a.length?('已處理 '+n+'／'+a.length):''}
var st=rd();document.querySelectorAll('input.dn').forEach(function(c){var k=c.getAttribute('data-k');function mark(){c.closest('tr').classList.toggle('done',c.checked);c.parentNode.setAttribute('data-v',c.checked?'1':'0')}if(st[k])c.checked=true;mark();
 c.addEventListener('change',function(){var o=rd();if(c.checked){o[k]=1}else{delete o[k]}wr(o);mark();cnt()})});cnt();
})();
'@
  $tabCnt = { param($n) "<span class='cnt'>$n</span>" }
  $html = '<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>每日系統檢查報告 ' + $ts.ToString('yyyy-MM-dd HH:mm') + '</title><style>' + $css + '</style></head><body data-runner="' + (Esc $runner) + '"><div class="wrap">' +
    '<header class="doc"><h1>每日系統檢查報告</h1><dl><dt>檢查日期</dt><dd>' + $ts.ToString('yyyy-MM-dd HH:mm') + '</dd><dt>執行人</dt><dd>' + (Esc $runner) + '</dd><dt>檢查範圍</dt><dd>' + (Esc $scope) + '</dd><dt>資料完整度</dt><dd>' + "$doneN／$($allKeys.Count) 項完成" + '</dd><dt>版本</dt><dd>' + (Esc $DcVer) + '</dd></dl></header>' +
    '<nav class="tabs" role="tablist" aria-label="報告分頁"><button type="button" role="tab" aria-selected="true" data-tab="t1">一、結論</button><button type="button" role="tab" aria-selected="false" data-tab="t2">二、須處理事項' + (& $tabCnt $pn) + '</button><button type="button" role="tab" aria-selected="false" data-tab="t3">三、追蹤事項' + (& $tabCnt $fn) + '</button><button type="button" role="tab" aria-selected="false" data-tab="tx">四、例外清單' + (& $tabCnt $xn) + '</button><button type="button" role="tab" aria-selected="false" data-tab="t4">五、檢查明細</button><button type="button" role="tab" aria-selected="false" data-tab="t5">六、檢核紀錄</button></nav>' +
    "<section class='panel' id='t1' role='tabpanel'><div class='verdict $vCls'><span class='lv'>" + (Esc $vHead) + '</span><p>' + (Esc $vText) + '</p></div><h2>檢查項目總表</h2>' +
    "<div class='tw'><table class='sum'><thead><tr><th class='n'>項次</th><th>檢查項目</th><th>檢查對象</th><th>狀態</th><th class='n'>須處理</th><th class='n'>追蹤</th><th>摘要</th></tr></thead><tbody>" + $sumSb.ToString() + '</tbody></table></div>' +
    "<p class='note'>狀態定義：須處理＝當日須通報並處置；追蹤＝未達處置門檻，持續觀察；查不到＝資料未取得，須人工確認。</p></section>" +
    "<section class='panel' id='t2' role='tabpanel' hidden><div class='h2r'><h2>須處理事項</h2><span id='dnc'></span></div>" + (& $sysBar 't2' $act) +
    "<div class='tw'><table class='act'><thead><tr><th>完成</th><th>項次</th><th>系統</th><th>等級</th><th>地點</th><th>IP</th><th>設備名稱</th><th>對象</th><th>問題</th><th class='n'>數值</th><th class='n'>每日成長（百分點）</th><th class='n'>估計滿載</th><th>首次發現</th><th>建議處置</th><th>例外</th><th>備註</th></tr></thead><tbody>" + $aSb.ToString() + '</tbody></table></div></section>' +
    "<section class='panel' id='t3' role='tabpanel' hidden><h2>追蹤事項</h2>" + (& $sysBar 't3' ($fDisp.ToArray())) +
    "<div class='tw'><table><thead><tr><th>項次</th><th>系統</th><th>地點</th><th>IP</th><th>設備名稱</th><th>對象</th><th>事項</th><th class='n'>數值</th><th class='n'>持續天數</th></tr></thead><tbody>" + $fSb.ToString() + '</tbody></table></div></section>' +
    "<section class='panel' id='tx' role='tabpanel' hidden><div class='h2r'><h2>例外清單</h2>" + $xlLink + "</div><p class='note'>已登記「暫不處理」的項目。有效例外不列入須處理；到期或使用率較登記時增加逾 3 個百分點即失效，自動回到須處理。</p>" + $exBar +
    "<div class='tw'><table><thead><tr><th>項次</th><th>系統</th><th>地點</th><th>IP</th><th>設備名稱</th><th>對象</th><th class='n'>登記時</th><th class='n'>目前</th><th>到期日</th><th>狀態</th><th>簽核</th><th>原因</th><th>例外檔</th></tr></thead><tbody>" + $exSb.ToString() + '</tbody></table></div>' +
    "<p class='note'>新增例外：在「二、須處理事項」該列按「列例外」，選擇原因與到期日後寫入程式資料夾「例外清單.csv」（下次執行生效）。填入簽呈文號即為已核准。</p></section>" +
    "<section class='panel' id='t4' role='tabpanel' hidden><h2>設備狀態</h2>" + $wallHtml +
    "<h2>各項執行結果</h2><div class='tw'><table><thead><tr><th>項次</th><th>檢查項目</th><th>結果</th><th>詳細報告</th><th>錯誤訊息</th></tr></thead><tbody>" + $sum.ToString() + '</tbody></table></div>' +
    "<h2>檢查表文字</h2><div class='secnav'>" + $secNav.ToString() + '</div>' + $tabs.ToString() + '</section>' +
    "<section class='panel' id='t5' role='tabpanel' hidden><h2>檢核紀錄</h2><div class='tw'><table><thead><tr><th>項次</th><th>類別</th><th>內容</th></tr></thead><tbody>" + $rSb.ToString() + '</tbody></table></div></section>' +
    '<footer>本報告由 DailyCheck 自動產生，唯讀檢查，不變更任何設定。</footer></div><script>' + $js + '</script></body></html>'
  $p = Join-Path $od '總覽.html'
  [IO.File]::WriteAllText($p, $html, (New-Object Text.UTF8Encoding($true)))
  try { $h2 = $html; if ($xlOk) { $enc = [Uri]::EscapeDataString($xlName); $h2 = $html.Replace("href='$enc'", "href='" + [Uri]::EscapeDataString((Split-Path $od -Leaf)) + "/$enc'") }; [IO.File]::WriteAllText((Join-Path (Join-Path $here 'daily_out') '最新總覽.html'), $h2, (New-Object Text.UTF8Encoding($true))) } catch {}
  Write-Host ("總覽：須處理 $($act.Count) 項（今日新增或變嚴重 $($urgent.Count) 項）、追蹤 $fn 項、例外 $xn 項")
  Write-Host ('總覽報告：' + $p)
  if (-not $NoOpen) { try { Start-Process $p } catch {} }
}

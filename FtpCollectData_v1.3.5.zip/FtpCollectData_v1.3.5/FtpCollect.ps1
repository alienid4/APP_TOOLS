﻿<#
.SYNOPSIS
  FtpCollect v1.3.2 -- FTP 主機本機唯讀收集（Serv-U／FileZilla，Windows PowerShell 5.1，不需 Python）。
  在 FTP 主機「上面」執行：設定檔遮密碼後複製、近 N 天 log、帳號／目錄／權限、目錄摘要（不帶完整檔名）、
  證據品質、時區、服務身分、監聽埠、防火牆、排程、NTFS ACL、SMB 分享、憑證到期日。

.USAGE
  雙擊 run.bat（會問 SOC 通知單號與存放目錄），或：
    run.bat -SocTicket SOC-123 [-OutDir D:\FtpCollect\out] [-Days 90] [-MaxMB 500] [-MaxLogGB 1] [-ExtraPaths 'D:\FTPLog;E:\x']
  結束代碼：0＝OK、1＝PARTIAL、2＝FAIL、3＝沒開始跑（參數或環境問題）。

.RULES
  - 不刪、不改主機上任何東西：不呼叫 Remove/Move/Set/Stop/Start、不寫登錄檔、不改 ACL、不改執行原則
    （run.bat 用單次 -ExecutionPolicy Bypass）。快速模式的 C# 在結果資料夾建好後才編譯（Add-Type），編譯暫存檔放在結果資料夾的 _compile\、
    組件只載入記憶體，不寫系統 TEMP（v1.3.1）。
  - 來源一律唯讀開檔、共用 ReadWrite+Delete，不鎖 FTP 服務正在寫的 log。
  - 所有輸出都用「只建新檔」(CreateNew) 寫在本次新開的結果資料夾裡；寫之前檢查路徑在結果資料夾內（Assert-InRun），
    附加寫入只限本次自己建立的檔。
  - 結果資料夾建立之前就中止時（例如沒填通知單號），錯誤只顯示在畫面上，不寫任何檔案。
    存放目錄（預設＝工具資料夾\out）若不存在會建立它（這是唯一在結果資料夾以外建立的東西）。
  - 設定檔：XML／JSON／INI 解析後依「欄位名」遮（字詞邊界，不看帳號值）＋值內的連線字串／URL 帳密／私鑰區塊；
    Serv-U .Archive（屬性區塊格式：欄位名／Val／值／<< 欄位名）依欄位名逐區塊遮：Password* 等密碼區塊整段換成 ***，
    其他值再過一次值內帳密遮罩＋長串（≥32 字元 base64／hex）遮罩；看不懂的 .Archive 才退回白名單模式並標示「需人工抽看」。
    排除：Serv-U\Client\（網頁介面範本）、*.Archive.Backup（備份，會讓帳號數重複）。
    FileZilla log 預設 slim：逐行讀，只留登入、傳輸／檔案操作、CWD 與它們的回應（依連線編號配對，丟掉的指令連回應一起丟），
    報表算出的次數與原檔相同；-FzLogMode raw 改回整份複製。Serv-U log 一律整份。
    log 複製時遮掉 PASS 指令、Password=、URL 帳密；超過 -MaxMB 的 log 分段存，不丟。遮完再自我檢查，殘留就整檔不落地。
    二進位、編碼不明、無法解析者不落地，只記在 manifest。解析錯誤訊息不寫原文（避免帶出值）。

.OUTPUTS  （run_local_<IP>_<主機名>_<時間>\）
  _run_info.txt、_run.csv（狀態＋原因）、_run_log.txt、_error_log.txt
  <IP>\manifest.csv      每個來源檔：kind,status,source_path,size,mtime,out_path,out_bytes,sha256,format,note
  <IP>\accounts.csv      帳號／群組（產品、domain、啟用、群組、允許／拒絕 IP）
  <IP>\dirs.csv          帳號／群組的虛擬路徑→實體路徑與原始權限（含權限來源 user/group）
  <IP>\subdir_summary.csv  每個帳號目錄的第一層子目錄小計（-Days 期間內檔數、大小、樣式前 5；最新修改時間；舊檔數）
  <IP>\servu_users.csv  Serv-U 帳號檔：姓名、家目錄、累計上下傳檔數／位元組、統計起點、最後登入（Unix 秒→當地時間；不含密碼）
  <IP>\dir_summary.csv   每個實體目錄：-Days 期間內的檔數、大小、檔名樣式前 10；整個目錄最新修改時間；期間外舊檔數；是否截斷
  <IP>\evidence_quality.csv、log_coverage.csv、log_settings.csv
  <IP>\log_events_agg.csv、log_parse_stats.csv（v1.3.0 log 摘要：照報表規則在主機上算好的事件彙總；報表有它就不讀 log。
                         上傳時預設只傳摘要、不傳 log 副本（副本留在本機結果資料夾當證據；ftpid.txt upload_logs=1 才連 log 一起傳））
  <IP>\host_info.csv（OS、IP、時區、時鐘、服務與執行身分、監聽埠）、firewall.csv、tasks.csv、acl.csv、shares.csv、certs.csv
  <IP>\<磁碟>\...        遮罩後設定檔與 log 的副本（保留原始路徑）

.STATUS
  FAIL    ：找不到 Serv-U／FileZilla 目錄，或沒收到任何主設定檔，或中途中止。
  PARTIAL ：主設定檔有收到，但有任一項：錯誤、未收集檔、讀取／複製不完整、沒解析出帳號、用白名單遮罩（需人工抽看）、
            沒有 log、最新 log 早於 2 天前、log 解析未完成、目錄摘要截斷或讀不到、設定的目錄不存在、目錄路徑無法展開。
            原因寫在 _run.csv。
  OK      ：以上都沒有。
#>
[CmdletBinding()]
param(
    [string]$SocTicket = '',
    [string]$OutDir = '',
    [ValidateRange(1, 400)][int]$Days = 90,
    [ValidateRange(10, 20000)][int]$MaxMB = 500,
    [string]$ExtraPaths = '',
    [ValidateSet('slim', 'raw')][string]$FzLogMode = 'slim',   # FileZilla log：slim＝只留報表要用的行（預設）；raw＝原樣（遮密碼）整份複製，排查用
    [switch]$FzDropListing,                                     # slim 時連 LIST/NLST/MLSD 也不留（更小，但報表就看不到「列目錄」）
    [ValidateRange(-1, 1000)][double]$MaxLogGB = -1,            # log 讀取上限（來源位元組）：從最新的檔往回挑到這個量為止；0＝不限。-1（預設）＝快速模式不限、一般模式 1 GB
    [switch]$AllowNonAdmin                                      # v1.3.4：允許不是系統管理員也跑（只給自我測試用；正式收集一定要系統管理員）
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

$VERSION = '1.3.5 (2026-11-13)'
$SCHEMA = '1.1'
$CHUNK = 1MB
$MIN_FREE = 2GB
$MAX_CONFIG = 20MB
$MAX_CERT = 1MB
$ROOT_WALK_MAX = 50000          # 安裝／log 目錄：最多列幾個項目
$ROOT_WALK_SEC = 120
$SUM_MAX_FILES = 300000         # 家目錄摘要：每個目錄最多看幾個項目（檔＋子目錄）
$SUM_DIR_SEC = 120              # 每個目錄最多幾秒
$SUM_TOTAL_SEC = 1200           # 全部目錄合計最多幾秒
$LOG_PARSE_SEC = 900            # log 解析合計最多幾秒
$MAX_PATTERNS = 5000
$MAX_SUBS = 500   # 每個帳號目錄最多記幾個第一層子目錄小計

$UTF8 = New-Object Text.UTF8Encoding($false)
$UTF8BOM = New-Object Text.UTF8Encoding($true)

$DEFAULT_ROOTS = @()
foreach ($b in @($env:ProgramData, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if ($b) { $DEFAULT_ROOTS += @((Join-Path $b 'RhinoSoft\Serv-U'), (Join-Path $b 'Serv-U'), (Join-Path $b 'FileZilla Server'), (Join-Path $b 'filezilla-server')) }
}
$PRODUCT_RX = '(?i)serv-?u|rhinosoft|filezilla'
$MAIN_CONFIG = '(?i)^(serv-u\.archive|servudaemon\.ini|filezilla server\.xml|users\.xml|groups\.xml|settings\.xml)$'
$CONFIG_EXT = @('.xml', '.ini', '.archive', '.config', '.cfg', '.json')
$CERT_EXT = @('.pem', '.crt', '.cer', '.der')
$LOG_NAME = '(?i)\.log(\.\d{1,3}|\.\d{4}-?\d{2}-?\d{2})?$'
$PRIVATE_KEY_MARK = '-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----'

function Ts($t) { if ($t) { ([datetime]$t).ToString('yyyy/MM/dd HH:mm:ss') } else { '' } }

# ======================= 安全寫入（只在結果資料夾內新建） =======================
$script:RunDir = $null
$script:LongOK = $false
$script:Created = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)

function Test-Inside([string]$child, [string]$parent) {
    $c = [IO.Path]::GetFullPath((ConvertFrom-LongPath $child)).TrimEnd('\') + '\'
    $p = [IO.Path]::GetFullPath((ConvertFrom-LongPath $parent)).TrimEnd('\') + '\'
    return $c.StartsWith($p, [StringComparison]::OrdinalIgnoreCase)
}
function ConvertFrom-LongPath([string]$p) {   # 去掉長路徑前綴（顯示／比對用）
    if ($p.StartsWith('\\?\UNC\')) { return '\\' + $p.Substring(8) }
    if ($p.StartsWith('\\?\')) { return $p.Substring(4) }
    return $p
}
function ConvertTo-LongPath([string]$p) {   # 加長路徑前綴（實際開檔用；不支援時原樣）
    if (-not $script:LongOK -or $p.StartsWith('\\?\')) { return $p }
    $f = [IO.Path]::GetFullPath($p)
    if ($f.StartsWith('\\')) { return '\\?\UNC\' + $f.Substring(2) }
    return '\\?\' + $f
}
function Assert-InRun([string]$path) {
    if (-not $script:RunDir -or -not (Test-Inside $path $script:RunDir)) { throw "STOP:安全檢查：要寫入的位置不在結果資料夾內（$path），中止" }
}
function New-RunSubDir([string]$path) {
    Assert-InRun $path
    [void][IO.Directory]::CreateDirectory((ConvertTo-LongPath $path))
}
function New-OutFile([string]$path, [byte[]]$bytes) {
    $path = [IO.Path]::GetFullPath($path)
    Assert-InRun $path
    if ($script:Created.Contains($path)) { throw "STOP:內部錯誤：重複建立 $path" }
    New-RunSubDir ([IO.Path]::GetDirectoryName($path))
    $fs = [IO.File]::Open((ConvertTo-LongPath $path), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)   # 已存在就失敗，不覆蓋
    try { if ($bytes -and $bytes.Length) { $fs.Write($bytes, 0, $bytes.Length) } } finally { $fs.Close() }
    [void]$script:Created.Add($path)
}
function Add-OutText([string]$path, [string]$text) {
    $path = [IO.Path]::GetFullPath($path)
    if (-not $script:Created.Contains($path)) { New-OutFile $path $UTF8BOM.GetPreamble() }
    Assert-InRun $path
    $b = $UTF8.GetBytes($text)
    $fs = [IO.File]::Open((ConvertTo-LongPath $path), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)   # 只附加到本次自己建的檔
    try { $fs.Write($b, 0, $b.Length) } finally { $fs.Close() }
}
function Csv([string]$path, [object[]]$cells) {
    $line = (@($cells) | ForEach-Object { '"' + ([string]$_).Replace('"', '""') + '"' }) -join ','
    Add-OutText $path ($line + "`r`n")
}

# ======================= 執行 LOG 與 ERROR LOG =======================
$script:LogFile = $null; $script:ErrFile = $null
$script:LogBuf = New-Object System.Collections.Generic.List[string]
$script:ErrBuf = New-Object System.Collections.Generic.List[string]
$script:ErrCount = 0
function Write-LogLine([bool]$isErr, [string]$line) {
    try {
        if ($script:LogFile) {
            if ($isErr) { Add-OutText $script:ErrFile ($line + "`r`n") } else { Add-OutText $script:LogFile ($line + "`r`n") }
        } elseif ($isErr) { $script:ErrBuf.Add($line) } else { $script:LogBuf.Add($line) }
    } catch { Write-Host "（寫執行紀錄失敗：$($_.Exception.Message)）" }
}
function Log([string]$msg, [string]$color = '') {
    if ($color) { Write-Host $msg -ForegroundColor $color } else { Write-Host $msg }
    Write-LogLine $false ("{0}  {1}" -f (Get-Date).ToString('yyyy/MM/dd HH:mm:ss'), $msg)
}
function ErrLog([string]$msg) {
    $script:ErrCount++
    Log "[ERROR] $msg" 'Yellow'
    Write-LogLine $true ("{0}  {1}" -f (Get-Date).ToString('yyyy/MM/dd HH:mm:ss'), $msg)
}
function Open-RunLogs([string]$dir) {
    $lf = Join-Path $dir '_run_log.txt'; $ef = Join-Path $dir '_error_log.txt'
    New-OutFile $lf $UTF8BOM.GetPreamble(); New-OutFile $ef $UTF8BOM.GetPreamble()   # 沒錯誤時 _error_log 是空檔
    $script:LogFile = $lf; $script:ErrFile = $ef
    foreach ($l in $script:LogBuf) { Add-OutText $lf ($l + "`r`n") }
    foreach ($l in $script:ErrBuf) { Add-OutText $ef ($l + "`r`n") }
    $script:LogBuf.Clear(); $script:ErrBuf.Clear()
}
function Stop-Early([string]$msg) {
    # 結果資料夾還沒建好前就中止：只顯示在畫面上，不寫任何檔案
    ErrLog $msg
    if (-not $script:LogFile) { Write-Host '（結果資料夾尚未建立，未寫任何檔案；請看上面的錯誤訊息）' }
    exit 3
}

# ======================= 遮罩（依欄位名，字詞邊界） =======================
$SECRET_WORDS = @('pass', 'password', 'passwd', 'passphrase', 'pwd', 'pw', 'pin', 'salt', 'hash', 'hashed', 'secret', 'token',
    'credential', 'credentials', 'apikey', 'privatekey', 'otp', 'hmac', 'digest', 'md5', 'sha', 'sha1', 'sha256', 'sha512', 'ntlm', 'cookie')
$SECRET_SUB = '(?i)password|passwd|passphrase|secret|credential|apikey|privatekey|accesskey|token'
$KEY_PREFIX = @('private', 'api', 'secret', 'access', 'encryption', 'ssh', 'shared', 'pre', 'master', 'session')
$KV_ELEMENTS = @('option', 'item', 'setting', 'param', 'parameter', 'property', 'add', 'entry', 'field', 'var', 'variable', 'pair')
$ACCOUNT_ELEMENTS = @('user', 'users', 'group', 'groups', 'domain', 'domains', 'account', 'accounts', 'member', 'login', 'client', 'mount_point', 'permission')
$script:MaskHits = 0

$RX_PEMKEY = New-Object regex('(?s)-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?(-----END [A-Z0-9 ]*PRIVATE KEY-----|$)')
$RX_KV = New-Object regex('(?i)(\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:][ \t]*)((?:"(?:[^"]|"")*"|''(?:[^'']|'''')*''|\{(?:[^}]|\}\})*\})?[^;&\r\n]*)')
# 殘留檢查：密碼鍵之後必須正好是 *** 再接分隔符號或結尾（不靠同一條 regex 自我驗證）
$RX_KV_LEFT = New-Object regex('(?i)\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:](?![ \t]*\*\*\*[ \t]*(?:[;&\r\n]|$))')
$RX_URLCRED = New-Object regex('(?i)\b([a-z][a-z0-9+.\-]*://[^:/@\s"''<>]*:)([^@\s"''<>/]+)@')
$RX_CLI = New-Object regex('(?i)((?:^|\s)(?:-pw|--?password|/password|/pass|/pw|-passphrase)(?:\s+|=|:))("(?:\\.|""|[^"\\])*"?|''(?:\\.|''''|[^''\\])*''?|\S+)')

function Get-KeyTokens([string]$name) {
    $s = [regex]::Replace($name, '([a-z0-9])([A-Z])', '$1 $2')
    $s = [regex]::Replace($s, '([A-Z]+)([A-Z][a-z])', '$1 $2')
    return @(($s.ToLowerInvariant() -split '[^a-z0-9]+') | Where-Object { $_ })
}
function Test-SecretKey([string]$name) {
    # 依「欄位名」判斷，切成字詞後比對：bypass_ap、passive_mode 不會被當成密碼欄位
    if (-not $name) { return $false }
    $t = @(Get-KeyTokens $name)
    for ($i = 0; $i -lt $t.Count; $i++) {
        $w = $t[$i]
        if ($SECRET_WORDS -contains $w) { return $true }
        if ($w -match $SECRET_SUB) { return $true }
        if ($w -eq 'key' -and $i -gt 0 -and ($KEY_PREFIX -contains $t[$i - 1])) { return $true }
    }
    return $false
}
function Test-ValueClean([string]$v) {
    # 值經過 Protect-Value 不會再變＝沒有殘留（不計次）
    $h = $script:MaskHits; $r = ((Protect-Value $v) -ceq $v); $script:MaskHits = $h
    if ($r -and $RX_KV_LEFT.IsMatch($v)) { $r = $false }
    return $r
}
function Protect-Value([string]$v) {
    # 值裡面的：私鑰區塊、Password=...;、URL 帳密、命令列 -pw xxx
    if (-not $v) { return $v }
    $o = $RX_PEMKEY.Replace($v, '***(private key removed)***')
    $o = $RX_KV.Replace($o, '${1}***')
    $o = $RX_URLCRED.Replace($o, '${1}***@')
    $o = $RX_CLI.Replace($o, '${1}***')
    if ($o -ne $v) { $script:MaskHits++ }
    return $o
}

# ---------- XML ----------
function Get-KvKeyAttr($el) {
    # 「鍵值」型元素（<Option Name="Pass">、<add key=.. value=..>）回傳存放鍵名的屬性名；帳號類元素永遠不是
    $ln = $el.LocalName.ToLowerInvariant()
    if ($ACCOUNT_ELEMENTS -contains $ln) { return '' }
    $isKv = ($KV_ELEMENTS -contains $ln) -or $el.HasAttribute('value')
    if (-not $isKv) {
        foreach ($c in $el.ChildNodes) { if ($c.NodeType -eq [Xml.XmlNodeType]::Element) { return '' } }
        $isKv = $true   # 葉節點且有 name 屬性，也當鍵值
    }
    foreach ($k in @('name', 'Name', 'NAME', 'key', 'Key', 'id', 'Id')) { if ($el.HasAttribute($k)) { return $k } }
    return ''
}
function Hide-XmlNode($node, [string]$keepAttr) {
    if ($node.Attributes) {
        foreach ($a in @($node.Attributes)) {
            if ($a.Name -eq 'xmlns' -or $a.Prefix -eq 'xmlns' -or ($keepAttr -and $a.Name -eq $keepAttr)) { continue }
            if ($a.Value) { $a.Value = '***'; $script:MaskHits++ }
        }
    }
    $hasEl = $false
    foreach ($c in $node.ChildNodes) { if ($c.NodeType -eq [Xml.XmlNodeType]::Element) { $hasEl = $true } }
    foreach ($c in @($node.ChildNodes)) {
        $t = $c.NodeType
        if ($t -eq [Xml.XmlNodeType]::Element) { Hide-XmlNode $c '' }
        elseif ($t -eq [Xml.XmlNodeType]::Text -or $t -eq [Xml.XmlNodeType]::CDATA -or $t -eq [Xml.XmlNodeType]::Comment) {
            if ($c.Value) { $c.Value = '***'; $script:MaskHits++ }   # 連全空白的密碼也遮
        } elseif (-not $hasEl -and ($t -eq [Xml.XmlNodeType]::Whitespace -or $t -eq [Xml.XmlNodeType]::SignificantWhitespace) -and $c.Value) {
            [void]$node.ReplaceChild($node.OwnerDocument.CreateTextNode('***'), $c); $script:MaskHits++
        }
    }
}
function Protect-XmlTree($node) {
    # 同一元素底下被切成多段的 Text／CDATA：合起來看，有帳密就整段換掉
    $tx = @($node.ChildNodes | Where-Object { $_.NodeType -eq [Xml.XmlNodeType]::Text -or $_.NodeType -eq [Xml.XmlNodeType]::CDATA })
    if ($tx.Count -gt 1) {
        $joined = (@($tx | ForEach-Object { $_.Value }) -join '')
        $m = Protect-Value $joined
        if ($m -cne $joined) { $tx[0].Value = $m; for ($i = 1; $i -lt $tx.Count; $i++) { $tx[$i].Value = '' } }
    }
    foreach ($c in @($node.ChildNodes)) {
        $t = $c.NodeType
        if ($t -eq [Xml.XmlNodeType]::Element) {
            if (Test-SecretKey $c.LocalName) { Hide-XmlNode $c ''; continue }
            $ka = Get-KvKeyAttr $c
            if ($ka -and (Test-SecretKey $c.GetAttribute($ka))) { Hide-XmlNode $c $ka; continue }
            foreach ($a in @($c.Attributes)) {
                if ($a.Name -eq 'xmlns' -or $a.Prefix -eq 'xmlns') { continue }
                if (Test-SecretKey $a.LocalName) { if ($a.Value) { $a.Value = '***'; $script:MaskHits++ } }
                else { $a.Value = Protect-Value $a.Value }
            }
            Protect-XmlTree $c
        } elseif ($t -eq [Xml.XmlNodeType]::Text -or $t -eq [Xml.XmlNodeType]::CDATA -or $t -eq [Xml.XmlNodeType]::Comment) {
            $c.Value = Protect-Value $c.Value   # 混合內容、CDATA、註解都逐一處理
        }
    }
}
function Read-XmlDoc([byte[]]$bytes, [string]$text) {
    $rs = New-Object Xml.XmlReaderSettings
    $rs.DtdProcessing = [Xml.DtdProcessing]::Ignore
    $rs.XmlResolver = $null
    $doc = New-Object Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.XmlResolver = $null
    $ok = $false
    if ($null -ne $bytes) {   # 先照檔頭 BOM／encoding 宣告讀
        try { $r = [Xml.XmlReader]::Create([IO.MemoryStream]::new($bytes), $rs); try { $doc.Load($r); $ok = $true } finally { $r.Close() } } catch { $ok = $false }
    }
    if (-not $ok) {
        if (-not $text) { throw 'XML 解析失敗（編碼或格式）' }
        $doc = New-Object Xml.XmlDocument; $doc.PreserveWhitespace = $true; $doc.XmlResolver = $null
        try { $r = [Xml.XmlReader]::Create((New-Object IO.StringReader($text)), $rs); try { $doc.Load($r) } finally { $r.Close() } }
        catch { throw ('XML 解析失敗（{0}）' -f $_.Exception.GetType().Name) }   # 不帶原文訊息
    }
    return $doc
}
function ConvertTo-XmlBytes($doc) {
    foreach ($n in @($doc.ChildNodes)) { if ($n.NodeType -eq [Xml.XmlNodeType]::XmlDeclaration) { $n.Encoding = 'utf-8' } }   # 宣告與實際位元組一致
    $ms = New-Object IO.MemoryStream
    $ws = New-Object Xml.XmlWriterSettings
    $ws.Encoding = $UTF8
    $w = [Xml.XmlWriter]::Create($ms, $ws)
    try { $doc.Save($w) } finally { $w.Close() }
    return , $ms.ToArray()
}
function Add-XmlPairs($el, [string]$parent, $list) {
    $ka = Get-KvKeyAttr $el
    $comp = $el.LocalName
    $key = $el.LocalName
    if ($ka) { $key = $el.GetAttribute($ka); $comp = $el.LocalName + ':' + $key }
    $path = "$parent/$comp"
    foreach ($a in @($el.Attributes)) {
        if ($a.Name -eq 'xmlns' -or $a.Prefix -eq 'xmlns' -or ($ka -and $a.Name -eq $ka)) { continue }
        $k = $a.LocalName; if ($ka) { $k = $key }
        $list.Add([pscustomobject]@{ Path = "$path/@$($a.LocalName)"; Key = $k; Value = $a.Value; Comps = "$path" })
    }
    $txt = ''
    foreach ($c in $el.ChildNodes) {
        if ($c.NodeType -eq [Xml.XmlNodeType]::Text -or $c.NodeType -eq [Xml.XmlNodeType]::CDATA) { $txt += $c.Value }
    }
    if ($txt.Trim()) { $list.Add([pscustomobject]@{ Path = $path; Key = $key; Value = $txt.Trim(); Comps = $path }) }
    foreach ($c in $el.ChildNodes) { if ($c.NodeType -eq [Xml.XmlNodeType]::Element) { Add-XmlPairs $c $path $list } }
}

# ---------- JSON ----------
Add-Type -AssemblyName System.Web.Extensions   # 載入既有組件（不編譯、不寫檔）
function New-JsonSer { $s = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $s.MaxJsonLength = [int]::MaxValue; $s.RecursionLimit = 512; return $s }
function Protect-JsonObj($o) {
    if ($null -eq $o) { return $null }
    if ($o -is [string]) { return (Protect-Value $o) }
    if ($o -is [System.Collections.IDictionary]) {
        foreach ($k in @($o.Keys)) {
            if (Test-SecretKey ([string]$k)) { if ($null -ne $o[$k] -and [string]$o[$k] -ne '') { $o[$k] = '***'; $script:MaskHits++ } }
            else { $o[$k] = Protect-JsonObj $o[$k] }
        }
        return , $o
    }
    if ($o -is [System.Collections.IList]) {   # 陣列（含陣列中的陣列、字串）逐一處理
        for ($i = 0; $i -lt $o.Count; $i++) { $o[$i] = Protect-JsonObj $o[$i] }
        return , $o
    }
    return $o
}
function Add-JsonPairs($o, [string]$path, [string]$key, $list) {
    if ($null -eq $o) { return }
    if ($o -is [string] -or $o -is [ValueType]) { $list.Add([pscustomobject]@{ Path = $path; Key = $key; Value = [string]$o; Comps = $path }); return }
    if ($o -is [System.Collections.IDictionary]) { foreach ($k in @($o.Keys)) { Add-JsonPairs $o[$k] "$path/$k" ([string]$k) $list }; return }
    if ($o -is [System.Collections.IList]) { for ($i = 0; $i -lt $o.Count; $i++) { Add-JsonPairs $o[$i] "$path[$i]" $key $list } }
}

# ---------- INI ----------
$RX_INI = New-Object regex('^\s*(?:[;#].*|\[[^\]]*\]\s*|([^=]+?)\s*=(.*))?$')
function Protect-Ini([string]$text) {
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($line in ($text -split "`r?`n")) {
        $m = $RX_INI.Match($line)
        if (-not $m.Success) { throw '不是 INI 格式' }
        if ($m.Groups[1].Success) {
            $k = $m.Groups[1].Value
            if (Test-SecretKey $k.Trim()) { if ($m.Groups[2].Value) { $script:MaskHits++ }; $line = $k + '=***' }
            else { $line = $k + '=' + (Protect-Value $m.Groups[2].Value) }
        } elseif ($line.TrimStart().StartsWith(';') -or $line.TrimStart().StartsWith('#')) { $line = Protect-Value $line }
        $out.Add($line)
    }
    return ($out -join "`r`n")
}
function Get-IniPairs([string]$text) {
    $list = New-Object System.Collections.Generic.List[object]
    $sec = ''
    foreach ($line in ($text -split "`r?`n")) {
        $t = $line.Trim()
        if ($t -match '^\[(.*)\]$') { $sec = $Matches[1]; continue }
        if ($t -match '^[;#]' -or -not $t) { continue }
        $i = $t.IndexOf('=')
        if ($i -gt 0) { $k = $t.Substring(0, $i).Trim(); $list.Add([pscustomobject]@{ Path = "[$sec]/$k"; Key = $k; Value = $t.Substring($i + 1).Trim(); Comps = "/$k" }) }
    }
    return , $list
}

# ---------- 通用逐行（只給 Serv-U .Archive 用） ----------
$RX_FIRSTID = New-Object regex('[A-Za-z][A-Za-z0-9_.\-]*')
$RX_BLOB = New-Object regex('(?<![A-Za-z0-9+/=\\:%.\-])[A-Za-z0-9+/]{32,}={0,2}(?![A-Za-z0-9+/=])')
$RX_GENKV = New-Object regex('^\s*[<"'']?([A-Za-z][A-Za-z0-9_.\- ]{0,60}?)["''>]?\s*(?:=|:|\s)\s*["'']?(.*?)["'']?\s*(?:</[^>]*>)?\s*$')
$ALLOW_TOKENS = @('dir', 'directory', 'path', 'home', 'root', 'folder', 'virtual', 'physical', 'enable', 'enabled', 'disable', 'disabled',
    'ip', 'ips', 'address', 'allow', 'allowed', 'deny', 'denied', 'access', 'permission', 'permissions', 'rights', 'right', 'domain', 'name',
    'login', 'loginid', 'id', 'user', 'username', 'group', 'groups', 'member', 'members', 'port', 'listener', 'log', 'logs', 'logging', 'level',
    'type', 'max', 'min', 'size', 'days', 'retention', 'rotate', 'rotation', 'quota', 'expire', 'expiration', 'expires', 'ssl', 'tls', 'cert',
    'certificate', 'ftps', 'sftp', 'protocol', 'passive', 'pasv', 'mode', 'flags', 'inherit', 'inherited', 'relpaths', 'locked', 'lock',
    'version', 'limit', 'limits', 'recursive', 'upload', 'download', 'read', 'write', 'delete', 'rename', 'append', 'list', 'create', 'hide')
function Test-AllowKey([string]$k) {
    if (Test-SecretKey $k) { return $false }
    foreach ($t in @(Get-KeyTokens $k)) { if ($ALLOW_TOKENS -contains $t) { return $true } }
    return $false
}
function Protect-Generic([string]$text) {
    # 格式不明（Serv-U .Archive）：只保留「白名單欄位」的值（路徑、啟用、IP、權限、domain、帳號名…），
    # 其他欄位只留欄位名、值不落地；密碼欄位與它底下的整個區塊都不輸出。fail closed。
    $out = New-Object System.Collections.Generic.List[string]
    $lines = @($text -split "`r?`n")
    $depth = 0; $skipAt = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $t = $lines[$i].Trim()
        if (-not $t) { continue }
        $opens = ([regex]::Matches($t, '\{')).Count; $closes = ([regex]::Matches($t, '\}')).Count
        if ($skipAt -ge 0) {
            $depth += $opens - $closes
            if ($depth -le $skipAt) { $skipAt = -1 }
            continue
        }
        if ($t -match '^[{}]+$') { $depth += $opens - $closes; $out.Add($t); continue }
        $next = ''; $jn = $i; for ($j = $i + 1; $j -lt $lines.Count; $j++) { if ($lines[$j].Trim()) { $next = $lines[$j].Trim(); $jn = $j; break } }
        if (($opens -gt $closes) -or $next.StartsWith('{')) {
            # 區塊標頭（同一行或下一行是 {）：先判斷是不是密碼區塊，是就整塊不輸出
            $hdr = $t; $bi = $hdr.IndexOf('{'); if ($bi -ge 0) { $hdr = $hdr.Substring(0, $bi) }
            $hdr = $hdr.Trim().TrimEnd('=', ':').Trim()
            $fid = $RX_FIRSTID.Match($hdr)
            $hk = $(if ($fid.Success) { $fid.Value } else { '' })
            if ((Test-SecretKey $hdr) -or (Test-SecretKey $hk)) {
                $script:MaskHits++; $out.Add("$(if ($hk) { $hk } else { '(block)' }) = ***")
                $skipAt = $depth
                if ($opens -gt $closes) { $depth += $opens - $closes } else { $i = $jn; $depth += 1 }
                continue
            }
            $hm = $RX_GENKV.Match($hdr)
            if ($hm.Success -and $hm.Groups[2].Value.Trim()) {
                $hkey = $hm.Groups[1].Value.Trim(); $hval = $hm.Groups[2].Value.Trim().Trim('"', "'")
                if (Test-AllowKey $hkey) { $out.Add("$hkey = " + $RX_BLOB.Replace((Protect-Value $hval), '***')) } else { $out.Add("$hkey = (not kept)") }
            } elseif ($hdr -match '^["''<\[]?[A-Za-z][A-Za-z0-9_.\- ]{0,60}["''>\]]?$') { $out.Add($hdr.Trim('"', "'", '<', '>', '[', ']')) }
            else { $out.Add('(block)') }
            if ($opens -gt $closes) { $depth += $opens - $closes; $out.Add('{') }
            continue
        }
        $m = $RX_GENKV.Match($t)
        $key = ''; $val = ''
        if ($m.Success) { $key = $m.Groups[1].Value.Trim(); $val = $m.Groups[2].Value.Trim().TrimEnd('{').Trim().Trim('"', "'") }
        if ($key -and $val) {
            if (Test-SecretKey $key) { $out.Add("$key = ***"); $script:MaskHits++ }
            elseif (Test-AllowKey $key) { $v2 = $RX_BLOB.Replace((Protect-Value $val), '***'); $out.Add("$key = $v2") }
            else { $out.Add("$key = (not kept)") }
            continue
        }
        # 其他無法辨識的行：不輸出
    }
    return ($out -join "`r`n")
}
function Get-GenericPairs([string]$text) {
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($line in ($text -split "`r?`n")) {
        $m = $RX_GENKV.Match($line)
        if ($m.Success -and $m.Groups[2].Value) { $k = $m.Groups[1].Value.Trim(); $list.Add([pscustomobject]@{ Path = "/$k"; Key = $k; Value = $m.Groups[2].Value; Comps = "/$k" }) }
    }
    return , $list
}

# ---------- Serv-U .Archive 屬性區塊格式（2026-11-11 實機確認，見 ServU格式_實測 (1111).md） ----------
# 每個欄位：<類別> / <欄位名> / <旗標> / <數量> / Val / <值> / << <欄位名>；區塊可巢狀（例 DirAccess 底下的 Dir、Access）
$RX_SU_END = New-Object regex('^<<\s*(\S.*?)\s*$')
$RX_SU_NAME = New-Object regex('^[A-Za-z][A-Za-z0-9_.]*$')
function Protect-ServUArchive([string]$text) {
    # 不是這種格式回傳 $null（交給後面的 INI／白名單）。規則：
    #  - `Val` 的下一行一律是值（就算長得像欄位名、Val 或 << X），不會被當成結構。
    #  - 密碼類欄位（依欄位名，含所在的外層區塊）裡面：除了 Val 與「堆疊裡已有的區塊」的結束標記，其他每一行都換成 ***。
    #  - 其他值再過值內帳密遮罩＋長串遮罩。Pairs 的值把檔內的 \\ 還原成 \；Inst＝區塊實例路徑（重複的區塊各有編號）。
    $lines = @($text -split "`r?`n")
    $ends = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    $hasVal = $false; $skip = $false
    foreach ($l in $lines) {
        $t = $l.Trim()
        if ($skip) { $skip = $false; continue }   # 值不參與結構判斷
        if ($t -ceq 'Val') { $hasVal = $true; $skip = $true; continue }
        $m = $RX_SU_END.Match($t); if ($m.Success) { [void]$ends.Add($m.Groups[1].Value) }
    }
    if (-not $hasVal -or $ends.Count -eq 0) { return $null }
    $out = New-Object System.Collections.Generic.List[string]
    $pairs = New-Object System.Collections.Generic.List[object]
    $stack = New-Object System.Collections.Generic.List[string]
    $inst = New-Object System.Collections.Generic.List[string]
    $secret = 0; $lastName = ''; $afterVal = $false; $seq = 0
    foreach ($l in $lines) {
        $t = $l.Trim()
        if ($afterVal) {
            $afterVal = $false
            $path = '/' + ($stack -join '/'); $ip = '/' + ($inst -join '/')
            if ($secret -gt 0 -or (Test-SecretKey $lastName)) {
                if ($t) { $script:MaskHits++ }
                $out.Add('***'); $pairs.Add([pscustomobject]@{ Path = $path; Key = $lastName; Value = '***'; Comps = $path; Inst = $ip })
                continue
            }
            $v = $RX_BLOB.Replace((Protect-Value $l), '***')
            $out.Add($v)
            $pairs.Add([pscustomobject]@{ Path = $path; Key = $lastName; Value = $v.Trim().Replace('\\', '\'); Comps = $path; Inst = $ip })
            continue
        }
        if ($t -ceq 'Val') { $out.Add($l); $afterVal = $true; continue }
        $m = $RX_SU_END.Match($t)
        if ($m.Success -and $stack.Contains($m.Groups[1].Value)) {
            $i = $stack.LastIndexOf($m.Groups[1].Value)
            $stack.RemoveRange($i, $stack.Count - $i); $inst.RemoveRange($i, $inst.Count - $i)
            $secret = @($stack | Where-Object { Test-SecretKey $_ }).Count
            $out.Add($l); continue
        }
        $isName = ($RX_SU_NAME.IsMatch($t) -and $ends.Contains($t))
        if ($isName) {
            $stack.Add($t); $seq++; $inst.Add("$t#$seq"); $lastName = $t
            if (Test-SecretKey $t) { $secret++ }
            if ($secret -gt 0 -and -not (Test-SecretKey $t)) { $out.Add('***'); $script:MaskHits++; continue }   # 密碼區塊裡的子欄位名也不保留
            $out.Add($l); continue
        }
        if ($RX_SU_NAME.IsMatch($t)) { $lastName = $t }   # 類別名稱、沒有結束標記的欄位名
        if ($secret -gt 0 -and $t) { $out.Add('***'); $script:MaskHits++; continue }
        $out.Add($RX_BLOB.Replace((Protect-Value $l), '***'))
    }
    return [pscustomobject]@{ Text = ($out -join "`r`n"); Pairs = $pairs }
}

# ---------- 遮完自我檢查（殘留就整檔不落地） ----------
function Test-Residual($pairs, [bool]$checkPath) {
    foreach ($p in $pairs) {
        $v = [string]$p.Value
        if ($v -match $PRIVATE_KEY_MARK) { return "殘留私鑰（$($p.Path)）" }
        if (-not $v -or $v -eq '***') { continue }
        if (-not (Test-ValueClean $v)) { return "值內帳密未遮（$($p.Path)）" }
        $secret = Test-SecretKey $p.Key
        if (-not $secret -and $checkPath) { foreach ($c in ($p.Comps -split '/')) { if ($c -and (Test-SecretKey $c)) { $secret = $true; break } } }
        if ($secret) { return "密碼欄位未遮（$($p.Path)）" }
    }
    return ''
}

function Test-XmlBytes([byte[]]$data) {
    $i = 0
    if ($data.Length -ge 3 -and $data[0] -eq 0xEF -and $data[1] -eq 0xBB -and $data[2] -eq 0xBF) { $i = 3 }
    while ($i -lt $data.Length -and @(9, 10, 13, 32) -contains $data[$i]) { $i++ }
    return ($i -lt $data.Length -and $data[$i] -eq 0x3C -and [Array]::IndexOf($data, [byte]0) -lt 0)
}
function Get-TextFromBytes([byte[]]$data) {
    if ($data.Length -ge 2 -and (($data[0] -eq 0xFF -and $data[1] -eq 0xFE) -or ($data[0] -eq 0xFE -and $data[1] -eq 0xFF))) {
        $enc = New-Object Text.UnicodeEncoding(($data[0] -eq 0xFE), $true, $true)
        try { return $enc.GetString($data, 2, $data.Length - 2) } catch { return $null }
    }
    if ([Array]::IndexOf($data, [byte]0) -ge 0) { return $null }   # 二進位
    $start = 0; if ($data.Length -ge 3 -and $data[0] -eq 0xEF -and $data[1] -eq 0xBB -and $data[2] -eq 0xBF) { $start = 3 }
    try { return (New-Object Text.UTF8Encoding($false, $true)).GetString($data, $start, $data.Length - $start) } catch { }
    try { return [Text.Encoding]::GetEncoding(950, [Text.EncoderFallback]::ExceptionFallback, [Text.DecoderFallback]::ExceptionFallback).GetString($data) } catch { }
    return $null
}

# 回傳物件：Bytes(遮後)、Format、Pairs、Doc(XML)、Text(遮後)、Generic
function Protect-Config([byte[]]$data, [string]$text, [string]$ext) {
    $t = $text.TrimStart([char]0xFEFF, ' ', "`t", "`r", "`n")
    if (-not $t -and (Test-XmlBytes $data)) { $t = '<' }
    $r = [pscustomobject]@{ Bytes = $null; Format = ''; Pairs = $null; Doc = $null; Text = ''; Generic = $false }
    if ($t.StartsWith('<')) {
        try {
            $doc = Read-XmlDoc $data $text
            Protect-XmlTree $doc
            $bytes = ConvertTo-XmlBytes $doc
            $doc2 = Read-XmlDoc $bytes $null   # 重讀遮後輸出，確認是合法 XML 並做殘留檢查
            $pairs = New-Object System.Collections.Generic.List[object]
            Add-XmlPairs $doc2.DocumentElement '' $pairs
            $bad = Test-Residual $pairs $true
            if ($bad) { throw "遮罩自我檢查失敗：$bad" }
            $r.Bytes = $bytes; $r.Format = 'XML'; $r.Pairs = $pairs; $r.Doc = $doc2
            return $r
        } catch { if ($ext -ne '.archive') { throw } }
    }
    if ($t.StartsWith('{') -or $t.StartsWith('[')) {
        $obj = $null
        try { $obj = (New-JsonSer).DeserializeObject($text) } catch { $obj = $null }
        if ($null -ne $obj) {
            $obj = Protect-JsonObj $obj
            $out = (New-JsonSer).Serialize($obj)
            $pairs = New-Object System.Collections.Generic.List[object]
            Add-JsonPairs ((New-JsonSer).DeserializeObject($out)) '' '' $pairs
            $bad = Test-Residual $pairs $false
            if ($bad) { throw "遮罩自我檢查失敗：$bad" }
            $r.Bytes = $UTF8.GetBytes($out); $r.Format = 'JSON'; $r.Pairs = $pairs; $r.Text = $out
            return $r
        }
        if ($t.StartsWith('{')) { if ($ext -ne '.archive') { throw 'JSON 解析失敗' } }
    }
    if ($ext -eq '.archive') {
        $sa = Protect-ServUArchive $text
        if ($null -ne $sa) {
            $bad = Test-Residual $sa.Pairs $true
            if (-not $bad) { foreach ($ol in ($sa.Text -split "`r`n")) { if ($ol -match $PRIVATE_KEY_MARK -or -not (Test-ValueClean $ol)) { $bad = 'Serv-U 區塊遮罩有殘留'; break } } }
            if ($bad) { throw "遮罩自我檢查失敗：$bad" }
            $r.Bytes = $UTF8.GetBytes($sa.Text); $r.Format = 'SERVU-ARCHIVE'; $r.Pairs = $sa.Pairs; $r.Text = $sa.Text
            return $r
        }
    }
    $ini = $null
    try { $ini = Protect-Ini $text } catch { $ini = $null }
    if ($null -ne $ini) {
        $pairs = Get-IniPairs $ini
        $bad = Test-Residual $pairs $false
        if ($bad) { throw "遮罩自我檢查失敗：$bad" }
        $r.Bytes = $UTF8.GetBytes($ini); $r.Format = 'INI'; $r.Pairs = $pairs; $r.Text = $ini
        return $r
    }
    if ($ext -eq '.archive') {
        $g = Protect-Generic $text
        foreach ($gl in ($g -split "`r`n")) { if ($gl -match $PRIVATE_KEY_MARK -or -not (Test-ValueClean $gl)) { throw '遮罩自我檢查失敗：通用遮罩有殘留' } }
        $r.Bytes = $UTF8.GetBytes($g); $r.Format = 'TEXT-ALLOWLIST'; $r.Pairs = (Get-GenericPairs $g); $r.Text = $g; $r.Generic = $true
        return $r
    }
    throw '格式無法確認'
}

# ======================= 檔案讀取／複製（唯讀、共用、驗證） =======================
function Open-Source([string]$path) {
    return [IO.File]::Open((ConvertTo-LongPath $path), [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
}
function Read-AllShared([string]$path, [long]$max) {
    # 回傳 @(bytes, 錯誤)；讀不滿長度＝短讀，視為錯誤
    $fs = Open-Source $path
    try {
        $len = $fs.Length
        if ($len -gt $max) { return @($null, "超過上限 $([int]($max / 1MB)) MB") }
        $data = New-Object byte[] $len
        $off = 0
        while ($off -lt $len) { $k = $fs.Read($data, $off, [int]($len - $off)); if ($k -le 0) { break }; $off += $k }
        if ($off -ne $len) { return @($null, "短讀：讀到 $off / $len 位元組") }
        return @($data, '')
    } finally { $fs.Close() }
}
function Get-Sha256Bytes([byte[]]$b) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($b)) -replace '-', '').ToLower() } finally { $h.Dispose() }
}
function Get-Sha256File([string]$path) {
    $h = [Security.Cryptography.SHA256]::Create(); $fs = Open-Source $path
    try { return ([BitConverter]::ToString($h.ComputeHash($fs)) -replace '-', '').ToLower() } finally { $fs.Close(); $h.Dispose() }
}
function Get-MirrorPath([string]$src) {
    $s = ConvertFrom-LongPath $src
    if ($s -match '^([A-Za-z]):\\(.*)$') { return (Join-Path (Join-Path $script:HostDir $Matches[1].ToUpper()) $Matches[2]) }
    if ($s -match '^\\\\(.*)$') { return (Join-Path (Join-Path $script:HostDir 'UNC') $Matches[1]) }
    throw "無法對應路徑：$s"
}
$L1 = [Text.Encoding]::GetEncoding(28591)   # Latin-1：位元組 1:1 對應，遮罩不會弄壞 Big5／UTF-8 內容
$RX_LOGPASS = New-Object regex('(?im)((?:^|[:>\])\-])[ \t]*PASS[ \t]+)([^\r\n]+)')   # FTP PASS 指令（不分大小寫；Serv-U HidePasswordInLog=0 時 log 會有明碼）
$RX_PEMBEGIN = New-Object regex('-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----')
$RX_PEMEND = New-Object regex('-----END [A-Z0-9 ]*PRIVATE KEY-----')
# 被丟棄（不輸出）的位元組也要更新私鑰狀態：BEGIN 落在丟棄區時，後面保留的內容仍要遮到 END
function Update-PemState([string]$t, [bool]$inPem) {
    if ($inPem) { $em = $RX_PEMEND.Match($t); if (-not $em.Success) { return $true }; $t = $t.Substring($em.Index + $em.Length) }
    $bm = $RX_PEMBEGIN.Matches($t)
    if ($bm.Count -gt 0) { $lb = $bm[$bm.Count - 1]; return (-not $RX_PEMEND.IsMatch($t.Substring($lb.Index))) }
    return $false
}
function Protect-LogText([string]$t) {
    $o = $RX_PEMKEY.Replace($t, '***(private key removed)***')
    $o = $RX_LOGPASS.Replace($o, '${1}***')
    $o = $RX_KV.Replace($o, '${1}***')
    $o = $RX_URLCRED.Replace($o, '${1}***@')
    return $o
}
# 本工具自己切的分段檔名：<副本>.partN；但主機上若真的有同名的來源檔（例 FileZilla 的 fzs-日期.log.part2），改用 .splitN 避免撞名。
# 每個 log 實際用了哪些分段，寫在 manifest 的 out_parts（報表照這欄讀，不靠檔名猜）。
$script:LogMirrors = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
function Get-PartPath([string]$dst, [int]$n) {
    $base = [IO.Path]::GetFullPath($dst)
    $p = "$base.part$n"
    $k = 0
    while ($script:LogMirrors.Contains($p) -or [IO.File]::Exists($p)) {   # 來源同名（.part2／.split2…）或已存在：再換名，直到沒人用
        $k++
        $p = if ($k -eq 1) { "$base.split$n" } else { "$base.split$n-$k" }
    }
    return $p
}
$script:ProgLast = 0
function Show-ReadProgress([string]$name, [long]$done, [long]$total, $sw) {
    # 讀大 log 時每 5 秒在同一行更新進度，讓畫面不像當機；讀完補一個換行
    $fin = ($done -ge $total)
    if (-not $fin -and ($sw.ElapsedMilliseconds - $script:ProgLast) -lt 5000) { return }
    $script:ProgLast = $sw.ElapsedMilliseconds
    if ($total -lt 50MB -and $fin -and $sw.ElapsedMilliseconds -lt 5000) { return }   # 小檔一下就讀完，不洗畫面
    $pct = $(if ($total -gt 0) { [int](100 * $done / $total) } else { 100 })
    $rate = $(if ($sw.Elapsed.TotalSeconds -gt 0) { $done / $sw.Elapsed.TotalSeconds } else { 0 })
    $eta = $(if ($rate -gt 0) { [Math]::Ceiling(($total - $done) / $rate / 60) } else { 0 })
    Write-Host ("`r  處理中 {0}：{1:N0} / {2:N0} MB（{3}%），約剩 {4} 分鐘    " -f $name, ($done / 1MB), ($total / 1MB), $pct, $eta) -NoNewline
    if ($fin) { Write-Host '' }
}
function Copy-LogFile([IO.FileInfo]$f, [string]$dst, [long]$partBytes) {
    # 逐塊（在換行處切）讀來源、遮掉帳密後寫出；超過 partBytes 就換下一個分段檔，不丟資料。
    # 回傳物件：Bytes、Sha（全部輸出串起來）、Note、Bad、Skip、Parts、Redacted
    $src = ConvertFrom-LongPath $f.FullName
    $res = [pscustomobject]@{ Bytes = [long]0; Sha = ''; Note = ''; Bad = $false; Skip = $false; Parts = (New-Object System.Collections.Generic.List[string]); Redacted = 0 }
    $note = @()
    $fi = Open-Source $src
    $sha = [Security.Cryptography.SHA256]::Create()
    $fo = $null
    try {
        $lenAtOpen = $fi.Length
        $head = New-Object byte[] 8192; $hk = $fi.Read($head, 0, 8192); [void]$fi.Seek(0, 'Begin')
        if ($hk -ge 2 -and (($head[0] -eq 0xFF -and $head[1] -eq 0xFE) -or ($head[0] -eq 0xFE -and $head[1] -eq 0xFF))) {
            $res.Skip = $true; $res.Note = 'UTF-16 log：無法在主機上安全遮罩，未收集'; return $res
        }
        if ($hk -gt 0 -and [Array]::IndexOf($head, [byte]0, 0, $hk) -ge 0) { $res.Skip = $true; $res.Note = '不是文字檔（二進位），未收集'; return $res }
        $state = @{ part = 1; cur = [IO.Path]::GetFullPath($dst); curBytes = [long]0 }
        New-OutFile $state.cur $null; $res.Parts.Add($state.cur)
        $fo = [IO.File]::Open((ConvertTo-LongPath $state.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $buf = New-Object byte[] $CHUNK
        $carry = New-Object byte[] 0
        $nRead = [long]0; $eof = $false
        $dropToNl = $false   # 超長（64 MB 沒換行）的一行：整行不保留，直到下一個換行
        $inPem = $false      # 私鑰區塊跨塊：遮到 END 為止
        $psw = [Diagnostics.Stopwatch]::StartNew(); $script:ProgLast = 0
        while (-not $eof) {
            $want = [int][Math]::Min([long]$CHUNK, $lenAtOpen - $nRead)   # 只讀到開檔當下的長度，服務一直寫也不會停不下來
            $k = 0; if ($want -gt 0) { $k = $fi.Read($buf, 0, $want) }
            $emit = $null
            if ($k -le 0) { $eof = $true; $data = $carry; $cut = $carry.Length }
            else {
                $nRead += $k
                Show-ReadProgress $f.Name $nRead $lenAtOpen $psw
                $data = New-Object byte[] ($carry.Length + $k)
                [Buffer]::BlockCopy($carry, 0, $data, 0, $carry.Length); [Buffer]::BlockCopy($buf, 0, $data, $carry.Length, $k)
                if ($dropToNl) {
                    $i0 = [Array]::IndexOf($data, [byte]10)
                    if ($i0 -lt 0) { $inPem = Update-PemState ($L1.GetString($data)) $inPem; $keep = [Math]::Min(64, $data.Length); $carry = New-Object byte[] $keep; [Buffer]::BlockCopy($data, $data.Length - $keep, $carry, 0, $keep); continue }
                    $inPem = Update-PemState ($L1.GetString($data, 0, $i0)) $inPem
                    $tmp = New-Object byte[] ($data.Length - $i0); [Buffer]::BlockCopy($data, $i0, $tmp, 0, $tmp.Length); $data = $tmp; $dropToNl = $false
                }
                $nl = [Array]::LastIndexOf($data, [byte]10)
                if ($nl -lt 0 -and $data.Length -lt 64MB) { $carry = $data; continue }   # 一律在換行處切，關鍵字與值不會被切開
                if ($nl -lt 0) { $inPem = Update-PemState ($L1.GetString($data)) $inPem; $emit = '***(over-long line without newline, not kept)***'; $dropToNl = $true; $cut = $data.Length; $res.Redacted++ }
                else { $cut = $nl + 1 }
            }
            if ($null -eq $emit -and $cut -gt 0) {
                $txt = $L1.GetString($data, 0, $cut)
                if ($inPem) {
                    $em = $RX_PEMEND.Match($txt)
                    if ($em.Success) { $txt = $txt.Substring($em.Index + $em.Length); $inPem = $false } else { $txt = '' }
                    $res.Redacted++
                }
                $bm = $RX_PEMBEGIN.Matches($txt)
                if ($bm.Count -gt 0) { $lb = $bm[$bm.Count - 1]; if (-not $RX_PEMEND.IsMatch($txt.Substring($lb.Index))) { $inPem = $true } }
                $emit = Protect-LogText $txt
                if ($emit -cne $txt) { $res.Redacted++ }
            }
            if ($emit) {
                $ob = $L1.GetBytes($emit)
                if ($state.curBytes -gt 0 -and ($state.curBytes + $ob.Length) -gt $partBytes) {
                    $fo.Close(); $state.part++; $state.cur = Get-PartPath $dst $state.part; $state.curBytes = 0
                    New-OutFile $state.cur $null; $res.Parts.Add($state.cur)
                    $fo = [IO.File]::Open((ConvertTo-LongPath $state.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
                }
                $fo.Write($ob, 0, $ob.Length); [void]$sha.TransformBlock($ob, 0, $ob.Length, $null, 0)
                $state.curBytes += $ob.Length; $res.Bytes += $ob.Length
            }
            if (-not $eof) { $rest = $data.Length - $cut; $carry = New-Object byte[] $rest; if ($rest) { [Buffer]::BlockCopy($data, $cut, $carry, 0, $rest) } }
        }
        [void]$sha.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        $res.Sha = ([BitConverter]::ToString($sha.Hash) -replace '-', '').ToLower()
        if ($nRead -lt $lenAtOpen) { $note += "短讀：$nRead / $lenAtOpen 位元組"; $res.Bad = $true }
    } finally {
        $fi.Close(); if ($fo) { $fo.Close() }; $sha.Dispose()
    }
    # 驗證：所有分段長度合計與 hash 都要對得上
    $vh = [Security.Cryptography.SHA256]::Create(); $vlen = [long]0
    try {
        foreach ($pp in $res.Parts) {
            $vf = Open-Source $pp
            try { $vb = New-Object byte[] $CHUNK; while (($vk = $vf.Read($vb, 0, $CHUNK)) -gt 0) { [void]$vh.TransformBlock($vb, 0, $vk, $null, 0); $vlen += $vk } } finally { $vf.Close() }
        }
        [void]$vh.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        if ($vlen -ne $res.Bytes -or (([BitConverter]::ToString($vh.Hash) -replace '-', '').ToLower()) -ne $res.Sha) { $note += "副本驗證不符（長度 $vlen／$($res.Bytes)）"; $res.Bad = $true }
    } finally { $vh.Dispose() }
    if ($res.Parts.Count -gt 1) { $note += "分成 $($res.Parts.Count) 段（每段約 $([int]($partBytes / 1MB)) MB）" }
    if ($res.Redacted) { $note += "遮掉帳密（$($res.Redacted) 個區塊有遮）" }
    try {
        $after = New-Object IO.FileInfo((ConvertTo-LongPath $src))
        if (-not $after.Exists) { $note += '複製完成後來源已不在（可能被輪替）' }
        elseif ($after.Length -ne $f.Length -or $after.LastWriteTime -ne $f.LastWriteTime) { $note += '複製中檔案有變動（服務正在寫）' }
    } catch { $note += '複製後無法再讀來源資訊' }
    $res.Note = ($note -join '；')
    return $res
}
# ======================= FileZilla log 精簡複製（slim） =======================
# 原則：slim 的每一個決定，都在「模擬 FtpReport 的 FileZilla 解析器」（ftp_report.py parse_logs）。
#  - 解析器的狀態（每個「連線編號|IP」：目前帳號 user、USER 嘗試的帳號 attempt、掛起的指令 pending）在這裡一模一樣地維護。
#  - 一行只有在「解析器處理它時狀態完全不變、也不產生任何紀錄」才丟；其他都留。因此報表在 slim 上的結果跟原檔相同。
#    例：PASV／TYPE／NOOP 在沒有掛起時、沒有掛起時的回應、掛起中的 1xx 回應 → 丟；
#    會改變帳號的行（括號裡的帳號跟目前不同）、會清掉掛起的指令、最終回應、登入失敗字樣 → 留。
#  - 整台主機第一個被解析的行、第一個回應行一定留（報表用「有沒有回應」決定要不要改用指令次數，不能因精簡而改變）。
#  - 狀態跨檔延續；不論這個檔輸出成 slim 還是整份（格式認不出來），都要過同一個狀態更新（整份的用輸出副本更新，就是報表會看到的內容）。
#    檔案收集失敗時，狀態還原成處理這個檔之前。
#  - 讀到開檔當下的長度為止（服務還在寫也不追）；最後沒有換行的半行照樣處理（整份複製也會留它）。
#  - 單行超過 $FZ_MAXLINE 位元組：那一行不保留，標示「不完整」（狀態 PARTIAL），不宣稱跟原檔相同。
# 解析用 UTF-8 解碼（跟報表一樣）、\s \d 等跟 Python 一致；輸出原始位元組（含帳密遮罩）。
$RX_FZ1L = New-Object regex('^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?)(Z)?\s+(\S{1,3})\s+\[([^\]]*)\]\s?(.*)$', 'Compiled')
$RX_FZBR = New-Object regex('^(.*?Session)\s+(\d+)\s+([0-9A-Fa-f:.]+)(?:\s+(.+?))?\s*$', 'Compiled')
$RX_FZ09L = New-Object regex('^\((\d+)\)\s*(\d{4}/\d{1,2}/\d{1,2} (?:(?:上午|下午|AM|PM) )?\d{1,2}:\d{2}:\d{2})\s*([AP]M|上午|下午)?\s*-\s*(.*?)\s*\(([0-9A-Fa-f:.]+)\)>\s?(.*)$', 'Compiled')   # 0.9：時間前可能有「上午／下午」（中文地區設定，168.100 實測）
$RX_FZCODE = New-Object regex('^(\d{3})(?:[ -]|$)', 'Compiled')
$RX_FZLOGINFAIL = New-Object regex('(?i)login incorrect|authentication failed|invalid password|login failed', 'Compiled')
$RX_FZNEEDMASK = New-Object regex('(?i)-----BEGIN|PASS[ \t]|\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:]|://\S*@', 'Compiled')   # Protect-LogText 會動到的行一定符合這個（私鑰、PASS 指令、key=、URL 帳密）；其他行不呼叫，省時間
$FZ_MAXLINE = 16MB
$RX_FZHI = New-Object regex('[^\x00-\x7F]', 'Compiled')
$UTF8R = New-Object Text.UTF8Encoding($false, $false)   # 解碼錯誤換成 U+FFFD（同 Python errors='replace'）
$FZ_PEND = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)   # 解析器會掛起等回應的指令
foreach ($v in @('USER', 'PASS', 'CWD', 'XCWD', 'CDUP', 'XCUP', 'STOR', 'APPE', 'STOU', 'RETR', 'DELE', 'RNFR', 'RNTO', 'MKD', 'XMKD', 'RMD', 'XRMD', 'LIST', 'NLST', 'MLSD')) { [void]$FZ_PEND.Add($v) }
$FZ_KEEP = New-Object 'System.Collections.Generic.HashSet[string]' ($FZ_PEND, [StringComparer]::Ordinal)   # 一律留的指令
if ($FzDropListing) { foreach ($v in @('LIST', 'NLST', 'MLSD')) { [void]$FZ_KEEP.Remove($v) } }
# 狀態：S[「連線編號|IP」] = @(目前帳號, USER 嘗試的帳號, 掛起的指令)；undo＝這個檔改過的連線原值（收集失敗時還原）
function New-FzState { return @{ S = (New-Object 'System.Collections.Generic.Dictionary[string,string[]]' ([StringComparer]::Ordinal)); matched = $false; resp = $false; undo = $null; um = $false; ur = $false } }
function Start-FzFile { $z = $script:Fz; $z.undo = (New-Object 'System.Collections.Generic.Dictionary[string,string[]]' ([StringComparer]::Ordinal)); $z.um = $z.matched; $z.ur = $z.resp }
function Undo-FzFile {
    $z = $script:Fz; if ($null -eq $z.undo) { return }
    foreach ($kv in $z.undo.GetEnumerator()) { if ($null -eq $kv.Value) { [void]$z.S.Remove($kv.Key) } else { $z.S[$kv.Key] = $kv.Value } }
    $z.matched = $z.um; $z.resp = $z.ur; $z.undo = $null
}
$script:Fz = New-FzState
# ---- 快速引擎（v1.2.0）：逐行判斷搬到 C#（PowerShell 逐行約 0.5 MB/s，大 log 要好幾小時）。
#      規則跟下面 PowerShell 版逐字一致，比對式直接用上面同一批 regex 物件；只在記憶體編譯，不改主機任何東西。
#      主機不允許即時編譯時自動改用 PowerShell 版（結果相同、只是慢），畫面會講。
$FZ_CS = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
public class FtpCollectFzEngineV120 {
    public Dictionary<string, string[]> S; public Dictionary<string, string[]> Undo;
    public bool Matched, Resp, SkipToNl;
    public long Kept, Dropped; public int Redacted, Over;
    Regex r1, rbr, r09, rc, rlf, rneed, rhi, pem, pass, kv, url, ampm;
    HashSet<string> keepV, pendV; Encoding l1, u8; int maxLine;
    string lastTs = null; bool lastOk = false;
    static readonly CultureInfo CI = CultureInfo.InvariantCulture;
    // 舊版 .NET 的「不分大小寫」比對很慢（每個字元查語系）。改成：整行轉小寫＋分大小寫、內容相同的比對式；
    // 再加「一行裡沒有任何關鍵字就不可能符合」的前置檢查。結果與原比對式相同（自我測試逐筆比對）。
    // 下面三個比對式＝PowerShell 的 $RX_OP／$RX_FZNEEDMASK／$RX_DATE 轉小寫版，改那邊要同步改這裡。
    static readonly Regex OPL = new Regex(@"(?<up>\b(?:stor|appe|stou)\b|received file|\buploaded\b|已成功收到檔案)|(?<down>\bretr\b|sent file|\bdownloaded\b|已成功發送檔)|(?<oth>\b(?:dele|rnfr|rnto|x?mkd|x?rmd|nlst|mlsd|list)\b|deleted file|renamed file|created directory|removed directory|檔已移除|目錄已創建)|(?<ok>\b230\b|logged on|logged in|login successful|"" 已登入)|(?<fail>\b530\b|login failed|login incorrect|invalid password|authentication failed)", RegexOptions.Compiled);
    static readonly string[] OPA = { "stor", "appe", "stou", "received file", "uploaded", "已成功收到檔案", "retr", "sent file", "downloaded", "已成功發送檔", "dele", "rnfr", "rnto", "mkd", "rmd", "nlst", "mlsd", "list", "renamed file", "created directory", "removed directory", "檔已移除", "目錄已創建", "230", "logged on", "logged in", "login successful", "\" 已登入", "530", "login failed", "login incorrect", "invalid password", "authentication failed" };
    static readonly Regex NEEDL = new Regex(@"-----begin|pass[ \t]|\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:]|://\S*@", RegexOptions.Compiled);
    static readonly string[] NEEDA = { "-----begin", "pass", "pwd", "secret", "token", "api", "access", "client", "shared", "://" };
    static readonly Regex DATEL = new Regex(@"(?<y>\d{4})[-/](?<m>\d{1,2})[-/](?<d>\d{1,2})[t ](?:(?:上午|下午|am|pm) )?\d{1,2}:\d{2}|(?<d2>\d{2})(?<mon>jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)(?<y2>\d{2})\s+\d{2}:\d{2}", RegexOptions.Compiled);
    // FileZilla 0.9 一行的手寫解析：照 $RX_FZ09L 的規則逐字判斷（比對式在舊版 .NET 一行要 10 多微秒）。
    // 回傳 true＝確定符合、欄位與比對式相同；false＝不確定，呼叫端改用比對式。逐筆一致性由自我測試比對。
    static bool Ws(char c) { return Char.IsWhiteSpace(c); }   // 同 \s
    static bool Dg(char c) { return Char.IsDigit(c); }        // 同 \d（Unicode 數字）
    static bool Hx(char c) { return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f') || c == ':' || c == '.'; }
    static int D12(string s, int i, char next) {   // \d{1,2} 後面接 next；回傳下一個位置，-1＝不符
        int n = s.Length;
        if (i + 2 < n && Dg(s[i]) && Dg(s[i + 1]) && s[i + 2] == next) return i + 3;
        if (i + 1 < n && Dg(s[i]) && s[i + 1] == next) return i + 2;
        return -1;
    }
    public static bool Parse09(string s, out string id, out string ts, out string user, out string ip, out string msg) {
        id = ts = user = ip = msg = null; int n = s.Length, i = 1, j;
        if (n < 2 || s[0] != '(') return false;
        while (i < n && Dg(s[i])) i++;
        if (i == 1 || i >= n || s[i] != ')') return false;
        id = s.Substring(1, i - 1); i++;
        while (i < n && Ws(s[i])) i++;
        int t0 = i;
        if (i + 4 >= n || !Dg(s[i]) || !Dg(s[i + 1]) || !Dg(s[i + 2]) || !Dg(s[i + 3]) || s[i + 4] != '/') return false;
        i += 5;
        if ((i = D12(s, i, '/')) < 0) return false;
        if ((i = D12(s, i, ' ')) < 0) return false;
        if (i + 2 < n && (s[i] == '上' || s[i] == '下') && s[i + 1] == '午' && s[i + 2] == ' ') i += 3;
        else if (i + 2 < n && (s[i] == 'A' || s[i] == 'P') && s[i + 1] == 'M' && s[i + 2] == ' ') i += 3;
        if ((i = D12(s, i, ':')) < 0) return false;
        if (i + 4 >= n || !Dg(s[i]) || !Dg(s[i + 1]) || s[i + 2] != ':' || !Dg(s[i + 3]) || !Dg(s[i + 4])) return false;
        i += 5; ts = s.Substring(t0, i - t0);
        while (i < n && Ws(s[i])) i++;
        if (i + 1 < n && ((s[i] == 'A' || s[i] == 'P') && s[i + 1] == 'M' || (s[i] == '上' || s[i] == '下') && s[i + 1] == '午')) { i += 2; while (i < n && Ws(s[i])) i++; }
        if (i >= n || s[i] != '-') return false;
        i++; while (i < n && Ws(s[i])) i++;
        int u0 = i, p = -1, q = -1;
        for (j = u0; j < n; j++) {
            if (s[j] != '(') continue;
            int k = j + 1; while (k < n && Hx(s[k])) k++;
            if (k > j + 1 && k + 1 < n && s[k] == ')' && s[k + 1] == '>') { p = j; q = k; break; }
        }
        if (p < 0) return false;
        int L = p; while (L > u0 && Ws(s[L - 1])) L--;
        user = s.Substring(u0, L - u0); ip = s.Substring(p + 1, q - p - 1);
        i = q + 2; if (i < n && Ws(s[i])) i++;
        msg = s.Substring(i);
        return true;
    }
    public static bool IsCode(string m) {   // 同 $RX_FZCODE.IsMatch：^(\d{3})(?:[ -]|$)
        return m.Length >= 3 && Dg(m[0]) && Dg(m[1]) && Dg(m[2]) && (m.Length == 3 || m[3] == ' ' || m[3] == '-');
    }
    public static bool HasHi(string s) { for (int i = 0; i < s.Length; i++) { if (s[i] > '\x7F') return true; } return false; }
    // ---- 統計用手寫判斷（規則同 $RX_OP／$RX_DATE；遇到零寬連字等少見字元改用比對式）----
    static bool IsW(char c) {   // 同 .NET 比對式 \w：字母、非間距標記、十進位數字、連接標點
        switch (Char.GetUnicodeCategory(c)) {
            case UnicodeCategory.UppercaseLetter: case UnicodeCategory.LowercaseLetter: case UnicodeCategory.TitlecaseLetter:
            case UnicodeCategory.ModifierLetter: case UnicodeCategory.OtherLetter: case UnicodeCategory.NonSpacingMark:
            case UnicodeCategory.DecimalDigitNumber: case UnicodeCategory.ConnectorPunctuation: return true;
        }
        return false;
    }
    static bool Bd(string s, int i) { bool l = i > 0 && IsW(s[i - 1]); bool r = i < s.Length && IsW(s[i]); return l != r; }   // 同 \b
    static readonly string[] OPT = { "stor", "appe", "stou", "received file", "uploaded", "已成功收到檔案", "retr", "sent file", "downloaded", "已成功發送檔",
        "dele", "rnfr", "rnto", "mkd", "rmd", "nlst", "mlsd", "list", "deleted file", "renamed file", "created directory", "removed directory", "檔已移除", "目錄已創建",
        "230", "logged on", "logged in", "login successful", "\" 已登入", "530", "login failed", "login incorrect", "invalid password", "authentication failed" };
    static readonly int[] OPG = { 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5 };   // 1 up 2 down 3 oth 4 ok 5 fail
    static readonly bool[] OPB = { true, true, true, false, true, false, true, false, true, false, true, true, true, true, true, true, true, true, false, false, false, false, false, false, true, false, false, false, false, true, false, false, false, false };
    public static int OpRegexGroup(string lo) {
        Match o = OPL.Match(lo); if (!o.Success) return 0;
        return o.Groups["up"].Success ? 1 : o.Groups["down"].Success ? 2 : o.Groups["oth"].Success ? 3 : o.Groups["ok"].Success ? 4 : 5;
    }
    public static int OpGroup(string lo) {   // lo＝已轉小寫的一行；回傳 0＝不符，1～5＝符合的類別（最左邊的那一個，同比對式）
        if (lo.IndexOf('\u200C') >= 0 || lo.IndexOf('\u200D') >= 0) return OpRegexGroup(lo);
        int best = Int32.MaxValue, bg = 0;
        for (int a = 0; a < OPT.Length; a++) {
            string t = OPT[a]; int k = lo.IndexOf(t, StringComparison.Ordinal);
            while (k >= 0 && k <= best) {
                int st = k;
                if (OPB[a]) {
                    if ((a == 13 || a == 14) && k > 0 && lo[k - 1] == 'x') st = k - 1;   // x?mkd／x?rmd
                    if (!(Bd(lo, st) && Bd(lo, k + t.Length))) { k = lo.IndexOf(t, k + 1, StringComparison.Ordinal); continue; }
                }
                if (st < best) { best = st; bg = OPG[a]; }
                break;
            }
        }
        return bg;
    }
    static int Dsep(string s, int i, int n, char x, char y) {   // \d{1,2}[xy]：回傳下一個位置，-1＝不符
        if (i + 2 < n && Dg(s[i]) && Dg(s[i + 1]) && (s[i + 2] == x || s[i + 2] == y)) return i + 3;
        if (i + 1 < n && Dg(s[i]) && (s[i + 1] == x || s[i + 1] == y)) return i + 2;
        return -1;
    }
    static readonly string MONS = "janfebmaraprmayjunjulaugsepoctnovdec";
    public static string DateRegexKey(string lo, int n) {
        Match m = DATEL.Match(lo, 0, n); if (!m.Success) return null;
        if (m.Groups["y"].Success) return m.Groups["y"].Value + "-" + Int32.Parse(m.Groups["m"].Value, CI).ToString("00", CI) + "-" + Int32.Parse(m.Groups["d"].Value, CI).ToString("00", CI);
        int mon = MONS.IndexOf(m.Groups["mon"].Value, StringComparison.Ordinal) / 3 + 1;
        return "20" + m.Groups["y2"].Value + "-" + mon.ToString("00", CI) + "-" + m.Groups["d2"].Value;
    }
    public static string DateKey(string lo, int n) {   // 同 DateRegexKey（在前 n 個字裡找最左邊的日期）
        for (int i = 0; i < n; i++) {
            if (!Dg(lo[i])) continue;
            // 選項一：\d{4}[-/]\d{1,2}[-/]\d{1,2}[t ](?:(?:上午|下午|am|pm) )?\d{1,2}:\d{2}
            if (i + 4 < n && Dg(lo[i + 1]) && Dg(lo[i + 2]) && Dg(lo[i + 3]) && (lo[i + 4] == '-' || lo[i + 4] == '/')) {
                int j = Dsep(lo, i + 5, n, '-', '/'), j2 = -1, j3 = -1;
                if (j > 0) j2 = Dsep(lo, j, n, 't', ' ');
                if (j2 > 0) {
                    int h = j2;
                    if (h + 2 < n && lo[h + 2] == ' ' && (((lo[h] == '上' || lo[h] == '下') && lo[h + 1] == '午') || ((lo[h] == 'a' || lo[h] == 'p') && lo[h + 1] == 'm'))) h += 3;
                    j3 = Dsep(lo, h, n, ':', ':');
                    if (j3 > 0 && j3 + 1 < n && Dg(lo[j3]) && Dg(lo[j3 + 1])) {
                        string ms = lo.Substring(i + 5, j - 1 - (i + 5)), ds = lo.Substring(j, j2 - 1 - j);
                        return lo.Substring(i, 4) + "-" + Int32.Parse(ms, CI).ToString("00", CI) + "-" + Int32.Parse(ds, CI).ToString("00", CI);
                    }
                }
            }
            // 選項二：(\d{2})(jan|…|dec)(\d{2})\s+\d{2}:\d{2}
            if (i + 6 < n && Dg(lo[i + 1])) {
                int mi = -1;
                for (int q = 0; q < 36; q += 3) { if (lo[i + 2] == MONS[q] && lo[i + 3] == MONS[q + 1] && lo[i + 4] == MONS[q + 2]) { mi = q; break; } }
                if (mi >= 0 && Dg(lo[i + 5]) && Dg(lo[i + 6])) {
                    int h = i + 7;
                    if (h < n && Ws(lo[h])) {
                        while (h < n && Ws(lo[h])) h++;
                        if (h + 4 < n && Dg(lo[h]) && Dg(lo[h + 1]) && lo[h + 2] == ':' && Dg(lo[h + 3]) && Dg(lo[h + 4]))
                            return "20" + lo.Substring(i + 5, 2) + "-" + (mi / 3 + 1).ToString("00", CI) + "-" + lo.Substring(i, 2);
                    }
                }
            }
        }
        return null;
    }
    public static string AmPmStrip(string t) {   // 同 Regex(" (上午|下午|AM|PM) ", IgnoreCase).Replace(t, " ")
        if (t.IndexOf(' ') < 0) return t;
        StringBuilder b = null; int i = 0, n = t.Length, last = 0;
        while (i + 3 < n) {
            char a = t[i + 1], m = t[i + 2];
            if (t[i] == ' ' && t[i + 3] == ' ' && (((a == '上' || a == '下') && m == '午') || ((a == 'a' || a == 'A' || a == 'p' || a == 'P') && (m == 'm' || m == 'M')))) {
                if (b == null) b = new StringBuilder(n);
                b.Append(t, last, i - last).Append(' '); i += 4; last = i;
            } else i++;
        }
        if (b == null) return t;
        b.Append(t, last, n - last); return b.ToString();
    }
    static readonly string[] LFA = { "login incorrect", "authentication failed", "invalid password", "login failed" };   // 同 $RX_FZLOGINFAIL（不分大小寫）
    public static bool LoginFail(string msg) { return AnyOf(msg.ToLowerInvariant(), LFA); }
    static bool AnyOf(string s, string[] a) { for (int i = 0; i < a.Length; i++) { if (s.IndexOf(a[i], StringComparison.Ordinal) >= 0) return true; } return false; }
    public static bool NeedMask(string raw) { string lo = raw.ToLowerInvariant(); return AnyOf(lo, NEEDA) && NEEDL.IsMatch(lo); }
    public static Match OpMatch(string line) { string lo = line.ToLowerInvariant(); if (!AnyOf(lo, OPA)) return Match.Empty; return OPL.Match(lo); }
    public FtpCollectFzEngineV120(Regex r1, Regex rbr, Regex r09, Regex rc, Regex rlf, Regex rneed, Regex rhi,
        Regex pem, Regex pass, Regex kv, Regex url, HashSet<string> keepV, HashSet<string> pendV, Encoding l1, Encoding u8, int maxLine) {
        this.r1 = r1; this.rbr = rbr; this.r09 = r09; this.rc = rc; this.rlf = rlf; this.rneed = rneed; this.rhi = rhi;
        this.pem = pem; this.pass = pass; this.kv = kv; this.url = url; this.keepV = keepV; this.pendV = pendV;
        this.l1 = l1; this.u8 = u8; this.maxLine = maxLine;
        ampm = new Regex(" (上午|下午|AM|PM) ", RegexOptions.IgnoreCase);   // 同 PowerShell -replace（不分大小寫）
    }
    string Protect(string t) {   // 同 Protect-LogText
        string o = pem.Replace(t, "***(private key removed)***");
        o = pass.Replace(o, "${1}***"); o = kv.Replace(o, "${1}***"); o = url.Replace(o, "${1}***@");
        return o;
    }
    public void Run(string text, int end, bool write, StringBuilder sbo) {
        int pos = 0;
        while (pos < end) {
            int nl = text.IndexOf('\n', pos); int next = (nl < 0) ? end : nl + 1;
            if (SkipToNl) { SkipToNl = false; pos = next; continue; }
            if ((next - pos) > maxLine) { Over++; pos = next; continue; }
            string raw = text.Substring(pos, next - pos); pos = next;
            if (NeedMask(raw)) { string o = Protect(raw); if (!String.Equals(o, raw, StringComparison.Ordinal)) { Redacted++; raw = o; } }
            string line = raw.TrimEnd('\r', '\n');
            if (HasHi(line)) line = u8.GetString(l1.GetBytes(line));
            bool keep = false, ok = false, isCmd = false, isResp = false;
            string key = null, buser = null, msg = null;
            bool p09 = line.StartsWith("(", StringComparison.Ordinal);
            if (!p09) {
                Match m = r1.Match(line);
                if (m.Success) {
                    GroupCollection g = m.Groups; Match bm = rbr.Match(g[4].Value);
                    if (bm.Success) {
                        string tsS = g[1].Value.Replace(' ', 'T').Substring(0, 19);
                        if (!String.Equals(tsS, lastTs, StringComparison.Ordinal)) { lastTs = tsS; DateTime tv; lastOk = DateTime.TryParseExact(tsS, "yyyy-MM-dd'T'HH:mm:ss", CI, DateTimeStyles.None, out tv); }
                        if (lastOk) {
                            ok = true; key = bm.Groups[2].Value + "|" + bm.Groups[3].Value; buser = bm.Groups[4].Value.Trim();
                            string d = g[3].Value; msg = g[5].Value;
                            isCmd = d == ">>"; isResp = d == "<<";
                            if (msg.StartsWith("Command: ", StringComparison.Ordinal)) { msg = msg.Substring(9); isCmd = true; isResp = false; }
                            else if (msg.StartsWith("Response: ", StringComparison.Ordinal)) { msg = msg.Substring(10); isCmd = false; isResp = true; }
                        }
                    }
                }
            } else {
                string hId, hTs, hUser, hIp, hMsg; bool hit = Parse09(line, out hId, out hTs, out hUser, out hIp, out hMsg);
                if (!hit) {
                    Match m = r09.Match(line);
                    if (m.Success) { GroupCollection g = m.Groups; hit = true; hId = g[1].Value; hTs = g[2].Value; hUser = g[4].Value; hIp = g[5].Value; hMsg = g[6].Value; }
                }
                if (hit) {
                    string tsS = hTs;
                    if (!String.Equals(tsS, lastTs, StringComparison.Ordinal)) { lastTs = tsS; DateTime tv; lastOk = DateTime.TryParseExact(AmPmStrip(tsS), "yyyy/M/d H:mm:ss", CI, DateTimeStyles.None, out tv); }
                    if (lastOk) {
                        ok = true; key = hId + "|" + hIp; buser = hUser.Trim();
                        if (String.Equals(buser, "(not logged in)", StringComparison.OrdinalIgnoreCase) || String.Equals(buser, "not logged in", StringComparison.OrdinalIgnoreCase)) buser = "";
                        msg = hMsg; isResp = IsCode(msg); isCmd = !isResp;
                    }
                }
            }
            if (ok) {
                if (!Matched) { Matched = true; keep = true; }
                string[] e; string curU, curA, curP;
                if (S.TryGetValue(key, out e)) { curU = e[0]; curA = e[1]; curP = e[2]; } else { e = null; curU = ""; curA = ""; curP = ""; }
                string newU = curU, newP = curP, newA = curA;
                if (buser.Length > 0 && !String.Equals(buser, curU, StringComparison.Ordinal)) { newU = buser; keep = true; }
                if (isCmd) {
                    string t = msg.Trim(); int sp = t.IndexOf(' '); string verb, arg;
                    if (sp >= 0) { verb = t.Substring(0, sp).ToUpperInvariant(); arg = t.Substring(sp + 1).Trim(); } else { verb = t.ToUpperInvariant(); arg = ""; }
                    if (keepV.Contains(verb) || curP.Length > 0) keep = true;
                    if (verb == "USER") { newA = arg; newU = buser; }
                    newP = pendV.Contains(verb) ? verb : "";
                } else if (isResp) {
                    if (!Resp) { Resp = true; keep = true; }
                    string tm = msg.Trim(); bool cmOk = IsCode(tm);
                    if (!cmOk || curP.Length == 0) {
                        if (curA.Length > 0 && LoginFail(msg)) keep = true;
                    } else if (Int32.Parse(tm.Substring(0, 3), CI) >= 200) {
                        keep = true; newP = "";
                        if ((curP == "USER" || curP == "PASS") && Int32.Parse(tm.Substring(0, 3), CI) == 230 && newU.Length == 0 && curA.Length > 0) newU = curA;
                    }
                }
                if ((keep || !write) && (newU != curU || newA != curA || newP != curP)) {
                    if (Undo != null && !Undo.ContainsKey(key)) Undo[key] = (e == null) ? null : (string[])e.Clone();
                    if (e == null) { e = new string[] { "", "", "" }; S[key] = e; }
                    e[0] = newU; e[1] = newA; e[2] = newP;
                }
            }
            if (write) { if (keep) { sbo.Append(raw); Kept++; } else { Dropped++; } }
        }
    }
    // 第 6 步 log 證據品質統計（同 PowerShell 版逐行：日期、UTC、上傳／下載／其他／登入成功／失敗）
    // c: 0 lines,1 dated,2 up,3 down,4 oth,5 ok,6 fail；utc[0]：'' / 'Z(UTC)' / 'none'；回傳 '' 或「超過 N 秒」
    public static string Stats(System.IO.Stream fs, Encoding enc, Regex rd, Regex ru, Regex rop, Dictionary<string, int> fd, long[] c, string[] utc, System.Diagnostics.Stopwatch sw, int limitSec) {
        using (System.IO.StreamReader sr = new System.IO.StreamReader(fs, enc, true)) {
            string line;
            while ((line = sr.ReadLine()) != null) {
                c[0]++;
                string lo = line.ToLowerInvariant();
                string key = DateKey(lo, Math.Min(80, line.Length));
                if (key != null) {
                    int n; if (fd.TryGetValue(key, out n)) fd[key] = n + 1; else fd[key] = 1;
                    c[1]++;
                    if (utc[0].Length == 0) utc[0] = ru.IsMatch(line) ? "Z(UTC)" : "none";
                }
                int og = AnyOf(lo, OPA) ? OpGroup(lo) : 0;
                if (og > 0) c[og + 1]++;
                if ((c[0] % 20000) == 0 && sw.Elapsed.TotalSeconds > limitSec) return "超過 " + limitSec + " 秒，部分 log 未解析完";
            }
        }
        return "";
    }
}
'@
$script:FzFast = $false; $script:FzFastErr = '尚未編譯'; $script:FzEngLogged = $false   # 編譯在主流程（結果資料夾建好後），見 Add-TypeInRun
function Add-TypeInRun([string]$src, [string]$typeName) {
    # v1.3.1：Add-Type（CodeDom）編譯會產生暫存檔（原始碼、命令列、組件）。預設寫在系統 TEMP（結果資料夾以外）——
    # 改成一律寫在本次結果資料夾的 _compile\，組件直接載入記憶體，暫存檔編譯完就由 CodeDom 刪掉（KeepFiles=$false）。
    if ($typeName -as [type]) { return }
    $tmp = Join-Path $script:RunDir '_compile'
    New-RunSubDir $tmp
    $cp = New-Object System.CodeDom.Compiler.CompilerParameters
    $cp.GenerateInMemory = $true
    $cp.TempFiles = New-Object System.CodeDom.Compiler.TempFileCollection(([IO.Path]::GetFullPath($tmp)), $false)
    [void]$cp.ReferencedAssemblies.Add('System.dll'); [void]$cp.ReferencedAssemblies.Add('System.Core.dll')
    Add-Type -TypeDefinition $src -CompilerParameters $cp -ErrorAction Stop
}
function Test-FzLog([IO.FileInfo]$f) {
    # 看開頭 64 KB：有 FileZilla 0.9／1.x 格式的行才輸出 slim（其他整份複製，但狀態一樣要更新）
    $fs = Open-Source (ConvertFrom-LongPath $f.FullName)
    try {
        $buf = New-Object byte[] 65536; $k = $fs.Read($buf, 0, 65536)
        if ($k -le 0) { return $false }
        if ($k -ge 2 -and (($buf[0] -eq 0xFF -and $buf[1] -eq 0xFE) -or ($buf[0] -eq 0xFE -and $buf[1] -eq 0xFF))) { return $false }
        if ([Array]::IndexOf($buf, [byte]0, 0, $k) -ge 0) { return $false }
        $n = 0
        foreach ($ln in ($UTF8R.GetString($buf, 0, $k) -split "`n")) {
            $ln = $ln.TrimEnd("`r")
            if ($RX_FZ09L.IsMatch($ln)) { return $true }
            $m = $RX_FZ1L.Match($ln); if ($m.Success -and $RX_FZBR.IsMatch($m.Groups[4].Value)) { return $true }
            if (++$n -ge 400) { break }
        }
        return $false
    } finally { $fs.Close() }
}
function Write-SlimChunk($st, [IO.MemoryStream]$ms, $sha, $res, [string]$dst, [long]$partBytes) {
    # 把累積的位元組寫出（約 1 MB 一次）；超過 partBytes 換下一段。獨立成函式：迴圈裡不能 dot-source（會讓整個函式的變數變慢）
    if (-not $ms.Length) { return }
    $ob = $ms.ToArray(); $ms.SetLength(0)
    if ($st.curBytes -gt 0 -and ($st.curBytes + $ob.Length) -gt $partBytes) {
        $st.fo.Close(); $st.part++; $st.cur = Get-PartPath $dst $st.part; $st.curBytes = 0
        New-OutFile $st.cur $null; $res.Parts.Add($st.cur)
        $st.fo = [IO.File]::Open((ConvertTo-LongPath $st.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    }
    $st.fo.Write($ob, 0, $ob.Length); [void]$sha.TransformBlock($ob, 0, $ob.Length, $null, 0)
    $st.curBytes += $ob.Length; $res.Bytes += $ob.Length
}
function Invoke-FzStream([string[]]$inputs, [string]$dst, [long]$partBytes, [bool]$write) {
    # $write=$true：讀來源（$inputs 只有一個），輸出 slim；$write=$false：只更新狀態（讀整份複製的輸出副本，依序各段）。
    # 回傳 Bytes、Sha、Parts、Kept、Dropped、Overlong、ReadBytes、Short、Redacted
    $res = [pscustomobject]@{ Bytes = [long]0; Sha = ''; Parts = (New-Object System.Collections.Generic.List[string]); Kept = [long]0; Dropped = [long]0
        Overlong = 0; ReadBytes = [long]0; Short = $false; Redacted = 0 }
    $Z = $script:Fz; $S = $Z.S; $undo = $Z.undo
    $keepV = $FZ_KEEP; $pendV = $FZ_PEND
    $r1 = $RX_FZ1L; $rbr = $RX_FZBR; $r09 = $RX_FZ09L; $rc = $RX_FZCODE; $rlf = $RX_FZLOGINFAIL; $rneed = $RX_FZNEEDMASK; $u8 = $UTF8R; $l1 = $L1
    $sha = $null; $st = @{ part = 1; cur = ''; curBytes = [long]0; fo = $null }; $ms = $null
    $kept = [long]0; $dropped = [long]0; $red = 0; $over = 0
    $sbo = New-Object Text.StringBuilder; $crlf = [char[]]@([char]13, [char]10); $rhi = $RX_FZHI
    $lastTs = $null; $lastOk = $false; $ci = [Globalization.CultureInfo]::InvariantCulture; $tsv = [datetime]::MinValue
    $eng = $null
    if ($script:FzFast) {
        $eng = [FtpCollectFzEngineV120]::new($r1, $rbr, $r09, $rc, $rlf, $rneed, $rhi, $RX_PEMKEY, $RX_LOGPASS, $RX_KV, $RX_URLCRED, $keepV, $pendV, $l1, $u8, [int]$FZ_MAXLINE)
        $eng.S = $S; $eng.Undo = $undo; $eng.Matched = [bool]$Z.matched; $eng.Resp = [bool]$Z.resp
    }
    if (-not $script:FzEngLogged) {
        $script:FzEngLogged = $true
        if ($eng) { Log 'FileZilla log 精簡：快速模式（C#，結果與一般模式相同）' }
        else { Log "FileZilla log 精簡：主機不允許快速模式，改用一般模式（結果相同但慢，大 log 可能要好幾小時，可按 Ctrl+C 中斷）：$($script:FzFastErr)" }
    }
    try {
        if ($write) {
            $sha = [Security.Cryptography.SHA256]::Create(); $ms = New-Object IO.MemoryStream
            $st.cur = [IO.Path]::GetFullPath($dst); New-OutFile $st.cur $null; $res.Parts.Add($st.cur)
            $st.fo = [IO.File]::Open((ConvertTo-LongPath $st.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        }
        $buf = New-Object byte[] 1048576
        foreach ($inp in $inputs) {
            $fs = Open-Source $inp
            try {
                $len = $fs.Length; $nRead = [long]0
                $psw = [Diagnostics.Stopwatch]::StartNew(); $script:ProgLast = 0; $pname = [IO.Path]::GetFileName([string]$inp)
                $carry = New-Object byte[] 0; $skipToNl = $false; $eof = $false
                while (-not $eof) {
                    $want = [int][Math]::Min([long]$buf.Length, $len - $nRead)   # 只讀到開檔當下的長度
                    $k = 0; if ($want -gt 0) { $k = $fs.Read($buf, 0, $want) }
                    if ($k -le 0) { $eof = $true; $data = $carry; $end = $carry.Length }
                    else {
                        $nRead += $k
                        Show-ReadProgress $pname $nRead $len $psw
                        $data = New-Object byte[] ($carry.Length + $k)
                        [Buffer]::BlockCopy($carry, 0, $data, 0, $carry.Length); [Buffer]::BlockCopy($buf, 0, $data, $carry.Length, $k)
                        $end = [Array]::LastIndexOf($data, [byte]10) + 1   # 只處理到最後一個換行，其餘留到下一塊
                        if ($end -le 0) {
                            if ($data.Length -gt $FZ_MAXLINE) { if (-not $skipToNl) { $over++ }; $skipToNl = $true; $carry = New-Object byte[] 0 }   # 超長行：不保留、不解析
                            else { $carry = $data }
                            continue
                        }
                    }
                    # 這一塊（到最後一個換行為止）用 Latin-1 轉成字串：位元組 1:1 對應，切行、輸出都不會改到內容
                    $text = $l1.GetString($data, 0, $end)
                    if ($eng) {
                        $eng.SkipToNl = $skipToNl; $eng.Run($text, $end, $write, $sbo); $skipToNl = $eng.SkipToNl
                        if ($write -and $sbo.Length -ge 1048576) { $ob = $l1.GetBytes($sbo.ToString()); [void]$sbo.Clear(); $ms.Write($ob, 0, $ob.Length); Write-SlimChunk $st $ms $sha $res $dst $partBytes }
                    } else {
                    $pos = 0
                    while ($pos -lt $end) {
                        $nl = $text.IndexOf("`n", $pos)
                        if ($nl -lt 0) { $next = $end } else { $next = $nl + 1 }   # EOF 時沒有換行的半行也處理
                        if ($skipToNl) { $skipToNl = $false; $pos = $next; continue }   # 超長行的尾巴
                        if (($next - $pos) -gt $FZ_MAXLINE) { $over++; $pos = $next; continue }
                        $raw = $text.Substring($pos, $next - $pos); $pos = $next   # 原始內容（含換行）
                        if ($rneed.IsMatch($raw)) {   # 可能含帳密：用遮過的內容（報表看到的就是遮過的）
                            $o = Protect-LogText $raw; if ($o -cne $raw) { $red++; $raw = $o }
                        }
                        $line = $raw.TrimEnd($crlf)   # 同 Python rstrip('\r\n')
                        if ($rhi.IsMatch($line)) { $line = $u8.GetString($l1.GetBytes($line)) }   # 有非 ASCII：照報表用 UTF-8 解碼後再解析
                        # ---- 解析（同 ftp_report.parse_logs）
                        $keep = $false; $ok = $false; $isCmd = $false; $isResp = $false
                        $p09 = $line.StartsWith('(', [StringComparison]::Ordinal)   # 0.9 格式以 ( 開頭；1.x 以數字開頭，兩個不會同時成立
                        if (-not $p09) { $m = $r1.Match($line) }
                        if (-not $p09 -and $m.Success) {
                            $g = $m.Groups; $bm = $rbr.Match($g[4].Value)
                            if ($bm.Success) {
                                $tsS = $g[1].Value.Replace(' ', 'T').Substring(0, 19)
                                if ($tsS -cne $lastTs) { $lastTs = $tsS; $lastOk = [datetime]::TryParseExact($tsS, "yyyy-MM-dd'T'HH:mm:ss", $ci, 'None', [ref]$tsv) }
                                if ($lastOk) {
                                    $ok = $true; $key = $bm.Groups[2].Value + '|' + $bm.Groups[3].Value; $buser = $bm.Groups[4].Value.Trim()
                                    $d = $g[3].Value; $msg = $g[5].Value
                                    $isCmd = ($d -ceq '>>'); $isResp = ($d -ceq '<<')
                                    if ($msg.StartsWith('Command: ', [StringComparison]::Ordinal)) { $msg = $msg.Substring(9); $isCmd = $true; $isResp = $false }
                                    elseif ($msg.StartsWith('Response: ', [StringComparison]::Ordinal)) { $msg = $msg.Substring(10); $isCmd = $false; $isResp = $true }
                                }
                            }
                        } elseif ($p09) {
                            $m = $r09.Match($line)
                            if ($m.Success) {
                                $g = $m.Groups; $tsS = $g[2].Value
                                if ($tsS -cne $lastTs) { $lastTs = $tsS; $lastOk = [datetime]::TryParseExact(($tsS -replace ' (上午|下午|AM|PM) ', ' '), 'yyyy/M/d H:mm:ss', $ci, 'None', [ref]$tsv) }
                                if ($lastOk) {
                                    $ok = $true; $key = $g[1].Value + '|' + $g[5].Value; $buser = $g[4].Value.Trim()
                                    if ($buser -eq '(not logged in)' -or $buser -eq 'not logged in') { $buser = '' }   # -eq 不分大小寫＝Python .lower()
                                    $msg = $g[6].Value
                                    $isResp = $rc.IsMatch($msg); $isCmd = -not $isResp
                                }
                            }
                        }
                        if ($ok) {
                            if (-not $Z.matched) { $Z.matched = $true; $keep = $true }
                            $e = $null
                            if ($S.TryGetValue($key, [ref]$e)) { $curU = $e[0]; $curA = $e[1]; $curP = $e[2] } else { $e = $null; $curU = ''; $curA = ''; $curP = '' }
                            $newU = $curU; $newP = $curP; $newA = $curA
                            if ($buser -and $buser -cne $curU) { $newU = $buser; $keep = $true }   # 這行會改變目前帳號
                            if ($isCmd) {
                                $t = $msg.Trim(); $sp = $t.IndexOf(' ')
                                if ($sp -ge 0) { $verb = $t.Substring(0, $sp).ToUpperInvariant(); $arg = $t.Substring($sp + 1).Trim() } else { $verb = $t.ToUpperInvariant(); $arg = '' }
                                if ($keepV.Contains($verb) -or $curP) { $keep = $true }   # 一律留的指令；或有掛起（這行會清掉／換掉掛起）
                                if ($verb -ceq 'USER') { $newA = $arg; $newU = $buser }   # 同報表：attempt＝參數、user＝這行的帳號或空
                                if ($pendV.Contains($verb)) { $newP = $verb } else { $newP = '' }
                            } elseif ($isResp) {
                                if (-not $Z.resp) { $Z.resp = $true; $keep = $true }
                                $cm = $rc.Match($msg.Trim())
                                if (-not $cm.Success -or -not $curP) {
                                    if ($curA -and $rlf.IsMatch($msg)) { $keep = $true }   # 會記一筆登入失敗
                                } elseif ([int]$cm.Groups[1].Value -ge 200) {
                                    $keep = $true; $newP = ''
                                    if (($curP -ceq 'USER' -or $curP -ceq 'PASS') -and [int]$cm.Groups[1].Value -eq 230 -and -not $newU -and $curA) { $newU = $curA }
                                }
                            }
                            if (($keep -or -not $write) -and ($newU -cne $curU -or $newA -cne $curA -or $newP -cne $curP)) {   # 留下的行才改變狀態（丟掉的行本來就不改）；只更新狀態時每行都算
                                if ($null -ne $undo -and -not $undo.ContainsKey($key)) { if ($null -eq $e) { $undo[$key] = $null } else { $undo[$key] = [string[]]$e.Clone() } }
                                if ($null -eq $e) { $e = [string[]]@('', '', ''); $S[$key] = $e }
                                $e[0] = $newU; $e[1] = $newA; $e[2] = $newP
                            }
                        }
                        if ($write) {
                            if ($keep) {
                                [void]$sbo.Append($raw); $kept++
                                if ($sbo.Length -ge 1048576) { $ob = $l1.GetBytes($sbo.ToString()); [void]$sbo.Clear(); $ms.Write($ob, 0, $ob.Length); Write-SlimChunk $st $ms $sha $res $dst $partBytes }
                            }
                            else { $dropped++ }
                        }
                    }
                    }
                    if (-not $eof) { $rest = $data.Length - $end; $carry = New-Object byte[] $rest; if ($rest) { [Buffer]::BlockCopy($data, $end, $carry, 0, $rest) } }
                }
                $res.ReadBytes += $nRead
                if ($nRead -lt $len) { $res.Short = $true }
            } finally { $fs.Close() }
        }
        if ($write) {
            $ob = $l1.GetBytes($sbo.ToString()); [void]$sbo.Clear(); $ms.Write($ob, 0, $ob.Length)
            Write-SlimChunk $st $ms $sha $res $dst $partBytes
            [void]$sha.TransformFinalBlock((New-Object byte[] 0), 0, 0)
            $res.Sha = ([BitConverter]::ToString($sha.Hash) -replace '-', '').ToLower()
        }
    } finally {
        if ($st.fo) { $st.fo.Close() }
        if ($sha) { $sha.Dispose() }
    }
    if ($eng) { $kept += $eng.Kept; $dropped += $eng.Dropped; $red += $eng.Redacted; $over += $eng.Over; $Z.matched = $eng.Matched; $Z.resp = $eng.Resp }
    $res.Kept = $kept; $res.Dropped = $dropped; $res.Redacted = $red; $res.Overlong = $over
    return $res
}
function Copy-FzSlim([IO.FileInfo]$f, [string]$dst, [long]$partBytes) {
    # 回傳物件同 Copy-LogFile，另有 Kept、Dropped、SrcBytes、Incomplete
    $src = ConvertFrom-LongPath $f.FullName; $swc = [Diagnostics.Stopwatch]::StartNew()
    $z = Invoke-FzStream @($src) $dst $partBytes $true
    $res = [pscustomobject]@{ Bytes = $z.Bytes; Sha = $z.Sha; Note = ''; Bad = $false; Skip = $false; Parts = $z.Parts; Redacted = $z.Redacted
        Kept = $z.Kept; Dropped = $z.Dropped; SrcBytes = [long]$f.Length; Incomplete = '' }
    $note = @()
    if ($z.Short) { $note += "短讀：$($z.ReadBytes) / $($f.Length) 位元組"; $res.Bad = $true }
    if ($z.Overlong) { $res.Incomplete = "有 $($z.Overlong) 行超過 $([int]($FZ_MAXLINE / 1MB)) MB，未保留（這個檔的 slim 與原檔不完全相同）"; $note += $res.Incomplete }
    $vh = [Security.Cryptography.SHA256]::Create(); $vlen = [long]0
    try {
        foreach ($pp in $res.Parts) {
            $vf = Open-Source $pp
            try { $vb = New-Object byte[] $CHUNK; while (($vk = $vf.Read($vb, 0, $CHUNK)) -gt 0) { [void]$vh.TransformBlock($vb, 0, $vk, $null, 0); $vlen += $vk } } finally { $vf.Close() }
        }
        [void]$vh.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        if ($vlen -ne $res.Bytes -or (([BitConverter]::ToString($vh.Hash) -replace '-', '').ToLower()) -ne $res.Sha) { $note += "副本驗證不符（長度 $vlen／$($res.Bytes)）"; $res.Bad = $true }
    } finally { $vh.Dispose() }
    $pct = $(if ($res.SrcBytes) { [Math]::Round(100.0 * $res.Bytes / $res.SrcBytes, 1) } else { 0 })
    $note += "slim：原始 $($z.ReadBytes) → $($res.Bytes) 位元組（$pct%），保留 $($res.Kept) 行、略過 $($res.Dropped) 行，花 $([int]$swc.Elapsed.TotalSeconds) 秒"
    if ($res.Parts.Count -gt 1) { $note += "分成 $($res.Parts.Count) 段" }
    if ($res.Redacted) { $note += "遮掉帳密 $($res.Redacted) 行" }
    try {
        $after = New-Object IO.FileInfo((ConvertTo-LongPath $src))
        if (-not $after.Exists) { $note += '複製完成後來源已不在（可能被輪替）' }
        elseif ($after.Length -ne $f.Length -or $after.LastWriteTime -ne $f.LastWriteTime) { $note += '複製中檔案有變動（服務正在寫；只收到開檔當下的長度）' }
    } catch { $note += '複製後無法再讀來源資訊' }
    $res.Note = ($note -join '；')
    return $res
}

# ======================= log 摘要（v1.3.0）：在主機上算好事件彙總，上傳小檔，log 副本留在主機 =======================
# 規格＝ftp_report.py 的 parse_logs（FileZilla）／parse_servu_logs（Serv-U）：連線狀態、目前目錄（含 cwd_ok 邊界規則）、
# 指令與回應配對、整份沒有回應時改用指令次數、LIST 去掉選項、路徑正規化、時間（含 UTC 的 Z 加主機時差）、-Days 期間起點，逐條照抄。
# 讀的就是報表會讀的東西：manifest 列出的 log 輸出副本（順序、分段同 iter_log_files）、_run.csv 產品、_run_info 開始時間、
# evidence_quality 的天數與時差。報表（v0.10.0 起）看到摘要就不讀 log，算出的數字相同（自我測試逐格比對）。
# 輸出（在主機資料夾 <IP>\ 底下，只建新檔）：
#   log_events_agg.csv   每列＝同一小時、同動作／帳號／來源 IP／目錄（檔案操作只留上一層目錄，檔名換成 *）的事件：次數、最早、最晚
#   log_parse_stats.csv  解析統計（行數、符合、回應、指令、事件數…）與核對資訊（產品、期間起點、時差、讀了哪些分段）
# 主機不允許即時編譯（C#）、或摘要失敗時：不產生摘要，log 副本照舊上傳（畫面與 _run_log 會講）。
# 上限（v1.3.1，超過就放棄摘要、照舊上傳 log，畫面與 _run_info 會講）：時間同第 6 步 log 統計（$LOG_PARSE_SEC，快速模式 6 小時）、
# 彙總列 $SUM_MAX_ROWS、不重複字串 $SUM_MAX_STRINGS（含 Serv-U 電腦名稱）、連線 $SUM_MAX_SESSIONS（合計約 1 GB 記憶體以內）、
# 單行 $FZ_MAXLINE 位元組（同 slim）。輸出彙總表、統計檔時也檢查時間。第 6 步已超時就不做摘要。
# 編譯在結果資料夾建好後才做（Add-TypeInRun，暫存檔放結果資料夾的 _compile\），見主流程。
$SUM_CS = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
public class FtpCollectSumV130 {
    // ---- Python semantics: \s and str.strip() (same whitespace set), \d (Unicode decimal digits incl. astral planes), \S (counted per code point)
    const string WS = "\\t\\n\\x0B\\f\\r\\x1C-\\x1F \\x85\\xA0\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000";
    static readonly string S = "[" + WS + "]";
    static readonly string NS = "(?:[^" + WS + "\\uD800-\\uDFFF]|[\\uD800-\\uDBFF][\\uDC00-\\uDFFF])";
    const string D = @"(?:[\u0030-\u0039\u0660-\u0669\u06F0-\u06F9\u07C0-\u07C9\u0966-\u096F\u09E6-\u09EF\u0A66-\u0A6F\u0AE6-\u0AEF\u0B66-\u0B6F\u0BE6-\u0BEF\u0C66-\u0C6F\u0CE6-\u0CEF\u0D66-\u0D6F\u0DE6-\u0DEF\u0E50-\u0E59\u0ED0-\u0ED9\u0F20-\u0F29\u1040-\u1049\u1090-\u1099\u17E0-\u17E9\u1810-\u1819\u1946-\u194F\u19D0-\u19D9\u1A80-\u1A89\u1A90-\u1A99\u1B50-\u1B59\u1BB0-\u1BB9\u1C40-\u1C49\u1C50-\u1C59\uA620-\uA629\uA8D0-\uA8D9\uA900-\uA909\uA9D0-\uA9D9\uA9F0-\uA9F9\uAA50-\uAA59\uABF0-\uABF9\uFF10-\uFF19]|\uD801[\uDCA0-\uDCA9]|\uD803[\uDD30-\uDD39]|\uD804[\uDC66-\uDC6F\uDCF0-\uDCF9\uDD36-\uDD3F\uDDD0-\uDDD9\uDEF0-\uDEF9]|\uD805[\uDC50-\uDC59\uDCD0-\uDCD9\uDE50-\uDE59\uDEC0-\uDEC9\uDF30-\uDF39]|\uD806[\uDCE0-\uDCE9\uDD50-\uDD59]|\uD807[\uDC50-\uDC59\uDD50-\uDD59\uDDA0-\uDDA9]|\uD81A[\uDE60-\uDE69\uDEC0-\uDEC9\uDF50-\uDF59]|\uD835[\uDFCE-\uDFFF]|\uD838[\uDD40-\uDD49\uDEF0-\uDEF9]|\uD83A[\uDD50-\uDD59]|\uD83E[\uDFF0-\uDFF9])";
    static readonly int[] ZEROS = { 0x30, 0x660, 0x6F0, 0x7C0, 0x966, 0x9E6, 0xA66, 0xAE6, 0xB66, 0xBE6, 0xC66, 0xCE6, 0xD66, 0xDE6, 0xE50, 0xED0, 0xF20, 0x1040, 0x1090, 0x17E0, 0x1810, 0x1946, 0x19D0, 0x1A80, 0x1A90, 0x1B50, 0x1BB0, 0x1C40, 0x1C50, 0xA620, 0xA8D0, 0xA900, 0xA9D0, 0xA9F0, 0xAA50, 0xABF0, 0xFF10, 0x104A0, 0x10D30, 0x11066, 0x110F0, 0x11136, 0x111D0, 0x112F0, 0x11450, 0x114D0, 0x11650, 0x116C0, 0x11730, 0x118E0, 0x11950, 0x11C50, 0x11D50, 0x11DA0, 0x16A60, 0x16AC0, 0x16B50, 0x1D7CE, 0x1D7D8, 0x1D7E2, 0x1D7EC, 0x1D7F6, 0x1E140, 0x1E2F0, 0x1E950, 0x1FBF0 };
    // Patterns below = ftp_report.py source text (Python syntax), converted to .NET at load: (?P< -> (?<, \d -> D, \s -> S, \S -> NS. Selftest compares them with the report.
    public const string PY_FZ1 = @"^(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?)(?P<z>Z)?\s+(?P<dir>\S{1,3})\s+\[(?P<br>[^\]]*)\]\s?(?P<msg>.*)$";
    public const string PY_BRACKET = @"^(?P<mod>.*?Session)\s+(?P<sid>\d+)\s+(?P<ip>[0-9A-Fa-f:.]+)(?:\s+(?P<user>.+?))?\s*$";
    public const string PY_FZ09 = @"^\((?P<sid>\d+)\)\s*(?P<d>\d{4}/\d{1,2}/\d{1,2}) (?:(?P<ap1>\u4E0A\u5348|\u4E0B\u5348|AM|PM) )?(?P<t>\d{1,2}:\d{2}:\d{2})\s*(?P<ampm>[AP]M|\u4E0A\u5348|\u4E0B\u5348)?\s*-\s*(?P<user>.*?)\s*\((?P<ip>[0-9A-Fa-f:.]+)\)>\s?(?P<msg>.*)$";
    public const string PY_CODE = @"^(\d{3})(?:[ -]|$)";
    public const string PY_LOGIN_FAIL = @"(?i)login incorrect|authentication failed|invalid password|login failed";
    public const string PY_SU = @"^\[(?P<cat>\d+)\]\s+\S+\s+(?P<d>\d{1,2})(?P<mon>[A-Za-z]{3})(?P<y>\d{2})\s+(?P<t>\d{1,2}:\d{2}:\d{2})\s+-\s+\((?P<sid>\d+)\)\s?(?P<msg>.*)$";
    public const string PY_SU_CONN = @"^\u5DF2\u9023\u63A5\u5230\s*(?P<ip>[0-9A-Fa-f:.]+)(?:.*?\u57E0\s*(?P<port>\d+))?";
    public const string PY_SU_LOGIN = @"^\u4F7F\u7528\u8005\s*""(?P<u>[^""]*)""\s*\u5DF2\u767B\u5165";
    public const string PY_SU_LOGOUT = @"^\u4F7F\u7528\u8005\s*""(?P<u>[^""]*)""\s*\u5DF2\u767B\u51FA";
    public const string PY_SU_CLOSE = @"^\u9023\u7DDA\u671F\u9593(?:\u5DF2\u95DC\u9589|\u7A7A\u9592\u903E\u6642)";
    public const string PY_SU_HOST = @"^IP-\u540D\u7A31\s*[:\uFF1A]\s*(?P<n>\S+)\s*\((?P<ip>[^)]+)\)";
    public static readonly string[] PY_SU_MSGS = {
        @"^\u5DF2\u6210\u529F\u6536\u5230\u6A94\u6848\s*""(?P<p>[^""]*)""", @"^\u5DF2\u6210\u529F\u767C\u9001\u6A94\u6848?\s*""(?P<p>[^""]*)""", @"^\u63A5\u6536\u6A94\u6848\s*""(?P<p>[^""]*)""\s*\u6642\u767C\u751F\u932F\u8AA4",
        @"^\u767C\u9001\u6A94\u6848\s*""(?P<p>[^""]*)""\s*\u6642\u767C\u751F\u932F\u8AA4", @"^\u6A94\u5DF2\u79FB\u9664\s*[:\uFF1A]?\s*""(?P<p>[^""]*)""", @"^\u76EE\u9304\u5DF2\u5275\u5EFA\s*[:\uFF1A]?\s*""(?P<p>[^""]*)""" };
    static readonly string[] SU_KIND = { "up", "down", "up_fail", "down_fail", "other", "other" };
    static readonly string[] SU_VERB = { "STOR", "RETR", "STOR", "RETR", "DELE", "MKD" };
    // The regexes datetime.strptime builds internally for these formats (IGNORECASE: T also matches t)
    public const string PY_STRP1 = @"(?P<Y>\d\d\d\d)-(?P<m>1[0-2]|0[1-9]|[1-9])-(?P<d>3[0-1]|[1-2]\d|0[1-9]|[1-9]| [1-9])[Tt](?P<H>2[0-3]|[0-1]\d|\d):(?P<M>[0-5]\d|\d):(?P<S>6[0-1]|[0-5]\d|\d)";
    public const string PY_STRP9 = @"(?P<Y>\d\d\d\d)/(?P<m>1[0-2]|0[1-9]|[1-9])/(?P<d>3[0-1]|[1-2]\d|0[1-9]|[1-9]| [1-9])\s+(?P<H>2[0-3]|[0-1]\d|\d):(?P<M>[0-5]\d|\d):(?P<S>6[0-1]|[0-5]\d|\d)";

    public static string ToNet(string py) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < py.Length; i++) {
            char c = py[i];
            if (c == '\\' && i + 1 < py.Length) {
                char n = py[i + 1];
                if (n == 'd') { b.Append(D); i++; continue; }
                if (n == 's') { b.Append(S); i++; continue; }
                if (n == 'S') { b.Append(NS); i++; continue; }
                b.Append(c).Append(n); i++; continue;
            }
            if (c == '(' && i + 2 < py.Length && py[i + 1] == '?' && py[i + 2] == 'P' && i + 3 < py.Length && py[i + 3] == '<') { b.Append("(?"); i += 2; continue; }
            b.Append(c);
        }
        return b.ToString();
    }
    static Regex R(string py) { return new Regex(ToNet(py), RegexOptions.CultureInvariant | RegexOptions.Compiled); }
    static readonly Regex RX_FZ1 = R(PY_FZ1), RX_BR = R(PY_BRACKET), RX_FZ09 = R(PY_FZ09), RX_CODE = R(PY_CODE);
    static readonly Regex RX_SU = R(PY_SU), SU_CONN = R(PY_SU_CONN), SU_LOGIN = R(PY_SU_LOGIN), SU_LOGOUT = R(PY_SU_LOGOUT), SU_CLOSE = R(PY_SU_CLOSE), SU_HOST = R(PY_SU_HOST);
    static readonly Regex[] SU_MSGS;
    static readonly Regex STRP1 = R("^" + PY_STRP1), STRP9 = R("^" + PY_STRP9);
    // (?i) in Python (Unicode): i also matches U+0130/U+0131, s also matches U+017F; other letters only their two cases. Spelled out, case-sensitive.
    static readonly Regex RX_LOGIN_FAIL;
    static FtpCollectSumV130() {
        SU_MSGS = new Regex[PY_SU_MSGS.Length];
        for (int i = 0; i < PY_SU_MSGS.Length; i++) SU_MSGS[i] = R(PY_SU_MSGS[i]);
        string src = PY_LOGIN_FAIL.Substring(4); StringBuilder b = new StringBuilder();
        foreach (char c in src) {
            if (c == 'i') b.Append("[iI\u0130\u0131]");
            else if (c == 's') b.Append("[sS\u017F]");
            else if (c >= 'a' && c <= 'z') b.Append('[').Append(c).Append(Char.ToUpperInvariant(c)).Append(']');
            else b.Append(c);
        }
        RX_LOGIN_FAIL = new Regex(b.ToString(), RegexOptions.CultureInvariant | RegexOptions.Compiled);
    }

    // Python str comparison (code point order; UTF-16 order differs only for surrogates vs U+E000..U+FFFF)
    public static int PyCmp(string a, string b) {
        int n = Math.Min(a.Length, b.Length);
        for (int i = 0; i < n; i++) {
            int x = a[i], y = b[i];
            if (x == y) continue;
            if (x >= 0xE000) x -= 0x800; else if (x >= 0xD800) x += 0x2000;
            if (y >= 0xE000) y -= 0x800; else if (y >= 0xD800) y += 0x2000;
            return x < y ? -1 : 1;
        }
        return a.Length.CompareTo(b.Length);
    }
    // ---- char helpers (Python semantics)
    public static bool IsW(char c) {
        if (c <= ' ') return c == ' ' || (c >= '\t' && c <= '\r') || (c >= '\x1C' && c <= '\x1F');
        if (c < '\x85') return false;
        return c == '\x85' || c == '\xA0' || c == '\u1680' || (c >= '\u2000' && c <= '\u200A') || c == '\u2028' || c == '\u2029' || c == '\u202F' || c == '\u205F' || c == '\u3000';
    }
    public static string PyStrip(string s) {   // str.strip()
        int a = 0, z = s.Length;
        while (a < z && IsW(s[a])) a++;
        while (z > a && IsW(s[z - 1])) z--;
        return (a == 0 && z == s.Length) ? s : s.Substring(a, z - a);
    }
    public static int DigitVal(int cp) {
        int lo = 0, hi = ZEROS.Length - 1, best = -1;
        while (lo <= hi) { int mid = (lo + hi) >> 1; if (ZEROS[mid] <= cp) { best = mid; lo = mid + 1; } else hi = mid - 1; }
        if (best < 0) return -1; int v = cp - ZEROS[best]; return (v >= 0 && v <= 9) ? v : -1;
    }
    public static long PyInt(string s) {   // int(): only used on regex-captured \d runs
        long v = 0;
        for (int i = 0; i < s.Length; i++) {
            int cp = s[i];
            if (Char.IsHighSurrogate(s[i]) && i + 1 < s.Length) { cp = Char.ConvertToUtf32(s[i], s[i + 1]); i++; }
            int d = DigitVal(cp); if (d < 0) throw new FormatException("not a digit");
            v = v * 10 + d; if (v > 100000000) v = 100000000;   // only used for date/time fields; avoid overflow
        }
        return v;
    }
    static string UpperForVerb(string v) {   // str.upper(); returns null when the result is not ASCII (cannot be a command verb)
        StringBuilder b = null;
        for (int i = 0; i < v.Length; i++) {
            char c = v[i]; string r;
            if (c < 0x80) { r = null; if (c >= 'a' && c <= 'z') r = ((char)(c - 32)).ToString(); }
            else {
                switch (c) {
                    case '\u00DF': r = "SS"; break; case '\u0131': r = "I"; break; case '\u017F': r = "S"; break;
                    case '\uFB00': r = "FF"; break; case '\uFB01': r = "FI"; break; case '\uFB02': r = "FL"; break;
                    case '\uFB03': r = "FFI"; break; case '\uFB04': r = "FFL"; break; case '\uFB05': r = "ST"; break; case '\uFB06': r = "ST"; break;
                    default: return null;
                }
            }
            if (r != null && b == null) { b = new StringBuilder(v.Length + 4); b.Append(v, 0, i); }
            if (b != null) { if (r != null) b.Append(r); else b.Append(c); }
        }
        return b == null ? v : b.ToString();
    }
    static bool IsNotLoggedIn(string u) {   // buser.lower() in (...): no non-ASCII char lowercases into these ASCII strings
        if (u.Length != 15 && u.Length != 13) return false;
        foreach (char c in u) if (c >= 0x80) return false;
        string lo = u.ToLowerInvariant();
        return lo == "(not logged in)" || lo == "not logged in";
    }
    // bytes.decode('utf-8', errors='replace') as CPython does: one U+FFFD per maximal invalid subpart
    public static string PyDecode(byte[] buf, int off, int n, StringBuilder sb) {
        sb.Length = 0; int i = off, end = off + n;
        while (i < end) {
            byte c0 = buf[i];
            if (c0 < 0x80) { sb.Append((char)c0); i++; continue; }
            int need, cp, lo = 0x80, hi = 0xBF;
            if (c0 >= 0xC2 && c0 <= 0xDF) { need = 1; cp = c0 & 0x1F; }
            else if (c0 >= 0xE0 && c0 <= 0xEF) { need = 2; cp = c0 & 0x0F; if (c0 == 0xE0) lo = 0xA0; else if (c0 == 0xED) hi = 0x9F; }
            else if (c0 >= 0xF0 && c0 <= 0xF4) { need = 3; cp = c0 & 0x07; if (c0 == 0xF0) lo = 0x90; else if (c0 == 0xF4) hi = 0x8F; }
            else { sb.Append('\uFFFD'); i++; continue; }
            int j = i + 1, k = 0;
            for (; k < need; k++) {
                if (j >= end) break;
                byte c = buf[j]; if (c < lo || c > hi) break;
                cp = (cp << 6) | (c & 0x3F); j++; lo = 0x80; hi = 0xBF;
            }
            if (k < need) { sb.Append('\uFFFD'); i = j; continue; }
            if (cp >= 0x10000) sb.Append(Char.ConvertFromUtf32(cp)); else sb.Append((char)cp);
            i = j;
        }
        return sb.ToString();
    }
    public static string DecodeForTest(byte[] b) { return PyDecode(b, 0, b.Length, new StringBuilder()); }

    // strptime: match the internal regex (must consume the whole string), then validate the date (invalid = ValueError, line skipped)
    static bool Strp(Regex rx, string s, out DateTime t) {
        t = DateTime.MinValue;
        Match m = rx.Match(s);
        if (!m.Success || m.Length != s.Length) return false;
        long Y = PyInt(m.Groups["Y"].Value), Mo = PyInt(m.Groups["m"].Value), Dd = PyInt(m.Groups["d"].Value);
        long H = PyInt(m.Groups["H"].Value), Mi = PyInt(m.Groups["M"].Value), Se = PyInt(m.Groups["S"].Value);
        return MakeDt(Y, Mo, Dd, H, Mi, Se, out t);
    }
    static bool MakeDt(long Y, long Mo, long Dd, long H, long Mi, long Se, out DateTime t) {
        t = DateTime.MinValue;
        if (Y < 1 || Y > 9999 || Mo < 1 || Mo > 12 || Dd < 1 || Dd > DateTime.DaysInMonth((int)Y, (int)Mo) || H > 23 || Mi > 59 || Se > 59) return false;
        t = new DateTime((int)Y, (int)Mo, (int)Dd, (int)H, (int)Mi, (int)Se); return true;
    }
    static readonly Dictionary<string, int> MON = new Dictionary<string, int>(StringComparer.Ordinal) {
        { "jan", 1 }, { "feb", 2 }, { "mar", 3 }, { "apr", 4 }, { "may", 5 }, { "jun", 6 }, { "jul", 7 }, { "aug", 8 }, { "sep", 9 }, { "oct", 10 }, { "nov", 11 }, { "dec", 12 } };
    static readonly Dictionary<string, string> SU_PROTO = new Dictionary<string, string>(StringComparer.Ordinal) { { "21", "FTP" }, { "22", "SFTP" }, { "989", "FTPS" }, { "990", "FTPS" } };
    static readonly HashSet<string> UPLOAD = new HashSet<string>(StringComparer.Ordinal) { "STOR", "APPE", "STOU" };
    static readonly HashSet<string> DOWNLOAD = new HashSet<string>(StringComparer.Ordinal) { "RETR" };
    static readonly HashSet<string> OTHER = new HashSet<string>(StringComparer.Ordinal) { "DELE", "RNFR", "RNTO", "MKD", "XMKD", "RMD", "XRMD", "LIST", "NLST", "MLSD" };
    static readonly HashSet<string> LIST_OPS = new HashSet<string>(StringComparer.Ordinal) { "LIST", "NLST", "MLSD" };
    static readonly HashSet<string> FILE_OPS = new HashSet<string>(StringComparer.Ordinal) { "STOR", "APPE", "STOU", "RETR", "DELE", "RNFR", "RNTO" };
    static readonly HashSet<string> CWDS = new HashSet<string>(StringComparer.Ordinal) { "CWD", "XCWD", "CDUP", "XCUP" };

    // ---- virtual paths (same as vnorm / vparent / strip_opts)
    public static string VNorm(string path, string cwd) {
        path = PyStrip(path ?? "").Trim('"');
        if (path.Length == 0) path = cwd;
        if (!path.StartsWith("/", StringComparison.Ordinal)) path = cwd.TrimEnd('/') + "/" + path;
        List<string> parts = new List<string>();
        foreach (string seg in path.Split('/')) {
            if (seg.Length == 0 || seg == ".") continue;
            if (seg == "..") { if (parts.Count > 0) parts.RemoveAt(parts.Count - 1); continue; }
            parts.Add(seg);
        }
        return "/" + String.Join("/", parts.ToArray());
    }
    public static string VParent(string p) {
        if (p == "/") return "/";
        int k = p.LastIndexOf('/'); string r = k < 0 ? p : p.Substring(0, k);
        return r.Length == 0 ? "/" : r;
    }
    static string StripOpts(string arg) {
        List<string> t = new List<string>();
        foreach (string x in arg.Split(' ')) { if (x.Length > 0 && !x.StartsWith("-", StringComparison.Ordinal)) t.Add(x); }
        return String.Join(" ", t.ToArray());
    }

    // ---- state
    class Sess { public string user = "", attempt = "", cwd = "/"; public bool logged, cwdOk; public string pVerb; public string pArg; }
    class SuSess { public string ip = "", proto = "", user = ""; }
    // aggregate rows keep pooled string ids (users, IPs, dirs repeat a lot): ~100 bytes per row instead of a long string key
    struct K : IEquatable<K> {
        public int a, b, c, d, e, f; public long h;
        public bool Equals(K o) { return a == o.a && b == o.b && c == o.c && d == o.d && e == o.e && f == o.f && h == o.h; }
        public override bool Equals(object o) { return o is K && Equals((K)o); }
        public override int GetHashCode() { unchecked { int x = a; x = x * 31 + b; x = x * 31 + c; x = x * 31 + d; x = x * 31 + e; x = x * 31 + f; return x * 31 + h.GetHashCode(); } }
    }
    class Agg { public K k; public long n; public DateTime first, last; }
    readonly Dictionary<string, int> pool = new Dictionary<string, int>(StringComparer.Ordinal);
    readonly List<string> strs = new List<string>();
    int Id(string x) {   // null -> -1
        if (x == null) return -1;
        int i; if (pool.TryGetValue(x, out i)) return i;
        if (strs.Count + ipNames.Count >= maxPool) throw new InvalidOperationException("LIMIT:pool:" + maxPool);   // Serv-U IP names count too
        i = strs.Count; strs.Add(x); pool[x] = i; return i;
    }
    // ---- limits (v1.3.1): exceeding any of them abandons the summary (caller uploads the logs as before)
    readonly int maxRows, maxPool, maxSess, limitSec, maxLine; int rowTotal; readonly System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
    void CheckTime() { if (sw.Elapsed.TotalSeconds > limitSec) throw new InvalidOperationException("LIMIT:time:" + limitSec); }
    // ---- FileZilla sessions, compact: (sid, ip) -> index; per-session state in parallel lists of pooled string ids.
    //      Python never forgets a session, so a busy host has millions of them; this keeps ~50 bytes each.
    readonly Dictionary<long, int> sfast = new Dictionary<long, int>();
    readonly Dictionary<string, int> sslow = new Dictionary<string, int>(StringComparer.Ordinal);
    readonly List<int> sUser = new List<int>(), sAtt = new List<int>(), sCwd = new List<int>(), sPV = new List<int>();
    readonly List<byte> sFlg = new List<byte>();   // bit0 logged, bit1 cwd_ok
    readonly Dictionary<int, string> sArg = new Dictionary<int, string>();   // argument of the pending command (only while pending)
    int SessCount { get { return sUser.Count + su.Count; } }
    int SessIdx(string sid, string ip) {
        int i, ipId = Id(ip); long fk = -1;
        if (sid.Length >= 1 && sid.Length <= 11 && ipId < (1 << 20)) {
            long v = 0; bool ok = true;
            foreach (char c in sid) { if (c < '0' || c > '9') { ok = false; break; } v = v * 10 + (c - '0'); }
            if (ok) fk = ((long)sid.Length << 58) + (v << 20) + ipId;
        }
        if (fk >= 0) { if (sfast.TryGetValue(fk, out i)) return i; }
        else if (sslow.TryGetValue(sid + "|" + ip, out i)) return i;
        if (SessCount >= maxSess) throw new InvalidOperationException("LIMIT:sessions:" + maxSess);
        i = sUser.Count; sUser.Add(Id("")); sAtt.Add(Id("")); sCwd.Add(Id("/")); sPV.Add(-1); sFlg.Add(0);
        if (fk >= 0) sfast[fk] = i; else sslow[sid + "|" + ip] = i;
        return i;
    }
    readonly Sess cur = new Sess(); string lu, la, lc, lv;
    Sess Load(int i) {
        Sess s = cur;
        s.user = lu = strs[sUser[i]]; s.attempt = la = strs[sAtt[i]]; s.cwd = lc = strs[sCwd[i]];
        s.pVerb = lv = sPV[i] < 0 ? null : strs[sPV[i]];
        byte f = sFlg[i]; s.logged = (f & 1) != 0; s.cwdOk = (f & 2) != 0;
        string a; s.pArg = sArg.TryGetValue(i, out a) ? a : null;
        return s;
    }
    void Save(int i, Sess s) {
        if (!Object.ReferenceEquals(s.user, lu)) sUser[i] = Id(s.user);
        if (!Object.ReferenceEquals(s.attempt, la)) sAtt[i] = Id(s.attempt);
        if (!Object.ReferenceEquals(s.cwd, lc)) sCwd[i] = Id(s.cwd);
        if (!Object.ReferenceEquals(s.pVerb, lv)) sPV[i] = Id(s.pVerb);
        sFlg[i] = (byte)((s.logged ? 1 : 0) | (s.cwdOk ? 2 : 0));
        if (s.pVerb != null) sArg[i] = s.pArg; else sArg.Remove(i);
    }
    readonly bool servu, hasOff; readonly DateTime win; readonly TimeSpan off;
    readonly HashSet<string> homeTails; readonly bool suReduce;
    readonly Dictionary<string, SuSess> su = new Dictionary<string, SuSess>(StringComparer.Ordinal);
    readonly Dictionary<K, Agg> map = new Dictionary<K, Agg>();
    readonly List<Agg> rows = new List<Agg>();
    Dictionary<K, Agg> fmap = new Dictionary<K, Agg>();   // fallback (whole log has no responses: count commands)
    List<Agg> frows = new List<Agg>();
    public long Lines, Matched, Responses, Commands, Z, Events;
    readonly List<string> fmtOrder = new List<string>(); readonly Dictionary<string, long> fmts = new Dictionary<string, long>(StringComparer.Ordinal);
    readonly List<string> ipOrder = new List<string>(); readonly Dictionary<string, string> ipNames = new Dictionary<string, string>(StringComparer.Ordinal);
    readonly List<string> partRel = new List<string>(); readonly List<long> partLen = new List<long>();
    readonly StringBuilder dsb = new StringBuilder();

    // homePaths: every physical_path in dirs.csv; last segment (lowercase ASCII projection). A file path whose name matches one of them is kept verbatim (see ReduceSu).
    public FtpCollectSumV130(bool servu, DateTime winStart, bool hasOffset, int offsetMinutes, string[] homePaths, int maxRows, int maxPool, int maxSess, int limitSec, int maxLine) {
        this.maxLine = maxLine; this.maxRows = maxRows; this.maxPool = maxPool; this.maxSess = maxSess; this.limitSec = limitSec;
        this.servu = servu; win = winStart; hasOff = hasOffset; off = TimeSpan.FromMinutes(offsetMinutes);
        homeTails = new HashSet<string>(StringComparer.Ordinal);
        if (homePaths != null) foreach (string h in homePaths) { string x = (h ?? "").TrimEnd('\\'); int k = x.LastIndexOf('\\'); homeTails.Add(Proj(k < 0 ? x : x.Substring(k + 1))); }
        suReduce = !homeTails.Contains("*");
    }
    static string Proj(string s) {   // Python lower(), keep ASCII only (only U+0130 -> i and U+212A -> k produce ASCII from non-ASCII)
        StringBuilder b = new StringBuilder(s.Length);
        foreach (char c in s) {
            if (c < 0x80) b.Append((c >= 'A' && c <= 'Z') ? (char)(c + 32) : c);
            else if (c == '\u0130') b.Append('i');
            else if (c == '\u212A') b.Append('k');
        }
        return b.ToString();
    }
    void Fmt(string f) { long n; if (fmts.TryGetValue(f, out n)) fmts[f] = n + 1; else { fmts[f] = 1; fmtOrder.Add(f); } }

    // aggregation: one row per (kind, verb, user, ip, path, proto, hour) with count, first, last. Row order = first appearance.
    void Put(Dictionary<K, Agg> m, List<Agg> l, string kind, string verb, string user, string ip, string path, string proto, DateTime ts) {
        K k = new K { a = Id(kind), b = Id(verb), c = Id(user), d = Id(ip), e = Id(path), f = Id(proto), h = ts.Ticks / TimeSpan.TicksPerHour };
        Agg a;
        if (m.TryGetValue(k, out a)) { a.n++; if (ts < a.first) a.first = ts; if (ts > a.last) a.last = ts; return; }
        if (rowTotal >= maxRows) throw new InvalidOperationException("LIMIT:rows:" + maxRows);
        rowTotal++;
        a = new Agg { k = k, n = 1, first = ts, last = ts };
        m[k] = a; l.Add(a);
    }
    // file ops only: ftp_report.attribute uses vparent() for FILE_OPS, so the file name is replaced by * and same-dir transfers collapse into one row
    static string ReduceFz(string verb, string vp) {
        if (vp == null || vp == "/" || !FILE_OPS.Contains(verb)) return vp;
        string p = VParent(vp); return (p == "/" ? "" : p) + "/*";
    }
    string ReduceSu(string verb, string phys) {
        if (!suReduce || phys.Length == 0 || !FILE_OPS.Contains(verb)) return phys;
        int k = phys.LastIndexOf('\\'); if (k < 0) return phys;
        if (homeTails.Contains(Proj(phys.Substring(k + 1)))) return phys;   // name may equal some home dir: keep verbatim (build_rows compares the whole string)
        return phys.Substring(0, k + 1) + "*";
    }
    void EmitFz(string kind, string verb, string user, string ip, DateTime ts, string vp) {
        if (ts < win) return;
        Put(map, rows, kind, verb, user, ip, ReduceFz(verb, vp), null, ts);
        Events++;
    }

    public void AddPart(Stream fs, string rel) {
        CheckTime();
        long len = 0; byte[] buf = new byte[1 << 20]; byte[] line = new byte[1 << 16]; int ll = 0; int k;
        while ((k = fs.Read(buf, 0, buf.Length)) > 0) {
            len += k; int p = 0;
            while (p < k) {
                int nl = Array.IndexOf(buf, (byte)10, p, k - p);
                int e = nl < 0 ? k : nl + 1;
                int add = e - p;
                if (ll + add > maxLine) throw new InvalidOperationException("LIMIT:line:" + maxLine);   // one line longer than maxLine bytes
                if (ll + add > line.Length) { int nn = line.Length * 2; while (nn < ll + add) nn *= 2; Array.Resize(ref line, nn); }
                Buffer.BlockCopy(buf, p, line, ll, add); ll += add; p = e;
                if (nl >= 0) { Line(line, ll); ll = 0; }
            }
        }
        if (ll > 0) Line(line, ll);
        partRel.Add(rel); partLen.Add(len);
    }
    void Line(byte[] b, int n) {
        Lines++;
        if ((Lines & 4095) == 0) CheckTime();
        string s = PyDecode(b, 0, n, dsb);
        if (servu) {
            int a = 0; while (a < s.Length && s[a] == '\uFEFF') a++;
            int z = s.Length; while (z > a && (s[z - 1] == '\r' || s[z - 1] == '\n')) z--;
            LineSu(s.Substring(a, z - a));
        } else {
            int z = s.Length; while (z > 0 && (s[z - 1] == '\r' || s[z - 1] == '\n')) z--;
            LineFz(z == s.Length ? s : s.Substring(0, z));
        }
    }
    void LineFz(string line) {
        string sid, ip, buser, msg; DateTime ts; bool isCmd, isResp; string fmt;
        Match m = RX_FZ1.Match(line);
        if (m.Success) {
            Match bm = RX_BR.Match(m.Groups["br"].Value);
            if (!bm.Success) return;
            fmt = "fz1"; sid = bm.Groups["sid"].Value; ip = bm.Groups["ip"].Value; buser = PyStrip(bm.Groups["user"].Success ? bm.Groups["user"].Value : "");
            string tsv = m.Groups["ts"].Value.Replace(' ', 'T');
            int cut = 0, cps = 0;   // s[:19] counted in code points
            while (cut < tsv.Length && cps < 19) { if (Char.IsHighSurrogate(tsv[cut]) && cut + 1 < tsv.Length && Char.IsLowSurrogate(tsv[cut + 1])) cut += 2; else cut++; cps++; }
            if (!Strp(STRP1, tsv.Substring(0, cut), out ts)) return;
            bool hz = m.Groups["z"].Success && m.Groups["z"].Length > 0;
            if (hz && hasOff) ts = ts + off;   // overflow throws = no summary written (Python fails the whole host too)
            if (hz) Z++;
            string d = m.Groups["dir"].Value; msg = m.Groups["msg"].Value;
            isCmd = d == ">>"; isResp = d == "<<";
            if (msg.StartsWith("Command: ", StringComparison.Ordinal)) { msg = msg.Substring(9); isCmd = true; isResp = false; }
            else if (msg.StartsWith("Response: ", StringComparison.Ordinal)) { msg = msg.Substring(10); isCmd = false; isResp = true; }
        } else {
            m = RX_FZ09.Match(line);
            if (!m.Success) return;
            fmt = "fz09"; sid = m.Groups["sid"].Value; ip = m.Groups["ip"].Value;
            buser = PyStrip(m.Groups["user"].Value);
            if (IsNotLoggedIn(buser)) buser = "";
            if (!Strp(STRP9, m.Groups["d"].Value + " " + m.Groups["t"].Value, out ts)) return;
            string ap = m.Groups["ap1"].Success && m.Groups["ap1"].Length > 0 ? m.Groups["ap1"].Value : (m.Groups["ampm"].Success ? m.Groups["ampm"].Value : "");
            if ((ap == "PM" || ap == "\u4E0B\u5348") && ts.Hour < 12) ts = ts.AddHours(12);
            else if ((ap == "AM" || ap == "\u4E0A\u5348") && ts.Hour == 12) ts = ts.AddHours(-12);
            msg = m.Groups["msg"].Value;
            isResp = RX_CODE.IsMatch(msg); isCmd = !isResp;
        }
        Matched++; Fmt(fmt);
        int si = SessIdx(sid, ip); Sess s = Load(si);
        try { FzBody(s, buser, isCmd, isResp, msg, ip, ts); } finally { Save(si, s); }
    }
    void FzBody(Sess s, string buser, bool isCmd, bool isResp, string msg, string ip, DateTime ts) {
        if (buser.Length > 0) s.user = buser;
        if (isCmd) {
            Commands++;
            string t = PyStrip(msg); int sp = t.IndexOf(' ');
            string verb = UpperForVerb(sp < 0 ? t : t.Substring(0, sp)); string arg = sp < 0 ? "" : PyStrip(t.Substring(sp + 1));
            if (verb == "USER") { s.attempt = arg; s.user = buser; s.logged = false; s.cwd = "/"; s.cwdOk = true; }
            if (verb != null && (verb == "USER" || verb == "PASS" || CWDS.Contains(verb) || UPLOAD.Contains(verb) || DOWNLOAD.Contains(verb) || OTHER.Contains(verb))) {
                s.pVerb = verb; s.pArg = arg;
                if (frows != null && (UPLOAD.Contains(verb) || DOWNLOAD.Contains(verb) || OTHER.Contains(verb)) && !(ts < win)) {
                    string user = s.user.Length > 0 ? s.user : s.attempt; string cwd = s.cwdOk ? s.cwd : null;
                    string a2 = PyStrip(LIST_OPS.Contains(verb) ? StripOpts(arg) : arg).Trim('"');
                    string vp = (cwd == null && !a2.StartsWith("/", StringComparison.Ordinal)) ? null : VNorm(a2, cwd ?? "/");
                    Put(fmap, frows, UPLOAD.Contains(verb) ? "up" : (DOWNLOAD.Contains(verb) ? "down" : "other"), verb, user, ip, ReduceFz(verb, vp), null, ts);
                }
            } else { s.pVerb = null; }
        } else if (isResp) {
            Responses++; frows = null; fmap = null;
            Match cm = RX_CODE.Match(PyStrip(msg));
            if (!cm.Success || s.pVerb == null) {
                if (s.attempt.Length > 0 && RX_LOGIN_FAIL.IsMatch(msg)) EmitFz("login_fail", "PASS", s.attempt, ip, ts, "");
                return;
            }
            long code = PyInt(cm.Groups[1].Value);
            string verb = s.pVerb, arg = s.pArg;
            if (code < 200) return;
            s.pVerb = null;
            bool ok = code >= 200 && code < 400;
            string user = s.user.Length > 0 ? s.user : s.attempt;
            if (verb == "USER" || verb == "PASS") {
                if (code == 230) { s.logged = true; if (s.user.Length == 0) s.user = s.attempt; EmitFz("login_ok", verb, s.user, ip, ts, ""); }
                else if (code >= 400) EmitFz("login_fail", verb, s.attempt.Length > 0 ? s.attempt : user, ip, ts, "");
            } else if (CWDS.Contains(verb)) {
                if (ok) {
                    if (verb == "CDUP" || verb == "XCUP") s.cwd = VParent(s.cwd);
                    else { string nv = FzVpath(arg, s); if (nv != null) { s.cwd = nv; s.cwdOk = true; } }
                }
            } else if (ok) {
                string vp = FzVpath(LIST_OPS.Contains(verb) ? StripOpts(arg) : arg, s);
                EmitFz(UPLOAD.Contains(verb) ? "up" : (DOWNLOAD.Contains(verb) ? "down" : "other"), verb, user, ip, ts, vp);
            }
        }
    }
    static string FzVpath(string arg, Sess s) {
        string a = PyStrip(arg ?? "").Trim('"');
        if (!s.cwdOk && !a.StartsWith("/", StringComparison.Ordinal)) return null;
        return VNorm(a, s.cwd);
    }
    void LineSu(string line) {
        Match m = RX_SU.Match(line);
        if (!m.Success) return;
        int mon; if (!MON.TryGetValue(m.Groups["mon"].Value.ToLowerInvariant(), out mon)) return;
        string[] tp = m.Groups["t"].Value.Split(':');
        DateTime ts;
        if (!MakeDt(2000 + PyInt(m.Groups["y"].Value), mon, PyInt(m.Groups["d"].Value), PyInt(tp[0]), PyInt(tp[1]), PyInt(tp[2]), out ts)) return;
        Matched++; Fmt("servu");
        string sid = m.Groups["sid"].Value, msg = PyStrip(m.Groups["msg"].Value);
        Match mc = SU_CONN.Match(msg);
        if (mc.Success) {
            string port = mc.Groups["port"].Success ? mc.Groups["port"].Value : ""; string pr;
            if (!SU_PROTO.TryGetValue(port, out pr)) pr = port.Length > 0 ? "port " + port : "";
            if (!su.ContainsKey(sid) && SessCount >= maxSess) throw new InvalidOperationException("LIMIT:sessions:" + maxSess);
            su[sid] = new SuSess { ip = mc.Groups["ip"].Value, proto = pr, user = "" };
            return;
        }
        if (SU_CLOSE.IsMatch(msg)) { su.Remove(sid); return; }
        Match mh = SU_HOST.Match(msg);
        if (mh.Success) {
            string ipk = PyStrip(mh.Groups["ip"].Value);
            if (!ipNames.ContainsKey(ipk)) { if (strs.Count + ipNames.Count >= maxPool) throw new InvalidOperationException("LIMIT:pool:" + maxPool); ipOrder.Add(ipk); }
            ipNames[ipk] = mh.Groups["n"].Value.Split('.')[0];
            return;
        }
        SuSess s; if (!su.TryGetValue(sid, out s)) { if (SessCount >= maxSess) throw new InvalidOperationException("LIMIT:sessions:" + maxSess); s = new SuSess(); su[sid] = s; }
        if (SU_LOGOUT.IsMatch(msg)) { s.user = ""; return; }
        Match ml = SU_LOGIN.Match(msg);
        if (ml.Success) {
            s.user = ml.Groups["u"].Value;
            if (!(ts < win)) { Events++; Put(map, rows, "login_ok", "LOGIN", s.user, s.ip, "", s.proto, ts); }
            return;
        }
        for (int i = 0; i < SU_MSGS.Length; i++) {
            Match mm = SU_MSGS[i].Match(msg);
            if (!mm.Success) continue;
            if (!(ts < win)) {
                Events++;
                string phys = mm.Groups["p"].Value.Replace('/', '\\').TrimEnd('\\');
                Put(map, rows, SU_KIND[i], SU_VERB[i], s.user, s.ip, ReduceSu(SU_VERB[i], phys), s.proto, ts);
            }
            break;
        }
    }

    // ---- output (UTF-8 with BOM, every cell quoted; control chars and % written as %XX, decoded by the report)
    static string Esc(string s) {
        if (s == null) return "";
        StringBuilder b = null;
        for (int i = 0; i < s.Length; i++) {
            char c = s[i]; bool bad = c < 0x20 || c == 0x7F || c == '%';
            if (bad && b == null) { b = new StringBuilder(s.Length + 8); b.Append(s, 0, i); }
            if (b != null) { if (bad) b.Append('%').Append(((int)c).ToString("X2", CultureInfo.InvariantCulture)); else b.Append(c); }
        }
        return (b == null ? s : b.ToString()).Replace("\"", "\"\"");
    }
    static void Row(StringBuilder b, params string[] cells) {
        for (int i = 0; i < cells.Length; i++) { if (i > 0) b.Append(','); b.Append('"').Append(Esc(cells[i])).Append('"'); }
        b.Append("\r\n");
    }
    string Str(int id) { return id < 0 ? "" : strs[id]; }
    static string T(DateTime t) { return t.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture); }
    public bool NoResponses { get { return !servu && Matched > 0 && Responses == 0; } }
    List<Agg> Final() { return NoResponses ? (frows ?? new List<Agg>()) : rows; }
    public int RowCount { get { return Final().Count; } }
    public long EventTotal { get { long n = 0; foreach (Agg a in Final()) n += a.n; return n; } }
    // written in chunks to a stream the caller opened (file created with just the BOM by New-OutFile): no full copy in memory.
    // SHA-256 of the whole file (BOM included) is computed while writing (AggSha256); the time cap is checked here too.
    public string AggSha256;
    public void WriteAgg(Stream o) {
        System.Security.Cryptography.SHA256 h = System.Security.Cryptography.SHA256.Create();
        byte[] bom = { 0xEF, 0xBB, 0xBF }; h.TransformBlock(bom, 0, 3, null, 0);
        UTF8Encoding u8 = new UTF8Encoding(false);
        StringBuilder b = new StringBuilder(1 << 16); CultureInfo ci = CultureInfo.InvariantCulture; int k = 0;
        Row(b, "n", "first_ts", "last_ts", "kind", "verb", "user", "ip", "path", "path_is_none", "proto");
        foreach (Agg a in Final()) {
            Row(b, a.n.ToString(ci), T(a.first), T(a.last), Str(a.k.a), Str(a.k.b), Str(a.k.c), Str(a.k.d), Str(a.k.e), a.k.e < 0 ? "1" : "", Str(a.k.f));
            if (b.Length > 60000) { Flush(o, h, u8, b); if ((++k & 63) == 0) CheckTime(); }
        }
        Flush(o, h, u8, b); o.Flush();
        h.TransformFinalBlock(new byte[0], 0, 0);
        AggSha256 = BitConverter.ToString(h.Hash).Replace("-", "").ToLowerInvariant();
        CheckTime();
    }
    static void Flush(Stream o, System.Security.Cryptography.SHA256 h, UTF8Encoding u8, StringBuilder b) {
        byte[] x = u8.GetBytes(b.ToString()); b.Length = 0;
        o.Write(x, 0, x.Length); h.TransformBlock(x, 0, x.Length, null, 0);
    }
    static byte[] Bom(StringBuilder b) {
        byte[] body = new UTF8Encoding(false).GetBytes(b.ToString()); byte[] o = new byte[body.Length + 3];
        o[0] = 0xEF; o[1] = 0xBB; o[2] = 0xBF; Buffer.BlockCopy(body, 0, o, 3, body.Length); return o;
    }
    public byte[] StatsCsv(string collector, DateTime start, int days, string aggSha256) {
        CheckTime();
        StringBuilder b = new StringBuilder(); CultureInfo ci = CultureInfo.InvariantCulture;
        Row(b, "key", "name", "value");
        Row(b, "summary_format", "", "1");
        Row(b, "collector", "", collector);
        Row(b, "parser", "", servu ? "servu" : "fz");
        Row(b, "start", "", T(start));
        Row(b, "days_requested", "", days.ToString(ci));
        Row(b, "window_start", "", T(win));
        Row(b, "offset_minutes", "", hasOff ? ((long)off.TotalMinutes).ToString(ci) : "none");
        Row(b, "complete", "", "yes");
        Row(b, "lines", "", Lines.ToString(ci));
        Row(b, "matched", "", Matched.ToString(ci));
        Row(b, "responses", "", Responses.ToString(ci));
        Row(b, "commands", "", Commands.ToString(ci));
        Row(b, "z", "", Z.ToString(ci));
        Row(b, "events", "", Events.ToString(ci));
        Row(b, "no_responses", "", NoResponses ? "yes" : "no");
        Row(b, "agg_rows", "", RowCount.ToString(ci));
        Row(b, "agg_events", "", EventTotal.ToString(ci));
        Row(b, "agg_sha256", "", aggSha256);   // SHA-256 of the whole log_events_agg.csv file (incl. BOM); the report checks it
        foreach (string f in fmtOrder) Row(b, "format", f, fmts[f].ToString(ci));
        { int q = 0; foreach (string ip in ipOrder) { Row(b, "ip_name", ip, ipNames[ip]); if ((++q & 4095) == 0) CheckTime(); } }
        for (int i = 0; i < partRel.Count; i++) Row(b, "part", partRel[i], partLen[i].ToString(ci));
        byte[] outB = Bom(b);
        CheckTime();   // v1.3.3: stats serialisation past the cap must not count as success
        return outB;
    }
}
'@
$script:SumReady = $false; $script:SumErr = '尚未編譯'
$SUM_MAX_ROWS = 3000000; $SUM_MAX_STRINGS = 2000000; $SUM_MAX_SESSIONS = 8000000
function Read-CsvRows([string]$path) {
    if (-not [IO.File]::Exists((ConvertTo-LongPath $path))) { return @() }
    return @(Import-Csv -LiteralPath $path -Encoding UTF8)
}
function Get-CsvCell($row, [string]$name) {   # 同 Python DictReader 的 r.get(name, '')
    if ($null -eq $row) { return '' }
    $p = $row.PSObject.Properties[$name]
    if ($null -eq $p -or $null -eq $p.Value) { return '' }
    return [string]$p.Value
}
function Get-PyOffsetMin([string]$s) {   # 同 ftp_report.parse_offset：'08:00:00'／'-05:00:00' → 分鐘；不符回 $null
    $m = [regex]::Match($s, '^\s*(-)?(\d{1,2}):(\d{2})(?::(\d{2}))?')
    if (-not $m.Success) { return $null }
    $v = [int]$m.Groups[2].Value * 60 + [int]$m.Groups[3].Value
    if ($m.Groups[1].Success) { $v = -$v }
    return $v
}
function Get-LogSummaryPlan([string]$runDir, [string]$hdir) {
    # 照 ftp_report.load_host／iter_log_files 準備同樣的輸入；回傳 Skip＝報表不會解析 log（或缺資料），不做摘要
    $r0 = @(Read-CsvRows (Join-Path $runDir '_run.csv')) | Select-Object -First 1
    $type = (Get-CsvCell $r0 'Type').ToLowerInvariant()
    $servu = $type.Contains('servu'); $isFz = $type.Contains('filezilla')
    if (-not $servu -and -not $isFz) { return @{ Skip = "產品類型「$(Get-CsvCell $r0 'Type')」報表不解析 log" } }
    $infoP = Join-Path $runDir '_run_info.txt'
    $infoT = $(if ([IO.File]::Exists((ConvertTo-LongPath $infoP))) { [IO.File]::ReadAllText((ConvertTo-LongPath $infoP), [Text.Encoding]::UTF8) } else { '' })
    $mi = [regex]::Match($infoT, '開始：(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})')
    $st0 = [datetime]::MinValue
    if (-not $mi.Success -or -not [datetime]::TryParseExact($mi.Groups[1].Value, 'yyyy/MM/dd HH:mm:ss', [Globalization.CultureInfo]::InvariantCulture, 'None', [ref]$st0)) { return @{ Skip = '_run_info.txt 沒有開始時間' } }
    $eq = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
    foreach ($r in (Read-CsvRows (Join-Path $hdir 'evidence_quality.csv'))) { $eq[(Get-CsvCell $r 'key')] = (Get-CsvCell $r 'value') }
    $days = 90; $dv = $(if ($eq.ContainsKey('days_requested')) { $eq['days_requested'] } else { '' })
    if ($dv -match '^\s*\+?[0-9]+\s*$') { $days = [int]$dv.Trim() }
    $off = Get-PyOffsetMin $(if ($eq.ContainsKey('host_utc_offset_now')) { $eq['host_utc_offset_now'] } else { '' })
    if ($null -eq $off) {
        foreach ($r in (Read-CsvRows (Join-Path $hdir 'host_info.csv'))) {
            if ((Get-CsvCell $r 'item') -eq 'timezone' -and (Get-CsvCell $r 'name') -eq 'current_utc_offset') { $off = Get-PyOffsetMin (Get-CsvCell $r 'value') }
        }
    }
    # log 輸出副本：manifest 的 collected 列，依 (mtime, 來源路徑) 由舊到新（Python 字串比較、穩定排序）；分段照 out_parts
    $rows = New-Object 'System.Collections.Generic.List[object]'; $i = 0
    foreach ($r in (Read-CsvRows (Join-Path $hdir 'manifest.csv'))) {
        if ((Get-CsvCell $r 'kind') -ne 'log' -or (Get-CsvCell $r 'status') -ne 'collected' -or -not (Get-CsvCell $r 'out_path')) { continue }
        $rows.Add([pscustomobject]@{ I = $i; M = (Get-CsvCell $r 'mtime'); S = (Get-CsvCell $r 'source_path'); O = (Get-CsvCell $r 'out_path'); P = (Get-CsvCell $r 'out_parts') }); $i++
    }
    $rows.Sort([Comparison[object]] { param($x, $y)
            $c = [FtpCollectSumV130]::PyCmp($x.M, $y.M); if ($c) { return $c }
            $c = [FtpCollectSumV130]::PyCmp($x.S, $y.S); if ($c) { return $c }
            return $x.I.CompareTo($y.I) })
    $own = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($r in $rows) { [void]$own.Add([IO.Path]::Combine($runDir, $r.O).Replace('/', '\')) }
    $parts = New-Object 'System.Collections.Generic.List[string]'
    foreach ($r in $rows) {
        if ($r.P) { foreach ($p in $r.P.Split('|')) { if ($p) { $parts.Add($p) } }; continue }
        $parts.Add($r.O); $k = 2   # 舊版收集結果（沒有 out_parts）：找 <副本>.partN，同 iter_log_files
        while ($true) {
            $cand = "$($r.O).part$k"; $full = [IO.Path]::Combine($runDir, $cand)
            if ($own.Contains($full.Replace('/', '\')) -or -not [IO.File]::Exists((ConvertTo-LongPath $full))) { break }
            $parts.Add($cand); $k++
        }
    }
    $homes = @(foreach ($r in (Read-CsvRows (Join-Path $hdir 'dirs.csv'))) { Get-CsvCell $r 'physical_path' })
    return @{ Skip = ''; ServU = $servu; Start = $st0; Days = $days; Win = $st0.AddDays(-$days); Off = $off; Parts = $parts; Homes = [string[]]$homes }
}
function Write-LogSummary([string]$runDir, [string]$hdir, [string]$collector, [int]$limitSec = $LOG_PARSE_SEC, [int]$maxRows = $SUM_MAX_ROWS, [int]$maxStrings = $SUM_MAX_STRINGS, [int]$maxSessions = $SUM_MAX_SESSIONS, [int]$maxLine = $FZ_MAXLINE) {
    # 回傳 Ok、Msg、Rows、Events、Bytes、Sec；失敗不丟例外（呼叫端改成照舊上傳 log）
    $res = @{ Ok = $false; Limit = $false; Msg = ''; Rows = 0; Events = [long]0; Bytes = [long]0; Sec = 0 }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    if (-not $script:SumReady) { $res.Msg = "主機不允許即時編譯（C#）：$($script:SumErr)"; return $res }
    try {
        $pl = Get-LogSummaryPlan $runDir $hdir
        if ($pl.Skip) { $res.Msg = $pl.Skip; return $res }
        $eng = [FtpCollectSumV130]::new([bool]$pl.ServU, [datetime]$pl.Win, ($null -ne $pl.Off), [int]$(if ($null -ne $pl.Off) { $pl.Off } else { 0 }), [string[]]$pl.Homes, $maxRows, $maxStrings, $maxSessions, $limitSec, $maxLine)
        $n = $pl.Parts.Count; $q = 0; $last = 0
        foreach ($rel in $pl.Parts) {
            $q++
            if ($n -gt 1 -and ($sw.ElapsedMilliseconds - $last) -ge 2000) { $last = $sw.ElapsedMilliseconds; Write-Host ("`r  log 摘要：第 {0} / {1} 個檔    " -f $q, $n) -NoNewline }
            $fs = Open-Source ([IO.Path]::Combine($runDir, $rel))
            try { $eng.AddPart($fs, $rel) } finally { $fs.Close() }
        }
        if ($last) { Write-Host '' }
        # 彙總表直接串流寫進自己新建的檔（大主機可能幾十萬列，不在記憶體裡組整份）；統計檔最後寫（報表要兩個都在才用）
        $aggP = [IO.Path]::GetFullPath((Join-Path $hdir 'log_events_agg.csv'))
        New-OutFile $aggP ([byte[]](0xEF, 0xBB, 0xBF))
        $fo = [IO.File]::Open((ConvertTo-LongPath $aggP), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        try { $eng.WriteAgg($fo) } finally { $fo.Close() }
        $sta = $eng.StatsCsv($collector, [datetime]$pl.Start, [int]$pl.Days, $eng.AggSha256)
        New-OutFile (Join-Path $hdir 'log_parse_stats.csv') $sta
        $res.Ok = $true; $res.Rows = $eng.RowCount; $res.Events = $eng.EventTotal
        $res.Bytes = (New-Object IO.FileInfo((ConvertTo-LongPath $aggP))).Length + $sta.Length
    } catch {
        $em = "$($_.Exception.Message)"; $lm = [regex]::Match($em, 'LIMIT:(\w+):(\d+)')
        if ($lm.Success) {
            $what = @{ time = '秒（時間上限）'; rows = '列（彙總列上限）'; pool = '個不重複字串（上限）'; sessions = '個連線（上限）'; line = '位元組的單行（上限）' }[$lm.Groups[1].Value]
            $res.Msg = "摘要中止：超過 $($lm.Groups[2].Value) $what"; $res.Limit = $true
        } else { $res.Msg = "摘要失敗：$em" }
    } finally { $res.Sec = [int]$sw.Elapsed.TotalSeconds }
    return $res
}

# ======================= 目錄走訪（串流、上限、長路徑、不跟隨連結） =======================
function Get-WalkFiles([string]$root, [int]$maxEntries, [int]$maxSec) {
    # 回傳 Files(List[FileInfo])、Errors(List[string])、Truncated
    $res = [pscustomobject]@{ Files = (New-Object System.Collections.Generic.List[IO.FileInfo]); Errors = (New-Object System.Collections.Generic.List[string]); Truncated = '' }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $fi = New-Object IO.FileInfo((ConvertTo-LongPath $root))
    if ($fi.Exists) { $res.Files.Add($fi); return $res }
    $stack = New-Object 'System.Collections.Generic.Stack[string]'
    $stack.Push((ConvertTo-LongPath $root))
    $count = 0
    while ($stack.Count -gt 0) {
        if ($sw.Elapsed.TotalSeconds -gt $maxSec) { $res.Truncated = "超過 $maxSec 秒"; break }
        $d = $stack.Pop()
        try {
            foreach ($e in (New-Object IO.DirectoryInfo($d)).EnumerateFileSystemInfos()) {
                $count++
                if ($count -gt $maxEntries) { $res.Truncated = "超過 $maxEntries 項"; break }
                if (($count % 100) -eq 0 -and $sw.Elapsed.TotalSeconds -gt $maxSec) { $res.Truncated = "超過 $maxSec 秒"; break }
                if ($e.Attributes -band [IO.FileAttributes]::Directory) {
                    if (-not ($e.Attributes -band [IO.FileAttributes]::ReparsePoint)) { $stack.Push($e.FullName) }
                } else { $res.Files.Add([IO.FileInfo]$e) }
            }
        } catch { $res.Errors.Add(("{0}：{1}" -f (ConvertFrom-LongPath $d), $_.Exception.GetType().Name)) }
        if ($res.Truncated) { break }
    }
    return $res
}
$script:PatCache = New-Object Collections.Hashtable ([StringComparer]::Ordinal)
function Get-NamePattern([string]$n) {
    # 檔名樣式：數字→#、4 個字母以上的字只留前 3 個＋*、非英數（中文等）→*；保證不會原樣重現完整檔名
    $ck = [regex]::Replace($n, '\d', '#')
    if ($ck -cne $n -and $script:PatCache.ContainsKey($ck)) { return $script:PatCache[$ck] }
    $p = Get-NamePatternCore $n
    if ($ck -cne $n -and $script:PatCache.Count -lt 20000) { $script:PatCache[$ck] = $p }
    return $p
}
function Get-NamePatternCore([string]$n) {
    $ext = [IO.Path]::GetExtension($n); $base = $n
    if ($ext -match '^\.[A-Za-z0-9]{1,6}$') { $base = $n.Substring(0, $n.Length - $ext.Length) } else { $ext = '' }
    $b = [regex]::Replace($base, '\d', '#')
    $b = [regex]::Replace($b, '[A-Za-z]{4,}', { param($m) $m.Value.Substring(0, 3) + '*' })
    $b = [regex]::Replace($b, '[^\x20-\x7E]+', '*')
    $p = $b + [regex]::Replace($ext, '\d', '#')
    if ($p -ceq $n) { $p = [regex]::Replace($b, '[A-Za-z]', 'a') + [regex]::Replace($ext, '\d', '#') }
    if ($p -ceq $n) { $p = '*' + $ext }
    if ($p.Length -gt 80) { $p = $p.Substring(0, 77) + '...' }
    return $p
}
function Get-DirSummary([string]$path, [datetime]$cutoff, [Diagnostics.Stopwatch]$global) {
    # 只統計 -Days 期間內有修改的檔（檔數、大小、檔名樣式）；期間外的只計數；另記整個目錄最新修改時間
    $r = @{ path = $path; exists = 'no'; files = 0; bytes = [long]0; old = 0; dirs = 0; newest = $null
        patterns = @{}; other = 0; seconds = 0; truncated = ''; errors = 0; links = 0; excluded = 0; subs = @{} }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    if (-not (New-Object IO.DirectoryInfo((ConvertTo-LongPath $path))).Exists) { return $r }
    $r.exists = 'yes'
    if ($global.Elapsed.TotalSeconds -gt $SUM_TOTAL_SEC) { $r.truncated = "全部目錄合計超過 $SUM_TOTAL_SEC 秒，未掃"; return $r }
    $stack = New-Object 'System.Collections.Generic.Stack[string]'
    $stack.Push((ConvertTo-LongPath $path))
    $tops = New-Object 'System.Collections.Generic.Stack[string]'   # 每個項目屬於哪個第一層子目錄（根目錄本身的檔＝(root)）
    $tops.Push('(root)')
    $entries = 0
    while ($stack.Count -gt 0) {
        if ($sw.Elapsed.TotalSeconds -gt $SUM_DIR_SEC) { $r.truncated = "超過 $SUM_DIR_SEC 秒"; break }
        if ($global.Elapsed.TotalSeconds -gt $SUM_TOTAL_SEC) { $r.truncated = "全部目錄合計超過 $SUM_TOTAL_SEC 秒"; break }
        $d = $stack.Pop(); $top = $tops.Pop()
        try {
            foreach ($e in (New-Object IO.DirectoryInfo($d)).EnumerateFileSystemInfos()) {
                $entries++
                if ($entries -gt $SUM_MAX_FILES) { $r.truncated = "超過 $SUM_MAX_FILES 項"; break }
                if (($entries % 200) -eq 0) {
                    if ($sw.Elapsed.TotalSeconds -gt $SUM_DIR_SEC) { $r.truncated = "超過 $SUM_DIR_SEC 秒"; break }
                    if ($global.Elapsed.TotalSeconds -gt $SUM_TOTAL_SEC) { $r.truncated = "全部目錄合計超過 $SUM_TOTAL_SEC 秒"; break }
                }
                if ($e.Attributes -band [IO.FileAttributes]::Directory) {
                    if ($e.Attributes -band [IO.FileAttributes]::ReparsePoint) { $r.links++ }
                    elseif (((ConvertFrom-LongPath $e.FullName).TrimEnd('\') + '\').StartsWith($script:OutDirPrefix, [StringComparison]::OrdinalIgnoreCase)) { $r.excluded++ }   # 本工具的存放目錄不算
                    else {
                        $r.dirs++; $stack.Push($e.FullName)
                        if ($top -eq '(root)') { $tops.Push($e.Name) } else { $tops.Push($top) }
                    }
                    continue
                }
                $f = [IO.FileInfo]$e
                $t = $f.LastWriteTime
                if ($null -eq $r.newest -or $t -gt $r.newest) { $r.newest = $t }
                # 第一層子目錄小計（上限 $MAX_SUBS 個，超過的併入 (其他)）
                $sk = $top; if (-not $r.subs.ContainsKey($sk) -and $r.subs.Count -ge $MAX_SUBS) { $sk = '(其他)' }
                if (-not $r.subs.ContainsKey($sk)) { $r.subs[$sk] = @{ files = 0; bytes = [long]0; old = 0; newest = $null; patterns = @{} } }
                $sb = $r.subs[$sk]
                if ($null -eq $sb.newest -or $t -gt $sb.newest) { $sb.newest = $t }
                if ($t -lt $cutoff) { $sb.old++ } else {
                    $sb.files++; $sb.bytes += $f.Length
                    $sp = Get-NamePattern $f.Name
                    if ($sb.patterns.ContainsKey($sp)) { $sb.patterns[$sp]++ } elseif ($sb.patterns.Count -lt 20) { $sb.patterns[$sp] = 1 }
                }
                if ($t -lt $cutoff) { $r.old++; continue }
                $r.files++
                $r.bytes += $f.Length
                $p = Get-NamePattern $f.Name
                if ($r.patterns.ContainsKey($p)) { $r.patterns[$p]++ } elseif ($r.patterns.Count -lt $MAX_PATTERNS) { $r.patterns[$p] = 1 } else { $r.other++ }
            }
        } catch { $r.errors++ }
        if ($r.truncated) { break }
    }
    $r.seconds = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
    return $r
}
# ======================= 帳號／目錄解析（從遮後設定檔） =======================
$script:Accounts = New-Object System.Collections.Generic.List[object]
$script:Dirs = New-Object System.Collections.Generic.List[object]
function CT($el, [string]$name) {
    $n = $el.SelectSingleNode("./*[local-name()='$name']")
    if ($n) { return $n.InnerText.Trim() } else { return '' }
}
function Resolve-NativePath([string]$raw, [string]$account, [string]$domain) {
    # 展開帳號目錄變數：FileZilla %u、%<user>、:u（0.9 版）；Serv-U %USER%、%DOMAIN%；系統環境變數。展不開的留空（只留原值）
    if (-not $raw) { return '' }
    $p = $raw
    $RXU = '(?i)%user_name%|%username%|%user%|%<user>|%u\b|:u\b'
    if ($account) { $p = [regex]::Replace($p, $RXU, { param($m) $account }) }
    elseif ($p -match $RXU) { return '' }   # 群組的帳號變數：之後依成員展開
    if ($domain) { $p = [regex]::Replace($p, '(?i)%domain%', { param($m) $domain }) }
    $p = [Environment]::ExpandEnvironmentVariables($p)
    if ($p -match '%') { return '' }
    $p = $p.Replace('/', '\')
    if ($p -match '^[A-Za-z]:\\?$') { return $p.Substring(0, 2) + '\' }
    return $p.TrimEnd('\')
}
function Add-Account($product, $cfg, $domain, $name, $kind, $enabled, $groups, $allow, $deny, $method) {
    $script:Accounts.Add([pscustomobject]@{ product = $product; config = $cfg; domain = $domain; name = $name; kind = $kind; enabled = $enabled; groups = $groups; allow = $allow; deny = $deny; method = $method })
}
function Add-Dir($product, $cfg, $domain, $ownerKind, $owner, $virtual, $raw, $perm, $isHome, $method) {
    $acct = ''; if ($ownerKind -ne 'group') { $acct = $owner }   # 群組的 %u 不能代入群組名，之後依成員展開
    $script:Dirs.Add([pscustomobject]@{ product = $product; config = $cfg; domain = $domain; ownerKind = $ownerKind; owner = $owner; virtual = $virtual
            raw = $raw; physical = (Resolve-NativePath $raw $acct $domain); perm = $perm; isHome = $isHome; method = $method; expanded = $false })
}
function Read-FzNew($doc, [string]$cfg) {
    # FileZilla Server 1.x：users.xml／groups.xml（<user name>、<group name>、<mount_point>）
    foreach ($kind in @('user', 'group')) {
        foreach ($u in @($doc.SelectNodes("//*[local-name()='$kind' and @name]"))) {
            $name = $u.GetAttribute('name')
            $groups = (@($u.SelectNodes("./*[local-name()='group' and not(@name)]") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
            Add-Account 'FileZilla' $cfg '' $name $kind $u.GetAttribute('enabled') $groups (CT $u 'allowed_ips') (CT $u 'disallowed_ips') 'fz1-xml'
            foreach ($m in @($u.SelectNodes("./*[local-name()='mount_point']"))) {
                $raw = $m.GetAttribute('native_path'); if (-not $raw) { $raw = $m.GetAttribute('new_native_path') }
                $perm = "access=$($m.GetAttribute('access'));recursive=$($m.GetAttribute('recursive'));flags=$($m.GetAttribute('flags'))"
                Add-Dir 'FileZilla' $cfg '' $kind $name $m.GetAttribute('tvfs_path') $raw $perm $(if ($m.GetAttribute('tvfs_path') -eq '/') { 'yes' } else { '' }) 'fz1-xml'
            }
        }
    }
}
function Read-FzOld($doc, [string]$cfg) {
    # FileZilla Server 0.9.x：FileZilla Server.xml（<User Name>、<Option Name>、<Permission Dir>）
    foreach ($kind in @('User', 'Group')) {
        foreach ($u in @($doc.SelectNodes("//*[local-name()='$kind' and @Name]"))) {
            $name = $u.GetAttribute('Name')
            $opt = @{}; foreach ($o in @($u.SelectNodes("./*[local-name()='Option']"))) { $opt[$o.GetAttribute('Name')] = $o.InnerText.Trim() }
            $allow = (@($u.SelectNodes("./*[local-name()='IpFilter']/*[local-name()='Allowed']/*") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
            $deny = (@($u.SelectNodes("./*[local-name()='IpFilter']/*[local-name()='Disallowed']/*") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
            $g = ''; if ($opt.ContainsKey('Group')) { $g = $opt['Group'] }
            $en = ''; if ($opt.ContainsKey('Enabled')) { $en = $opt['Enabled'] }
            Add-Account 'FileZilla' $cfg '' $name $kind.ToLower() $en $g $allow $deny 'fz09-xml'
            foreach ($p in @($u.SelectNodes("./*[local-name()='Permissions']/*[local-name()='Permission']"))) {
                $po = @(); $isHome = ''
                foreach ($o in @($p.SelectNodes("./*[local-name()='Option']"))) {
                    $po += ($o.GetAttribute('Name') + '=' + $o.InnerText.Trim())
                    if ($o.GetAttribute('Name') -eq 'IsHome' -and $o.InnerText.Trim() -eq '1') { $isHome = 'yes' }
                }
                $alias = (@($p.SelectNodes(".//*[local-name()='Alias']") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
                $virt = $alias; if ($isHome) { $virt = '/' + $(if ($alias) { ";$alias" } else { '' }) }
                Add-Dir 'FileZilla' $cfg '' $kind.ToLower() $name $virt $p.GetAttribute('Dir') ($po -join ';') $isHome 'fz09-xml'
            }
        }
    }
}
function Read-ServUIni([string]$text, [string]$cfg) {
    # Serv-U 6 以前：ServUDaemon.ini（[USER=name|domainNo]、HomeDir、AccessN=path|flags、IPAccessN）
    $sec = ''; $cur = $null; $items = @()
    $flush = {
        if ($cur) {
            Add-Account 'ServU' $cfg $cur.domain $cur.name $cur.kind $cur.enabled $cur.groups (($cur.ips | Where-Object { $_ -match '^A' }) -join ';') (($cur.ips | Where-Object { $_ -match '^D' }) -join ';') 'servu-ini'
            if ($cur.home) { Add-Dir 'ServU' $cfg $cur.domain $cur.kind $cur.name '/' $cur.home '' 'yes' 'servu-ini' }
            foreach ($a in $cur.access) { $parts = $a -split '\|', 2; $pm = ''; if ($parts.Count -gt 1) { $pm = $parts[1] }; Add-Dir 'ServU' $cfg $cur.domain $cur.kind $cur.name '' $parts[0] $pm '' 'servu-ini' }
        }
    }
    foreach ($line in ($text -split "`r?`n")) {
        $t = $line.Trim()
        if ($t -match '^\[(.*)\]$') {
            . $flush; $cur = $null
            $sec = $Matches[1]
            if ($sec -match '^(?i)(USER|GROUP)=([^|]+)(?:\|(\d+))?') {
                $cur = @{ kind = $Matches[1].ToLower(); name = $Matches[2]; domain = $(if ($Matches[3]) { $Matches[3] } else { '' }); enabled = ''; groups = ''; home = ''; access = @(); ips = @() }
            }
            continue
        }
        if (-not $cur -or $t -notmatch '^([^=]+)=(.*)$') { continue }
        $k = $Matches[1].Trim(); $v = $Matches[2].Trim()
        if ($k -ieq 'HomeDir') { $cur.home = $v }
        elseif ($k -match '^(?i)Access\d+$') { $cur.access += $v }
        elseif ($k -match '^(?i)IPAccess\d+$') { $cur.ips += $v }
        elseif ($k -ieq 'Enable' -or $k -ieq 'Disable') { $cur.enabled = "$k=$v" }
        elseif ($k -ieq 'Groups' -or $k -ieq 'Group') { $cur.groups = $v }
    }
    . $flush
}
function Read-ServUGeneric([string]$text, [string]$cfg, $pairs) {
    # Serv-U 15 .Archive：格式尚未在本公司主機確認 → 啟發式（帳號＝檔名、domain＝上層資料夾），標 heuristic
    $leaf = [IO.Path]::GetFileNameWithoutExtension($cfg)
    $parent = [IO.Path]::GetFileName([IO.Path]::GetDirectoryName($cfg))
    $isUser = ([IO.Path]::GetFileName([IO.Path]::GetDirectoryName([IO.Path]::GetDirectoryName($cfg))) -ieq 'Users')   # ...\Users\<domain>\<帳號>.Archive
    $name = ''; $domain = ''
    if ($isUser) { $name = $leaf; $domain = $parent }
    $en = ''; $allow = @(); $deny = @(); $ds = @()
    foreach ($p in $pairs) {
        $tk = @(Get-KeyTokens $p.Key)
        $v = [string]$p.Value
        if (-not $isUser -and -not $name -and ($p.Key -match '^(?i)(login ?id|user ?name|user ?id|login)$') -and $v -and $v -ne '***') { $name = $v }
        if ($tk -contains 'enabled' -or $tk -contains 'enable' -or $tk -contains 'disabled') { if (-not $en) { $en = "$($p.Key)=$v" } }
        if ((($tk -contains 'ip') -or ($tk -contains 'ips') -or ($tk -contains 'address')) -and $v -match '\d+\.\d+') { if ($tk -contains 'deny' -or $tk -contains 'disallowed' -or $tk -contains 'denied') { $deny += $v } else { $allow += $v } }
        if (@($tk | Where-Object { @('dir', 'directory', 'path', 'home', 'root', 'folder') -contains $_ }).Count -gt 0 -and ($v -match '^[A-Za-z]:\\|^\\\\|^%')) {
            if (-not (($tk -contains 'log') -or ($tk -contains 'logs') -or ($tk -contains 'cert') -or ($tk -contains 'certificate'))) { $ds += , @($p.Key, $v) }
        }
    }
    if ($name -or $ds.Count) {
        if (-not $name) { $name = "($leaf)" }
        Add-Account 'ServU' $cfg $domain $name $(if ($isUser) { 'user' } else { 'unknown' }) $en '' ($allow -join ';') ($deny -join ';') 'servu-heuristic'
        foreach ($d in $ds) { Add-Dir 'ServU' $cfg $domain $(if ($isUser) { 'user' } else { 'unknown' }) $name '' $d[1] ("key=" + $d[0]) $(if ($d[0] -match '(?i)home') { 'yes' } else { '' }) 'servu-heuristic' }
    }
}
$script:SuUsers = New-Object System.Collections.Generic.List[object]
$script:SuLog = New-Object System.Collections.Generic.List[object]
$script:SuLdap = New-Object System.Collections.Generic.List[object]
$script:SuMain = New-Object System.Collections.Generic.List[string]
$script:SuIssues = New-Object System.Collections.Generic.List[string]
$UNIX0 = New-Object DateTime(1970, 1, 1, 0, 0, 0, [DateTimeKind]::Utc)
function ConvertFrom-UnixSec([string]$v) {
    $n = [long]0
    if ([long]::TryParse(([string]$v).Trim(), [ref]$n) -and $n -gt 0 -and $n -lt 32503680000) { return (Ts $UNIX0.AddSeconds($n).ToLocalTime()) }
    return ''
}
function Read-ServUArchive($pairs, [string]$cfg) {
    # Serv-U 15 .Archive（區塊格式）：Users\<domain>\<帳號>.Archive → 帳號、家目錄、DirAccess、累計統計；
    # Serv-U.Archive → LogFilePath／LogToFile、LDAP 驗證設定（只記錄，AD 登入屬個人不納入轉置）
    $leaf = [IO.Path]::GetFileNameWithoutExtension($cfg)
    $dir = [IO.Path]::GetDirectoryName($cfg)
    $domain = [IO.Path]::GetFileName($dir)
    $gp = [IO.Path]::GetFileName([IO.Path]::GetDirectoryName($dir))
    if ($gp -ieq 'Users' -or $gp -ieq 'Groups') {
        $kind = $(if ($gp -ieq 'Users') { 'user' } else { 'group' })
        $f = @{}; $da = New-Object System.Collections.Generic.List[object]
        foreach ($p in $pairs) {
            $k = [string]$p.Key; $v = [string]$p.Value
            if (-not $k -or $v -eq '***') { continue }
            if ($p.Path -match '(?i)/DirAccess(/|$)' -and $k -ine 'DirAccess') {
                if ($k -ieq 'Dir') { $da.Add(@{ dir = $v; access = '' }) }
                elseif ($k -ieq 'Access' -and $da.Count -and -not $da[$da.Count - 1].access) { $da[$da.Count - 1].access = $v }
                continue
            }
            if (-not $f.ContainsKey($k)) { $f[$k] = $v }
        }
        $g = { param($n) if ($f.ContainsKey($n)) { [string]$f[$n] } else { '' } }
        $name = & $g 'LoginID'; if (-not $name) { $name = $leaf }
        $en = ''
        foreach ($ek in @('Enabled', 'Enable', 'Disabled', 'Disable', 'AccountDisabled')) { if ($f.ContainsKey($ek)) { $en = "$ek=$($f[$ek])"; break } }
        Add-Account 'ServU' $cfg $domain $name $kind $en '' '' '' 'servu-archive'
        $homeDir = & $g 'HomeDir'
        if ($homeDir) { Add-Dir 'ServU' $cfg $domain $kind $name '/' $homeDir '' 'yes' 'servu-archive' }
        foreach ($d in $da) {
            $raw = [string]$d.dir
            if ($homeDir) { $raw = [regex]::Replace($raw, '(?i)%HOME%', { param($m) $homeDir }) }
            Add-Dir 'ServU' $cfg $domain $kind $name '' $raw "access=$($d.access)" '' 'servu-archive'
        }
        $script:SuUsers.Add([pscustomobject]@{ domain = $domain; name = $name; kind = $kind; full = (& $g 'FullName'); home = $homeDir
                up = (& $g 'FilesUploaded'); down = (& $g 'FilesDownloaded'); bup = (& $g 'BytesUploaded'); bdown = (& $g 'BytesDownloaded')
                since = (ConvertFrom-UnixSec (& $g 'StatisticsStartTime')); last = (ConvertFrom-UnixSec (& $g 'LastLoginTime')); lastOut = (ConvertFrom-UnixSec (& $g 'LastLogoutTime')); cfg = $cfg })
        return
    }
    if ($leaf -ieq 'Serv-U') {
        $script:SuMain.Add($cfg)
        # 同一個容器實例（例：第 2 個 Domain 區塊）裡的 LogFilePath 與 LogToFile 才配對；欄位自己的區塊不算容器
        $parentOf = { param($p0) $ip0 = [string]$p0.Inst; $lastSeg = $ip0.Substring($ip0.LastIndexOf('/') + 1); if ($lastSeg -like "$($p0.Key)#*") { $ip0.Substring(0, [Math]::Max(0, $ip0.LastIndexOf('/'))) } else { $ip0 } }
        $ltfAll = @($pairs | Where-Object { $_.Key -ieq 'LogToFile' })
        foreach ($x in @($pairs | Where-Object { $_.Key -ieq 'LogFilePath' -and $_.Value -and $_.Value -ne '***' })) {
            $par = & $parentOf $x
            $ltf = @($ltfAll | Where-Object { (& $parentOf $_) -eq $par } | Select-Object -First 1)
            $script:SuLog.Add([pscustomobject]@{ Config = $cfg; Key = $x.Inst; LogFilePath = [string]$x.Value; LogToFile = $(if ($ltf.Count) { [string]$ltf[0].Value } else { '' }) })
        }
        foreach ($p in $pairs) {
            if ($script:SuLdap.Count -ge 40) { break }
            $full = "$($p.Path)/$($p.Key)"
            if ((@(Get-KeyTokens $full) -contains 'ldap') -and $p.Value -ne '***') { $script:SuLdap.Add([pscustomobject]@{ Path = $full; Key = [string]$p.Key; Value = [string]$p.Value }) }
        }
    }
}

# ======================= log 解析 =======================
$RX_DATE = New-Object regex('(?<y>\d{4})[-/](?<m>\d{1,2})[-/](?<d>\d{1,2})[T ](?:(?:上午|下午|AM|PM) )?\d{1,2}:\d{2}|(?<d2>\d{2})(?<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(?<y2>\d{2})\s+\d{2}:\d{2}', 'Compiled, IgnoreCase')
$RX_UTCZ = New-Object regex('\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z', 'Compiled')
$RX_OP = New-Object regex('(?<up>\b(?:STOR|APPE|STOU)\b|Received file|\buploaded\b|已成功收到檔案)|(?<down>\bRETR\b|Sent file|\bdownloaded\b|已成功發送檔)|(?<oth>\b(?:DELE|RNFR|RNTO|X?MKD|X?RMD|NLST|MLSD|LIST)\b|Deleted file|Renamed file|Created directory|Removed directory|檔已移除|目錄已創建)|(?<ok>\b230\b|Logged on|logged in|Login successful|" 已登入)|(?<fail>\b530\b|Login failed|Login incorrect|Invalid password|Authentication failed)', 'Compiled, IgnoreCase')
$MONTHS = @{ jan = 1; feb = 2; mar = 3; apr = 4; may = 5; jun = 6; jul = 7; aug = 8; sep = 9; oct = 10; nov = 11; dec = 12 }

# ======================= 其他小工具 =======================
function Get-LocalIPv4 {
    try {
        $ip = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' |
            Sort-Object { if ($_.DefaultIPGateway) { 0 } else { 1 } } |
            ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' -and $_ -notmatch '^(127|169\.254)\.' } |
            Select-Object -First 1
        if ($ip) { return $ip }
    } catch { ErrLog "取本機 IP 失敗：$($_.Exception.Message)" }
    return 'unknown-ip'
}
function Get-ExePath([string]$cmd) { $m = [regex]::Match($cmd, '^\s*"?([^"]+?\.exe)'); if ($m.Success) { return $m.Groups[1].Value } else { return '' } }
function CimVal($o, [string]$n) { try { $p = $o.CimInstanceProperties[$n]; if ($p) { return $p.Value } } catch { }; return $null }
function Test-PortSpec($spec, $ports, $ranges) {
    foreach ($s in @($spec)) {
        $s = [string]$s
        $lo = -1; $hi = -1
        if ($s -match '^(\d+)-(\d+)$') { $lo = [int]$Matches[1]; $hi = [int]$Matches[2] } elseif ($s -match '^\d+$') { $lo = [int]$s; $hi = $lo } else { continue }
        foreach ($p in $ports) { if ($p -ge $lo -and $p -le $hi) { return $true } }
        foreach ($r in $ranges) { if ($r[0] -le $hi -and $r[1] -ge $lo) { return $true } }
    }
    return $false
}

trap { ErrLog ("未預期錯誤（第 {0} 行）：{1}" -f $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message); if (-not $script:LogFile) { Stop-Early '未預期錯誤，中止' }; continue }

# ============================== 主流程 ==============================
Log "FTP 主機本機收集（PowerShell 版 $VERSION）" 'Green'
Log '只讀不改、不刪除；設定檔遮密碼後才寫入；結果只寫在新開的結果資料夾。'
Log ''

# v1.3.4：沒有系統管理員權限就不跑（2026-11-13 3.33：一般權限讀不到 C:\ProgramData\RhinoSoft\Serv-U 和防火牆規則，整台 FAIL 白跑）
$amAdmin = $false; try { $amAdmin = (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { }
if (-not $amAdmin -and -not $AllowNonAdmin) { Stop-Early '沒有系統管理員權限，不執行：請在 run.bat 上按右鍵 →「以系統管理員身分執行」。（一般權限讀不到 FTP 設定檔與防火牆規則，結果會是 FAIL）' }
if (-not $SocTicket.Trim()) { $SocTicket = Read-Host '資安／SOC 通知單號（必填）' }
if (-not $SocTicket.Trim()) { Stop-Early '沒有通知單號，不執行。' }
if (-not $OutDir) {
    $def = Join-Path $PSScriptRoot 'out'
    $ans = Read-Host "存放目錄（直接按 Enter＝$def）"
    $OutDir = if ($ans.Trim()) { $ans.Trim().Trim('"') } else { $def }
}
if ($OutDir.StartsWith('\\')) { Stop-Early '存放目錄請用本機磁碟，不要放網路共用。' }
$OutDir = [IO.Path]::GetFullPath($OutDir)
$drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($OutDir))
if ($drive.DriveType -eq 'Network') { Stop-Early '存放目錄請用本機磁碟，不要放對應的網路磁碟。' }

try { $script:LongOK = (New-Object IO.DirectoryInfo('\\?\' + $env:SystemDrive + '\')).Exists } catch { $script:LongOK = $false }
# ---- FTP 上傳設定（v1.2.1）：同資料夾的 ftpid.txt；host 空白＝不上傳。密碼可留空，開頭當場輸入（檔案裡就不留密碼）----
$script:Up = $null
function Up-Uri([string[]]$segs) { return ('ftp://{0}:{1}/{2}' -f $script:Up.Host, $script:Up.Port, ((@($segs) | ForEach-Object { [Uri]::EscapeDataString($_) }) -join '/')) }
function Up-Req([string]$uri, [string]$method) {
    $r = [Net.FtpWebRequest]::Create($uri)
    $r.Method = $(switch ($method) { 'STOR' { [Net.WebRequestMethods+Ftp]::UploadFile } 'MKD' { [Net.WebRequestMethods+Ftp]::MakeDirectory } 'SIZE' { [Net.WebRequestMethods+Ftp]::GetFileSize } 'LIST' { [Net.WebRequestMethods+Ftp]::ListDirectory } })
    $r.Credentials = $script:Up.Cred; $r.UseBinary = $true; $r.UsePassive = $true; $r.KeepAlive = $true; $r.Timeout = 60000; $r.ReadWriteTimeout = 300000
    return $r
}
$script:UpMade = @{}
function Up-Mkd([string[]]$segs) {
    $u = Up-Uri $segs; if ($script:UpMade.ContainsKey($u)) { return }; $script:UpMade[$u] = 1
    try { (Up-Req $u 'MKD').GetResponse().Close() } catch {}   # 已存在會回 550，不理
}
$iniP = Join-Path $PSScriptRoot 'ftpid.txt'
if (Test-Path -LiteralPath $iniP) {
    $cfg = @{}
    foreach ($ln in [IO.File]::ReadAllLines($iniP, [Text.Encoding]::UTF8)) {
        $t = $ln.Trim(); if (-not $t -or $t.StartsWith('#') -or $t.StartsWith(';')) { continue }
        $eq = $t.IndexOf('='); if ($eq -gt 0) { $cfg[$t.Substring(0, $eq).Trim().ToLower()] = $t.Substring($eq + 1).Trim() }
    }
    $uh = $(if ($cfg.ContainsKey('host')) { [string]$cfg['host'] } else { '' })
    if ($uh) {
        $uport = $(if ($cfg['port']) { [int]$cfg['port'] } else { 21 })
        $uuser = [string]$cfg['user']; $upw = [string]$cfg['password']
        $ulim = $(if ($cfg.ContainsKey('limit_mb') -and "$($cfg['limit_mb'])" -ne '') { [double]$cfg['limit_mb'] } else { 2 })
        if (-not $upw) { $sp = Read-Host "FTP 上傳密碼（$uuser@$uh；不會顯示、不會存檔）" -AsSecureString; $ucred = New-Object Net.NetworkCredential($uuser, $sp) }
        else { $ucred = New-Object Net.NetworkCredential($uuser, $upw) }
        $usegs = @(([string]$cfg['dir']).Split('/') | Where-Object { $_ }) + @((Get-Date).ToString('yyyyMMdd'))
        $ulogs = ($cfg.ContainsKey('upload_logs') -and "$($cfg['upload_logs'])".Trim() -eq '1')   # v1.3.0：1＝連 log 副本也上傳；預設 0（有摘要就只傳摘要）
        $script:Up = @{ Host = $uh; Port = $uport; Cred = $ucred; Segs = $usegs; Lim = $ulim; Logs = $ulogs; Show = ('ftp://{0}:{1}/{2}' -f $uh, $uport, ($usegs -join '/')) }
        # 先試：建目錄＋列目錄，帳密或路徑錯了現在就知道，不要跑完才發現
        try {
            # v1.3.4：先用 5 秒試連埠，連不上就不要每一步各等 60 秒
            $tc = New-Object Net.Sockets.TcpClient
            try { $ar = $tc.BeginConnect($uh, $uport, $null, $null); if (-not $ar.AsyncWaitHandle.WaitOne(5000) -or -not $tc.Connected) { throw "連不上 ${uh}:$uport（5 秒內沒有回應）" }; $tc.EndConnect($ar) } finally { $tc.Close() }
            for ($q = 1; $q -le $usegs.Count; $q++) { Up-Mkd @($usegs | Select-Object -First $q) }
            $lr = (Up-Req (Up-Uri $usegs) 'LIST').GetResponse(); $lr.Close()
            Log "FTP 上傳：測試登入成功，跑完會傳到 $($script:Up.Show)/（$(if ($ulim -gt 0) { "限速每秒 $ulim MB" } else { '不限速' })）" 'Green'
        } catch {
            # v1.3.4（使用者 2026-11-13）：連不上 FTP 不要卡住等人，倒數 10 秒自動改成只在本機收集（不上傳）；按 Q 結束、其他鍵馬上繼續
            Write-Host "FTP 上傳設定測試失敗：$($_.Exception.Message)" -ForegroundColor Yellow
            $quit = $false
            for ($cd = 10; $cd -ge 1; $cd--) {
                Write-Host ("`r  {0} 秒後自動改成只在本機收集（跑完不上傳）；按 Q 結束、按其他鍵馬上繼續 " -f $cd) -NoNewline -ForegroundColor Yellow
                $hit = $false
                for ($t = 0; $t -lt 10; $t++) {
                    try { if ([Console]::KeyAvailable) { $k = [Console]::ReadKey($true); if ($k.Key -eq 'Q') { $quit = $true }; $hit = $true; break } } catch { }
                    Start-Sleep -Milliseconds 100
                }
                if ($hit) { break }
            }
            Write-Host ''
            if ($quit) { Stop-Early 'FTP 連不上，使用者按 Q 結束，未執行。請檢查 ftpid.txt 或網路。' }
            Log "FTP 上傳：連不上（$($_.Exception.Message)），改成只在本機收集，結果請自行拷回" 'Yellow'
            $script:Up = $null
        }
    }
}



$extra = @($ExtraPaths -split ';' | Where-Object { $_.Trim() } | ForEach-Object { $_.Trim().Trim('"') })
foreach ($p in $extra) { if ($p -notmatch '^[A-Za-z]:\\') { Stop-Early "ExtraPaths 要是 X:\... 完整路徑：$p" } }

# 服務：執行檔目錄、命令列裡的路徑（例如 --config-dir）、執行身分
$svcRoots = @(); $ftpPids = @(); $ftpExes = @(); $services = @()
try {
    $services = @(Get-CimInstance Win32_Service | Where-Object { "$($_.Name) $($_.DisplayName) $($_.PathName)" -match '(?i)ftp|serv-?u|rhinosoft|filezilla|sshd|sftp' })
    foreach ($sv in $services) {
        if ("$($sv.Name) $($sv.PathName)" -notmatch $PRODUCT_RX) { continue }
        $exe = Get-ExePath ([string]$sv.PathName)
        if ($exe) { $svcRoots += [IO.Path]::GetDirectoryName($exe); $ftpExes += $exe }
        foreach ($m in [regex]::Matches([string]$sv.PathName, '"([A-Za-z]:\\[^"]+)"|(?<=\s)([A-Za-z]:\\\S+)')) {
            $p = $m.Value.Trim('"')
            if ($p -notmatch '(?i)\.exe$' -and (Test-Path -LiteralPath $p -PathType Container)) { $svcRoots += $p }
        }
        if ($sv.ProcessId) { $ftpPids += [int]$sv.ProcessId }
        try {   # 服務執行帳號的使用者設定檔底下（FileZilla 以非 SYSTEM 帳號執行時設定會放這裡）
            $acct = [string]$sv.StartName; $prof = ''
            if ($acct -match '^(?i)(LocalSystem|NT AUTHORITY\\SYSTEM)$') { $prof = Join-Path $env:windir 'System32\config\systemprofile' }
            elseif ($acct -match '^(?i)NT AUTHORITY\\(LocalService|NetworkService)$') { $prof = Join-Path $env:windir ('ServiceProfiles\' + ($acct -replace '^.*\\', '')) }
            elseif ($acct) {
                if ($acct.StartsWith('.\')) { $acct = $env:COMPUTERNAME + $acct.Substring(1) }
                $sid = (New-Object Security.Principal.NTAccount($acct)).Translate([Security.Principal.SecurityIdentifier]).Value
                $up = Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop
                if ($up) { $prof = [string]$up.LocalPath }
            }
            if ($prof) {
                foreach ($sub in @('AppData\Local\filezilla-server', 'AppData\Roaming\filezilla-server', 'AppData\Local\FileZilla Server', 'AppData\Roaming\FileZilla Server', 'AppData\Local\RhinoSoft\Serv-U', 'AppData\Roaming\RhinoSoft\Serv-U')) {
                    $cand = Join-Path $prof $sub
                    if (Test-Path -LiteralPath $cand -PathType Container) { $svcRoots += $cand }
                }
            }
        } catch { ErrLog "找服務帳號設定目錄失敗（$($sv.Name)）：$($_.Exception.GetType().Name)" }
    }
} catch { ErrLog "讀服務資訊失敗：$($_.Exception.Message)" }

$roots = @($DEFAULT_ROOTS + $svcRoots + $extra | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') } | Select-Object -Unique)
foreach ($p in $roots) { if (Test-Inside $OutDir $p) { Stop-Early "存放目錄不能放在要收集的資料夾裡：$p" } }

$ip = Get-LocalIPv4
$hostName = $env:COMPUTERNAME
$start = Get-Date
[void][IO.Directory]::CreateDirectory($OutDir)   # 存放目錄（不存在才建）
$runDir = Join-Path $OutDir ("run_local_{0}_{1}_{2}" -f $ip, $hostName, $start.ToString('yyyyMMdd_HHmmss'))
$k = 1; $baseDir = $runDir
while (Test-Path -LiteralPath $runDir) { $k++; $runDir = "${baseDir}_$k" }
[void][IO.Directory]::CreateDirectory($runDir)
$script:RunDir = [IO.Path]::GetFullPath($runDir)
$script:OutDirPrefix = $OutDir.TrimEnd('\') + '\'
$hdir = Join-Path $runDir $ip
$script:HostDir = $hdir
New-RunSubDir $hdir
Open-RunLogs $runDir
Log "結果資料夾已建立：$runDir"
# 快速模式引擎（C#）：結果資料夾建好後才編譯，暫存檔只在結果資料夾的 _compile\（見 Add-TypeInRun）；不允許時照舊改用一般模式
try { Add-TypeInRun $FZ_CS 'FtpCollectFzEngineV120'; $script:FzFast = $true; $script:FzFastErr = '' } catch { $script:FzFastErr = $_.Exception.Message }
try { Add-TypeInRun $SUM_CS 'FtpCollectSumV130'; $script:SumReady = $true; $script:SumErr = '' } catch { $script:SumErr = $_.Exception.Message }
try { [IO.Directory]::Delete((ConvertTo-LongPath (Join-Path $runDir '_compile'))) } catch { }   # 只刪自己剛建的空資料夾（不空就留著）
if ($script:FzFast) { $LOG_PARSE_SEC = 21600 }
if ($MaxLogGB -lt 0) { $MaxLogGB = $(if ($script:FzFast) { 0 } else { 1 }) }   # 預設：快速模式讀滿 -Days 天；主機不允許快速模式時（約每秒 1 MB）維持 1 GB   # 快速模式：90 天大 log 的統計也要做完（一般模式維持 900 秒，避免跑太久）

$isAdmin = $false
try { $isAdmin = (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { }
$info = Join-Path $runDir '_run_info.txt'
$who = [Security.Principal.WindowsIdentity]::GetCurrent().Name
Add-OutText $info @"
SOC 通知單號：$SocTicket
執行者（Windows 登入）：$who（系統管理員權限：$isAdmin）
連線帳號：（本機模式）
執行機器：$hostName（$ip）
開始：$(Ts $start)
收集工具：FtpCollect.ps1 $VERSION
輸出格式版本（schema）：$SCHEMA
log 天數：$Days
log 分段大小：$MaxMB MB
log 讀取上限：$(if ($MaxLogGB -gt 0) { "$MaxLogGB GB（從最新往回挑，超過的較舊 log 不讀）" } else { "不限" })
FileZilla log 模式：$FzLogMode$(if ($FzDropListing) { '（不留 LIST/NLST/MLSD）' } else { '' })
長路徑支援：$script:LongOK
模式：本機（PowerShell $($PSVersionTable.PSVersion)）
從服務找到的目錄：$($svcRoots -join '；')
額外路徑：$($extra -join '；')

"@

# 輸出檔
$runCsv = Join-Path $runDir '_run.csv'
$manifest = Join-Path $hdir 'manifest.csv'
$accCsv = Join-Path $hdir 'accounts.csv'
$dirCsv = Join-Path $hdir 'dirs.csv'
$sumCsv = Join-Path $hdir 'dir_summary.csv'
$subCsv = Join-Path $hdir 'subdir_summary.csv'
$eqCsv = Join-Path $hdir 'evidence_quality.csv'
$covCsv = Join-Path $hdir 'log_coverage.csv'
$suCsv = Join-Path $hdir 'servu_users.csv'
$lsCsv = Join-Path $hdir 'log_settings.csv'
$hostInfo = Join-Path $hdir 'host_info.csv'
$fwCsv = Join-Path $hdir 'firewall.csv'
$taskCsv = Join-Path $hdir 'tasks.csv'
$aclCsv = Join-Path $hdir 'acl.csv'
$shareCsv = Join-Path $hdir 'shares.csv'
$certCsv = Join-Path $hdir 'certs.csv'
Csv $manifest @('kind', 'status', 'source_path', 'size', 'mtime', 'out_path', 'out_bytes', 'sha256', 'format', 'note', 'out_parts')
Csv $accCsv @('product', 'config_file', 'domain', 'name', 'kind', 'enabled', 'groups', 'allowed_ips', 'denied_ips', 'parse_method')
Csv $dirCsv @('product', 'config_file', 'domain', 'owner_kind', 'owner', 'virtual_path', 'physical_path_raw', 'physical_path', 'perm_raw', 'is_home', 'parse_method')
Csv $subCsv @('physical_path', 'subfolder', 'window_days', 'files_in_window', 'bytes_in_window', 'top_patterns_in_window', 'newest_mtime_overall', 'files_older_than_window', 'parent_truncated')
Csv $sumCsv @('physical_path', 'exists', 'window_days', 'files_in_window', 'bytes_in_window', 'top_patterns_in_window', 'newest_mtime_overall', 'files_older_than_window', 'dir_count', 'scan_seconds', 'truncated', 'enum_errors', 'links_skipped', 'scan_time')
Csv $covCsv @('log_file', 'first_date', 'last_date', 'lines', 'dated_lines', 'upload', 'download', 'other_ops', 'login_ok', 'login_fail', 'utc_marker', 'copy_mode', 'source_bytes', 'out_bytes', 'lines_kept', 'lines_dropped')
Csv $lsCsv @('config_file', 'key_path', 'value')
Csv $hostInfo @('item', 'name', 'value')
Csv $certCsv @('source', 'cert_file', 'referenced_by', 'subject', 'issuer', 'not_before', 'not_after', 'thumbprint', 'note')
Csv $suCsv @('domain', 'name', 'kind', 'full_name', 'home_dir', 'files_uploaded', 'files_downloaded', 'bytes_uploaded', 'bytes_downloaded', 'statistics_start', 'last_login', 'last_logout', 'config_file')

function Add-Manifest($kind, $status, $src, $size, $mtime, $out, $outBytes, $sha, $fmt, $note, $parts = $null) {
    $pr = ''; if ($parts) { $pr = (@($parts | ForEach-Object { (ConvertFrom-LongPath $_).Substring($script:RunDir.Length).TrimStart('\') }) -join '|') }   # 輸出分段（依序，含第一段）
    $rel = ''; if ($out) { $rel = (ConvertFrom-LongPath $out).Substring($script:RunDir.Length).TrimStart('\') }
    Csv $manifest @($kind, $status, $src, $size, (Ts $mtime), $rel, $outBytes, $sha, $fmt, $note, $pr)
}

$cutoff = $start.AddDays(-$Days)
$maxBytes = [long]$MaxMB * $CHUNK
$maxLogBytes = $(if ($MaxLogGB -gt 0) { [long][Math]::Max(1, [Math]::Floor($MaxLogGB * 1GB)) } else { [long]0 })   # 只有 0 代表不限；極小正值至少 1 位元組
$logCap = @{ sampled = $false; files = 0; bytes = [long]0; keptFiles = 0; keptBytes = [long]0; from = '' }
$s = @{ found = 0; denied = 0; main = 0; config = 0; log = 0; bytes = [long]0; masked = 0; generic = 0; skipped = 0; copyErr = 0; truncated = 0 }
$types = @()
$endReason = '正常結束'
$aborted = $false
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$cfgFiles = New-Object System.Collections.Generic.List[IO.FileInfo]
$logFiles = New-Object System.Collections.Generic.List[IO.FileInfo]
$certFiles = New-Object System.Collections.Generic.List[IO.FileInfo]
$logDirs = New-Object System.Collections.Generic.List[string]
$certRefs = @{}        # 憑證路徑 → 被哪個設定引用
$inlineCerts = New-Object System.Collections.Generic.List[object]
$extraCfg = New-Object System.Collections.Generic.List[string]
$cfgPorts = New-Object 'System.Collections.Generic.HashSet[int]'
$cfgRanges = New-Object System.Collections.Generic.List[object]
$logSettingText = New-Object System.Collections.Generic.List[string]
$walked = New-Object System.Collections.Generic.List[string]
$copiedLogs = New-Object System.Collections.Generic.List[object]

$PACKED_EXT = @('.zip', '.gz', '.7z', '.rar', '.bz2')
$NOT_LOG_EXT = @('.exe', '.dll', '.sys', '.msi', '.bat', '.cmd', '.ps1', '.vbs', '.js', '.ico', '.png', '.jpg', '.htm', '.html', '.chm', '.pdf',
    '.key', '.pfx', '.p12', '.jks', '.keystore', '.ppk', '.kdbx', '.p8', '.pk8')   # 金鑰／憑證容器一律不當 log
function Test-LogCandidate([IO.FileInfo]$f, [bool]$inLogDir) {
    $n = $f.Name; $ext = $f.Extension.ToLower()
    if ($NOT_LOG_EXT -contains $ext -or $CERT_EXT -contains $ext) { return $false }
    if ($n -match '(?i)\.log$|\.log\.[^\\]+$') { return $true }                      # x.log、x.log.1、x.log.20261101
    if ($inLogDir) { return (($NOT_LOG_EXT -notcontains $ext) -and ($CONFIG_EXT -notcontains $ext) -and ($CERT_EXT -notcontains $ext)) }   # 設定指定的 log 目錄：events.csv、無副檔名、x.txt.1 都收
    $logish = ($n -match '(?i)log|event|xfer|transfer|audit') -or ((ConvertFrom-LongPath $f.DirectoryName) -match '(?i)\\logs?(\\|$)')
    if ($logish -and $n -match '(?i)\.(txt|csv)(\.\d+)?$') { return $true }
    return $false
}
$SU_CLIENT_RX = '(?i)\\Serv-U\\Client\\'
$script:Excl = @{ client = 0; backup = 0 }
function Add-WalkResult([string]$root, [bool]$isLogDir) {
    $w = Get-WalkFiles $root $ROOT_WALK_MAX $ROOT_WALK_SEC
    $walked.Add($root)
    foreach ($e in $w.Errors) { ErrLog "無法列目錄 $e"; Add-Manifest 'error' 'error' $e '' $null '' '' '' '' '無法列目錄' }
    if ($w.Truncated) { $s.truncated++; ErrLog "目錄走訪截斷 $root：$($w.Truncated)"; Add-Manifest 'error' 'truncated' $root '' $null '' '' '' '' "走訪截斷：$($w.Truncated)" }
    foreach ($f in $w.Files) {
        $full = ConvertFrom-LongPath $f.FullName
        if (Test-Inside $full $script:RunDir) { continue }
        if ($full -match $SU_CLIENT_RX) { $script:Excl.client++; continue }      # Serv-U 網頁介面範本，不是設定
        if ($full -match '(?i)\.Archive\.Backup$') { $script:Excl.backup++; continue }   # Serv-U 備份檔：會讓帳號重複
        if ($seen.Contains($full)) { continue }
        $ext = $f.Extension.ToLower()
        if (-not $isLogDir -and ($CONFIG_EXT -contains $ext)) { [void]$seen.Add($full); $cfgFiles.Add($f) }
        elseif ($CERT_EXT -contains $ext) { [void]$seen.Add($full); $certFiles.Add($f) }
        elseif ($PACKED_EXT -contains $ext -and ($isLogDir -or $f.Name -match '(?i)log') -and $f.LastWriteTime -ge $cutoff) {
            [void]$seen.Add($full); $s.skipped++; ErrLog "未收集 $full：壓縮的 log"
            Add-Manifest 'log' 'skipped' $full $f.Length $f.LastWriteTime '' '' '' '' '壓縮的 log：無法在主機上安全遮罩，未收集（請人工處理）'
        }
        elseif (Test-LogCandidate $f $isLogDir) { if ($f.LastWriteTime -ge $cutoff) { [void]$seen.Add($full); $logFiles.Add($f) } }
    }
}

function Invoke-ConfigCollect([IO.FileInfo]$f) {
    $src = ConvertFrom-LongPath $f.FullName
    try {
        $r = Read-AllShared $src $MAX_CONFIG
        if ($null -eq $r[0]) {
            if ($r[1] -match '^短讀') { $s.copyErr++; ErrLog "讀設定檔失敗 $src：$($r[1])"; Add-Manifest 'config' 'error' $src $f.Length $f.LastWriteTime '' '' '' '' $r[1] }
            else { $s.skipped++; ErrLog "未收集 $src：$($r[1])"; Add-Manifest 'config' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' '' $r[1] }
            return
        }
        $data = [byte[]]$r[0]
        $text = Get-TextFromBytes $data
        if ($null -eq $text -and (Test-XmlBytes $data)) { $text = '' }   # 非 UTF-8／Big5 但看起來是 XML：交給 XML 解析器照 encoding 宣告讀
        if ($null -eq $text) { $s.skipped++; ErrLog "未收集 $src：二進位或編碼無法辨識"; Add-Manifest 'config' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' '' '未收集：二進位或編碼無法辨識，無法安全遮罩（請在主機上用主控台匯出）'; return }
        $before = $script:MaskHits
        $pc = $null
        try { $pc = Protect-Config $data $text $f.Extension.ToLower() }
        catch {
            $msg = "$($_.Exception.Message)"; if ($msg -notmatch '^(遮罩自我檢查失敗|格式無法確認|XML 解析失敗|JSON 解析失敗|不是 INI)') { $msg = '解析失敗（' + $_.Exception.GetType().Name + '）' }
            $s.skipped++; ErrLog "未收集 $src：$msg"; Add-Manifest 'config' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' '' "未收集：$msg"; return
        }
        $dst = Get-MirrorPath $src
        New-OutFile $dst $pc.Bytes
        $sha = Get-Sha256Bytes $pc.Bytes
        if ((Get-Sha256File $dst) -ne $sha) { $s.copyErr++; ErrLog "設定檔副本驗證不符 $src"; Add-Manifest 'config' 'error' $src $f.Length $f.LastWriteTime $dst $pc.Bytes.Length $sha $pc.Format '副本驗證不符'; return }
        $changed = $script:MaskHits -gt $before
        if ($changed) { $s.masked++ }
        $note = $(if ($changed) { '已遮密碼' } else { '無密碼欄位' })
        if ($pc.Generic) { $s.generic++; $note += '；格式不明，只保留白名單欄位（路徑、啟用、IP、權限…），請人工抽看' }
        $s.config++
        $accBefore = $script:Accounts.Count
        $product = ''
        if ($src -match '(?i)serv-?u|rhinosoft' -or $text -match '(?i)ServUDaemon|Serv-U') { $product = 'ServU' }
        if ($src -match '(?i)filezilla' -or $text -match '(?i)<filezilla|FileZillaServer') { $product = 'FileZilla' }
        try {
            if ($pc.Format -eq 'XML') {
                $root = $pc.Doc.DocumentElement.LocalName
                if ($root -ieq 'FileZillaServer') { Read-FzOld $pc.Doc $src }
                elseif ($pc.Doc.SelectSingleNode("//*[local-name()='mount_point']") -or ($root -ieq 'filezilla' -and $pc.Doc.SelectSingleNode("//*[(local-name()='user' or local-name()='group') and @name]"))) { Read-FzNew $pc.Doc $src }
                elseif ($f.Extension -ieq '.archive' -or $product -eq 'ServU') { Read-ServUGeneric '' $src $pc.Pairs }
            } elseif ($pc.Format -eq 'SERVU-ARCHIVE') { Read-ServUArchive $pc.Pairs $src
            } elseif ($pc.Format -eq 'INI' -and $pc.Text -match '(?im)^\s*\[(USER|GROUP)=') { Read-ServUIni $pc.Text $src }
            elseif ($f.Extension -ieq '.archive' -or $product -eq 'ServU') { Read-ServUGeneric $pc.Text $src $pc.Pairs }
        } catch { ErrLog "解析帳號失敗 $src：$($_.Exception.GetType().Name)" }
        $nAcc = $script:Accounts.Count - $accBefore
        if ($nAcc) { $note += "；帳號／群組 $nAcc 筆" }
        if ($f.Name -match $MAIN_CONFIG -or $nAcc -gt 0) { $s.main++ }
        Add-Manifest 'config' 'collected' $src $f.Length $f.LastWriteTime $dst $pc.Bytes.Length $sha $pc.Format $note
        # 從設定值找：log 位置與設定、憑證、其他設定檔、埠
        $mins = @{}; $maxs = @{}; $nls = 0
        foreach ($p in $pc.Pairs) {
            $v = ([string]$p.Value).Trim()
            $tk = @(Get-KeyTokens ($p.Path))
            $isLog = @($tk | Where-Object { @('log', 'logs', 'logging', 'logger', 'logfile', 'logfiles', 'logdir') -contains $_ }).Count -gt 0
            if ($isLog -and $nls -lt 300) { Csv $lsCsv @($src, $p.Path, $v); $nls++; if ($logSettingText.Count -lt 40) { $logSettingText.Add("$($p.Key)=$v") } }
            if ($v -match '-----BEGIN CERTIFICATE-----') { $inlineCerts.Add([pscustomobject]@{ Ref = "$src :: $($p.Path)"; Text = $v }) }
            $ev = [Environment]::ExpandEnvironmentVariables($v)
            if ($ev -match '^[A-Za-z]:\\|^\\\\') {
                $pp = ($ev -split '[|<>"*?]')[0]   # 例：Serv-U AccessN=路徑|權限
                if ($pp -match '%') { $i = $pp.IndexOf('%'); $pp = $pp.Substring(0, $pp.LastIndexOf('\', [Math]::Max(0, $i - 1)) + 1) }
                $pp = $pp.TrimEnd('\')
                $ext = [IO.Path]::GetExtension($pp).ToLower()
                if ($CERT_EXT -contains $ext -or @('.pfx', '.p12', '.key') -contains $ext) {
                    if (-not $certRefs.ContainsKey($pp)) { $certRefs[$pp] = @() }
                    $certRefs[$pp] += "$src :: $($p.Path)"
                } elseif ($isLog -and $pp.Length -gt 3 -and $pc.Format -ne 'SERVU-ARCHIVE') {   # Serv-U LogFilePath 另外處理（4b，照檔名樣式收）
                    $d = $pp; if ($ext -and (Test-Path -LiteralPath $pp -PathType Leaf)) { $d = [IO.Path]::GetDirectoryName($pp) } elseif ($ext -in @('.log', '.txt')) { $d = [IO.Path]::GetDirectoryName($pp) }
                    if ($d -and -not $logDirs.Contains($d)) { $logDirs.Add($d) }
                } elseif (($CONFIG_EXT -contains $ext) -and (Test-Path -LiteralPath $pp -PathType Leaf) -and -not $extraCfg.Contains($pp)) { $extraCfg.Add($pp) }
            }
            $kt = @(Get-KeyTokens ([string]$p.Key))
            if (($kt -contains 'port' -or $kt -contains 'ports') -and $v -match '^\d{1,5}$' -and [int]$v -gt 0 -and [int]$v -lt 65536) {
                [void]$cfgPorts.Add([int]$v)
                $par = $p.Path.Substring(0, [Math]::Max(0, $p.Path.LastIndexOf('/')))
                if ($kt -contains 'min' -or $kt -contains 'low' -or $kt -contains 'start' -or $kt -contains 'from') { $mins[$par] = [int]$v }
                if ($kt -contains 'max' -or $kt -contains 'high' -or $kt -contains 'end' -or $kt -contains 'to') { $maxs[$par] = [int]$v }
            }
        }
        foreach ($k2 in $mins.Keys) { if ($maxs.ContainsKey($k2) -and $maxs[$k2] -ge $mins[$k2]) { $cfgRanges.Add(@($mins[$k2], $maxs[$k2])) } }
        if ($product) { $script:types += $product }
    } catch {
        if ("$($_.Exception.Message)".StartsWith('STOP:')) { throw }
        $s.copyErr++
        ErrLog "收集設定檔失敗 $src：$($_.Exception.Message)"
        Add-Manifest 'config' 'error' $src '' $null '' '' '' '' "$($_.Exception.GetType().Name)"
    }
}

$script:types = @()
$logStats = $null
try {
    # 1. 走訪安裝／設定目錄
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        try { [void](Get-Item -LiteralPath $root -Force) } catch { $s.denied++; ErrLog "無法存取 $root：$($_.Exception.Message)"; Add-Manifest 'root' 'error' $root '' $null '' '' '' '' '無法存取'; continue }
        $s.found++
        if ($root -match '(?i)serv-?u|rhinosoft') { $script:types += 'ServU' } elseif ($root -match '(?i)filezilla') { $script:types += 'FileZilla' }
        Add-Manifest 'root' 'found' $root '' $null '' '' '' '' ''
        Log "找到：$root"
        Add-WalkResult $root $false
    }
    if ($script:Excl.client) { Log "排除 Serv-U\Client 網頁範本 $($script:Excl.client) 個檔"; Add-Manifest 'excluded' 'excluded' 'Serv-U\Client\' '' $null '' '' '' '' "網頁介面範本，不是設定：$($script:Excl.client) 個檔，不收" }
    if ($script:Excl.backup) { Log "排除 *.Archive.Backup $($script:Excl.backup) 個檔"; Add-Manifest 'excluded' 'excluded' '*.Archive.Backup' '' $null '' '' '' '' "Serv-U 備份檔：$($script:Excl.backup) 個，不收（避免帳號重複）" }
    # 2. 設定檔（遮罩、寫入、解析帳號）
    foreach ($f in @($cfgFiles)) { Invoke-ConfigCollect $f }
    # 3. 設定檔裡引用的其他設定檔（例如 Serv-U domain 檔在別處）
    for ($qi = 0; $qi -lt $extraCfg.Count -and $qi -lt 500; $qi++) {   # 佇列：被引用的設定檔再引用的也會處理
        $p = $extraCfg[$qi]
        if ($seen.Add($p)) { Log "設定引用的設定檔：$p"; Invoke-ConfigCollect (New-Object IO.FileInfo((ConvertTo-LongPath $p))) }
    }
    if ($extraCfg.Count -gt 500) { ErrLog "設定引用的設定檔超過 500 個，其餘未處理" }
    # 4. 設定檔裡指定的 log 目錄
    foreach ($d in @($logDirs)) {
        if (-not (Test-Path -LiteralPath $d -PathType Container)) { Log "設定指定的 log 目錄不存在：$d"; Add-Manifest 'logdir' 'missing' $d '' $null '' '' '' '' '設定裡指定，但目錄不存在'; continue }
        Add-Manifest 'logdir' 'found' $d '' $null '' '' '' '' '設定裡指定的 log 目錄'
        Log "找 log（設定指定的目錄）：$d"; Add-WalkResult $d $true
    }
    # 4b. Serv-U：照 Serv-U.Archive 的 LogFilePath 收 log（%Y、%M、%D… 換成萬用字元；位置常在別的磁碟）
    if ($script:SuMain.Count -and -not $script:SuLog.Count) {
        $script:SuIssues.Add('Serv-U 設定裡沒有 LogFilePath（log 位置不明）')
        Add-Manifest 'logdir' 'missing' ($script:SuMain -join ';') '' $null '' '' '' '' 'Serv-U.Archive 沒有 LogFilePath'
    }
    foreach ($suL in $script:SuLog.ToArray()) {
        if ($suL.LogToFile -eq '0') {
            $script:SuIssues.Add("Serv-U LogToFile=0（沒有開檔案 log）：$($suL.LogFilePath)")
            Log "Serv-U 沒有開檔案 log（LogToFile=0）：$($suL.LogFilePath)"
            Add-Manifest 'logdir' 'disabled' $suL.LogFilePath '' $null '' '' '' '' "Serv-U LogToFile=0（$($suL.Key)）"; continue
        }
        $lfp = [Environment]::ExpandEnvironmentVariables($suL.LogFilePath.Trim().Trim('"'))
        if ($lfp -notmatch '^[A-Za-z]:\\|^\\\\') { $lfp = Join-Path ([IO.Path]::GetDirectoryName($suL.Config)) $lfp }
        $pi = $lfp.IndexOf('%')
        $base = $(if ($pi -gt 0) { $lfp.Substring(0, [Math]::Max(0, $lfp.LastIndexOf('\', $pi - 1))) } else { [IO.Path]::GetDirectoryName($lfp) })
        $rx = '(?i)^' + [regex]::Replace([regex]::Escape($lfp), '%[A-Za-z]+%|%[A-Za-z]', '[^\\]*') + '$'
        if (-not $base -or -not (Test-Path -LiteralPath $base -PathType Container)) {
            $script:SuIssues.Add("Serv-U log 目錄不存在：$base")
            Add-Manifest 'logdir' 'missing' $lfp '' $null '' '' '' '' "Serv-U LogFilePath 指定，但目錄不存在（$($suL.Key)）"; continue
        }
        $w = Get-WalkFiles $base $ROOT_WALK_MAX $ROOT_WALK_SEC
        foreach ($e in $w.Errors) { ErrLog "無法列目錄 $e"; Add-Manifest 'error' 'error' $e '' $null '' '' '' '' '無法列目錄' }
        if ($w.Truncated) { $s.truncated++; ErrLog "目錄走訪截斷 $base：$($w.Truncated)"; Add-Manifest 'error' 'truncated' $base '' $null '' '' '' '' "走訪截斷：$($w.Truncated)" }
        $nm = 0; $nOld = 0; $nWin = 0   # nWin＝符合樣式且在期間內（含別的步驟已收過的）；nm＝這一步新加的
        foreach ($f in $w.Files) {
            $full = ConvertFrom-LongPath $f.FullName
            if ($full -notmatch $rx -or (Test-Inside $full $script:RunDir)) { continue }
            if ($f.LastWriteTime -lt $cutoff) { $nOld++; continue }
            $nWin++
            if ($seen.Add($full)) { $logFiles.Add($f); $nm++ }
        }
        Log "Serv-U log（LogFilePath=$($suL.LogFilePath)）：近 $Days 天符合 $nWin 個（新加入 $nm 個），更舊 $nOld 個不收"
        Add-Manifest 'logdir' 'found' $base '' $null '' '' '' '' "Serv-U LogFilePath=$($suL.LogFilePath)；LogToFile=$($suL.LogToFile)；近 $Days 天符合 $nWin 個（新加入 $nm）、更舊 $nOld 個"
        if (-not $nWin) { $script:SuIssues.Add("Serv-U log 目錄 $base 近 $Days 天沒有符合 $($suL.LogFilePath) 的檔") }
    }
    $tLog0 = Get-Date
    # 5. 複製 log（由舊到新：FileZilla slim 的連線狀態要跨輪替檔延續，順序跟報表一樣）
    #    排序＝報表的 (manifest mtime 字串, 來源路徑)，用 Ordinal 比較（跟 Python 字串比較一樣）
    #    v1.1.9 修正：原本 [Array]::Sort($keys, $items, Ordinal) 在 PowerShell 5.1 只排了 keys、沒帶動 items（實測），檔案其實沒照時間處理。
    #    改成把 key 跟檔案綁在同一個物件裡，用 List.Sort（CompareOrdinal）排。
    $lpairs = New-Object 'System.Collections.Generic.List[object]'
    foreach ($lf in @($logFiles)) { $lpairs.Add([pscustomobject]@{ K = (Ts $lf.LastWriteTime) + '|' + (ConvertFrom-LongPath $lf.FullName); F = $lf }) }
    $lpairs.Sort([Comparison[object]] { param($x, $y) [string]::CompareOrdinal($x.K, $y.K) })
    $litems = [object[]]@($lpairs | ForEach-Object { $_.F })
    # 5a. 讀取上限（-MaxLogGB）：從最新的檔往回挑，累計來源大小到上限為止（最新的一個檔一定收）；挑到的再照上面的順序由舊到新處理。
    #     沒挑到的記 manifest（skipped：超過 log 讀取上限），報表據此標「log 抽樣」，抽樣主機沒看到活動不判「沒在用」。
    if ($maxLogBytes -gt 0 -and $litems.Count -gt 0) {
        $acc = [long]0; $keepIdx = New-Object 'System.Collections.Generic.HashSet[int]'; $lastDay = $null
        for ($i = $litems.Count - 1; $i -ge 0; $i--) {
            $ln = [long]$litems[$i].Length; $dday = $litems[$i].LastWriteTime.Date
            # 一旦超過就停（不跳著挑，保持時間連續）；但以「整天」為單位：同一天的檔（例如 FileZilla 的 .log 與 .log.part2）一起收，不切半天
            if ($keepIdx.Count -gt 0 -and ($acc + $ln) -gt $maxLogBytes -and $dday -ne $lastDay) { break }
            [void]$keepIdx.Add($i); $acc += $ln; $lastDay = $dday
        }
        if ($keepIdx.Count -lt $litems.Count) {
            $kept = New-Object System.Collections.Generic.List[object]
            for ($i = 0; $i -lt $litems.Count; $i++) {
                $lf = $litems[$i]
                if ($keepIdx.Contains($i)) { $kept.Add($lf); continue }
                $logCap.files++; $logCap.bytes += [long]$lf.Length; $s.skipped++
                Add-Manifest 'log' 'skipped' (ConvertFrom-LongPath $lf.FullName) $lf.Length $lf.LastWriteTime '' '' '' 'LOG' "超過 log 讀取上限（-MaxLogGB $MaxLogGB），未讀（抽樣）"
            }
            $litems = [object[]]$kept.ToArray()
            $logCap.sampled = $true
            Log ("log 讀取上限 $MaxLogGB GB：只讀最新 {0} 個檔（{1:N0} MB，最早一個修改於 {2}），略過較舊 {3} 個檔（{4:N0} MB）" -f $litems.Count, ($acc / 1MB), (Ts $litems[0].LastWriteTime), $logCap.files, ($logCap.bytes / 1MB))
        }
    }
    # 選定要讀的 log（不論有沒有抽樣）：檔數、來源大小、最早一個的修改時間
    $logCap.keptFiles = $litems.Count; $logCap.keptBytes = [long]0
    foreach ($lf in $litems) { $logCap.keptBytes += [long]$lf.Length }
    if ($litems.Count) { $logCap.from = (Ts $litems[0].LastWriteTime) }
    $slimMode = ($FzLogMode -eq 'slim')
    foreach ($lf in $litems) { [void]$script:LogMirrors.Add([IO.Path]::GetFullPath((Get-MirrorPath (ConvertFrom-LongPath $lf.FullName)))) }
    foreach ($f in $litems) {
        $src = ConvertFrom-LongPath $f.FullName
        if ($slimMode) { Start-FzFile }   # 這個檔收集失敗時還原狀態（報表不會讀它）
        try {
            $free = (New-Object IO.DriveInfo([IO.Path]::GetPathRoot($runDir))).AvailableFreeSpace
            if ($free - $f.Length -lt $MIN_FREE) { throw 'STOP:目的磁碟剩不到 2 GB' }
            $dst = Get-MirrorPath $src
            $slim = ($slimMode -and (Test-FzLog $f))
            if ($slim) { $r = Copy-FzSlim $f $dst $maxBytes }
            else {
                $r = Copy-LogFile $f $dst $maxBytes
                # 整份複製的檔也要過 FileZilla 狀態更新（用輸出副本＝報表會看到的內容），後面輪替檔的 slim 才不會配錯
                if ($slimMode -and -not $r.Skip -and -not $r.Bad) { [void](Invoke-FzStream ([string[]]@($r.Parts)) '' 0 $false) }
            }
            if ($slimMode -and ($r.Skip -or $r.Bad)) { Undo-FzFile }
            $fmtL = $(if ($slim) { 'LOG-SLIM' } else { 'LOG-REDACTED' })
            if ($r.Skip) { $s.skipped++; ErrLog "未收集 $src：$($r.Note)"; Add-Manifest 'log' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' 'LOG' $r.Note }
            elseif (-not $r.Bad) {
                $s.log++; $s.bytes += $r.Bytes
                $copiedLogs.Add([pscustomobject]@{ Src = $src; Parts = $r.Parts; Mode = $(if ($slim) { 'slim' } else { 'raw' }); SrcBytes = $f.Length; OutBytes = $r.Bytes
                        Kept = $(if ($slim) { $r.Kept } else { '' }); Dropped = $(if ($slim) { $r.Dropped } else { '' }) })
                Add-Manifest 'log' 'collected' $src $f.Length $f.LastWriteTime $dst $r.Bytes $r.Sha $fmtL $r.Note $r.Parts
                if ($slim -and $r.Incomplete) { $s.copyErr++; ErrLog "log 不完整 $src：$($r.Incomplete)" }
            }
            else { $s.copyErr++; ErrLog "log 複製不完整 $src：$($r.Note)"; Add-Manifest 'log' 'error' $src $f.Length $f.LastWriteTime $dst $r.Bytes $r.Sha $fmtL $r.Note }
        } catch {
            if ($slimMode) { Undo-FzFile }
            if ("$($_.Exception.Message)".StartsWith('STOP:')) { throw }
            $s.copyErr++; ErrLog "收集 log 失敗 $src：$($_.Exception.Message)"
            Add-Manifest 'log' 'error' $src $f.Length $f.LastWriteTime '' '' '' '' "$($_.Exception.GetType().Name)"
        }
    }
} catch {
    $msg = "$($_.Exception.Message)" -replace '^STOP:', ''
    $endReason = "中止：$msg"; ErrLog ("$endReason（第 {0} 行）" -f $_.InvocationInfo.ScriptLineNumber); $aborted = $true
}

$tStat0 = Get-Date
# ---------- 6. log 解析：證據品質 ----------
$dates = @{}; $tot = @{ lines = [long]0; dated = [long]0; up = [long]0; down = [long]0; oth = [long]0; ok = [long]0; fail = [long]0 }
$parseIncomplete = ''; $utcFiles = 0
$psw = [Diagnostics.Stopwatch]::StartNew()
try {
    $ri = 0; $rn = $copiedLogs.Count
    foreach ($row in $copiedLogs) {
        $ri++; if ($rn -gt 1) { Write-Host ("`r  統計中：第 {0} / {1} 個 log    " -f $ri, $rn) -NoNewline; if ($ri -eq $rn) { Write-Host '' } }
        if ($psw.Elapsed.TotalSeconds -gt $LOG_PARSE_SEC) { $parseIncomplete = "超過 $LOG_PARSE_SEC 秒，部分 log 未解析"; break }
        $fd = New-Object 'System.Collections.Generic.Dictionary[string,int]'; $c = @{ lines = 0; dated = 0; up = 0; down = 0; oth = 0; ok = 0; fail = 0 }; $utc = ''
        $ca = New-Object long[] 7; $ua = [string[]]@('')
        foreach ($path in $row.Parts) {
        if ($parseIncomplete) { break }
        if ($script:FzFast) {   # 快速模式（C#），規則同下面逐行
            $fsx = Open-Source $path
            try { $pi = [FtpCollectFzEngineV120]::Stats($fsx, $UTF8, $RX_DATE, $RX_UTCZ, $RX_OP, $fd, $ca, $ua, $psw, [int]$LOG_PARSE_SEC) } finally { $fsx.Close() }
            if ($pi) { $parseIncomplete = $pi }
            continue
        }
        $sr = New-Object IO.StreamReader((Open-Source $path), $UTF8, $true)
        try {
            while ($null -ne ($line = $sr.ReadLine())) {
                $c.lines++
                $m = $RX_DATE.Match($line, 0, [Math]::Min(80, $line.Length))
                if ($m.Success) {
                    if ($m.Groups['y'].Success) { $key = '{0}-{1:00}-{2:00}' -f $m.Groups['y'].Value, [int]$m.Groups['m'].Value, [int]$m.Groups['d'].Value }
                    else { $key = '20{0}-{1:00}-{2}' -f $m.Groups['y2'].Value, $MONTHS[$m.Groups['mon'].Value.ToLower()], $m.Groups['d2'].Value }
                    if ($fd.ContainsKey($key)) { $fd[$key]++ } else { $fd[$key] = 1 }
                    $c.dated++
                    if (-not $utc) { $utc = $(if ($RX_UTCZ.IsMatch($line)) { 'Z(UTC)' } else { 'none' }) }
                }
                $o = $RX_OP.Match($line)
                if ($o.Success) {
                    if ($o.Groups['up'].Success) { $c.up++ } elseif ($o.Groups['down'].Success) { $c.down++ } elseif ($o.Groups['oth'].Success) { $c.oth++ } elseif ($o.Groups['ok'].Success) { $c.ok++ } else { $c.fail++ }
                }
                if (($c.lines % 20000) -eq 0 -and $psw.Elapsed.TotalSeconds -gt $LOG_PARSE_SEC) { $parseIncomplete = "超過 $LOG_PARSE_SEC 秒，部分 log 未解析完"; break }
            }
        } finally { $sr.Close() }
        }
        if ($script:FzFast) { $c.lines = $ca[0]; $c.dated = $ca[1]; $c.up = $ca[2]; $c.down = $ca[3]; $c.oth = $ca[4]; $c.ok = $ca[5]; $c.fail = $ca[6]; $utc = $ua[0] }
        $valid = @($fd.Keys | Where-Object { $d = [datetime]::MinValue; [datetime]::TryParseExact($_, 'yyyy-MM-dd', $null, 'None', [ref]$d) } | Sort-Object)
        foreach ($kk in $valid) { if ($dates.ContainsKey($kk)) { $dates[$kk] += $fd[$kk] } else { $dates[$kk] = $fd[$kk] } }
        if ($utc -eq 'Z(UTC)') { $utcFiles++ }
        $first = ''; $last = ''; if ($valid.Count) { $first = $valid[0]; $last = $valid[-1] }
        Csv $covCsv @($row.Src, $first, $last, $c.lines, $c.dated, $c.up, $c.down, $c.oth, $c.ok, $c.fail, $utc, $row.Mode, $row.SrcBytes, $row.OutBytes, $row.Kept, $row.Dropped)
        foreach ($kk in @('lines', 'dated', 'up', 'down', 'oth', 'ok', 'fail')) { $tot[$kk] += $c[$kk] }
        if ($parseIncomplete) { break }
    }
} catch { ErrLog "log 解析失敗（第 $($_.InvocationInfo.ScriptLineNumber) 行）：$($_.Exception.Message)"; if (-not $parseIncomplete) { $parseIncomplete = '解析時發生錯誤' } }
$winStart = $start.Date.AddDays(-$Days).ToString('yyyy-MM-dd')
$beforeWin = @($dates.Keys | Where-Object { $_ -lt $winStart }).Count
$dkeys = @($dates.Keys | Where-Object { $_ -ge $winStart } | Sort-Object)   # 只算 -Days 期間內的日期
$earliest = ''; $latest = ''; $span = 0; $missing = @()
if ($dkeys.Count) {
    $earliest = $dkeys[0]; $latest = $dkeys[-1]
    $d0 = [datetime]::ParseExact($earliest, 'yyyy-MM-dd', $null); $d1 = [datetime]::ParseExact($latest, 'yyyy-MM-dd', $null)
    $span = [int]($d1 - $d0).TotalDays + 1
    for ($d = $d0; $d -le $d1; $d = $d.AddDays(1)) { if (-not $dates.ContainsKey($d.ToString('yyyy-MM-dd'))) { $missing += $d.ToString('yyyy-MM-dd') } }
}
$transfers = ($tot.up + $tot.down) -gt 0
$covered = $dkeys.Count
$eqRows = @(
    @('days_requested', $Days), @('window_start', $winStart), @('dates_before_window_ignored', $beforeWin), @('log_files_collected', $s.log), @('log_earliest_date', $earliest), @('log_latest_date', $latest),
    @('span_days', $span), @('days_with_entries', $covered), @('missing_days_count', $missing.Count), @('missing_days', (($missing | Select-Object -First 120) -join ';')),
    @('coverage_meets_requested', $(if ($covered -ge $Days -and -not $logCap.sampled) { 'yes' } else { 'no' })),
    @('log_sampled', $(if ($logCap.sampled) { 'yes' } else { 'no' })), @('log_read_cap_gb', $MaxLogGB), @('log_cap_skipped_files', $logCap.files), @('log_cap_skipped_bytes', $logCap.bytes),
    @('log_selected_files', $logCap.keptFiles), @('log_selected_source_bytes', $logCap.keptBytes), @('log_selected_earliest_mtime', $logCap.from),
    @('transfers_logged', $(if ($transfers) { 'yes' } else { 'no' })), @('upload_lines', $tot.up), @('download_lines', $tot.down), @('other_op_lines', $tot.oth),
    @('login_ok_lines', $tot.ok), @('login_fail_lines', $tot.fail), @('lines_total', $tot.lines), @('lines_dated', $tot.dated),
    @('files_with_utc_Z_timestamps', $utcFiles), @('parse_complete', $(if ($parseIncomplete) { "no：$parseIncomplete" } else { 'yes' })),
    @('logging_settings', (($logSettingText | Select-Object -First 40) -join ' | ')), @('log_dirs_from_config', ($logDirs -join ';')),
    @('host_timezone', [TimeZoneInfo]::Local.Id), @('host_utc_offset_now', [TimeZoneInfo]::Local.GetUtcOffset((Get-Date)).ToString()),
    @('note', '日期以 log 原文為準；有 Z 的是 UTC。行數為粗略比對（指令字樣），帳號級／目錄級統計由集中整理程式做。')
)
Csv $eqCsv @('key', 'value')
foreach ($r in $eqRows) { Csv $eqCsv $r }
Log "log：$($s.log) 個檔，日期 $earliest ～ $latest，有資料 $covered 天、缺 $($missing.Count) 天，傳輸紀錄：$(if ($transfers) { '有' } else { '沒有' })"

$tStat1 = Get-Date
# ---------- 7. 主機資訊：OS、IP、時區、時鐘、服務（含執行身分）、監聽埠 ----------
try {
    foreach ($a in @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True')) {
        foreach ($x in @($a.IPAddress)) { if ($x -match '^\d+\.\d+\.\d+\.\d+$') { Csv $hostInfo @('ipv4', $a.Description, $x) } }
    }
    $os = Get-CimInstance Win32_OperatingSystem
    Csv $hostInfo @('os', $os.Caption, $os.Version)
    Csv $hostInfo @('os', 'last_boot', (Ts $os.LastBootUpTime))
} catch { ErrLog "取 OS／IP 資訊失敗：$($_.Exception.Message)" }
try {
    $tz = [TimeZoneInfo]::Local; $now = Get-Date
    Csv $hostInfo @('timezone', 'id', $tz.Id)
    Csv $hostInfo @('timezone', 'display', $tz.DisplayName)
    Csv $hostInfo @('timezone', 'base_utc_offset', $tz.BaseUtcOffset.ToString())
    Csv $hostInfo @('timezone', 'current_utc_offset', $tz.GetUtcOffset($now).ToString())
    Csv $hostInfo @('timezone', 'dst_now', $tz.IsDaylightSavingTime($now))
    Csv $hostInfo @('clock', 'local', $now.ToString('yyyy-MM-dd HH:mm:ss.fff'))
    Csv $hostInfo @('clock', 'utc', $now.ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss.fff'))
    try {   # 校時設定（唯讀讀登錄檔）
        $tp = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters' -ErrorAction Stop
        Csv $hostInfo @('clock', 'w32time_type', [string]$tp.Type)
        Csv $hostInfo @('clock', 'w32time_ntpserver', [string]$tp.NtpServer)
        $ws = Get-CimInstance Win32_Service -Filter "Name='W32Time'"
        if ($ws) { Csv $hostInfo @('clock', 'w32time_service', "$($ws.State)／$($ws.StartMode)") }
    } catch { Csv $hostInfo @('clock', 'w32time', '讀不到') }
} catch { ErrLog "取時區／時鐘失敗：$($_.Exception.Message)" }
$procNames = @{}
try { foreach ($p in @(Get-Process)) { $procNames[[int]$p.Id] = $p.ProcessName } } catch { }
foreach ($svc in $services) {
    $exe = Get-ExePath ([string]$svc.PathName)
    $ver = ''; try { if ($exe -and (Test-Path -LiteralPath $exe)) { $ver = (Get-Item -LiteralPath $exe).VersionInfo.ProductVersion } } catch { }
    Csv $hostInfo @('service', $svc.Name, "顯示名=$($svc.DisplayName)；狀態=$($svc.State)；啟動=$($svc.StartMode)；執行身分=$($svc.StartName)；版本=$ver；PID=$($svc.ProcessId)；$(Protect-Value ([string]$svc.PathName))")
}
$listenPorts = New-Object 'System.Collections.Generic.HashSet[int]'
try {
    $conns = @(Get-NetTCPConnection -State Listen -ErrorAction Stop)
    foreach ($c in $conns) {
        if (($ftpPids -contains [int]$c.OwningProcess) -or (@(20, 21, 22, 989, 990) -contains [int]$c.LocalPort)) {
            $pn = ''; if ($procNames.ContainsKey([int]$c.OwningProcess)) { $pn = $procNames[[int]$c.OwningProcess] }
            Csv $hostInfo @('listen', "pid $($c.OwningProcess) $pn", "$($c.LocalAddress):$($c.LocalPort)")
            [void]$listenPorts.Add([int]$c.LocalPort)
        }
    }
} catch {
    foreach ($ln in @(netstat -ano -p tcp | Select-String 'LISTENING')) {
        $p = ($ln.ToString().Trim() -split '\s+')
        if ($p.Count -ge 5) {
            $port = 0; [void][int]::TryParse(($p[1] -split ':')[-1], [ref]$port)
            if (($ftpPids -contains [int]$p[4]) -or (@(20, 21, 22, 989, 990) -contains $port)) { Csv $hostInfo @('listen', "pid $($p[4])", $p[1]); [void]$listenPorts.Add($port) }
        }
    }
}
foreach ($p in $cfgPorts) { Csv $hostInfo @('config_port', '', $p) }
foreach ($r in $cfgRanges) { Csv $hostInfo @('config_port_range', '', "$($r[0])-$($r[1])") }

# ---------- 8. 防火牆（跟 FTP 埠或程式有關的規則） ----------
Csv $fwCsv @('display_name', 'rule_id', 'enabled', 'direction', 'action', 'profile', 'protocol', 'local_port', 'remote_address', 'program', 'match')
try {
    $ports = New-Object 'System.Collections.Generic.HashSet[int]'
    foreach ($p in @(20, 21, 22, 989, 990)) { [void]$ports.Add($p) }
    foreach ($p in $listenPorts) { [void]$ports.Add($p) }
    foreach ($p in $cfgPorts) { [void]$ports.Add($p) }
    $pf = @{}; foreach ($x in @(Get-NetFirewallPortFilter -All -PolicyStore ActiveStore -ErrorAction Stop)) { $pf[$x.InstanceID] = $x }
    $af = @{}; foreach ($x in @(Get-NetFirewallApplicationFilter -All -PolicyStore ActiveStore -ErrorAction Stop)) { $af[$x.InstanceID] = $x }
    $adf = @{}; foreach ($x in @(Get-NetFirewallAddressFilter -All -PolicyStore ActiveStore -ErrorAction Stop)) { $adf[$x.InstanceID] = $x }
    $nfw = 0
    foreach ($rule in @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop)) {
        $id = $rule.InstanceID
        $lp = ''; $proto = ''; $prog = ''; $ra = ''
        if ($pf.ContainsKey($id)) { $lp = (@($pf[$id].LocalPort) -join ','); $proto = [string]$pf[$id].Protocol }
        if ($af.ContainsKey($id)) { $prog = [string]$af[$id].Program }
        if ($adf.ContainsKey($id)) { $ra = (@($adf[$id].RemoteAddress) -join ',') }
        $why = @()
        if ("$($rule.DisplayName) $prog" -match '(?i)ftp|serv-?u|filezilla|rhinosoft|sftp|ssh') { $why += 'name/program' }
        foreach ($e in $ftpExes) { if ($prog -and ([Environment]::ExpandEnvironmentVariables($prog) -ieq $e)) { $why += 'service exe' } }
        if ($lp -and (Test-PortSpec @($pf[$id].LocalPort) $ports $cfgRanges)) { $why += 'port' }
        $isFtpProg = $false; foreach ($e in $ftpExes) { if ($prog -and ([Environment]::ExpandEnvironmentVariables($prog) -ieq $e)) { $isFtpProg = $true } }
        if ($lp -eq 'Any' -and [string]$rule.Direction -eq 'Inbound' -and ($proto -match '^(TCP|Any)$') -and (-not $prog -or $prog -eq 'Any' -or $isFtpProg)) { $why += 'any-port' }
        if ($why.Count) { Csv $fwCsv @($rule.DisplayName, $id, $rule.Enabled, $rule.Direction, $rule.Action, $rule.Profile, $proto, $lp, $ra, $prog, ($why -join '+')); $nfw++ }
    }
    foreach ($pr in @(Get-NetFirewallProfile -PolicyStore ActiveStore -ErrorAction Stop)) { Csv $hostInfo @('firewall_profile', $pr.Name, "Enabled=$($pr.Enabled)；DefaultInbound=$($pr.DefaultInboundAction)") }
    Log "防火牆相關規則：$nfw 筆"
} catch { ErrLog "讀防火牆規則失敗：$($_.Exception.Message)" }

# ---------- 9. 帳號／目錄輸出 ----------
foreach ($gd in @($script:Dirs | Where-Object { $_.ownerKind -eq 'group' -and $_.raw })) {
    # 群組的掛載點展開到每個成員（權限來源＝群組），帳號變數代入成員名稱
    foreach ($a in @($script:Accounts | Where-Object { $_.kind -eq 'user' -and $_.product -eq $gd.product -and (@(([string]$_.groups) -split ';') -contains $gd.owner) })) {
        $rp = Resolve-NativePath $gd.raw $a.name $gd.domain
        if ($rp) { if (-not $gd.physical) { $gd.expanded = $true }; $script:Dirs.Add([pscustomobject]@{ product = $gd.product; config = $gd.config; domain = $gd.domain; ownerKind = 'user-via-group'; owner = $a.name; virtual = $gd.virtual
                    raw = $gd.raw; physical = $rp; perm = $gd.perm; isHome = $gd.isHome; method = "$($gd.method);via-group:$($gd.owner)" }) }
    }
}
$unresolved = @($script:Dirs | Where-Object { $_.raw -and -not $_.physical -and -not $_.expanded })
foreach ($u in $unresolved) { Log "目錄路徑無法展開：$($u.owner) $($u.raw)" }
$physDirs = @($script:Dirs | Where-Object { $_.physical } | ForEach-Object { $_.physical } | Sort-Object -Unique)
foreach ($a in $script:Accounts) { Csv $accCsv @($a.product, $a.config, $a.domain, $a.name, $a.kind, $a.enabled, $a.groups, $a.allow, $a.deny, $a.method) }
foreach ($d in $script:Dirs) { Csv $dirCsv @($d.product, $d.config, $d.domain, $d.ownerKind, $d.owner, $d.virtual, $d.raw, $d.physical, $d.perm, $d.isHome, $d.method) }
foreach ($u in $script:SuUsers) { Csv $suCsv @($u.domain, $u.name, $u.kind, $u.full, $u.home, $u.up, $u.down, $u.bup, $u.bdown, $u.since, $u.last, $u.lastOut, $u.cfg) }
# Serv-U 伺服器設定摘要（log 位置、LDAP 驗證；AD／LDAP 登入屬個人，不納入轉置，只記錄）
$suLdapText = ''
if ($script:SuMain.Count) {
    foreach ($suL in $script:SuLog) { Csv $hostInfo @('servu_log', $suL.Key, "LogFilePath=$($suL.LogFilePath)；LogToFile=$($suL.LogToFile)") }
    $ldOn = @($script:SuLdap | Where-Object { $tk = @(Get-KeyTokens $_.Key); (($tk -contains 'enable') -or ($tk -contains 'enabled') -or ($tk -contains 'use') -or ($tk -contains 'auth') -or ($tk -contains 'authentication')) -and $_.Value -match '^(?i)(0|1|true|false|yes|no)$' } | Select-Object -First 1)
    $ldSrv = @($script:SuLdap | Where-Object { $tk = @(Get-KeyTokens $_.Key); (($tk -contains 'server') -or ($tk -contains 'host') -or ($tk -contains 'address') -or ($tk -contains 'url') -or ($tk -contains 'uri')) -and $_.Value } | ForEach-Object { $_.Value } | Select-Object -Unique -First 5)
    $ldEn = $(if ($ldOn.Count) { "$($ldOn[0].Key)=$($ldOn[0].Value)" } elseif ($script:SuLdap.Count) { '有 LDAP 設定（啟用欄位待確認）' } else { '設定裡沒有 LDAP 欄位' })
    $suLdapText = "LDAP 驗證：$ldEn；伺服器：$(if ($ldSrv.Count) { $ldSrv -join ',' } else { '（無）' })（AD 登入屬個人，不納入轉置，只記錄）"
    Csv $hostInfo @('servu_ldap', 'enabled', $ldEn)
    Csv $hostInfo @('servu_ldap', 'server', ($ldSrv -join ','))
    foreach ($l in $script:SuLdap) { Csv $hostInfo @('servu_ldap_raw', $l.Path, $l.Value) }
    Log "Serv-U $suLdapText"
}
Log "帳號／群組 $($script:Accounts.Count) 筆，目錄對應 $($script:Dirs.Count) 筆，實體目錄 $($physDirs.Count) 個"

# ---------- 10. 排程（指到 FTP 程式或帳號目錄的） ----------
Csv $taskCsv @('task_path', 'task_name', 'state', 'run_as', 'logon_type', 'execute', 'arguments', 'working_dir', 'triggers', 'last_run', 'last_result', 'next_run', 'match')
try {
    $needles = @($physDirs + $roots | Where-Object { $_ } | Select-Object -First 300)
    $nt = 0
    foreach ($t in @(Get-ScheduledTask -ErrorAction Stop)) {
        $acts = @($t.Actions)
        $txt = (@($acts | ForEach-Object { "$(CimVal $_ 'Execute') $(CimVal $_ 'Arguments') $(CimVal $_ 'WorkingDirectory')" }) -join ' | ')
        $why = ''
        if ($txt -match '(?i)ftp|winscp|psftp|pscp|filezilla|serv-?u|rhinosoft') { $why = 'keyword' }
        else { foreach ($n in $needles) { if ($txt.IndexOf($n, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $why = 'path'; break } } }
        if (-not $why) { continue }
        $ti = $null; try { $ti = Get-ScheduledTaskInfo -InputObject $t -ErrorAction Stop } catch { }
        $trig = (@($t.Triggers | Where-Object { $_ } | ForEach-Object { $_.CimClass.CimClassName -replace '^MSFT_Task', '' -replace 'Trigger$', '' }) -join ';')
        foreach ($a in $acts) {
            Csv $taskCsv @($t.TaskPath, $t.TaskName, $t.State, (CimVal $t.Principal 'UserId'), (CimVal $t.Principal 'LogonType'), (Protect-Value ([string](CimVal $a 'Execute'))),
                (Protect-Value ([string](CimVal $a 'Arguments'))), (CimVal $a 'WorkingDirectory'), $trig,
                $(if ($ti) { Ts $ti.LastRunTime } else { '' }), $(if ($ti) { $ti.LastTaskResult } else { '' }), $(if ($ti) { Ts $ti.NextRunTime } else { '' }), $why)
        }
        $nt++
    }
    Log "相關排程：$nt 個"
} catch { ErrLog "讀排程失敗：$($_.Exception.Message)" }

# ---------- 11. SMB 分享 ----------
Csv $shareCsv @('share', 'path', 'type', 'description', 'related_to_ftp_dir', 'share_access')
try {
    foreach ($sh in @(Get-CimInstance Win32_Share -ErrorAction Stop)) {
        $rel = ''
        if ($sh.Path -and [long]$sh.Type -eq 0) { foreach ($d in @($physDirs + $roots)) { if ($d -and ((Test-Inside $d $sh.Path) -or (Test-Inside $sh.Path $d))) { $rel = $d; break } } }
        $acc = ''
        if ($rel) { try { $acc = (@(Get-SmbShareAccess -Name $sh.Name -ErrorAction Stop | ForEach-Object { "$($_.AccountName):$($_.AccessControlType):$($_.AccessRight)" }) -join ';') } catch { $acc = '（讀不到）' } }
        Csv $shareCsv @($sh.Name, $sh.Path, $sh.Type, $sh.Description, $rel, $acc)
    }
} catch { ErrLog "讀 SMB 分享失敗：$($_.Exception.Message)" }

# ---------- 12. 憑證（只讀憑證，不碰私鑰；對應到引用它的設定） ----------
$certDone = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
function Write-CertRows([string]$source, [string]$file, [string]$refBy, [byte[]]$data, [string]$text) {
    $n = 0
    if ($text -and $text -match '-----BEGIN CERTIFICATE-----') {
        foreach ($m in [regex]::Matches($text, '-----BEGIN CERTIFICATE-----([A-Za-z0-9+/=\s]+)-----END CERTIFICATE-----')) {
            try {
                $cb = [Convert]::FromBase64String(($m.Groups[1].Value -replace '\s', ''))
                if ([Security.Cryptography.X509Certificates.X509Certificate2]::GetCertContentType($cb) -ne [Security.Cryptography.X509Certificates.X509ContentType]::Cert) { throw '不是單純憑證' }
                $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2(, $cb)
                Csv $certCsv @($source, $file, $refBy, $c.Subject, $c.Issuer, $c.NotBefore.ToString('yyyy/MM/dd'), $c.NotAfter.ToString('yyyy/MM/dd'), $c.Thumbprint, ''); $n++
            } catch { Csv $certCsv @($source, $file, $refBy, '', '', '', '', '', "解析失敗（$($_.Exception.GetType().Name)）") }
        }
    } elseif ($data) {
        try {
            if ([Security.Cryptography.X509Certificates.X509Certificate2]::GetCertContentType($data) -ne [Security.Cryptography.X509Certificates.X509ContentType]::Cert) { throw '不是單純憑證（可能含私鑰），不解析' }
            $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2(, $data); Csv $certCsv @($source, $file, $refBy, $c.Subject, $c.Issuer, $c.NotBefore.ToString('yyyy/MM/dd'), $c.NotAfter.ToString('yyyy/MM/dd'), $c.Thumbprint, 'DER'); $n++ } catch { }
    }
    if (-not $n) { Csv $certCsv @($source, $file, $refBy, '', '', '', '', '', '檔內沒有可讀的憑證') }
}
try {
    $allCertPaths = @(@($certFiles | ForEach-Object { ConvertFrom-LongPath $_.FullName }) + @($certRefs.Keys)) | Select-Object -Unique
    foreach ($cp in $allCertPaths) {
        if (-not $certDone.Add($cp)) { continue }
        $refBy = ''; if ($certRefs.ContainsKey($cp)) { $refBy = ($certRefs[$cp] -join ' ; ') }
        $ext = [IO.Path]::GetExtension($cp).ToLower()
        if ($ext -eq '.key') { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', '私鑰檔：不讀，只記位置'); continue }
        if ($ext -eq '.pfx' -or $ext -eq '.p12') { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', 'PFX 需密碼：不讀，只記位置'); continue }
        if (-not (Test-Path -LiteralPath $cp -PathType Leaf)) { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', '設定指定，但檔案不存在'); continue }
        try {
            $r = Read-AllShared $cp $MAX_CERT
            if ($null -eq $r[0]) { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', $r[1]); continue }
            $txt = $null; if ([Array]::IndexOf([byte[]]$r[0], [byte]0) -lt 0) { $txt = [Text.Encoding]::ASCII.GetString([byte[]]$r[0]) }
            Write-CertRows 'file' $cp $refBy ([byte[]]$r[0]) $txt
        } catch { ErrLog "讀憑證失敗 $cp：$($_.Exception.Message)" }
    }
    foreach ($ic in $inlineCerts) { Write-CertRows 'inline' '' $ic.Ref $null $ic.Text }
} catch { ErrLog "憑證步驟失敗：$($_.Exception.Message)" }

# ---------- 13. 目錄摘要（不帶完整檔名）＋ NTFS ACL ----------
Csv $aclCsv @('path', 'owner', 'access_rules_protected', 'identity', 'rights', 'type', 'inherited', 'inheritance_flags', 'propagation_flags')
$gsw = [Diagnostics.Stopwatch]::StartNew()
$sumTrunc = 0; $sumMissing = 0; $sumErr = 0
foreach ($d in $physDirs) {
    if (Test-Inside $d $OutDir) { Log "目錄在存放目錄裡，不掃：$d"; continue }
    try {
        $scanAt = Get-Date
        $r = Get-DirSummary $d $cutoff $gsw
        $top = (@($r.patterns.GetEnumerator() | Sort-Object -Property @{ Expression = 'Value'; Descending = $true }, @{ Expression = 'Name'; Descending = $false } | Select-Object -First 10 | ForEach-Object { "$($_.Name)×$($_.Value)" }) -join ' | ')
        if ($r.other) { $top += " | (超過 $MAX_PATTERNS 種樣式，其餘 $($r.other) 個檔未分類)" }
        Csv $sumCsv @($d, $r.exists, $Days, $r.files, $r.bytes, $top, (Ts $r.newest), $r.old, $r.dirs, $r.seconds, $r.truncated, $r.errors, $r.links, (Ts $scanAt))
        foreach ($sk in @($r.subs.Keys | Sort-Object)) {
            $sb = $r.subs[$sk]
            $stop = (@($sb.patterns.GetEnumerator() | Sort-Object -Property @{ Expression = 'Value'; Descending = $true }, @{ Expression = 'Name'; Descending = $false } | Select-Object -First 5 | ForEach-Object { "$($_.Name)×$($_.Value)" }) -join ' | ')
            Csv $subCsv @($d, $sk, $Days, $sb.files, $sb.bytes, $stop, (Ts $sb.newest), $sb.old, $r.truncated)
        }
        if ($r.truncated) { $sumTrunc++ }
        if ($r.errors) { $sumErr++ }
        if ($r.exists -ne 'yes') { $sumMissing++; continue }
        $acl = Get-Acl -LiteralPath $d
        foreach ($rule in @($acl.Access)) {
            Csv $aclCsv @($d, $acl.Owner, $acl.AreAccessRulesProtected, $rule.IdentityReference, $rule.FileSystemRights, $rule.AccessControlType, $rule.IsInherited, $rule.InheritanceFlags, $rule.PropagationFlags)
        }
    } catch { ErrLog "目錄摘要／ACL 失敗 $d：$($_.Exception.Message)" }
}
Log "目錄摘要 $($physDirs.Count) 個（截斷 $sumTrunc、不存在 $sumMissing），花 $([int]$gsw.Elapsed.TotalSeconds) 秒"

# ---------- 14. 狀態判定 ----------
$reasons = New-Object System.Collections.Generic.List[string]
if ($aborted) { $status = 'FAIL'; $reasons.Add($endReason) }
elseif (-not $s.found -and $s.denied) { $status = 'FAIL'; $reasons.Add("$($s.denied) 個安裝目錄存取被拒") }
elseif (-not $s.found) { $status = 'FAIL'; $reasons.Add('找不到 Serv-U／FileZilla 目錄（裝在別處請用 -ExtraPaths）') }
elseif (-not $s.main) { $status = 'FAIL'; $reasons.Add('找到目錄但沒收到主設定檔（看 manifest）') }
else {
    $status = 'OK'
    if ($script:ErrCount) { $reasons.Add("錯誤 $script:ErrCount 筆（看 _error_log.txt）") }
    if ($s.skipped) { $reasons.Add("$($s.skipped) 個檔未收集（看 manifest）") }
    if ($logCap.sampled) { $reasons.Add("log 抽樣：超過讀取上限 $MaxLogGB GB，較舊 $($logCap.files) 個 log 未讀（只讀最新 $($logCap.keptFiles) 個）") }
    if ($s.copyErr) { $reasons.Add("$($s.copyErr) 個檔讀取／複製不完整") }
    if (-not $script:Accounts.Count) { $reasons.Add('沒解析出帳號') }
    if ($s.generic) { $reasons.Add("$($s.generic) 個設定檔用通用遮罩，需人工抽看") }
    if (-not $s.log) { $reasons.Add("近 $Days 天沒有 log（log 可能沒開或在別處）") }
    elseif (-not $latest) { $reasons.Add('log 裡讀不到日期') }
    elseif ([datetime]::ParseExact($latest, 'yyyy-MM-dd', $null) -lt $start.Date.AddDays(-2)) { $reasons.Add("最新 log 日期 $latest 早於 2 天前") }
    if ($parseIncomplete) { $reasons.Add("log 解析未完成：$parseIncomplete") }
    if ($s.truncated) { $reasons.Add("$($s.truncated) 個安裝／log 目錄走訪截斷") }
    if ($sumTrunc) { $reasons.Add("$sumTrunc 個目錄摘要截斷") }
    if ($sumErr) { $reasons.Add("$sumErr 個目錄有子目錄讀不到（權限）") }
    if ($sumMissing) { $reasons.Add("$sumMissing 個設定的目錄不存在（看 dir_summary）") }
    if ($unresolved.Count) { $reasons.Add("$($unresolved.Count) 個目錄路徑無法展開（看 dirs.csv）") }
    foreach ($suI in $script:SuIssues) { $reasons.Add($suI) }
    if ($reasons.Count) { $status = 'PARTIAL' }
}
$typeStr = (@($script:types | Select-Object -Unique) -join '+'); if (-not $typeStr) { $typeStr = 'auto' }
Csv $runCsv @('#', 'IP', 'Type', '狀態', '原因', '主設定檔', '設定檔', '已遮密碼檔', '通用遮罩檔', 'log 檔', 'log 起', 'log 訖', '有資料天數', '缺日數', '有傳輸紀錄', '帳號群組數', '實體目錄數', '未收集', 'MB', 'Note')
Csv $runCsv @(1, $ip, $typeStr, $status, ($reasons -join '；'), $s.main, $s.config, $s.masked, $s.generic, $s.log, $earliest, $latest, $covered, $missing.Count,
    $(if ($transfers) { 'yes' } else { 'no' }), $script:Accounts.Count, $physDirs.Count, $s.skipped, [Math]::Round($s.bytes / $CHUNK, 1), $hostName)
if ($suLdapText) { Add-OutText $info ("Serv-U $suLdapText`r`n") }

# ---------- 14b. log 摘要（v1.3.0）：照報表的解析規則在主機上算好，上傳只帶摘要；log 副本留在本機結果資料夾當證據 ----------
$sumRes = @{ Ok = $false; Msg = '沒有收到 log'; Rows = 0; Events = [long]0; Bytes = [long]0; Sec = 0 }
if ($copiedLogs.Count -and "$parseIncomplete".StartsWith('超過')) {
    $sumRes.Msg = "第 6 步 log 統計已超過時間上限（$parseIncomplete），不再做摘要"
    Log "log 摘要沒有產生（$($sumRes.Msg)）：上傳時照舊連 log 副本一起傳，報表照舊讀 log" 'Yellow'
}
elseif ($copiedLogs.Count) {
    Log "log 摘要：照報表規則逐行解析 $($copiedLogs.Count) 個 log 副本…"
    $sumRes = Write-LogSummary $runDir $hdir "FtpCollect.ps1 $VERSION"
    if ($sumRes.Ok) { Log ("log 摘要：{0:N0} 列（事件 {1:N0} 筆），{2:N0} KB，花 {3} 秒" -f $sumRes.Rows, $sumRes.Events, ($sumRes.Bytes / 1KB), $sumRes.Sec) 'Green' }
    else { Log "log 摘要沒有產生（$($sumRes.Msg)）：上傳時照舊連 log 副本一起傳，報表照舊讀 log" 'Yellow'; if ($sumRes.Msg -like '摘要失敗*') { ErrLog "log 摘要失敗：$($sumRes.Msg)" } }
}
Add-OutText $info ("log 摘要：$(if ($sumRes.Ok) { "有（log_events_agg.csv $($sumRes.Rows) 列、事件 $($sumRes.Events) 筆）" } else { "沒有（$($sumRes.Msg)）" })`r`n")
Add-OutText $info ("結束：$(Ts (Get-Date))（$endReason）`r`n狀態：$status`r`n原因：$($reasons -join '；')`r`n")

Log ''
Log "狀態：$status" $(if ($status -eq 'OK') { 'Green' } else { 'Yellow' })
if ($reasons.Count) { Log "原因：$($reasons -join '；')" 'Yellow' }
Log "主設定檔 $($s.main)、設定檔 $($s.config)（遮密碼 $($s.masked)、通用遮罩 $($s.generic)）、log $($s.log)、未收集 $($s.skipped)、共 $([Math]::Round($s.bytes / $CHUNK, 1)) MB"
Log "結果資料夾：$runDir"
Log "執行紀錄：$script:LogFile；錯誤紀錄：$script:ErrFile（錯誤 $script:ErrCount 筆）"
function Fmt-Dur($a, $b) { if (-not $a -or -not $b) { return '—' }; $t = $b - $a; if ($t.TotalHours -ge 1) { return ('{0} 小時 {1} 分' -f [int][Math]::Floor($t.TotalHours), $t.Minutes) }; if ($t.TotalMinutes -ge 1) { return ('{0} 分 {1} 秒' -f [int][Math]::Floor($t.TotalMinutes), $t.Seconds) }; return ('{0} 秒' -f [int]$t.TotalSeconds) }
$tLogA = $(if (Get-Variable tLog0 -ErrorAction SilentlyContinue) { $tLog0 } else { $null })
$tSA = $(if (Get-Variable tStat0 -ErrorAction SilentlyContinue) { $tStat0 } else { $null })
$tSB = $(if (Get-Variable tStat1 -ErrorAction SilentlyContinue) { $tStat1 } else { $null })
$tEnd = Get-Date
$durText = "花費時間：總共 $(Fmt-Dur $start $tEnd)（log 收集 $(Fmt-Dur $tLogA $tSA)、log 統計 $(Fmt-Dur $tSA $tSB)、目錄摘要 $(if (Get-Variable gsw -ErrorAction SilentlyContinue) { "$([int]$gsw.Elapsed.TotalSeconds) 秒" } else { "—" })）；開始 $(Ts $start)，結束 $(Ts $tEnd)"
Log $durText 'Cyan'
Add-OutText $info ($durText + "`r`n")

# ---------- 15. 上傳結果到 FTP（v1.2.1；ftpid.txt 有填 host 才做）----------
# 不壓縮（壓縮在正式機上吃 CPU）；在遠端建 <dir>/<日期>/<run 資料夾名>/…，照原目錄結構逐檔上傳、逐檔核對大小；限速（預設每秒 2 MB）避免塞網路。
$upOk = $false
if ($script:Up) {
    $U = $script:Up; $leaf = Split-Path $runDir -Leaf
    $runL = ConvertTo-LongPath $runDir
    $allF = @([IO.Directory]::GetFiles($runL, '*', [IO.SearchOption]::AllDirectories))
    # v1.3.0：有摘要就不傳 log 副本（含分段 .partN／.splitN；manifest 照樣列著，報表知道有收）；ftpid.txt upload_logs=1 才傳
    if ($sumRes.Ok -and -not $U.Logs) {
        $keepF = New-Object System.Collections.Generic.List[string]; $nLog = 0; $bLog = [long]0
        foreach ($zp in $allF) {
            $zf = [IO.Path]::GetFullPath((ConvertFrom-LongPath $zp)); $isLog = $false
            foreach ($lm in $script:LogMirrors) {
                if ($zf.Equals($lm, [StringComparison]::OrdinalIgnoreCase) -or $zf.StartsWith("$lm.part", [StringComparison]::OrdinalIgnoreCase) -or $zf.StartsWith("$lm.split", [StringComparison]::OrdinalIgnoreCase)) { $isLog = $true; break }
            }
            if ($isLog) { $nLog++; $bLog += (New-Object IO.FileInfo($zp)).Length } else { $keepF.Add($zp) }
        }
        $allF = @($keepF.ToArray())
        Log ("log 副本 {0} 個檔（{1:N0} MB）留在本機結果資料夾、不上傳（已有 log 摘要；要連 log 一起傳請在 ftpid.txt 設 upload_logs=1）" -f $nLog, ($bLog / 1MB))
    } elseif ($U.Logs) { Log 'ftpid.txt 設了 upload_logs=1：log 副本一起上傳' }
    elseif ($copiedLogs.Count) { Log "沒有 log 摘要（$($sumRes.Msg)）：log 副本照舊一起上傳" 'Yellow' }
    $totUp = [long]0; foreach ($zp in $allF) { $totUp += (New-Object IO.FileInfo($zp)).Length }
    Log ("上傳到 FTP：{0}/{1}（{2} 個檔、{3:N0} MB，{4}）…" -f $U.Show, $leaf, $allF.Count, ($totUp / 1MB), $(if ($U.Lim -gt 0) { "限速每秒 $($U.Lim) MB" } else { '不限速' }))
    $usw = [Diagnostics.Stopwatch]::StartNew(); $ulast = 0; $sent = [long]0; $nOk = 0; $nNoSize = 0
    $fails = New-Object System.Collections.Generic.List[string]; $ubuf = New-Object byte[] 262144
    foreach ($zp in $allF) {
        $rel = $zp.Substring($runL.Length).TrimStart('\')
        $rs = @($rel.Split('\') | Where-Object { $_ })
        $dsegs = @($U.Segs) + @($leaf) + @($rs | Select-Object -First ($rs.Count - 1))
        for ($q = 1; $q -le $dsegs.Count; $q++) { Up-Mkd @($dsegs | Select-Object -First $q) }
        $uri = Up-Uri (@($U.Segs) + @($leaf) + $rs)
        $flen = (New-Object IO.FileInfo($zp)).Length
        for ($try = 1; $try -le 3; $try++) {
            $mark = $sent
            try {
                $rq = Up-Req $uri 'STOR'
                $in = [IO.File]::Open($zp, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite); $os = $null
                try {
                    $os = $rq.GetRequestStream()
                    while (($uk = $in.Read($ubuf, 0, $ubuf.Length)) -gt 0) {
                        $os.Write($ubuf, 0, $uk); $sent += $uk
                        if ($U.Lim -gt 0) { $want = $sent / ($U.Lim * 1MB) * 1000 - $usw.ElapsedMilliseconds; if ($want -gt 0) { [Threading.Thread]::Sleep([int][Math]::Min(2000, $want)) } }
                        if (($usw.ElapsedMilliseconds - $ulast) -ge 5000) {
                            $ulast = $usw.ElapsedMilliseconds; $urate = $sent / [Math]::Max(0.001, $usw.Elapsed.TotalSeconds)
                            Write-Host ("`r  上傳中：{0:N0} / {1:N0} MB（{2}%），約剩 {3} 分鐘    " -f ($sent / 1MB), ($totUp / 1MB), [int](100 * $sent / [Math]::Max(1, $totUp)), [int][Math]::Ceiling(($totUp - $sent) / [Math]::Max(1, $urate) / 60)) -NoNewline
                        }
                    }
                } finally { if ($os) { $os.Close() }; $in.Close() }
                $rq.GetResponse().Close()
                try {
                    $sz = Up-Req $uri 'SIZE'; $sr = $sz.GetResponse(); $rlen = $sr.ContentLength; $sr.Close()
                    if ($rlen -ne $flen) { throw "遠端大小 $rlen 不等於本機 $flen" }
                } catch [Net.WebException] { $nNoSize++ }   # 伺服器不支援 SIZE：不核對
                $nOk++; break
            } catch {
                $sent = $mark
                if ($try -eq 3) { $fails.Add("$rel：$($_.Exception.Message)") } else { Start-Sleep -Seconds 3 }
            }
        }
    }
    Write-Host ''
    $ut = $usw.Elapsed; $utT = $(if ($ut.TotalHours -ge 1) { '{0} 小時 {1} 分' -f [int][Math]::Floor($ut.TotalHours), $ut.Minutes } else { '{0} 分 {1} 秒' -f [int][Math]::Floor($ut.TotalMinutes), $ut.Seconds })
    foreach ($fl in $fails) { ErrLog "上傳失敗 $fl" }
    $upOk = ($fails.Count -eq 0)
    Log ("上傳{0}：成功 {1} / {2} 個檔（{3:N0} MB），花 {4}{5}{6}" -f $(if ($upOk) { '完成' } else { '未完成' }), $nOk, $allF.Count, ($sent / 1MB), $utT,
        $(if ($fails.Count) { "；失敗 $($fails.Count) 個（看 _error_log.txt，可再跑一次或手動補傳）" } else { '' }),
        $(if ($nNoSize) { "；$nNoSize 個伺服器不支援核對大小" } else { '' })) $(if ($upOk) { 'Green' } else { 'Yellow' })
    Log "遠端位置：$($U.Show)/$leaf（這兩行上傳後才寫，遠端的 _run_log 不含）"
}
if (-not $upOk) { Log '請把整個 run_local_ 資料夾拷回集中的地方；第一次跑請打開一份設定檔確認密碼已遮。' }
if ($status -eq 'OK') { exit 0 } elseif ($status -eq 'PARTIAL') { exit 1 } else { exit 2 }

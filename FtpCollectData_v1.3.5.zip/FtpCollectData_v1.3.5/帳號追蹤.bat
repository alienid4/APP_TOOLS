@echo off
chcp 65001 >nul
setlocal
rem AcctTrace v1.0.0 - trace one FTP account in the FileZilla log (read-only). Double-click, type account + dates.
set "PSModuleAnalysisCachePath=NUL"
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0AcctTrace.ps1" %*
echo.
pause

﻿#requires -Version 5.1
<#
  AcctTrace v1.0.0 (2026-11-13) -- 帳號追蹤（唯讀）
  在 FTP 主機上雙擊「帳號追蹤.bat」：輸入帳號、日期 → 讀那天的 FileZilla log，產出這個帳號的行為報告
  （每小時上傳／下載次數、來源 IP、抓了哪些檔、同一個檔被抓幾次、原始紀錄樣本）。
  只讀 log、不改任何東西；結果寫在本工具旁邊的「帳號追蹤_<帳號>_<時間>.txt」。
#>
param([string]$Account = '', [string]$Dates = '', [string]$LogDir = '')
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$VERSION = '1.0.0 (2026-11-13)'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Write-Host "帳號追蹤 AcctTrace $VERSION（只讀 log，不改任何東西）" -ForegroundColor Green
Write-Host ''

# ---- log 目錄：預設找 FileZilla Server 0.9／1.x 的 Logs
if (-not $LogDir) {
    foreach ($c in @("${env:ProgramFiles(x86)}\FileZilla Server\Logs", "$env:ProgramFiles\FileZilla Server\Logs", "$env:ProgramData\filezilla-server\logs")) {
        if ($c -and (Test-Path -LiteralPath $c)) { $LogDir = $c; break }
    }
    $ans = Read-Host "log 資料夾（直接按 Enter＝$(if ($LogDir) { $LogDir } else { '找不到，請輸入' })）"
    if ($ans.Trim()) { $LogDir = $ans.Trim().Trim('"') }
}
if (-not $LogDir -or -not (Test-Path -LiteralPath $LogDir)) { Write-Host "找不到 log 資料夾：$LogDir" -ForegroundColor Yellow; exit 3 }

if (-not $Account) { $Account = (Read-Host '要追蹤的帳號（例如 ftp11-1）').Trim() }
if (-not $Account) { Write-Host '沒有輸入帳號，結束。' -ForegroundColor Yellow; exit 3 }

$today = Get-Date
if (-not $Dates) {
    $d1 = $today.AddDays(-1).ToString('yyyy-MM-dd'); $d0 = $today.ToString('yyyy-MM-dd')
    $Dates = (Read-Host "日期（可多個，用逗號分開；直接按 Enter＝昨天 $d1 和今天 $d0）").Trim()
    if (-not $Dates) { $Dates = "$d1,$d0" }
}
$dayList = @($Dates -split '[,，\s]+' | Where-Object { $_ } | ForEach-Object { ([datetime]::Parse($_)).ToString('yyyy-MM-dd') })

# 0.9：(000123)2026/11/13 下午 13:16:05 - user01 (192.0.2.31)> STOR x
# 1.x：2026-11-13T13:16:05.123Z == [FTP Session 1234 192.0.2.3 user01] Command: STOR x
$rx09 = New-Object regex('^\((\d+)\)\s*(\d{4}/\d{1,2}/\d{1,2})\s+(?:(上午|下午|AM|PM)\s+)?(\d{1,2}):(\d{2}):(\d{2})\s*(?:(上午|下午|AM|PM)\s*)?-\s*(.*?)\s*\(([0-9A-Fa-f:.]+)\)>\s?(.*)$', 'Compiled')
$rx1 = New-Object regex('^(\d{4}-\d{2}-\d{2})[T ](\d{2}):(\d{2}):(\d{2})\S*\s+\S+\s+\[[^\]]*?Session\s+(\d+)\s+([0-9A-Fa-f:.]+)\s+([^\]]*)\]\s*(?:Command:\s*|Response:\s*)?(.*)$', 'Compiled')
$acctL = $Account.ToLowerInvariant()

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$outF = Join-Path $here ("帳號追蹤_{0}_{1}.txt" -f ($Account -replace '[\\/:*?"<>|]', '_'), $today.ToString('yyyyMMdd_HHmmss'))
$sb = New-Object Text.StringBuilder
function Out([string]$s) { [void]$sb.AppendLine($s); Write-Host $s }

Out "帳號追蹤報告　帳號：$Account　產生：$($today.ToString('yyyy/MM/dd HH:mm:ss'))　主機：$env:COMPUTERNAME"
Out "log 資料夾：$LogDir"
Out '說明：只讀 log。上傳＝STOR／APPE，下載＝RETR，以「226 傳輸成功」為準另列；同一個檔被下載很多次，通常是整個目錄重複抓或定時輪詢。'
Out ''

foreach ($day in $dayList) {
    $dt = [datetime]::ParseExact($day, 'yyyy-MM-dd', $null)
    $files = @(Get-ChildItem -LiteralPath $LogDir -File | Where-Object { $_.Name -like ("*{0}*" -f $day) -or $_.Name -like ("*{0}*" -f $dt.ToString('yyyyMMdd')) } | Sort-Object Name)
    Out ("========== {0}（{1} 個 log 檔：{2}）==========" -f $day, $files.Count, (($files | ForEach-Object { '{0} {1:N0} MB' -f $_.Name, ($_.Length / 1MB) }) -join '、'))
    if (-not $files.Count) { Out '　這天沒有 log 檔。'; Out ''; continue }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $hourUp = @{}; $hourDown = @{}; $ips = @{}; $retr = @{}; $sess = @{}
    $nLine = 0; $nUp = 0; $nDown = 0; $nOk226 = 0; $nLogin = 0; $first = ''; $last = ''
    $sample = New-Object System.Collections.Generic.List[string]
    $pend = @{}   # 連線 → 最後一個 RETR/STOR 的檔名（對 226 用）
    foreach ($f in $files) {
        Write-Host ("　讀取 {0} …" -f $f.Name)
        # 先用 Select-String（內建、快）只挑含帳號名稱的行，再細看
        foreach ($m in (Select-String -LiteralPath $f.FullName -SimpleMatch -Pattern $Account)) {
            $line = $m.Line
            $user = ''; $ip = ''; $sid = ''; $msg = ''; $hh = -1; $ts = ''
            $g = $rx09.Match($line)
            if ($g.Success) {
                $sid = $g.Groups[1].Value; $hh = [int]$g.Groups[4].Value
                $ap = $(if ($g.Groups[3].Success) { $g.Groups[3].Value } elseif ($g.Groups[7].Success) { $g.Groups[7].Value } else { '' })
                if (($ap -eq '下午' -or $ap -eq 'PM') -and $hh -lt 12) { $hh += 12 } elseif (($ap -eq '上午' -or $ap -eq 'AM') -and $hh -eq 12) { $hh = 0 }
                $ts = '{0:00}:{1}:{2}' -f $hh, $g.Groups[5].Value, $g.Groups[6].Value
                $user = $g.Groups[8].Value.Trim(); $ip = $g.Groups[9].Value; $msg = $g.Groups[10].Value
            } else {
                $g = $rx1.Match($line)
                if (-not $g.Success) { continue }
                $hh = [int]$g.Groups[2].Value; $ts = '{0}:{1}:{2}' -f $g.Groups[2].Value, $g.Groups[3].Value, $g.Groups[4].Value
                $sid = $g.Groups[5].Value; $ip = $g.Groups[6].Value; $user = $g.Groups[7].Value.Trim(); $msg = $g.Groups[8].Value
            }
            if ($user.ToLowerInvariant() -ne $acctL) { continue }   # 只算這個帳號（不是名字裡含有）
            $nLine++
            if (-not $first) { $first = $ts }; $last = $ts
            if (-not $sess.ContainsKey($sid)) { $sess[$sid] = 1 }
            if ($ip) { $ips[$ip] = 1 + $(if ($ips.ContainsKey($ip)) { $ips[$ip] } else { 0 }) }
            $t = $msg.Trim(); $verb = ($t -split '\s+', 2)[0].ToUpperInvariant(); $arg = $(if ($t.IndexOf(' ') -gt 0) { $t.Substring($t.IndexOf(' ') + 1).Trim() } else { '' })
            if ($verb -eq 'RETR') {
                $nDown++; $hourDown[$hh] = 1 + $(if ($hourDown.ContainsKey($hh)) { $hourDown[$hh] } else { 0 })
                $retr[$arg] = 1 + $(if ($retr.ContainsKey($arg)) { $retr[$arg] } else { 0 })
            } elseif ($verb -eq 'STOR' -or $verb -eq 'APPE') {
                $nUp++; $hourUp[$hh] = 1 + $(if ($hourUp.ContainsKey($hh)) { $hourUp[$hh] } else { 0 })
            } elseif ($t -like '230*') { $nLogin++ }
            elseif ($t -like '226*') { $nOk226++ }
            if ($sample.Count -lt 30) { $sample.Add(($line -replace '(?i)(PASS\s+)\S.*$', '$1***')) }
        }
    }
    Out ("　這個帳號的紀錄 {0:N0} 行；連線（session）{1:N0} 個；登入成功 {2:N0} 次；第一筆 {3}，最後一筆 {4}；讀檔花 {5:N0} 秒" -f $nLine, $sess.Count, $nLogin, $first, $last, $sw.Elapsed.TotalSeconds)
    Out ("　上傳 {0:N0} 次、下載 {1:N0} 次、傳輸成功回應（226）{2:N0} 次" -f $nUp, $nDown, $nOk226)
    if (-not $nLine) { Out '　這天沒有這個帳號的紀錄。'; Out ''; continue }
    Out '　【每小時】時：上傳／下載'
    $hl = for ($h = 0; $h -lt 24; $h++) { $u = $(if ($hourUp.ContainsKey($h)) { $hourUp[$h] } else { 0 }); $d = $(if ($hourDown.ContainsKey($h)) { $hourDown[$h] } else { 0 }); if ($u -or $d) { '{0:00} 點：{1:N0}／{2:N0}' -f $h, $u, $d } }
    foreach ($x in $hl) { Out ('　　' + $x) }
    Out ("　【來源 IP】共 {0} 個（依行數排序）" -f $ips.Count)
    foreach ($kv in ($ips.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 30)) { Out ('　　{0}　{1:N0} 行' -f $kv.Key, $kv.Value) }
    if ($retr.Count) {
        $rep = @($retr.Values | Where-Object { $_ -gt 1 }).Count
        $maxr = ($retr.Values | Measure-Object -Maximum).Maximum
        Out ("　【下載的檔】不同檔名 {0:N0} 個；被下載超過 1 次的 {1:N0} 個；同一個檔最多被下載 {2:N0} 次；平均每檔 {3:N1} 次" -f $retr.Count, $rep, $maxr, ($nDown / [Math]::Max(1, $retr.Count)))
        Out '　　下載次數最多的 20 個檔：'
        foreach ($kv in ($retr.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 20)) { Out ('　　{0:N0} 次　{1}' -f $kv.Value, $kv.Key) }
    }
    Out '　【原始紀錄樣本】前 30 行（密碼已遮）'
    foreach ($s in $sample) { Out ('　　' + $s) }
    Out ''
}
[IO.File]::WriteAllText($outF, $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
Write-Host ''
Write-Host "報告已存：$outF" -ForegroundColor Green
exit 0

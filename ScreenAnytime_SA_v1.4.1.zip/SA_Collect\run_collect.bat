@echo off
rem ScreenAnytime Collect - read-only. Right-click > Run as administrator (recommended).
rem Extra options example: run_collect.bat -RecordDir "D:\ScreenAnytime" -MaxMinutes 60
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SA_Collect.ps1" %*

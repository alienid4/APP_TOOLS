# ScreenAnytime Collect v1.1.0  (read-only on recordings; ASCII only)
# Run on each jump host, or ONCE on the central host with hosts.txt to collect every host over the network.
#   Local : this computer's D:\ScreenAnytime / T:\ScreenAnytime + local disks + agent services.
#   Remote: for each line in hosts.txt (or -Hosts): \\HOST\D$\ScreenAnytime + disk size/free of \\HOST\C$, \\HOST\D$
#           (needs admin share access with the current account; nothing is written on the remote host).
# Host of a recording = first folder in its path that is an IP or matches -HostPattern; otherwise the collected host.
# Writes ONLY new run_<HOST>_<time> folders under -OutDir (built as .tmp, renamed when complete).
# Exit: 0=all OK 1=some PARTIAL 2=some FAIL 3=not started
param(
[string[]]$RecordDir = @(),
[string[]]$Hosts = @(),
[string]$HostsFile = (Join-Path $PSScriptRoot 'hosts.txt'),
[switch]$NoLocal,
[string]$RemoteShare = 'D$\ScreenAnytime',
[string[]]$RemoteDisks = @('C$', 'D$'),
[string]$OutDir = (Join-Path $PSScriptRoot 'out'),
[string]$Pattern = '*.svl',
[int]$MaxMinutes = 30,
[string]$HostPattern = '^[A-Za-z][A-Za-z0-9]*-\d{3}$',
[switch]$NoPause
)
$Ver = '1.1.0'; $Schema = '1'
$IC = [Globalization.CultureInfo]::InvariantCulture
function F([double]$x) { $x.ToString('0.###', $IC) }
function TS([datetime]$t) { $t.ToString('yyyy-MM-dd HH:mm:ss', $IC) }
function Get-HostKey([string]$seg) {
if ($seg -match '^\d{1,3}(\.\d{1,3}){3}$') { return (($seg.Split('.') | ForEach-Object { [int]$_ }) -join '.') }
if ($seg -match $HostPattern) { return $seg.ToUpper() }
return $null
}
function Done([int]$code) { if (-not $NoPause) { Read-Host 'Press Enter to exit' | Out-Null }; exit $code }
function Note([string]$m) { [void]$script:Reasons.Add($m); Write-Host "  ! $m" -ForegroundColor Yellow }
function Err([string]$m) { [void]$script:Errs.Add("$(TS (Get-Date)) $m") }

function Scan-Root([string]$rootFull, [string]$selfKey, $Roots, $Daily) {
    Write-Host "  Scanning $rootFull ..."
    $sum = [ordered]@{ Root = $rootFull; Exists = 'N'; Files = 0; SizeMB = ''; RecFiles = 0; RecMB = ''; Oldest = ''; Newest = ''; Truncated = 'N'; Errors = 0; SkippedLinks = 0; Seconds = '' }
    if (-not (Test-Path -LiteralPath $rootFull)) { Note "folder not found or no access: $rootFull"; $script:Partial = $true; [void]$Roots.Add([pscustomobject]$sum); return }
    $sum.Exists = 'Y'
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $agg = @{}; $files = 0; $bytes = [long]0; $rec = 0; $recBytes = [long]0; $old = $null; $new = $null; $errc = 0; $skip = 0
    $stack = New-Object System.Collections.Stack
    $stack.Push((New-Object IO.DirectoryInfo $rootFull))
    while ($stack.Count -gt 0) {
        if ($sw.Elapsed.TotalMinutes -gt $MaxMinutes) { $sum.Truncated = 'Y'; $script:Partial = $true; Note "scan stopped after $MaxMinutes min: $rootFull"; break }
        $di = $stack.Pop()
        try { $subs = $di.GetDirectories() } catch { $errc++; Err "dir $($di.FullName): $($_.Exception.Message)"; continue }
        foreach ($s in $subs) { if ($s.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skip++; continue }; $stack.Push($s) }
        try { $fs = $di.GetFiles() } catch { $errc++; Err "files $($di.FullName): $($_.Exception.Message)"; continue }
        foreach ($f in $fs) {
            $files++; $bytes += $f.Length
            if ($files % 20000 -eq 0) { Write-Host "    $files files..." }
            if ($f.Name -notlike $Pattern) { continue }
            $rec++; $recBytes += $f.Length
            $t = $f.LastWriteTime
            if (-not $old -or $t -lt $old) { $old = $t }
            if (-not $new -or $t -gt $new) { $new = $t }
            $rel = $f.FullName.Substring($rootFull.Length).TrimStart('\')
            $segs = $rel.Split('\')
            $area = '.'; if ($segs.Count -gt 1) { $area = $segs[0] }
            $hk = $null; $src = 'self'
            for ($i = 0; $i -lt $segs.Count - 1; $i++) { $k = Get-HostKey $segs[$i]; if ($k) { $hk = $k; $src = 'path'; break } }
            if (-not $hk) { $hk = $selfKey }
            $acct = $f.Name.Split('.')[0].Trim()
            $day = $t.ToString('yyyy-MM-dd', $IC)
            $key = "$area|$hk|$($acct.ToUpper())|$day"
            $x = $agg[$key]
            if (-not $x) { $x = [pscustomobject]@{ Root = $rootFull; Area = $area; Host = $hk; Src = $src; Account = $acct; Day = $day; Files = 0; Bytes = [long]0; Last = $t }; $agg[$key] = $x }
            $x.Files++; $x.Bytes += $f.Length
            if ($t -gt $x.Last) { $x.Last = $t }
        }
    }
    $sum.Files = $files; $sum.SizeMB = F ($bytes / 1MB); $sum.RecFiles = $rec; $sum.RecMB = F ($recBytes / 1MB)
    if ($old) { $sum.Oldest = TS $old }; if ($new) { $sum.Newest = TS $new }
    $sum.Errors = $errc; $sum.SkippedLinks = $skip; $sum.Seconds = F $sw.Elapsed.TotalSeconds
    if ($errc -gt 0) { $script:Partial = $true; Note "$errc folders unreadable under $rootFull (see errors.txt)" }
    [void]$Roots.Add([pscustomobject]$sum)
    foreach ($x in $agg.Values) {
        [void]$Daily.Add([pscustomobject]@{ Root = $x.Root; Area = $x.Area; Host = $x.Host; Src = $x.Src; Account = $x.Account; Day = $x.Day; Files = $x.Files; MB = (F ($x.Bytes / 1MB)); Last = (TS $x.Last) })
    }
    Write-Host "    recordings: $rec  ($([math]::Round($recBytes / 1GB, 2)) GB)  folder total: $([math]::Round($bytes / 1GB, 2)) GB  $([int]$sw.Elapsed.TotalSeconds)s"
}

# one target -> one run_ folder; returns status
function Invoke-Collect([string]$name, [string]$hostKey, [string[]]$roots, [bool]$remote) {
    $start = Get-Date
    $script:Reasons = New-Object System.Collections.ArrayList
    $script:Errs = New-Object System.Collections.ArrayList
    $script:Partial = $false
    $runId = "$name`_$($start.ToString('yyyyMMdd_HHmmss', $IC))"
    $final = Join-Path $OutDir "run_$runId"; $tmp = "$final.tmp"
    try { New-Item -ItemType Directory -Force -Path $tmp -ErrorAction Stop | Out-Null }
    catch { Write-Host "ERROR: cannot create $tmp : $($_.Exception.Message)" -ForegroundColor Red; return [pscustomobject]@{ Host = $name; Status = 'FAIL'; Reasons = 'cannot create output folder'; Folder = '' } }
    Write-Host ''
    Write-Host "== $name $(if ($remote) { '(remote)' } else { '(this computer)' })" -ForegroundColor Cyan

    # disks
    $disks = New-Object System.Collections.ArrayList
    if ($remote) {
        $fso = New-Object -ComObject Scripting.FileSystemObject
        foreach ($sh in $RemoteDisks) {
            $unc = "\\$name\$sh"
            $row = [ordered]@{ Drive = ($sh.TrimEnd('$') + ':'); Type = 'Remote'; Label = $unc; TotalGB = ''; FreeGB = ''; UsedPct = ''; Status = '' }
            try {
                $d = $fso.GetDrive($unc)
                $t = [double]$d.TotalSize; $f = [double]$d.AvailableSpace
                $row.TotalGB = F ($t / 1GB); $row.FreeGB = F ($f / 1GB); if ($t -gt 0) { $row.UsedPct = F ((1 - $f / $t) * 100) }
                $row.Status = 'OK'
            } catch { $row.Status = 'ERROR'; Err "disk $unc : $($_.Exception.Message)" }
            [void]$disks.Add([pscustomobject]$row)
        }
    } else {
        foreach ($d in [IO.DriveInfo]::GetDrives()) {
            $ty = "$($d.DriveType)"
            if ($ty -ne 'Fixed' -and $ty -ne 'Network') { continue }
            $row = [ordered]@{ Drive = $d.Name.TrimEnd('\'); Type = $ty; Label = ''; TotalGB = ''; FreeGB = ''; UsedPct = ''; Status = '' }
            try {
                if (-not $d.IsReady) { $row.Status = 'NOT_READY' }
                else {
                    $t = [double]$d.TotalSize; $f = [double]$d.AvailableFreeSpace
                    $row.Label = $d.VolumeLabel; $row.TotalGB = F ($t / 1GB); $row.FreeGB = F ($f / 1GB)
                    if ($t -gt 0) { $row.UsedPct = F ((1 - $f / $t) * 100) }
                    $row.Status = 'OK'
                }
            } catch { $row.Status = 'ERROR'; Err "disk $($d.Name): $($_.Exception.Message)" }
            [void]$disks.Add([pscustomobject]$row)
        }
    }
    if (@($disks | Where-Object { $_.Status -ne 'OK' -and $_.Type -ne 'Network' }).Count -gt 0) { $script:Partial = $true; Note 'some disk could not be read' }

    # recordings
    $rootRows = New-Object System.Collections.ArrayList
    $daily = New-Object System.Collections.ArrayList
    if ($roots.Count -eq 0) { Note 'no recording folder found; use -RecordDir' }
    foreach ($r in $roots) { Scan-Root ([IO.Path]::GetFullPath($r).TrimEnd('\')) $hostKey $rootRows $daily }

    # services (local only; informational)
    $svcs = New-Object System.Collections.ArrayList
    if (-not $remote) {
        try {
            foreach ($s in @(Get-Service -ErrorAction Stop | Where-Object { $_.Name -match 'screen|anytime' -or $_.DisplayName -match 'screen|anytime' -or $_.Name -like 'SA*Service' })) {
                $st = ''; try { $st = "$($s.StartType)" } catch { }
                [void]$svcs.Add([pscustomobject]@{ Name = $s.Name; DisplayName = $s.DisplayName; Status = "$($s.Status)"; StartType = $st })
            }
        } catch { Err "service: $($_.Exception.Message)" }
    }

    $ips = ''
    try { $ips = (@([Net.Dns]::GetHostAddresses($name) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.IPAddressToString }) -join ' ') } catch { }
    $status = 'OK'
    if (@($rootRows | Where-Object { $_.Exists -eq 'Y' }).Count -eq 0) { $status = 'FAIL' } elseif ($script:Partial) { $status = 'PARTIAL' }
    $info = [ordered]@{
        SchemaVersion = $Schema; CollectorVersion = $Ver; RunId = $runId; Computer = $name; HostKey = $hostKey; IPs = $ips
        StartTime = (TS $start); EndTime = (TS (Get-Date)); TimeZone = [TimeZoneInfo]::Local.Id; User = "$env:USERDOMAIN\$env:USERNAME"
        CollectedFrom = $env:COMPUTERNAME; Mode = $(if ($remote) { 'remote' } else { 'local' })
        RecordDirs = ($roots -join ';'); Pattern = $Pattern; Status = $status; Reasons = ($script:Reasons -join ' | ')
        Services = (@($svcs | ForEach-Object { "$($_.Name)=$($_.Status)" }) -join ' ')
    }
    try {
        @($info.Keys | ForEach-Object { [pscustomobject]@{ Key = $_; Value = $info[$_] } }) | Export-Csv (Join-Path $tmp 'run_info.csv') -NoTypeInformation -Encoding UTF8
        if ($disks.Count) { @($disks) | Export-Csv (Join-Path $tmp 'disks.csv') -NoTypeInformation -Encoding UTF8 }
        else { 'Drive,Type,Label,TotalGB,FreeGB,UsedPct,Status' | Set-Content (Join-Path $tmp 'disks.csv') -Encoding UTF8 }
        @($rootRows) | Export-Csv (Join-Path $tmp 'roots.csv') -NoTypeInformation -Encoding UTF8
        if ($daily.Count) { @($daily) | Export-Csv (Join-Path $tmp 'daily.csv') -NoTypeInformation -Encoding UTF8 }
        else { 'Root,Area,Host,Src,Account,Day,Files,MB,Last' | Set-Content (Join-Path $tmp 'daily.csv') -Encoding UTF8 }
        if ($svcs.Count) { @($svcs) | Export-Csv (Join-Path $tmp 'services.csv') -NoTypeInformation -Encoding UTF8 }
        else { 'Name,DisplayName,Status,StartType' | Set-Content (Join-Path $tmp 'services.csv') -Encoding UTF8 }
        @($script:Errs) | Set-Content (Join-Path $tmp 'errors.txt') -Encoding UTF8
        Rename-Item -LiteralPath $tmp -NewName (Split-Path $final -Leaf) -ErrorAction Stop
    } catch { Write-Host "ERROR writing results: $($_.Exception.Message)" -ForegroundColor Red; return [pscustomobject]@{ Host = $name; Status = 'FAIL'; Reasons = 'cannot write results'; Folder = '' } }
    $color = @{ OK = 'Green'; PARTIAL = 'Yellow'; FAIL = 'Red' }[$status]
    Write-Host "  Status: $status" -ForegroundColor $color
    return [pscustomobject]@{ Host = $name; Status = $status; Reasons = ($script:Reasons -join ' | '); Folder = (Split-Path $final -Leaf) }
}

# ---------------- main ----------------
Write-Host '=====' -ForegroundColor Cyan
Write-Host " ScreenAnytime Collect v$Ver (read-only)" -ForegroundColor Cyan
Write-Host '=====' -ForegroundColor Cyan
$targets = New-Object System.Collections.ArrayList
$list = @($Hosts)
if ($list.Count -eq 0 -and (Test-Path $HostsFile)) {
    $list = @(Get-Content $HostsFile | ForEach-Object { ($_ -replace '#.*$', '').Trim() } | Where-Object { $_ })
    Write-Host "Hosts file: $HostsFile ($($list.Count) hosts)"
}
$me = $env:COMPUTERNAME
if (-not $NoLocal) {
    if ($RecordDir.Count -eq 0) { $RecordDir = @(@('D:\ScreenAnytime', 'T:\ScreenAnytime') | Where-Object { Test-Path $_ }) }
    $k = Get-HostKey $me; if (-not $k) { $k = $me.ToUpper() }
    [void]$targets.Add(@{ Name = $me; Key = $k; Roots = @($RecordDir); Remote = $false })
}
foreach ($h in $list) {
    $name = $h
    if ($h -match '^\d{1,3}(\.\d{1,3}){3}$') { try { $name = ([Net.Dns]::GetHostEntry($h).HostName.Split('.')[0]).ToUpper() } catch { $name = $h } }
    if ($name -ieq $me) { continue }
    $k = Get-HostKey $name; if (-not $k) { $k = $name.ToUpper() }
    [void]$targets.Add(@{ Name = $name; Key = $k; Roots = @("\\$h\$RemoteShare"); Remote = $true })
}
if ($targets.Count -eq 0) { Write-Host 'Nothing to collect.' -ForegroundColor Red; Done 3 }
$OutFull = [IO.Path]::GetFullPath($OutDir).TrimEnd('\') + '\'
foreach ($t in $targets) { foreach ($r in $t.Roots) {
    $rf = [IO.Path]::GetFullPath($r).TrimEnd('\') + '\'
    if ($OutFull.StartsWith($rf, [StringComparison]::OrdinalIgnoreCase)) { Write-Host "ERROR: output folder ($OutDir) is inside recording folder ($r). Use -OutDir elsewhere." -ForegroundColor Red; Done 3 }
} }
$results = foreach ($t in $targets) { Invoke-Collect $t.Name $t.Key $t.Roots $t.Remote }
Write-Host ''
Write-Host '===== Summary =====' -ForegroundColor Cyan
$results | Format-Table Host, Status, Reasons -AutoSize -Wrap | Out-String -Width 160 | Write-Host
Write-Host "Results: $OutDir" -ForegroundColor Yellow
Write-Host 'Copy the run_ folders to the report machine (SA_Report\collect). Do not rename them.'
$worst = 0; foreach ($r in $results) { $c = @{ OK = 0; PARTIAL = 1; FAIL = 2 }["$($r.Status)"]; if ($c -gt $worst) { $worst = $c } }
Done $worst

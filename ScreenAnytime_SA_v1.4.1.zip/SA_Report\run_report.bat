@echo off
rem ScreenAnytime Report - put all run_ folders under .\collect\ then run this.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SA_Report.ps1" %*

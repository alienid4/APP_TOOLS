# ScreenAnytime Collect v1.0.0  (read-only on recordings; ASCII only)
# Run on each jump host and on the central recording host.
# Host = first folder in the path that is an IP or matches -HostPattern (default: LETTERS-123).
# Collects: disk usage, recording folder size, per host x account x day recording totals, agent service state.
# Writes ONLY a new run_<COMPUTER>_<time> folder under -OutDir (built as .tmp, renamed when complete).
# Exit: 0=OK 1=PARTIAL 2=FAIL 3=not started
param(
[string[]]$RecordDir = @(),
[string]$OutDir = (Join-Path $PSScriptRoot 'out'),
[string]$Pattern = '*.svl',
[int]$MaxMinutes = 30,
[string]$HostPattern = '^[A-Za-z][A-Za-z0-9]*-\d{3}$',
[switch]$NoPause
)
$Ver = '1.0.0'; $Schema = '1'
$IC = [Globalization.CultureInfo]::InvariantCulture
function F([double]$x) { $x.ToString('0.###', $IC) }
function TS([datetime]$t) { $t.ToString('yyyy-MM-dd HH:mm:ss', $IC) }
function Get-HostKey([string]$seg) {
if ($seg -match '^\d{1,3}(\.\d{1,3}){3}$') { return (($seg.Split('.') | ForEach-Object { [int]$_ }) -join '.') }
if ($seg -match $HostPattern) { return $seg.ToUpper() }
return $null
}
function Done([int]$code) { if (-not $NoPause) { Read-Host 'Press Enter to exit' | Out-Null }; exit $code }

Write-Host '=====' -ForegroundColor Cyan
Write-Host " ScreenAnytime Collect v$Ver (read-only)" -ForegroundColor Cyan
Write-Host '=====' -ForegroundColor Cyan
$Start = Get-Date
$Computer = $env:COMPUTERNAME
$SelfKey = Get-HostKey $Computer
if (-not $SelfKey) { $SelfKey = $Computer.ToUpper() }

if ($RecordDir.Count -eq 0) { $RecordDir = @(@('D:\ScreenAnytime', 'T:\ScreenAnytime') | Where-Object { Test-Path $_ }) }
$OutFull = [IO.Path]::GetFullPath($OutDir).TrimEnd('\') + '\'
foreach ($r in $RecordDir) {
    $rf = [IO.Path]::GetFullPath($r).TrimEnd('\') + '\'
    if ($OutFull.StartsWith($rf, [StringComparison]::OrdinalIgnoreCase)) {
        Write-Host "ERROR: output folder ($OutDir) is inside recording folder ($r). Use -OutDir elsewhere." -ForegroundColor Red
        Done 3
    }
}
$RunId = "$Computer`_$($Start.ToString('yyyyMMdd_HHmmss', $IC))"
$Final = Join-Path $OutDir "run_$RunId"
$Tmp = "$Final.tmp"
try { New-Item -ItemType Directory -Force -Path $Tmp -ErrorAction Stop | Out-Null }
catch { Write-Host "ERROR: cannot create $Tmp : $($_.Exception.Message)" -ForegroundColor Red; Done 3 }

$Reasons = New-Object System.Collections.ArrayList
$Errs = New-Object System.Collections.ArrayList
$Partial = $false
function Note([string]$m) { [void]$Reasons.Add($m); Write-Host "  ! $m" -ForegroundColor Yellow }
function Err([string]$m) { [void]$Errs.Add("$(TS (Get-Date)) $m") }

# ---- 1. disks ----
Write-Host 'Disks...'
$Disks = New-Object System.Collections.ArrayList
foreach ($d in [IO.DriveInfo]::GetDrives()) {
    $ty = "$($d.DriveType)"
    if ($ty -ne 'Fixed' -and $ty -ne 'Network') { continue }
    $row = [ordered]@{ Drive = $d.Name.TrimEnd('\'); Type = $ty; Label = ''; TotalGB = ''; FreeGB = ''; UsedPct = ''; Status = '' }
    try {
        if (-not $d.IsReady) { $row.Status = 'NOT_READY' }
        else {
            $t = [double]$d.TotalSize; $f = [double]$d.AvailableFreeSpace
            $row.Label = $d.VolumeLabel; $row.TotalGB = F ($t / 1GB); $row.FreeGB = F ($f / 1GB)
            if ($t -gt 0) { $row.UsedPct = F ((1 - $f / $t) * 100) }
            $row.Status = 'OK'
        }
    } catch { $row.Status = 'ERROR'; Err "disk $($d.Name): $($_.Exception.Message)" }
    [void]$Disks.Add([pscustomobject]$row)
}
if (@($Disks | Where-Object { $_.Status -ne 'OK' -and $_.Type -eq 'Fixed' }).Count -gt 0) { $Partial = $true; Note 'some fixed disk could not be read' }

# ---- 2. recording folders ----
$Roots = New-Object System.Collections.ArrayList
$Daily = New-Object System.Collections.ArrayList
if ($RecordDir.Count -eq 0) { Note 'no recording folder found (D:\ScreenAnytime / T:\ScreenAnytime); use -RecordDir' }
foreach ($root in $RecordDir) {
    $rootFull = [IO.Path]::GetFullPath($root).TrimEnd('\')
    Write-Host "Scanning $rootFull ..."
    $sum = [ordered]@{ Root = $rootFull; Exists = 'N'; Files = 0; SizeMB = ''; RecFiles = 0; RecMB = ''; Oldest = ''; Newest = ''; Truncated = 'N'; Errors = 0; SkippedLinks = 0; Seconds = '' }
    if (-not (Test-Path -LiteralPath $rootFull)) { Note "folder not found: $rootFull"; $Partial = $true; [void]$Roots.Add([pscustomobject]$sum); continue }
    $sum.Exists = 'Y'
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $agg = @{}; $files = 0; $bytes = [long]0; $rec = 0; $recBytes = [long]0; $old = $null; $new = $null; $errc = 0; $skip = 0
    $stack = New-Object System.Collections.Stack
    $stack.Push((New-Object IO.DirectoryInfo $rootFull))
    while ($stack.Count -gt 0) {
        if ($sw.Elapsed.TotalMinutes -gt $MaxMinutes) { $sum.Truncated = 'Y'; $Partial = $true; Note "scan stopped after $MaxMinutes min: $rootFull"; break }
        $di = $stack.Pop()
        try { $subs = $di.GetDirectories() } catch { $errc++; Err "dir $($di.FullName): $($_.Exception.Message)"; continue }
        foreach ($s in $subs) { if ($s.Attributes -band [IO.FileAttributes]::ReparsePoint) { $skip++; continue }; $stack.Push($s) }
        try { $fs = $di.GetFiles() } catch { $errc++; Err "files $($di.FullName): $($_.Exception.Message)"; continue }
        foreach ($f in $fs) {
            $files++; $bytes += $f.Length
            if ($files % 20000 -eq 0) { Write-Host "  $files files..." }
            if ($f.Name -notlike $Pattern) { continue }
            $rec++; $recBytes += $f.Length
            $t = $f.LastWriteTime
            if (-not $old -or $t -lt $old) { $old = $t }
            if (-not $new -or $t -gt $new) { $new = $t }
            $rel = $f.FullName.Substring($rootFull.Length).TrimStart('\')
            $segs = $rel.Split('\')
            $area = '.'; if ($segs.Count -gt 1) { $area = $segs[0] }
            $hk = $null; $src = 'self'
            for ($i = 0; $i -lt $segs.Count - 1; $i++) { $k = Get-HostKey $segs[$i]; if ($k) { $hk = $k; $src = 'path'; break } }
            if (-not $hk) { $hk = $SelfKey }
            $acct = $f.Name.Split('.')[0].Trim()
            $day = $t.ToString('yyyy-MM-dd', $IC)
            $key = "$area|$hk|$($acct.ToUpper())|$day"
            $x = $agg[$key]
            if (-not $x) { $x = [pscustomobject]@{ Root = $rootFull; Area = $area; Host = $hk; Src = $src; Account = $acct; Day = $day; Files = 0; Bytes = [long]0; Last = $t }; $agg[$key] = $x }
            $x.Files++; $x.Bytes += $f.Length
            if ($t -gt $x.Last) { $x.Last = $t }
        }
    }
    $sum.Files = $files; $sum.SizeMB = F ($bytes / 1MB); $sum.RecFiles = $rec; $sum.RecMB = F ($recBytes / 1MB)
    if ($old) { $sum.Oldest = TS $old }; if ($new) { $sum.Newest = TS $new }
    $sum.Errors = $errc; $sum.SkippedLinks = $skip; $sum.Seconds = F $sw.Elapsed.TotalSeconds
    if ($errc -gt 0) { $Partial = $true; Note "$errc folders unreadable under $rootFull (see errors.txt)" }
    [void]$Roots.Add([pscustomobject]$sum)
    foreach ($x in $agg.Values) {
        [void]$Daily.Add([pscustomobject]@{ Root = $x.Root; Area = $x.Area; Host = $x.Host; Src = $x.Src; Account = $x.Account; Day = $x.Day; Files = $x.Files; MB = (F ($x.Bytes / 1MB)); Last = (TS $x.Last) })
    }
    Write-Host "  recordings: $rec  ($([math]::Round($recBytes / 1GB, 2)) GB)  folder total: $([math]::Round($bytes / 1GB, 2)) GB  $([int]$sw.Elapsed.TotalSeconds)s"
}

# ---- 3. agent service ----
$Svcs = New-Object System.Collections.ArrayList
try {
    foreach ($s in @(Get-Service -ErrorAction Stop | Where-Object { $_.Name -match 'screen|anytime' -or $_.DisplayName -match 'screen|anytime' })) {
        $st = ''; try { $st = "$($s.StartType)" } catch { }
        [void]$Svcs.Add([pscustomobject]@{ Name = $s.Name; DisplayName = $s.DisplayName; Status = "$($s.Status)"; StartType = $st })
    }
} catch { Err "service: $($_.Exception.Message)" }
if ($Svcs.Count -eq 0) { Write-Host '  (no service named like ScreenAnytime found)' }

# ---- 4. write ----
$ips = ''
try { $ips = (@([Net.Dns]::GetHostAddresses($Computer) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.IPAddressToString }) -join ' ') } catch { }
$status = 'OK'
if (@($Roots | Where-Object { $_.Exists -eq 'Y' }).Count -eq 0) { $status = 'FAIL' } elseif ($Partial) { $status = 'PARTIAL' }
$End = Get-Date
$info = [ordered]@{
    SchemaVersion = $Schema; CollectorVersion = $Ver; RunId = $RunId; Computer = $Computer; HostKey = $SelfKey; IPs = $ips
    StartTime = (TS $Start); EndTime = (TS $End); TimeZone = [TimeZoneInfo]::Local.Id; User = "$env:USERDOMAIN\$env:USERNAME"
    RecordDirs = ($RecordDir -join ';'); Pattern = $Pattern; Status = $status; Reasons = ($Reasons -join ' | ')
    Services = (@($Svcs | ForEach-Object { "$($_.Name)=$($_.Status)" }) -join ' ')
}
try {
    @($info.Keys | ForEach-Object { [pscustomobject]@{ Key = $_; Value = $info[$_] } }) | Export-Csv (Join-Path $Tmp 'run_info.csv') -NoTypeInformation -Encoding UTF8
    @($Disks) | Export-Csv (Join-Path $Tmp 'disks.csv') -NoTypeInformation -Encoding UTF8
    @($Roots) | Export-Csv (Join-Path $Tmp 'roots.csv') -NoTypeInformation -Encoding UTF8
    if ($Daily.Count) { @($Daily) | Export-Csv (Join-Path $Tmp 'daily.csv') -NoTypeInformation -Encoding UTF8 }
    else { 'Root,Area,Host,Src,Account,Day,Files,MB,Last' | Set-Content (Join-Path $Tmp 'daily.csv') -Encoding UTF8 }
    if ($Svcs.Count) { @($Svcs) | Export-Csv (Join-Path $Tmp 'services.csv') -NoTypeInformation -Encoding UTF8 }
    else { 'Name,DisplayName,Status,StartType' | Set-Content (Join-Path $Tmp 'services.csv') -Encoding UTF8 }
    @($Errs) | Set-Content (Join-Path $Tmp 'errors.txt') -Encoding UTF8
    Rename-Item -LiteralPath $Tmp -NewName (Split-Path $Final -Leaf) -ErrorAction Stop
} catch {
    Write-Host "ERROR writing results: $($_.Exception.Message)" -ForegroundColor Red
    Done 2
}
Write-Host ''
$color = @{ OK = 'Green'; PARTIAL = 'Yellow'; FAIL = 'Red' }[$status]
Write-Host "Status: $status" -ForegroundColor $color
if ($Reasons.Count) { $Reasons | ForEach-Object { Write-Host "  - $_" } }
Write-Host "Result: $Final" -ForegroundColor Yellow
Write-Host 'Copy this whole run_ folder to the report machine (collect folder). Do not rename it.'
Done (@{ OK = 0; PARTIAL = 1; FAIL = 2 }[$status])

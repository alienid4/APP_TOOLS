﻿# devlist.ps1 —— 每日檢查工具共用的「設備清單.csv」讀取（v1，2026-11-17）
# 欄位：類別,地點,廠牌,型號,IP,帳號,密碼,備註（第一行是欄位名稱；Excel 可直接編輯）
#   類別＝紙本大項編號（2＝VMware、3＝Storage/San Switch、4＝其他／AD net time）。
#   密碼：明文寫入後，第一次執行自動換成 dpapi:…（Windows 加密，只有同一帳號在同一台電腦解得開）；留空＝執行時詢問。
# 舊版 ip.list（位址,帳號,密碼）會自動轉成 設備清單.csv（類別 3），原檔改名 ip.list.已轉換。
# 只讀本機檔案，不連網。

$DevCols = @('類別', '地點', '廠牌', '型號', 'IP', '帳號', '密碼', '備註')

function Read-TextAuto([string]$path) {
  # Excel 存 CSV 可能是 UTF-8（含／不含 BOM）或 Big5：有 BOM 用 UTF-8；沒有就先試嚴格 UTF-8，失敗改 Big5
  $bytes = [IO.File]::ReadAllBytes($path)
  if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { return [Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3) }
  try { return (New-Object Text.UTF8Encoding($false, $true)).GetString($bytes) } catch { return [Text.Encoding]::GetEncoding(950).GetString($bytes) }
}

function Write-DevList([string]$path, $rows, [string[]]$cols) {
  if (-not $cols) { $cols = $DevCols }
  $sb = New-Object Text.StringBuilder
  [void]$sb.AppendLine((($cols | ForEach-Object { '"' + ($_ -replace '"', '""') + '"' }) -join ','))
  foreach ($r in $rows) { [void]$sb.AppendLine((($cols | ForEach-Object { '"' + ([string]$r.$_ -replace '"', '""') + '"' }) -join ',')) }
  $tmp = $path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  [IO.File]::WriteAllText($tmp, '', (New-Object Text.UTF8Encoding($false)))
  if (-not (Lock-Acl $tmp)) { Remove-Item -Force $tmp -ErrorAction SilentlyContinue; throw '暫存檔權限設不起來，為安全起見不寫回設備清單' }
  [IO.File]::WriteAllText($tmp, $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
  Move-Item -Force -Path $tmp -Destination $path
}

function Lock-Acl([string]$path) {
  # 只留目前帳號：移除繼承＋移除其他所有明確授權
  $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  & icacls.exe $path /inheritance:r /grant:r ("*{0}:F" -f $sid) | Out-Null
  if ($LASTEXITCODE -ne 0) { return $false }
  foreach ($a in @((Get-Acl $path).Access)) {
    try { $v = $a.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value } catch { $v = $null }
    if ($v -ne $sid) { & icacls.exe $path /remove:g ("*" + $(if ($v) { $v } else { $a.IdentityReference.Value })) | Out-Null }
  }
  $left = @((Get-Acl $path).Access | Where-Object { try { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value -ne $sid } catch { $true } })
  return ($left.Count -eq 0)
}

function Protect-DevList([string]$path) {
  if (-not (Lock-Acl $path)) { Write-Host "⚠ $(Split-Path $path -Leaf) 權限沒辦法收緊成只有你，請自行確認只有你讀得到" }
}

# 回傳指定類別的設備（每筆含 No、Line、Cat、Loc、Brand、Model、Host、User、Sec、Note、Reject）
function Read-DevList([string]$here, [string]$Category, [string]$ModelMatch = '', [string]$ModelNotMatch = '') {   # 型號篩選：同一類別不同工具（例：Unity／ME4）
  $path = Join-Path $here '設備清單.csv'
  if (-not (Test-Path $path)) {
    $old = @('ip.list', 'ip.list.txt') | ForEach-Object { Join-Path $here $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $old) {
      Write-Host "找不到 設備清單.csv（要放在 $here）。欄位：類別,地點,廠牌,型號,IP,帳號,密碼,備註"
      return $null
    }
    $conv = New-Object System.Collections.Generic.List[object]
    foreach ($line in ((Read-TextAuto $old) -split "`r?`n")) {
      $t = $line.Trim(); if (-not $t -or $t.StartsWith('#')) { continue }
      $p = $line -split ',', 3
      $conv.Add([pscustomobject]@{ 類別 = '3'; 地點 = ''; 廠牌 = 'DellEMC'; 型號 = ''; IP = $p[0].Trim().TrimStart([char]0xFEFF); 帳號 = $(if ($p.Count -ge 2) { $p[1].Trim() } else { '' }); 密碼 = $(if ($p.Count -ge 3) { $p[2] } else { '' }); 備註 = '由 ip.list 轉入' })
    }
    Write-DevList $path $conv
    $bak = $old + '.已轉換_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    Move-Item -Path $old -Destination $bak
    Protect-DevList $bak
    Write-Host "已把 $(Split-Path $old -Leaf) 轉成 設備清單.csv（類別 3）；請用 Excel 補上「地點」。"
    Write-Host "⚠ 原檔已改名為 $(Split-Path $bak -Leaf)，裡面還有明文密碼：確認新清單能用之後請刪除它。"
  }
  $hash0 = (Get-FileHash -Algorithm SHA256 -Path $path).Hash
  $text = Read-TextAuto $path
  $hdr = @((($text -split "`r?`n")[0] | ConvertFrom-Csv -Header (1..50 | ForEach-Object { "c$_" })).PSObject.Properties | Where-Object { $_.Value } | ForEach-Object { ([string]$_.Value).Trim().TrimStart([char]0xFEFF) })
  $miss = @($DevCols | Where-Object { $hdr -notcontains $_ })
  if ($miss.Count) { Write-Host ('設備清單.csv 第一行少了欄位：' + ($miss -join '、') + '（需要：' + ($DevCols -join ',') + '）。請修正欄名後再執行，程式不會改你的檔案。'); return $null }
  $rows = @($text | ConvertFrom-Csv)
  $allCols = @($hdr)
  $out = New-Object System.Collections.Generic.List[object]
  $seen = @{}; $rewrite = $false; $ln = 1
  foreach ($r in $rows) {
    $ln++
    foreach ($c in $DevCols) { if (-not ($r.PSObject.Properties.Name -contains $c)) { $r | Add-Member -NotePropertyName $c -NotePropertyValue '' } }
    $cat = ([string]$r.類別).Trim()
    $ip = ([string]$r.IP).Trim()
    if (-not $ip -and -not $cat) { continue }
    $pw = [string]$r.密碼
    $sec = $null; $rej = $null
    if ($pw -like 'dpapi:*') {
      try { $sec = ConvertTo-SecureString -String $pw.Substring(6) }
      catch { $rej = "設備清單第 $ln 行密碼解不開（不是同一個 Windows 帳號／同一台電腦加密的）：請把該格密碼改回明文再執行一次" }
    } elseif ($pw) {
      if ($pw -match '[\r\n\x00]') { $rej = "設備清單第 $ln 行密碼含換行或控制字元，不支援（原內容保留，請修正）" }
      else { $sec = ConvertTo-SecureString -String $pw -AsPlainText -Force; $r.密碼 = 'dpapi:' + (ConvertFrom-SecureString -SecureString $sec); $rewrite = $true }
    }
    $pw = $null
    if ($cat -ne $Category) { continue }
    $mdl = ([string]$r.型號).Trim()
    if ($ModelMatch -and $mdl -notmatch $ModelMatch) { continue }
    if ($ModelNotMatch -and $mdl -match $ModelNotMatch) { continue }
    if (-not $rej -and $ip -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]{0,251}$') { $rej = "設備清單第 $ln 行 IP 格式不對"; $ip = "(第 $ln 行)" }
    $us = ([string]$r.帳號).Trim()
    if (-not $rej -and $us -match '[:\x00-\x1F]') { $rej = "設備清單第 $ln 行帳號含冒號或控制字元" }
    if (-not $rej -and $seen.ContainsKey($ip.ToLower())) { $rej = "設備清單第 $ln 行跟第 " + $seen[$ip.ToLower()] + " 行是同一個 IP（重複）" }
    if (-not $rej) { $seen[$ip.ToLower()] = $ln }
    $out.Add([pscustomobject]@{ No = $out.Count + 1; Line = $ln; Cat = $cat; Loc = ([string]$r.地點).Trim(); Brand = ([string]$r.廠牌).Trim(); Model = ([string]$r.型號).Trim()
                                Host = $ip; User = $us; Sec = $sec; Note = ([string]$r.備註).Trim(); Reject = $rej })
  }
  if ($rewrite -and (Get-FileHash -Algorithm SHA256 -Path $path).Hash -ne $hash0) {
    Write-Host '⚠ 設備清單在執行期間被修改過（例如 Excel 剛存檔），這次不寫回加密結果；請關掉 Excel 後再執行一次。'
    $rewrite = $false
  }
  if ($rewrite) {
    Write-DevList $path $rows $allCols
    Write-Host '設備清單.csv 裡的明文密碼已換成 Windows 加密字串（只有你這個帳號在這台電腦解得開）。'
    Write-Host '提醒：明文寫過的密碼可能還留在 Excel 暫存、備份或同步資料夾；若有疑慮請更換密碼。'
  }
  $rows = $null
  Protect-DevList $path
  return ,$out
}

function Label($d, [string]$model) {
  $m = if ($d.Model) { $d.Model } elseif ($model) { $model } else { '型號不明' }
  return (@($(if ($d.Loc) { $d.Loc } else { '未填地點' }), $(if ($d.Brand) { $d.Brand } else { '廠牌不明' }), ($m -replace '\s+', ''), $d.Host) -join '_')
}

# 執行時輸入的密碼：登入成功後問要不要記住；記住＝把加密字串（DPAPI）寫進設備清單的「密碼」欄（只填原本空白的格子）
function Save-DevPasswords([string]$here, [int[]]$lines, [string]$dpapi) {
  $path = Join-Path $here '設備清單.csv'
  $text = Read-TextAuto $path
  $hdr = @((($text -split "`r?`n")[0] | ConvertFrom-Csv -Header (1..50 | ForEach-Object { "c$_" })).PSObject.Properties | Where-Object { $_.Value } | ForEach-Object { ([string]$_.Value).Trim().TrimStart([char]0xFEFF) })
  $rows = @($text | ConvertFrom-Csv)
  $n = 0
  foreach ($ln in $lines) { $i = $ln - 2; if ($i -ge 0 -and $i -lt $rows.Count -and -not ([string]$rows[$i].密碼)) { $rows[$i].密碼 = 'dpapi:' + $dpapi; $n++ } }
  if ($n) { Write-DevList $path $rows $hdr; Protect-DevList $path }
  return $n
}
function Ask-Remember([string]$here, [int[]]$lines, [string]$dpapi, [string]$what) {
  if (-not $dpapi -or -not $lines.Count) { return }
  try {
    $a = (Read-Host ("要記住 $what 的密碼嗎？記住後下次（含排程）不用再輸入。輸入 Y 記住，其他鍵不記") ).Trim()
    if ($a -notin 'Y', 'y') { Write-Host '沒有記住，下次還會再問。'; return }
    $n = Save-DevPasswords $here $lines $dpapi
    Write-Host $(if ($n) { "已記住（$n 台）：密碼以 Windows 加密存進設備清單，只有你這個帳號在這台電腦解得開。" } else { '設備清單那幾格已經有密碼，沒有覆蓋。' })
  } catch { Write-Host ('記住密碼失敗：' + $_.Exception.Message + '（請關掉開著設備清單的 Excel 再試）') }
}

#!/usr/bin/env bash
# disk_housekeeping.sh v1.1.2 (2026-11-18) — Linux 磁碟 Housekeeping 唯讀盤點（RHEL／CentOS／Debian／Ubuntu）
# 跟 Windows 版 Get-DiskHousekeeping 同一套報告：最佔空間的目錄、整包很久沒動的目錄、目錄內的舊檔、
# 名稱像備份的目錄、單一大檔、已刪除但還被程式開著的檔案，產出可貼進 email 的 summary.txt 與給 AP 回填的 ap_reply.csv。
#
# 設計原則（給資安／主管審閱）：
#   1. 只讀：不刪、不改、不搬任何檔案；只在報告目錄（預設本程式旁邊的 Reports/）寫報告。
#      讀檔案時作業系統可能依掛載設定更新目錄的存取時間（atime），那不是本程式的動作。
#   2. 不提權：用誰的身分跑就看得到誰看得到的；沒權限的目錄略過並計數（不用 sudo、不改權限、不連網路）。
#   3. 不打擾營運：開跑前看 load、可用記憶體、IO 等待，超過門檻就不跑；掃描中每 10 秒再看一次，
#      連續 3 次超標就中止並輸出已完成部分。整支程式（含子程序）用 nice 19＋ionice idle。同一台同時只跑一份。
#   4. 有時限：每個掛載點各自最多跑 -m 分鐘，時間到就停，未完成的數字標「≥」。
#   5. 只掃本機實體檔案系統；不跨檔案系統（find -xdev）、不跟隨符號連結；NFS／CIFS／proc 等一律不掃。
#   6. 「多久沒動」看檔案最後修改時間（mtime），只是線索、不能當刪除依據。系統與資料庫目錄
#      （/usr /lib /boot /var/lib/mysql /var/lib/docker…）只列大小，不列進給 AP 的清理清單。
#      大小是檔案的邏輯大小（稀疏檔、硬連結、快照會讓加總跟 df 不同，刪了也不一定釋放這麼多）。
#
# 結束代碼：0＝完成；1＝部分完成（時間到或負載中止）；2＝負載過高未執行；3＝執行錯誤、參數錯誤或已有一份在跑。
#
# 用法：
#   ./disk_housekeeping.sh                 互動：列出掛載點讓你選、問每個最多跑幾分鐘
#   ./disk_housekeeping.sh -a              掃使用率 ≥ 80% 的本機掛載點（排程用，不問問題）
#   ./disk_housekeeping.sh -d /data -d /   指定掛載點
#   ./disk_housekeeping.sh -p /data/app    只掃某個目錄（要在本機檔案系統上）
#   其他：-A 全部掛載點　-m 每個最多幾分鐘（預設 10）　-t 目標使用率%　-r 回覆期限　-o 報告目錄　-n 不寫報告
#         -y 舊檔年數（預設 5）　-Y 很舊年數（預設 10）　-N 每類列幾筆（預設 5）　-g 小於幾 GB 不列（預設 1）　-c 小檔堆積門檻：一個目錄幾個檔就列（預設 10000，不看大小）
#         -D 目錄統計深度（預設 4）　-x 排除路徑（可重複，萬用字元照 find -path）　-L 負載上限（每核心，預設 2.0）　-h 說明
set -u
umask 077
VERSION='1.1.2'
LC_ALL=C; export LC_ALL   # find／df 的訊息與數字格式固定成英文，程式才解析得了（報告文字仍是中文）
unset CDPATH

ALERT=80; TOPN=5; MINUTES=10; DEPTH=4; OLDY=5; ANCY=10; MINGB=1; TARGET=0; REPLYBY=''; OUTDIR=''; NOREPORT=0
LOADMAX=2.0; MEMMIN=10; IOWMAX=50; MAXNODES=200000; MINFC=10000
MODE=''; declare -a DIRS=() PATHS=() EXCL=()
INTERACTIVE=0; [ $# -eq 0 ] && [ -t 0 ] && INTERACTIVE=1
HERE=$(cd -P "$(dirname "$0")" && pwd)

usage() { sed -n '2,32p' "$0" | sed 's/^# \{0,1\}//'; }
die() { echo "錯誤：$*" >&2; exit 3; }
isnum() { [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ ]]; }
dec() { echo $((10#$1)); }   # 08、09 不要被當成八進位

while getopts ':aAd:p:m:t:r:o:ny:Y:N:g:D:x:L:c:h' opt; do
  case "$opt" in
    a) MODE='alert' ;; A) MODE='all' ;; d) DIRS+=("$OPTARG") ;; p) PATHS+=("$OPTARG") ;;
    m) isnum "$OPTARG" || die "-m 要是數字"; MINUTES=$OPTARG ;;
    t) [[ "$OPTARG" =~ ^[0-9]{1,2}$ ]] || die "-t 要是 0～99"; TARGET=$(dec "$OPTARG") ;;
    r) [ ${#OPTARG} -le 40 ] || die "-r 最多 40 字"; REPLYBY=$OPTARG ;;
    o) OUTDIR=$OPTARG ;; n) NOREPORT=1 ;;
    y) [[ "$OPTARG" =~ ^[0-9]{1,3}$ ]] || die "-y 要是整數"; OLDY=$(dec "$OPTARG") ;;
    Y) [[ "$OPTARG" =~ ^[0-9]{1,3}$ ]] || die "-Y 要是整數"; ANCY=$(dec "$OPTARG") ;;
    N) [[ "$OPTARG" =~ ^[0-9]{1,2}$ ]] || die "-N 要是 1～50"; TOPN=$(dec "$OPTARG") ;;
    g) isnum "$OPTARG" || die "-g 要是數字"; MINGB=$OPTARG ;;
    D) [[ "$OPTARG" =~ ^[1-8]$ ]] || die "-D 要是 1～8"; DEPTH=$OPTARG ;;
    c) [[ "$OPTARG" =~ ^[0-9]{3,9}$ ]] || die "-c 要是 100 以上的整數"; MINFC=$(dec "$OPTARG"); [ "$MINFC" -ge 100 ] || die "-c 至少 100" ;;
    x) EXCL+=("${OPTARG%/}") ;; L) isnum "$OPTARG" || die "-L 要是數字"; LOADMAX=$OPTARG ;;
    h) usage; exit 0 ;; :) die "-$OPTARG 後面要接值" ;; *) die "看不懂的參數 -$OPTARG（-h 看說明）" ;;
  esac
done
shift $((OPTIND - 1)); [ $# -eq 0 ] || die "多了看不懂的參數：$*（-h 看說明）"
[ ${#PATHS[@]} -gt 0 ] && [ ${#DIRS[@]} -gt 0 ] && die "-p 跟 -d 不能一起用"
[ "$TOPN" -ge 1 ] && [ "$TOPN" -le 50 ] || die "-N 要是 1～50"
[ "$OLDY" -ge 1 ] || die "-y 至少 1 年"
awk -v m="$MINUTES" 'BEGIN{exit !(m>0 && m<=120)}' || die "-m 要在 0～120 分鐘之間"
[ "$ANCY" -gt "$OLDY" ] || ANCY=$((OLDY * 2))
for t in find df awk sort timeout date; do command -v "$t" >/dev/null 2>&1 || die "找不到 $t 指令"; done
# 整支程式降優先權（子程序都會繼承）：只影響自己
{ renice -n 19 -p $$ || renice 19 -p $$; } >/dev/null 2>&1; command -v ionice >/dev/null 2>&1 && ionice -c3 -p $$ >/dev/null 2>&1

HOST=$(hostname 2>/dev/null || uname -n); WHO=$(id -un 2>/dev/null || echo "uid$(id -u)"); ISROOT=0; [ "$(id -u)" = 0 ] && ISROOT=1
START=$(date +%s); STAMP=$(date +%Y%m%d_%H%M%S)
NOW=$START; OLDCUT=$((NOW - OLDY * 365 * 86400)); ANCCUT=$((NOW - ANCY * 365 * 86400))

fmt_size() { awk -v b="$1" 'BEGIN{ if(b>=1099511627776) printf "%.2f TB", b/1099511627776; else if(b>=1073741824) printf "%.1f GB", b/1073741824; else if(b>=1048576) printf "%.0f MB", b/1048576; else printf "%.0f KB", b/1024 }'; }

# ---------------- 負載：load（每核心）、可用記憶體 %、IO 等待 %
NCPU=$(getconf _NPROCESSORS_ONLN 2>/dev/null); [[ "$NCPU" =~ ^[1-9][0-9]*$ ]] || NCPU=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null); [[ "$NCPU" =~ ^[1-9][0-9]*$ ]] || NCPU=1
read_load() {   # 印「load每核心 可用記憶體% iowait%」；讀不到的印 -1
  local l1 ma mt a b
  l1=$(awk '{print $1}' /proc/loadavg 2>/dev/null)
  mt=$(awk '/^MemTotal:/{print $2}' /proc/meminfo 2>/dev/null); ma=$(awk '/^MemAvailable:/{print $2}' /proc/meminfo 2>/dev/null)
  [ -z "$ma" ] && ma=$(awk '/^(MemFree|Buffers|Cached):/{s+=$2; n++} END{if(n==3) printf "%.0f", s}' /proc/meminfo 2>/dev/null)   # RHEL6 沒有 MemAvailable：粗估
  a=$(awk '/^cpu /{printf "%.0f %.0f", $2+$3+$4+$5+$6+$7+$8, $6}' /proc/stat 2>/dev/null); sleep 2
  b=$(awk '/^cpu /{printf "%.0f %.0f", $2+$3+$4+$5+$6+$7+$8, $6}' /proc/stat 2>/dev/null)
  awk -v l="$l1" -v n="$NCPU" -v ma="$ma" -v mt="$mt" -v a="$a" -v b="$b" 'BEGIN{
    split(a,x," "); split(b,y," "); dt=y[1]-x[1]; io=(dt>0 && y[2]>=x[2])?100*(y[2]-x[2])/dt:-1
    printf "%.2f %.1f %.1f", (l==""?-1:l/n), ((mt>0 && ma!="")?100*ma/mt:-1), io }'
}
busy_reason() {
  awk -v s="$1" -v L="$LOADMAX" -v M="$MEMMIN" -v I="$IOWMAX" 'BEGIN{ split(s,v," "); r=""
    if (v[1]<0 || v[2]<0 || v[3]<0) r="讀不到系統負載；"
    else { if (v[1]>L) r=r sprintf("load 每核心 %.2f > %s；", v[1], L); if (v[2]<M) r=r sprintf("可用記憶體 %.1f%% < %d%%；", v[2], M); if (v[3]>I) r=r sprintf("IO 等待 %.1f%% > %d%%；", v[3], I) }
    printf "%s", r }'
}
load_text() { awk -v s="$1" 'BEGIN{split(s,v," "); printf "load 每核心 %s、可用記憶體 %s%%、IO 等待 %s%%", v[1], v[2], v[3]}'; }

# ---------------- 掛載點（df -l：只問本機，不會卡在失聯的 NFS）
SKIPFS='^(tmpfs|devtmpfs|overlay|squashfs|iso9660|udf|proc|sysfs|cgroup2?|devpts|nfs4?|cifs|smb3?|smbfs|autofs|fuse.*|9p|ramfs|efivarfs|debugfs|tracefs|securityfs|pstore|bpf|mqueue|hugetlbfs|nsfs|binfmt_misc|configfs|rpc_pipefs|gpfs|lustre|ceph|glusterfs|afs|davfs)$'
list_mounts() {   # 輸出：使用率\t總KB\t已用KB\t可用KB\t型態\t掛載點（使用率照 df 自己算的）
  timeout 30 df -P -T -k -l 2>/dev/null | awk -v skip="$SKIPFS" 'NR>1{
    t=$2; if (t ~ skip) next
    if ($3<=0) next; mp=$7; for(i=8;i<=NF;i++) mp=mp" "$i
    if (mp ~ /^\/(proc|sys|dev|run)(\/|$)/) next
    pct=$6; sub(/%/,"",pct); printf "%d\t%.0f\t%.0f\t%.0f\t%s\t%s\n", pct, $3, $4, $5, t, mp }' | sort -t"$(printf '\t')" -k6,6 -u
}
MOUNTS=$(list_mounts)
[ -n "$MOUNTS" ] || die "讀不到任何本機掛載點（df 沒有輸出或逾時）"
mrow() { M="$1" awk -F'\t' 'BEGIN{m=ENVIRON["M"]} $6==m' <<< "$MOUNTS"; }
INODES=$(timeout 30 df -P -i -l 2>/dev/null | awk 'NR>1{mp=$6; for(i=7;i<=NF;i++) mp=mp" "$i; u=$5; sub(/%/,"",u); if (u ~ /^[0-9]+$/) print mp "\t" u}')
ipct() { I="$1" awk -F'\t' 'BEGIN{m=ENVIRON["I"]} $1==m{print $2; exit}' <<< "$INODES"; }   # 讀不到印空白（例如 XFS 動態配置也照樣有值）
path_mount() {   # 一個目錄實際所在的掛載點與型態（直接問 df，不靠上面過濾過的清單）
  timeout 30 df -P -T -k "$1" 2>/dev/null | awk 'NR==2{mp=$7; for(i=8;i<=NF;i++) mp=mp" "$i; print $2 "\t" mp}'
}

# ---------------- 互動選單
if [ "$INTERACTIVE" = 1 ]; then
  echo "======== Linux 磁碟盤點 v$VERSION（只讀，不刪任何檔案）========"
  echo "主機 $HOST，執行身分 $WHO$( [ "$ISROOT" = 0 ] && echo '（非 root：沒權限的目錄會略過）')"
  i=0; declare -a MLIST=()
  while IFS=$'\t' read -r pct tot used avail typ mp; do
    i=$((i+1)); MLIST+=("$mp")
    ip=$(ipct "$mp")
    printf '  %2d. %-30s %3d%%  已用 %s / %s，剩 %s%s%s\n' "$i" "$mp" "$pct" "$(fmt_size $((used*1024)))" "$(fmt_size $((tot*1024)))" "$(fmt_size $((avail*1024)))" "$( [ -n "$ip" ] && echo "　inode $ip%")" "$( { [ "$pct" -ge "$ALERT" ] || { [ -n "$ip" ] && [ "$ip" -ge "$ALERT" ]; }; } && echo "  ← ≥$ALERT%")"
  done <<< "$MOUNTS"
  read -r -p "要掃哪幾個？輸入編號（可多個，例 1 3），ALL＝全部，直接 Enter＝使用率 ≥$ALERT% 的：" ans
  ans=$(echo "$ans" | tr ',' ' ')
  if [ -z "$ans" ]; then MODE='alert'
  elif [ "$(echo "$ans" | tr 'a-z' 'A-Z')" = ALL ]; then MODE='all'
  else for k in $ans; do [[ "$k" =~ ^[0-9]+$ ]] && k=$(dec "$k") && [ "$k" -ge 1 ] && [ "$k" -le "$i" ] || die "沒有這個編號：$k"; DIRS+=("${MLIST[$((k-1))]}"); done; fi
  read -r -p "每個掛載點最多跑幾分鐘？（直接 Enter＝30，最多 120）：" mm
  if [ -n "$mm" ]; then isnum "$mm" && awk -v m="$mm" 'BEGIN{exit !(m>0&&m<=120)}' || die "要輸入 1～120"; MINUTES=$mm; else MINUTES=30; fi
fi

# ---------------- 決定要掃什麼：每筆「根目錄\t所屬掛載點」
declare -a ROOTS=()
if [ ${#PATHS[@]} -gt 0 ]; then
  for p in "${PATHS[@]}"; do
    [ -d "$p" ] || die "目錄不存在：$p"
    rp=$(cd -P -- "$p" 2>/dev/null && pwd -P) || die "進不去：$p"; [ -n "$rp" ] || die "讀不到路徑：$p"
    pm=$(path_mount "$rp"); typ=${pm%%$'\t'*}; mp=${pm#*$'\t'}
    [ -n "$pm" ] || die "查不到 $rp 在哪個檔案系統"
    echo "$typ" | grep -Eq "$SKIPFS" && die "$rp 在 $typ 檔案系統（$mp）上，不是本機實體磁碟，不掃"
    ROOTS+=("$rp"$'\t'"$mp")
  done
elif [ ${#DIRS[@]} -gt 0 ]; then
  for d in "${DIRS[@]}"; do [ "$d" != / ] && d=${d%/}; [ -n "$(mrow "$d")" ] || die "不是本機掛載點：$d（可用 -p 掃一般目錄）"; ROOTS+=("$d"$'\t'"$d"); done
else
  [ -z "$MODE" ] && MODE='alert'
  while IFS=$'\t' read -r pct _ _ _ _ mp; do
    ip=$(ipct "$mp")
    if [ "$MODE" = all ] || [ "$pct" -ge "$ALERT" ] || { [ -n "$ip" ] && [ "$ip" -ge "$ALERT" ]; }; then ROOTS+=("$mp"$'\t'"$mp"); fi   # inode 快滿（小檔太多）也要掃
  done <<< "$MOUNTS"
fi
if [ ${#ROOTS[@]} -eq 0 ]; then
  echo "沒有使用率（容量或 inode）≥ $ALERT% 的掛載點，不用掃。（要全部掃加 -A）"; echo "完成度：100%（沒有需要掃的掛載點）"; exit 0
fi

# ---------------- 報告目錄、單一實例鎖（先確認空間）
[ -z "$OUTDIR" ] && OUTDIR="$HERE/Reports"
[ "$NOREPORT" = 0 ] && { mkdir -p "$OUTDIR" 2>/dev/null || { echo "⚠ 無法建立 $OUTDIR，改成只印在畫面上"; NOREPORT=1; }; }
if [ "$NOREPORT" = 0 ]; then LOCK="$OUTDIR/.running"; else LOCK="${TMPDIR:-/tmp}/disk_housekeeping.$(id -u).running"; fi
if ! mkdir "$LOCK" 2>/dev/null; then
  if [ -f "$LOCK/pid" ] && kill -0 "$(cat "$LOCK/pid" 2>/dev/null)" 2>/dev/null; then die "另一份盤點正在跑（PID $(cat "$LOCK/pid")），同一台同時只跑一份"; fi
  rm -rf "$LOCK"; mkdir "$LOCK" 2>/dev/null || die "無法建立執行鎖 $LOCK"
fi
echo $$ > "$LOCK/pid"
REPDIR=''
if [ "$NOREPORT" = 0 ]; then
  freek=$(df -P -k "$OUTDIR" 2>/dev/null | awk 'NR==2{print $4}')
  if ! [[ "$freek" =~ ^[0-9]+$ ]] || [ "$freek" -lt 512000 ]; then echo "⚠ 報告目錄所在磁碟剩不到 500 MB（或查不到），不寫報告，只印在畫面上"; NOREPORT=1; fi
fi
if [ "$NOREPORT" = 0 ]; then
  REPDIR="$OUTDIR/${HOST}_${STAMP}_$$"
  mkdir "$REPDIR" 2>/dev/null || die "無法建立報告目錄 $REPDIR"
  WORK="$REPDIR/.work"; mkdir "$WORK" || die "無法建立 $WORK"
else WORK=$(mktemp -d 2>/dev/null) || die "無法建立暫存目錄"; fi
LOG="$WORK/run.log"; : > "$LOG"
FINISHED=0
log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOG" 2>/dev/null; }
cleanup() {
  [ -n "${WATCH_PID:-}" ] && kill "$WATCH_PID" 2>/dev/null
  pkill -TERM -P $$ 2>/dev/null
  rm -rf "$WORK" 2>/dev/null
  [ "$FINISHED" = 0 ] && [ -n "$REPDIR" ] && rmdir "$REPDIR" 2>/dev/null
  rm -rf "$LOCK" 2>/dev/null
}
trap cleanup EXIT
trap 'echo; echo "被中斷，已掃的部分不完整，不產生報告。"; exit 3' INT TERM HUP

log "start v$VERSION host=$HOST user=$WHO roots=${#ROOTS[@]} minutes=$MINUTES"
echo "檢查系統負載（約 2 秒）…"
PRELOAD=$(read_load); why=$(busy_reason "$PRELOAD")
if [ -n "$why" ]; then
  echo "系統目前太忙，這次不掃：${why%；}（$(load_text "$PRELOAD")）"; log "skip: $why"
  echo "完成度：0%（負載過高未執行）"; exit 2
fi

# ---------------- 規則
# 系統、資料庫、容器目錄：只列大小，不列進 AP 清理清單、不判斷整包沒動
SYS_RE='^/(usr|lib|lib32|lib64|libx32|bin|sbin|boot|etc|opt/rh|var/lib/(rpm|dpkg|yum|dnf|apt|mysql|pgsql|postgresql|mongodb|redis|docker|containerd|containers|kubelet|libvirt|elasticsearch|cassandra|influxdb|etcd|ceph|snapd|flatpak|systemd)|var/cache/(yum|dnf|apt)|snap)(/|$)|/\.snapshots?(/|$)|/lost\+found(/|$)'
BAK_RE='(back ?up|(^|[^a-z])(bak|old|copy)([^a-z]|$)|複製|備份|副本|舊)|^[a-z].*[-_. ](19|20)[0-9][0-9][-_.]?[0-9][0-9][-_.]?[0-9][0-9]$'
TF=$(( TOPN > 20 ? TOPN : 20 ))

# ---------------- 掃描一個根目錄：find 一次走完，awk 彙整到第 DEPTH 層
scan_root() {   # $1=根 $2=結果 $3=錯誤檔 $4=磁碟已用 bytes（進度用）；回傳 0 完成／124 時間到／125 負載中止／3 程式錯誤
  local root="$1" out="$2" err="$3" used="$4" secs stopflag="$WORK/stop" e st
  secs=$(awk -v m="$MINUTES" 'BEGIN{s=int(m*60); if (s<1) s=1; print s}')
  rm -f "$stopflag"
  ( n=0; while sleep 8; do r=$(busy_reason "$(read_load)"); if [ -n "$r" ]; then n=$((n+1)); echo "  … 系統忙碌（${r%；}）第 $n 次" >&2
      if [ $n -ge 3 ]; then pkill -TERM -P $$ -x timeout 2>/dev/null && echo "$r" > "$stopflag"; break; fi; else n=0; fi; done ) &
  WATCH_PID=$!
  local -a ex=()
  for e in "${EXCL[@]+"${EXCL[@]}"}"; do ex+=(-path "$e" -prune -o); done
  timeout -s TERM -k 15 "$secs" find "$root" -xdev ${ex[@]+"${ex[@]}"} \( -type f -o -type d \) -printf '%y\t%s\t%T@\t%p\0' 2> "$err" |
    tr '\n\0' '\001\n' |   # 一筆一個 NUL 結尾；檔名裡的換行先換成 SOH 字元，輸出時再一對一跳脫（不會撞名、偽造不出假紀錄；awk 不必支援 NUL）
    awk -F'\t' -v root="$root" -v D="$DEPTH" -v oc="$OLDCUT" -v ac="$ANCCUT" -v maxn="$MAXNODES" -v used="$used" -v t0="$(date +%s)" -v tf="$TF" '
    function anc(p,   rel, n, k, a, i, cur) {   # p 所在的統計節點（最多第 D 層）
      if (p == root) return root
      rel = (root == "/") ? substr(p, 2) : substr(p, length(root) + 2)
      n = split(rel, a, "/"); k = (n > D) ? D : n
      cur = root; for (i = 1; i <= k; i++) cur = (cur == "/" ? "" : cur) "/" a[i]
      return cur
    }
    function par(p,   i) { if (p == root) return root; i = p; sub(/\/[^\/]*$/, "", i); if (i == "") i = "/"; if (length(i) < length(root)) i = root; return i }
    function known(p) { while (!(p in B)) { capped = 1; p = par(p) } return p }   # 節點數到上限：歸到已記錄的上層
    function newnode(p) { if (!(p in B) && nn < maxn) { nn++; B[p] = 0; F[p] = 0; NW[p] = 0; TO[p] = 0 } }
    function esc(x) { gsub(/\\/, "\\\\", x); gsub(/\t/, "\\t", x); gsub(/\001/, "\\n", x); return x }   # 一對一跳脫：\ → \\、定位字元 → \t、換行 → \n
    function systime_(   c, t) { c = "date +%s"; c | getline t; close(c); return t + 0 }
    BEGIN { B[root]=0; F[root]=0; NW[root]=0; TO[root]=0; nn=1; last=t0 }
    {
      if (NF < 4 || $2 !~ /^[0-9]+$/ || $3 !~ /^-?[0-9]+(\.[0-9]+)?$/ || ($1 != "f" && $1 != "d")) { weird++; next }   # 格式不對：略過並計數
      ty = $1; sz = $2 + 0; mt = int($3); p = $4; for (i = 5; i <= NF; i++) p = p "\t" $i
      if (ty == "d") { dirs++; for (q = anc(p); q != root && !(q in B); q = par(q)) newnode(q); next }
      files++; scanned += sz
      nd = par(p); nd = (nd == root) ? root : anc(nd); newnode(nd); nd = known(nd)
      isold = (mt < oc); DF[nd]++; DB[nd] += sz; if (mt > DN[nd]) DN[nd] = mt
      for (cur = nd; ; cur = par(cur)) { B[cur] += sz; F[cur]++; if (mt > NW[cur]) NW[cur] = mt; if (isold) { TO[cur] += sz; TOF[cur]++ } if (cur == root) break; cur = known(cur) }
      if (isold) { OB[nd] += sz; OF[nd]++; if (mt < ac) AB[nd] += sz
        e = p; sub(/^.*\//, "", e); if (e ~ /\.[A-Za-z0-9][A-Za-z0-9]*$/ && e !~ /^\.[^.]*$/) { sub(/^.*\./, "", e); e = (length(e) <= 8) ? "." tolower(e) : "（無副檔名）" } else e = "（無副檔名）"; XO[e] += sz }
      if (nt < tf || sz > TS[nt]) {   # 前 tf 大的單一檔
        if (nt < tf) nt++
        for (j = nt; j > 1 && TS[j-1] < sz; j--) { TS[j] = TS[j-1]; TP[j] = TP[j-1]; TM[j] = TM[j-1] }
        TS[j] = sz; TP[j] = p; TM[j] = mt
      }
      if (files % 50000 == 0) { now = systime_(); if (now - last >= 15) { last = now
        printf "  … 掃描中，已讀 %.0f 個檔、%.1f GB%s\n", files, scanned/1073741824, (used > 0 ? sprintf("（約 %.0f%%）", (scanned*100/used > 99 ? 99 : scanned*100/used)) : "") > "/dev/stderr" } }
    }
    END {
      printf "S\t%.0f\t%.0f\t%.0f\t%d\t%.0f\n", files, dirs, scanned, capped + 0, weird + 0
      # 路徑裡的定位字元換成 ?：中間檔用定位字元分欄，不換會讓欄位錯位（可被惡意目錄名偽造數字）
      for (k in B) { kk = esc(k); printf "N\t%s\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\t%.0f\n", kk, B[k], F[k], NW[k], TO[k], OB[k] + 0, AB[k] + 0, OF[k] + 0, DF[k] + 0, DB[k] + 0, DN[k] + 0, TOF[k] + 0 }
      for (j = 1; j <= nt; j++) { pp = esc(TP[j]); printf "F\t%.0f\t%.0f\t%s\n", TS[j], TM[j], pp }
      for (e in XO) printf "X\t%s\t%.0f\n", e, XO[e]
    }' > "$out"
  st=("${PIPESTATUS[@]}")
  kill "$WATCH_PID" 2>/dev/null; wait "$WATCH_PID" 2>/dev/null; WATCH_PID=''
  log "scan $root pipestatus=${st[*]}"
  if [ "${st[2]}" != 0 ]; then echo "awk 彙整失敗（代碼 ${st[2]}）" > "$out.stop"; return 3; fi
  if [ -s "$stopflag" ]; then cat "$stopflag" > "$out.stop"; rm -f "$stopflag"; return 125; fi
  case "${st[0]}" in
    0|1) return 0 ;;                       # find 讀不到某些目錄會回 1（另外計數）
    124|137) echo "timeout" > "$out.stop"; return 124 ;;
    *) echo "find 結束代碼 ${st[0]}" > "$out.stop"; return 3 ;;
  esac
}

# ---------------- 分析一個根目錄，輸出 summary 段落與 CSV 中間檔
analyze_root() {   # $1=根 $2=結果 $3=沒權限清單 $4=停止原因 $5=段落 $6=dirs 中間檔 $7=files 中間檔 $8=ap 中間檔 $9=涵蓋
  SYSRE="$SYS_RE" BAKRE="$BAK_RE" awk -F'\t' -v root="$1" -v stop="$4" -v D="$DEPTH" -v N="$TOPN" -v oc="$OLDCUT" -v now="$NOW" -v OY="$OLDY" -v AY="$ANCY" \
      -v ming="$MINGB" -v sec="$5" -v dtsv="$6" -v ftsv="$7" -v aptsv="$8" -v cov="$9" -v hasex="${#EXCL[@]}" -v minfc="$MINFC" '
    function sz(b) { if (b>=1099511627776) return sprintf("%.2f TB", b/1099511627776); if (b>=1073741824) return sprintf("%.1f GB", b/1073741824); if (b>=1048576) return sprintf("%.0f MB", b/1048576); return sprintf("%.0f KB", b/1024) }
    function dt(t,   d, c, r) { if (t <= 0) return "—"; d = int(t / 86400); if (d in DC) return DC[d]; c = "date -d @" int(t) " +%Y-%m-%d 2>/dev/null"; r = ""; c | getline r; close(c); DC[d] = r; return r }
    function age(t,   y) { if (t <= 0) return ""; y = int((now - t) / 31557600); return (y >= 1) ? "（約 " y " 年前）" : "" }
    function depth(p,   n, a) { if (p == root) return 0; n = split((root == "/") ? substr(p, 2) : substr(p, length(root) + 2), a, "/"); return n }
    function par(p,   i) { if (p == root) return ""; i = p; sub(/\/[^\/]*$/, "", i); if (i == "") i = "/"; return i }
    function base(p,   b) { b = p; sub(/^.*\//, "", b); return b }
    BEGIN { sysre = ENVIRON["SYSRE"]; bakre = ENVIRON["BAKRE"] }   # 用環境變數傳：正規表示式裡的反斜線才不會被 -v 處理掉
    function isprot(p) { return (p ~ sysre) }
    function L(s) { print s > sec }
    function partial(p) { return (stop != "") || (p in PD) }
    function top(arr, cnt, key, n,   i, j, b, x) { # 從 arr[1..cnt] 依 key 選前 n 個放進 SEL[1..]（只做 n 輪，不排全部）
      for (i = 1; i <= cnt; i++) USED[i] = 0
      for (j = 1; j <= n && j <= cnt; j++) { b = 0; for (i = 1; i <= cnt; i++) if (!USED[i] && (b == 0 || key[arr[i]] > key[arr[b]])) b = i; USED[b] = 1; SEL[j] = arr[b] }
      return (n < cnt) ? n : cnt }
    FILENAME ~ /\.denied$/ { if ($0 != "") PD[$0] = 1; next }
    $1 == "S" { files = $2; dirs = $3; scanned = $4; capped = $5; weird = $6; next }
    $1 == "N" { P = $2; B[P] = $3; F[P] = $4; NW[P] = $5; TO[P] = $6; OB[P] = $7; AB[P] = $8; OF[P] = $9; DF[P] = $10; DB[P] = $11; DN[P] = $12; TOF[P] = $13; nodes[++nn] = P; next }
    $1 == "F" { ft++; FS_[ft] = $2; FM[ft] = $3; FP[ft] = $4; next }
    $1 == "X" { XO[$2] = $3; next }
    END {
      minb = ming * 1073741824; tag = (stop != "") ? "≥" : ""
      for (p in PD) { q = par(p); while (q != "") { PD[q] = 1; if (q == root) break; q = par(q) } }   # 讀不到的地方：每一層上層（含根）都算「部分」
      for (i = 1; i <= nn; i++) { p = nodes[i]; if (isprot(p)) { q = par(p); while (q != "") { HP[q] = 1; if (q == root) break; q = par(q) } } }   # 底下含系統／資料庫目錄
      for (i = 1; i <= nn; i++) { p = nodes[i]; if (p == root) continue; q = par(p); if (q == "") continue; KC[q]++; K[q, KC[q]] = p }
      for (d = 0; d <= D; d++) for (i = 1; i <= nn; i++) { p = nodes[i]; if (depth(p) != d) continue
        q = par(p)
        ST[p] = (d >= 1 && F[p] > 0 && NW[p] < oc && !partial(p) && !isprot(p) && !(p in HP) && hasex == 0)
        BK[p] = (d >= 1 && !isprot(p) && !(p in HP) && tolower(base(p)) ~ bakre)
        INS[p] = ST[p] || (q != "" && (q in INS) && INS[q]); INB[p] = BK[p] || (q != "" && (q in INB) && INB[q])
        STT[p] = ST[p] && (q == "" || !INS[q]); BKT[p] = BK[p] && (q == "" || !INB[q]) }
      ap = 0
      # 1. 最佔空間（第一層）＋熱點
      L(""); L("■ " root " 最佔空間的目錄 Top " N)
      m = KC[root]; for (i = 1; i <= m; i++) T[i] = K[root, i]
      c = top(T, m, B, N); if (!c) L("  （無）")
      for (i = 1; i <= c; i++) { p = SEL[i]
        L("  " i ". " p "　" tag sz(B[p]) (TO[p] > 0 ? "，其中 " OY " 年以上沒動 " sz(TO[p]) : "") "　最後異動 " dt(NW[p]) (isprot(p) ? "（系統／資料庫目錄，只列大小，請勿直接刪）" : ""))
        cur = p; while (KC[cur]) { bg = ""; for (j = 1; j <= KC[cur]; j++) { x = K[cur, j]; if (bg == "" || B[x] > B[bg]) bg = x } ; if (bg != "" && B[bg] > 0 && B[bg] >= B[cur] * 0.5) cur = bg; else break }
        if (cur != p) L("     主要集中在：" cur "（" tag sz(B[cur]) "）" (isprot(cur) && !isprot(p) ? "（系統／資料庫目錄）" : ""))
        if ((p in PD) && stop == "") L("     ※ 此目錄有部分沒有權限讀取，實際大小可能更大") }
      # 2. 整包沒動
      L(""); L("■ " root " 整個目錄 " OY " 年以上沒有新檔（看得到的檔案都超過 " OY " 年沒改；請擁有者確認用途後再決定）")
      if (stop != "") L("  （這次沒掃完，不判斷整包沒動，避免把還在用的目錄列進來）")
      else if (hasex) L("  （這次有排除路徑，不判斷整包沒動）")
      c = 0; for (i = 1; i <= nn; i++) { p = nodes[i]; if (STT[p] && ((B[p] >= minb && B[p] > 0) || F[p] >= minfc)) S2[++c] = p }
      c = top(S2, c, B, N); if (!c && stop == "" && !hasex) L("  （無）")
      for (i = 1; i <= c; i++) { p = SEL[i]; L("  " i ". " p "　" sz(B[p]) "、" F[p] " 個檔　最新的檔 " dt(NW[p]) age(NW[p])); ap++; AP[ap] = "整包沒有新檔\t" p "\t" B[p] "\t" NW[p] "\t目錄整包" }
      # 3. 目錄內的舊檔（同目錄還有新檔；最深一層含子目錄）
      L(""); L("■ " root " 目錄內的舊檔（目錄還在用，但裡面有 " OY " 年以上沒改的檔；建議訂保留期限定期清理）")
      c = 0; for (i = 1; i <= nn; i++) { p = nodes[i]; if (!INS[p] && !isprot(p) && NW[p] >= oc && ((OB[p] > 0 && OB[p] >= minb) || OF[p] >= minfc)) S3[++c] = p }
      c = top(S3, c, OB, N); if (!c) L("  （無）")
      for (i = 1; i <= c; i++) { p = SEL[i]; L("  " i ". " p (depth(p) == D ? "（含子目錄）" : "") "　" OY " 年以上的舊檔 " sz(OB[p]) "（" OF[p] " 個" (AB[p] > 0 ? "，其中 " AY " 年以上 " sz(AB[p]) : "") "）"); if (stop == "") { ap++; AP[ap] = "目錄內的舊檔\t" p "\t" OB[p] "\t0\t只算 " OY " 年以上的檔，不是整個目錄" } }
      # 3.5 小檔堆積：直接放在這一層（最深一層含子目錄）的檔案數很多；用檔案數排，不看大小
      # 連同子目錄的檔案數 ≥ 門檻、而且沒有哪個子目錄自己就達標（列最深的那一層）：一個目錄塞一萬個、或一百個子目錄各五千個都抓得到
      L(""); L("■ " root " 小檔堆積（一個目錄連同子目錄的檔案數 ≥ " minfc " 個，列最深的那一層；小檔太多會拖慢備份、防毒，也會吃光 inode，即使總大小不大）")
      c = 0; for (i = 1; i <= nn; i++) { p = nodes[i]; if (depth(p) < 1 || isprot(p) || F[p] < minfc) continue
        hit = 0; for (j = 1; j <= KC[p]; j++) if (F[K[p, j]] >= minfc) { hit = 1; break }
        if (!hit) S5[++c] = p }
      c = top(S5, c, F, N); if (!c) L("  （無）")
      for (i = 1; i <= c; i++) { p = SEL[i]
        L("  " i ". " p "（含子目錄）　" (partial(p) ? "≥" : "") sprintf("%.0f", F[p]) " 個檔，其中 " OY " 年以上 " sprintf("%.0f", TOF[p]) " 個（" (F[p] > 0 ? int(100 * TOF[p] / F[p] + 0.5) : 0) "%）　共 " sz(B[p]) "　最新的檔 " dt(NW[p]))
        if (stop == "") { ap++; AP[ap] = "小檔堆積\t" p "\t" B[p] "\t" NW[p] "\t含子目錄共 " sprintf("%.0f", F[p]) " 個檔，其中舊檔 " sprintf("%.0f", TOF[p]) " 個；請擁有者確認用途後訂保留期限" } }
      # 4. 名稱像備份
      L(""); L("■ " root " 名稱像備份的目錄（名稱含 bak / backup / old / copy / 日期；可能是正式備份或每日批次，請先確認用途）")
      c = 0; for (i = 1; i <= nn; i++) { p = nodes[i]; if (BKT[p] && B[p] > 0 && B[p] >= minb) S4[++c] = p }
      c = top(S4, c, B, N); if (!c) L("  （無）")
      for (i = 1; i <= c; i++) { p = SEL[i]; L("  " i ". " p "　" (partial(p) ? "≥" : "") sz(B[p]) "　最新的檔 " dt(NW[p]) age(NW[p])); if (stop == "") { ap++; AP[ap] = "名稱像備份（請確認用途）\t" p "\t" B[p] "\t" NW[p] "\t目錄整包" } }
      # 5. 單一大檔
      L(""); L("■ " root " 單一大檔 Top " N)
      if (!ft) L("  （無）")
      for (i = 1; i <= ft && i <= N; i++) { L("  " i ". " FP[i] "　" sz(FS_[i]) "　最後異動 " dt(FM[i]) (isprot(FP[i]) ? "（系統／資料庫檔，請勿直接刪）" : "")); if (FS_[i] >= minb && !isprot(FP[i])) { ap++; AP[ap] = "單一大檔\t" FP[i] "\t" FS_[i] "\t" FM[i] "\t單一檔案" } }
      # 6. 舊檔類型
      c = 0; for (e in XO) S6[++c] = e
      c = top(S6, c, XO, 6)
      if (c) { s = ""; for (i = 1; i <= c; i++) s = s (i > 1 ? "、" : "") SEL[i] " " sz(XO[SEL[i]]); L(""); L("■ " root " " OY " 年以上舊檔的類型"); L("  " s) }
      # 中間檔（bytes 放第一欄，之後用 sort -n 排，再轉 CSV）
      for (i = 1; i <= nn; i++) { p = nodes[i]; printf "%.0f\t%s\t%d\t%s\t%.0f\t%s\t%.0f\t%s\t%s\n", B[p], p, depth(p), (partial(p) ? "≥" : "") sz(B[p]), F[p], dt(NW[p]), TO[p], (partial(p) ? "是" : "否"), (isprot(p) ? "是" : "否") >> dtsv }
      for (i = 1; i <= ft; i++) printf "%.0f\t%s\t%s\t%s\n", FS_[i], FP[i], sz(FS_[i]), dt(FM[i]) >> ftsv
      for (i = 1; i <= ap; i++) print AP[i] >> aptsv
      printf "%.0f\t%.0f\t%.0f\t%d\t%.0f\n", B[root], files, dirs, capped, weird > cov
    }' "$3" "$2"
}

# ---------------- 已刪除但還被程式開著的檔案（只有 root 看得到全部；lsof 沒裝就略過）
deleted_open() {   # $1=掛載點；輸出段落
  local mp="$1"
  echo ""; echo "■ $mp 已刪除但還被程式開著的檔案（刪了空間沒回來，通常要重啟該程式或清空 log 才會釋放）"
  if ! command -v lsof >/dev/null 2>&1; then echo "  （這台沒有 lsof，無法檢查）"; return; fi
  [ "$ISROOT" = 0 ] && echo "  ※ 非 root 執行，只看得到自己的程式開的檔案"
  timeout 60 lsof -nP +L1 2>/dev/null | awk -v mp="$mp" 'NR>1 && $5=="REG" {
      p=$10; for(j=11;j<=NF;j++) p=p" "$j
      sub(/ \(deleted\)$/, "", p); if (mp != "/" && index(p, mp "/") != 1) next
      k=$2 SUBSEP p; if (k in S) next; S[k]=$7+0; C[$1 " (PID " $2 ")\t" p]+=$7 }
    END { n=0; for (k in C) { n++; L[n]=k; V[n]=C[k] }
      for (i=1;i<=n;i++) for (j=i+1;j<=n;j++) if (V[j]>V[i]) { t=V[i]; V[i]=V[j]; V[j]=t; t=L[i]; L[i]=L[j]; L[j]=t }
      if (!n) print "  （無）"
      for (i=1;i<=n && i<=5;i++) { split(L[i], a, "\t"); b=V[i]; s=(b>=1073741824)?sprintf("%.1f GB",b/1073741824):sprintf("%.0f MB",b/1048576); print "  " i ". " a[2] "　" s "　程式 " a[1] } }'
}

# ---------------- 主流程
DTSV="$WORK/dirs.tsv"; FTSV="$WORK/files.tsv"; APT="$WORK/ap.tsv"; : > "$DTSV"; : > "$FTSV"; : > "$APT"
declare -a SECS=() COMP=()
EXITC=0; SUMSCAN=0; SUMUSED=0; ALL100=1; UNKNOWN=0; SKIPPED=0
idx=0
for r in "${ROOTS[@]}"; do
  idx=$((idx+1)); root=${r%%$'\t'*}; mp=${r#*$'\t'}
  row=$(mrow "$mp"); usedk=$(echo "$row" | awk -F'\t' '{print $3}'); [[ "$usedk" =~ ^[0-9]+$ ]] || usedk=0
  usedb=$(awk -v k="$usedk" 'BEGIN{printf "%.0f", k*1024}')
  echo "[$idx/${#ROOTS[@]}] 掃描 $root（最多 $MINUTES 分鐘；每 15 秒左右會印一次進度）…"
  out="$WORK/scan.$idx"; err="$WORK/err.$idx"
  t1=$(date +%s); scan_root "$root" "$out" "$err" "$( [ "$root" = "$mp" ] && echo "$usedb" || echo 0)"; rc=$?
  stopw=''
  case $rc in 124) stopw='時間到' ;; 125) stopw="系統忙碌中止（$(sed 's/；$//' "$out.stop" 2>/dev/null)）" ;;
    3) stopw="程式錯誤（$(cat "$out.stop" 2>/dev/null)）"; EXITC=3 ;; esac
  # 沒權限的路徑：find 訊息「find: '/x': Permission denied」（引號樣式依版本不同，全部剝掉）
  grep 'Permission denied' "$err" 2>/dev/null | sed -e 's/^find: //' -e 's/: Permission denied$//' -e "s/^[\`'‘\"]//" -e "s/[’'\"]\$//" > "$err.denied"
  denied=$(grep -c '' "$err.denied" 2>/dev/null); denied=${denied:-0}; other=$(grep -vc 'Permission denied' "$err" 2>/dev/null); other=${other:-0}
  [ -s "$err" ] && { echo "---- $root 讀取錯誤（最多 200 行）----"; head -200 "$err"; } >> "$LOG"
  sec="$WORK/sec.$idx"; cov="$WORK/cov.$idx"; : > "$sec"; printf '0\t0\t0\t0\t0\n' > "$cov"
  if [ -s "$out" ] && [ $rc -ne 3 ]; then analyze_root "$root" "$out" "$err.denied" "$stopw" "$sec" "$DTSV" "$FTSV" "$APT" "$cov" || { stopw="分析失敗"; EXITC=3; }
  else { echo ""; echo "■ $root（沒有讀到資料：${stopw:-可能整個目錄都沒權限}）"; } >> "$sec"; fi
  IFS=$'\t' read -r tb nf ndir capped weird < "$cov"
  note=''; [ "$denied" -gt 0 ] && note="${note}無權限略過 $denied 處；"; [ "$other" -gt 0 ] && note="${note}其他讀取錯誤 $other 筆（見 run.log）；"
  [ "${weird:-0}" != 0 ] && note="${note}檔名特殊（含換行等）無法解析 $weird 筆；"
  [ "${capped:-0}" = 1 ] && note="${note}目錄數超過 $MAXNODES 個，其餘併入上層；"; [ -n "$stopw" ] && note="${note}${stopw}，部分目錄未掃完（標 ≥ 者）；"
  [ ${#EXCL[@]} -gt 0 ] && note="${note}排除：${EXCL[*]}；"
  { echo ""; echo "■ $root 掃描涵蓋"; echo "  已掃 $(fmt_size "${tb:-0}")$( [ "$root" = "$mp" ] && echo " / 磁碟已用 $(fmt_size "$usedb")")（$nf 個檔、$ndir 個目錄，耗時 $(( $(date +%s) - t1 )) 秒）"; [ -n "$note" ] && echo "  ${note%；}"; } >> "$sec"
  [ "$root" = "$mp" ] && deleted_open "$mp" >> "$sec"
  SECS+=("$sec")
  if [ -z "$stopw" ]; then c=100; ct="100%（範圍內都掃過$( [ $((denied+other)) -gt 0 ] && echo "；有 $((denied+other)) 處讀不到而略過，見「掃描涵蓋」")）"
    [ "$root" = "$mp" ] && { SUMSCAN=$(awk -v a="$SUMSCAN" -v u="$usedb" 'BEGIN{printf "%.0f",a+u}'); SUMUSED=$(awk -v a="$SUMUSED" -v u="$usedb" 'BEGIN{printf "%.0f",a+u}'); }
  elif [ "$root" = "$mp" ] && [ "$usedb" != 0 ] && [ $rc -ne 3 ]; then
    c=$(awk -v s="${tb:-0}" -v u="$usedb" 'BEGIN{c=int(s*100/u); if(c>99)c=99; print c}'); ALL100=0; [ "$EXITC" = 0 ] && EXITC=1
    SUMSCAN=$(awk -v a="$SUMSCAN" -v s="${tb:-0}" -v u="$usedb" 'BEGIN{printf "%.0f", a+(s<u?s:u)}'); SUMUSED=$(awk -v a="$SUMUSED" -v u="$usedb" 'BEGIN{printf "%.0f",a+u}')
    ct="約 $c%（$stopw；以「已掃大小 ÷ 磁碟已用」估計，不是精確進度）"
  else ALL100=0; UNKNOWN=1; [ "$EXITC" = 0 ] && EXITC=1; ct="未完成（$stopw；無法估算）"; fi
  COMP+=("  $root　$ct")
  if [ $rc -eq 125 ]; then
    SKIPPED=$(( ${#ROOTS[@]} - idx ))
    for r2 in "${ROOTS[@]:$idx}"; do COMP+=("  ${r2%%$'\t'*}　0%（系統忙碌，沒掃）"); m2=${r2#*$'\t'}; u2=$(mrow "$m2" | awk -F'\t' '{printf "%.0f", $3*1024}'); SUMUSED=$(awk -v a="$SUMUSED" -v u="${u2:-0}" 'BEGIN{printf "%.0f",a+u}'); done
    echo "系統持續忙碌，後面的掛載點不掃了。"; break
  fi
done

# ---------------- summary
SUM="$WORK/summary.txt"
{
  echo "【磁碟空間 Housekeeping 盤點（Linux）】"
  el=$(( $(date +%s) - START ))
  echo "主機：$HOST　執行身分：$WHO　執行時間：$(date -d @"$START" '+%Y-%m-%d %H:%M')　耗時 $((el/60)) 分 $((el%60)) 秒"
  echo "本報告為只讀查詢結果，未刪除或變更任何檔案。"
  echo "「沒有異動」以檔案最後修改時間判斷；$OLDY 年以上視為舊檔，$ANCY 年以上另外標出。修改時間只是線索，不能直接當刪除依據。"
  echo "大小是檔案的邏輯大小：稀疏檔、硬連結、快照會讓加總跟 df 不同，刪了也不一定釋放這麼多；搬到同一顆磁碟的別處不會釋放空間。"
  echo "系統與資料庫目錄（/usr /lib /boot /var/lib/mysql /var/lib/docker …）只列大小，不列進清理清單，請勿直接刪除。"
  [ "$ISROOT" = 0 ] && echo "※ 這次不是用 root 跑：沒權限的目錄會略過，實際用量可能更大（每個掛載點的「掃描涵蓋」有寫略過幾處）。"
  echo "※ 本報告列有完整路徑與檔名，轉寄前請確認內容不含客戶或個人資料名稱。"
  echo ""
  echo "■ 通知摘要（給 AP）"
  for r in "${ROOTS[@]}"; do mrow "${r#*$'\t'}"; done | sort -u | while IFS=$'\t' read -r pct tot used avail typ mp; do
    echo "  主機 $HOST 的 $mp 使用率 $pct%，剩 $(fmt_size $((avail*1024)))（共 $(fmt_size $((tot*1024)))）。"
    if [ "$TARGET" -gt 0 ]; then need=$(awk -v u="$used" -v a="$avail" -v t="$TARGET" 'BEGIN{printf "%.0f", (u - (u+a)*t/100)*1024}')
      if [ "$need" -gt 0 ] 2>/dev/null; then echo "  請 AP 協助降到 $TARGET% 以下，約需再釋放 $(fmt_size "$need")。"; else echo "  目前已在目標 $TARGET% 以下。"; fi; fi
  done
  [ "$TARGET" -le 0 ] && echo "  請 AP 協助將使用率降到：____ %（SP 填）"
  if [ -n "$REPLYBY" ]; then echo "  請在 $REPLYBY 前回覆。"; else echo "  請在 ____ 前回覆（SP 填）"; fi
  echo "  請依同資料夾的 ap_reply.csv 逐項填：處理方式（刪除／移出／壓縮／保留）、負責人、預計完成日。"
  echo ""
  echo "■ 掛載點使用率"
  IUSE=$INODES
  IU="$IUSE" awk -F'\t' -v a="$ALERT" 'BEGIN{n=split(ENVIRON["IU"], L, "\n"); for(i=1;i<=n;i++){split(L[i], x, "\t"); I[x[1]]=x[2]}}
    {printf "  %s　%d%%　已用 %.1f GB / %.1f GB，剩 %.1f GB%s%s\n", $6, $1, $3/1048576, $2/1048576, $4/1048576, (($6 in I) ? "　inode " I[$6] "%" : ""), ($1>=a?"　← 超過 " a "%":"") ((($6 in I) && I[$6]>=a)?"　← inode 超過 " a "%（小檔太多）":"")}' <<< "$MOUNTS"
  for s in "${SECS[@]}"; do cat "$s"; done
  echo ""
  echo "■ 完成度"
  printf '%s\n' "${COMP[@]}"
  echo ""
  echo "處理前請先由系統／資料擁有者確認用途、相依程式與保留規範，再依公司核准程序處理。"
  echo "以上項目請 AP 確認是否可刪除、壓縮或移出，處理後請回覆，謝謝。"
  echo "（執行前負載：$(load_text "$PRELOAD")；工具版本 Linux v$VERSION）"
} > "$SUM"

if [ "$ALL100" = 1 ] && [ "$EXITC" = 0 ]; then CTXT='100%（範圍內都掃過）'
elif [ "$EXITC" = 3 ]; then CTXT='未完成（有程式錯誤，見上方與 run.log）'
elif [ "$UNKNOWN" = 0 ] && [ "$SUMUSED" != 0 ]; then CTXT="約 $(awk -v s="$SUMSCAN" -v u="$SUMUSED" 'BEGIN{c=int(s*100/u); if(c>99)c=99; print c}')%（部分完成；以已掃大小 ÷ 磁碟已用估計）$( [ "$SKIPPED" -gt 0 ] && echo "；有 $SKIPPED 個掛載點因系統忙碌沒掃")"
else CTXT='未完成（無法估算）'; fi
grep -q '^■ 完成度' "$SUM" && echo "整體：$CTXT" >> "$SUM"

echo ""
echo "==================== summary（可直接複製貼到 email）===================="
cat "$SUM"

if [ "$NOREPORT" = 0 ]; then
  bom=$'\xef\xbb\xbf'
  CSVQ='function q(s){ gsub(/"/,"\"\"",s); gsub(/[\r\n]/," ",s); if (s ~ /^[ \t]*[=+@-]/) s="'\''" s; return "\"" s "\"" }'
  { printf '%s' "$bom"; cat "$SUM"; } > "$REPDIR/summary.txt"
  { printf '%s' "$bom"; echo '"路徑","深度","大小(bytes)","大小","檔案數","最新的檔","舊檔(bytes)","有部分沒掃到","系統／資料庫目錄"'
    sort -t"$(printf '\t')" -k1,1nr "$DTSV" | awk -F'\t' "$CSVQ"' { print q($2) "," $3 "," $1 "," q($4) "," $5 "," q($6) "," $7 "," $8 "," $9 }'; } > "$REPDIR/dirs.csv"
  { printf '%s' "$bom"; echo '"路徑","大小(bytes)","大小","最後異動"'
    sort -t"$(printf '\t')" -k1,1nr "$FTSV" | awk -F'\t' "$CSVQ"' { print q($2) "," $1 "," q($3) "," q($4) }'; } > "$REPDIR/large_files.csv"
  { printf '%s' "$bom"; echo '"項次","類別","路徑","大小","最新的檔","範圍","處理方式（刪除／移出／壓縮／保留）","負責人","預計完成日","備註"'
    awk -F'\t' "$CSVQ"'
      function sz(b){ if(b>=1099511627776) return sprintf("%.2f TB",b/1099511627776); if(b>=1073741824) return sprintf("%.1f GB",b/1073741824); if(b>=1048576) return sprintf("%.0f MB",b/1048576); return sprintf("%.0f KB",b/1024)}
      { if (!($2 in R)) { n++; O[n]=$2; R[$2]=$0; CAT[$2]=$1 } else CAT[$2]=CAT[$2] "＋" $1 }
      END { for (i=1;i<=n;i++) { split(R[O[i]], v, "\t"); d=""; if (v[4]+0 > 0) { c="date -d @" int(v[4]) " +%Y-%m-%d 2>/dev/null"; c | getline d; close(c) }
        print i "," q(CAT[O[i]]) "," q(v[2]) "," q(sz(v[3])) "," q(d) "," q(v[5]) ",,,," } }' "$APT"; } > "$REPDIR/ap_reply.csv"
  log "end exit=$EXITC completion=$CTXT"; cp "$LOG" "$REPDIR/run.log" 2>/dev/null
  FINISHED=1
  echo ""; echo "報告：$REPDIR（summary.txt、ap_reply.csv、dirs.csv、large_files.csv、run.log）"
else
  FINISHED=1
fi
echo "完成度：$CTXT"
exit $EXITC

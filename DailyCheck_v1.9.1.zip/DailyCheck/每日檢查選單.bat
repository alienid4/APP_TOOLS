@echo off
chcp 950 >nul
cd /d "%~dp0"
powershell -NoProfile -File "%~dp0dailycheck_menu.ps1" %*

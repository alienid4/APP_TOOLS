﻿# DailyCheck 選單 v1.2.0 (2026-11-17)：仿 AIX SMIT 的全螢幕選單
#   操作只有兩個：↑↓ 移動、Enter 執行。離開／回上一層都是選單裡的一個項目。
#   「0 全部檢查」跑完會另外產生一份總覽報告（照紙本 1～4 分頁），只開總覽，不開四份。
param([switch]$NoOpen, [switch]$All)   # -All＝排程用：不用按鍵，跑完全部並產生總覽
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
if (-not $All -and ([Console]::IsInputRedirected -or $Host.Name -ne 'ConsoleHost')) {
  Write-Host '這個選單要在一般命令視窗（雙擊「每日檢查選單.bat」）執行；排程請用「0_全部檢查_排程.bat」。'
  exit 3
}
. (Join-Path $here 'devlist.ps1')
try { $Host.UI.RawUI.WindowTitle = 'DailyCheck 每日檢查' } catch {}

$ITEMS = @(
  @{ Key = '1'; Text = 'WhatsUp 監控檢查'; Script = 'whatsup_daily.ps1'; Cat = '1'; Pick = $false; Out = 'whatsup_out' },
  @{ Key = '2'; Text = 'VMware 系統檢查'; Script = 'vmware_daily.ps1'; Cat = '2'; Pick = $true; Out = 'vmware_out' },
  @{ Key = '3'; Text = 'Storage/San Switch 檢查'; Script = 'unity_daily.ps1'; Cat = '3'; Pick = $true; Out = 'unity_out' },
  @{ Key = '4'; Text = '其他：AD net time'; Script = 'ad_time.ps1'; Cat = '4'; Pick = $false; Out = 'ad_out' },
  @{ Key = '0'; Text = '全部檢查（1～4 依序執行，產生總覽報告）'; Script = ''; Cat = ''; Pick = $false; Out = '' },
  @{ Key = 'Q'; Text = '離開'; Script = ''; Cat = ''; Pick = $false; Out = '' }
)
$CODE = @{ 0 = '正常'; 1 = '注意'; 2 = '須回報'; 3 = '查不到或不完整'; 4 = '有維護中裝置（須記錄）' }

function W([string]$t) { $n = 0; foreach ($ch in $t.ToCharArray()) { $n += $(if ([int]$ch -ge 0x1100) { 2 } else { 1 }) }; return $n }
function Cut([string]$t, [int]$w) { $o = ''; $n = 0; foreach ($ch in $t.ToCharArray()) { $c = $(if ([int]$ch -ge 0x1100) { 2 } else { 1 }); if ($n + $c -gt $w) { break }; $o += $ch; $n += $c }; return $o }
function Width { $w = 78; try { $w = [Math]::Max([Console]::WindowWidth - 2, 20) } catch {}; return $w }
function Line([string]$t = '', [string]$fg = '', [string]$bg = '') {
  $w = Width; $t = Cut $t $w; $len = W $t; if ($len -lt $w) { $t = $t + (' ' * ($w - $len)) }
  $p = @{ Object = $t }; if ($fg) { $p.ForegroundColor = $fg }; if ($bg) { $p.BackgroundColor = $bg }
  Write-Host @p
}
# 共用：SMIT 樣式畫面，↑↓ 選、Enter 回傳選到的索引；項目太多時自動捲動
function Choose([string]$title, [string[]]$lines, [int]$start = 0) {
  $i = $start
  while ($true) {
    Clear-Host
    $w = Width; $h = 25; try { $h = [Console]::WindowHeight } catch {}
    $room = [Math]::Max($h - 9, 3)
    $top = [Math]::Min([Math]::Max($i - [int]($room / 2), 0), [Math]::Max($lines.Count - $room, 0))
    Line ((' ' * [Math]::Max([int](($w - (W $title)) / 2), 0)) + $title) 'White' 'DarkBlue'
    Line ''
    Line '將游標移到要執行的項目，按 Enter。' 'Gray'
    Line $(if ($top -gt 0) { '  ↑ 上面還有' } else { '' }) 'DarkGray'
    for ($k = $top; $k -lt [Math]::Min($top + $room, $lines.Count); $k++) { if ($k -eq $i) { Line ('  ' + $lines[$k]) 'Black' 'Gray' } else { Line ('  ' + $lines[$k]) } }
    Line $(if ($top + $room -lt $lines.Count) { '  ↓ 下面還有' } else { '' }) 'DarkGray'
    Line ('-' * [Math]::Min($w, 60)) 'DarkGray'
    Line '↑↓ 移動　　Enter 執行' 'Yellow'
    $key = [Console]::ReadKey($true)
    switch ($key.Key) {
      'UpArrow' { $i = ($i - 1 + $lines.Count) % $lines.Count }
      'DownArrow' { $i = ($i + 1) % $lines.Count }
      'Enter' { return $i }
    }
  }
}

# 跑一支檢查；回傳 結束代碼、報告資料夾、錯誤
function RunOne($item, [string]$only, [bool]$quiet) {
  Line ("==== 執行：$($item.Key). $($item.Text)" + $(if ($only) { "（第 $only 號）" } else { '（全部）' })) 'White' 'DarkBlue'
  $t0 = Get-Date
  $sp = @{ NoOpen = ($NoOpen -or $quiet) }
  if ($only) { $sp.Only = $only }
  if ($All) { try { if ((Get-Command (Join-Path $here $item.Script)).Parameters.ContainsKey('NonInteractive')) { $sp.NonInteractive = $true } } catch {} }   # 排程沒人輸入密碼
  $global:LASTEXITCODE = $null; $err = ''
  try { & (Join-Path $here $item.Script) @sp | Out-Host } catch { $err = $_.Exception.Message; Write-Host ('執行失敗：' + $err) -ForegroundColor Red }
  $xc = if ($err) { 3 } elseif ($null -eq $LASTEXITCODE) { 3 } else { [int]$LASTEXITCODE }
  $dir = $null
  $od = Join-Path $here $item.Out
  if (Test-Path $od) { $dir = Get-ChildItem $od -Directory | Where-Object { $_.LastWriteTime -ge $t0.AddSeconds(-2) -and (Test-Path (Join-Path $_.FullName 'report.html')) } | Sort-Object LastWriteTime | Select-Object -Last 1 }
  return [pscustomobject]@{ Item = $item; Code = $xc; Dir = $(if ($dir) { $dir.FullName } else { '' }); Err = $err }
}

function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
. (Join-Path $here 'overview.ps1')   # 總覽：馬上處理／天天發生／備查

# ---------------- 排程模式
if ($All) {
  $logDir = Join-Path $here 'daily_out'; New-Item -ItemType Directory -Force -Path $logDir | Out-Null
  $log = Join-Path $logDir ('排程_' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.log')
  try { Start-Transcript -Path $log | Out-Null } catch {}
  $res = @()
  try {
    foreach ($x in @($ITEMS | Where-Object { $_.Script })) {
      $n = 0; try { $dl = Read-DevList $here $x.Cat 6>$null; if ($null -ne $dl) { $n = $dl.Count } } catch {}
      if ($n -eq 0) { Write-Host ("略過：$($x.Key). $($x.Text)（這台的設備清單沒有設定）"); continue }
      $res += (RunOne $x '' $true)
    }
    try { Overview $res } catch { Write-Host ('總覽報告產生失敗：' + $_.Exception.Message) }
    foreach ($r in $res) { Write-Host ("$($r.Item.Key). $($r.Item.Text)：" + $CODE[$r.Code]) }
  } finally { try { Stop-Transcript | Out-Null } catch {} }
  $codes = @($res | ForEach-Object { $_.Code })
  exit $(if (-not $codes.Count) { 3 } elseif ($codes -contains 2) { 2 } elseif ($codes -contains 3) { 3 } elseif (@($codes | Where-Object { $_ -ne 0 }).Count) { 1 } else { 0 })
}

$pos = 0
while ($true) {
  $pos = Choose 'DailyCheck 每日檢查（唯讀，不改任何設定）' @($ITEMS | ForEach-Object { $_.Key + '. ' + $_.Text }) $pos
  $it = $ITEMS[$pos]
  if ($it.Key -eq 'Q') { Clear-Host; exit 0 }
  Clear-Host
  $res = @()
  if ($it.Key -eq '0') {
    # 這台電腦的設備清單裡沒有的類別就略過（例如 WhatsUp 只在能連到它的電腦上設定）
    foreach ($x in @($ITEMS | Where-Object { $_.Script })) {
      $n = 0; try { $dl = Read-DevList $here $x.Cat 6>$null; if ($null -ne $dl) { $n = $dl.Count } } catch {}
      if ($n -eq 0) { Line ("==== 略過：$($x.Key). $($x.Text)（這台的設備清單沒有設定）") 'DarkGray'; continue }
      $res += (RunOne $x '' $true)
    }
    try { Overview $res } catch { Write-Host ('總覽報告產生失敗：' + $_.Exception.Message) -ForegroundColor Red }
  } else {
    $only = ''
    if ($it.Pick) {
      $devs = Read-DevList $here $it.Cat   # 不要用 @()：PS5.1 對 List 會出錯
      if ($null -ne $devs -and $devs.Count -gt 1) {
        $opts = @("全部（$($devs.Count) 台）") + @($devs | ForEach-Object { ('{0}. {1}' -f $_.No, (Label $_ '')) + $(if ($_.Reject) { '（' + $_.Reject + '）' } else { '' }) }) + @('回上一層')
        $c = Choose "$($it.Key). $($it.Text)：選設備" $opts 0
        if ($c -eq $opts.Count - 1) { continue }
        if ($c -gt 0) { $only = [string]$devs[$c - 1].No }
        Clear-Host
      }
    }
    $res += (RunOne $it $only $false)
  }
  Write-Host ''
  foreach ($r in $res) { Write-Host ("$($r.Item.Key). $($r.Item.Text)：" + $CODE[$r.Code]) }
  Write-Host '按 Enter 回到選單…'
  do { $k = [Console]::ReadKey($true) } until ($k.Key -eq 'Enter')
}

﻿# WhatsUpDaily v1.1.0 (2026-11-17)
# 每日檢查「1. WhatsUp 監控檢查」（唯讀）：讀 WhatsUp Gold REST API（預設 port 9644），對應紙本 5 項：
#   1 離線裝置 Device Down（數量應為 0，不為 0 須發信通知）
#   2 維護裝置 Maintenance Device（數量應為 0，不為 0 須記錄）
#   3 CPU 超出告警：指定群組、上次輪詢，上次輪詢值須低於 75%
#   4 記憶體超出告警：指定群組、上次輪詢，上次輪詢值須低於 90%
#   5 Linux_SWAP 超出告警：REST API 沒有自訂效能監控的數值，改用同一組帳密登入 WhatsUp 網頁，讀「自訂效能監控工具」報表（v2.4.2）；讀不到才列「請人工檢查」
# 只用 GET 讀資料（登入取 token 用 POST），不改 WhatsUp 任何設定。
# 設備清單.csv：類別 1＝WhatsUp 主機（IP 填 WhatsUp 主機，帳號留空＝webit3sc）。
# 結束代碼：0 不會出現（SWAP 一定要人工）、1 自動 5 項正常（SWAP 待人工）、4 有維護裝置、或硬碟 80%～未滿 85% 須記錄（其餘正常）、2 異常、3 查不到／不完整。
# CPU／記憶體：每台取上次輪詢的整台值（rollupByDevice）判定，另列「最高單核心」供對照網頁逐顆 CPU 畫面；輪詢超過 -StaleMin 分鐘＝資料過期，不算正常。
param(
  [ValidateRange(1, 100)][double]$CpuPct = 75,
  [ValidateRange(1, 100)][double]$MemPct = 90,
  [string]$CpuGroup = '1-xServer (重要系統/交易)',
  [string]$MemGroup = '1-xServer (重要系統/交易)',
  [string]$RootGroup = 'My Network',
  [ValidateRange(1, 65535)][int]$Port = 9644,
  [ValidateRange(5, 1440)][int]$StaleMin = 60,
  [ValidatePattern('^$|^[A-Za-z0-9+/]{43}=$')][string]$PinnedPubKey = '',   # 選填：WhatsUp 主機憑證公鑰的 SHA-256（base64）；有填就釘選，不符就拒絕連線
  [switch]$NonInteractive,
  [switch]$Detail,   # 另外讀「逐顆 CPU」與「群組成員對帳」（很慢，預設不讀；CPU 只備查）
  [switch]$NoOpen,
  [ValidateRange(1, 100)][double]$DiskPct = 85,       # 硬碟：任一顆 ≥ 此值＝異常（須通知；總覽列第一級，除非列進「硬碟例外.txt」）
  [ValidateRange(1, 100)][double]$DiskWarnPct = 80,   # 硬碟：任一顆 ≥ 此值＝列參考（注意）；必須小於 DiskPct
  [string]$DiskGroup = 'Server',   # 硬碟只看主機群組（v2.3.0）：網路設備（交換器、F5）的內部分割區本來就常駐滿，不列；空白＝整個 RootGroup
  [string]$DiskExclude = '',  # 選填：磁碟名稱符合這個正規表示式的不列入（光碟機等，自己確認再用）
  [ValidateRange(1, 100)][double]$SwapPct = 90,       # SWAP：任一台 ≥ 此值＝異常（須通知）
  [string]$SwapMonitor = 'Linux_SWAP',                # WhatsUp 自訂效能監控工具的名稱
  [ValidateRange(1, 65535)][int]$WebPort = 443,       # WhatsUp 網頁（NmConsole）的連接埠
  [ValidateRange(30, 3600)][int]$DiskMaxSec = 180   # 硬碟這一步最多讀幾秒；到了先用已讀到的部分出報告，沒讀完的標「查不到（部分）」
)
$ErrorActionPreference = 'Stop'
$ToolVersion = 'WhatsUpDaily v1.9.0'
if ([string]::IsNullOrWhiteSpace($DiskGroup)) { $DiskGroup = $RootGroup } else { $DiskGroup = $DiskGroup.Trim() }
if ($DiskWarnPct -ge $DiskPct) { Write-Host '硬碟參考門檻（DiskWarnPct）必須小於異常門檻（DiskPct）。'; exit 3 }
if ($DiskExclude) { try { [void][regex]::new($DiskExclude) } catch { Write-Host '-DiskExclude 不是有效的正規表示式。'; exit 3 } }
$here = $PSScriptRoot
. (Join-Path $here 'devlist.ps1')

function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
function CsvSafe([object]$v) { if ($null -eq $v) { return '' }; $s = [string]$v -replace '^[\x00-\x1F]+', ''; if ($s -match '^[=+\-@]') { return "'" + $s }; return $s }
function NumOk([object]$v) { if ($null -eq $v -or "$v" -eq '') { return $false }; $x = 0.0; return [double]::TryParse([string]$v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$x) }
function Num([object]$v) { return [double]::Parse([string]$v, [Globalization.CultureInfo]::InvariantCulture) }
function LocalT([object]$s) {
  if ($null -eq $s -or "$s" -eq '') { return '' }
  $o = [DateTimeOffset]::MinValue
  if ([DateTimeOffset]::TryParse([string]$s, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal, [ref]$o)) { return $o.ToLocalTime().ToString('yyyy-MM-dd HH:mm') }
  return [string]$s
}
function CfgQ([string]$s) { return ($s -replace '\\', '\\' -replace '"', '\"') }   # curl 設定檔的雙引號字串

$curl = Join-Path $env:SystemRoot 'System32\curl.exe'
if (-not (Test-Path $curl)) { Write-Host '找不到 Windows 內建 curl.exe（需要 Windows 10 1803／Server 2019 以上），結束。'; exit 3 }

$runStart = Get-Date
$logDir = Join-Path $here 'whatsup_out'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
try { Start-Transcript -Path (Join-Path $logDir ('run_' + $runStart.ToString('yyyyMMdd_HHmmss') + '.log')) -Append | Out-Null; $transcript = $true } catch { $transcript = $false }
$exitCode = 3
$cover = @{}   # 登入失敗時檢查表文字也會用到，先建好（否則 Cannot index into a null array）
try {
$srvList = Read-DevList $here '1'
if ($null -eq $srvList) { exit 3 }
if ($srvList.Count -eq 0) { Write-Host '設備清單.csv 裡沒有類別 1（WhatsUp 主機）。'; exit 3 }
$srv = $srvList[0]
if ($srvList.Count -gt 1) { Write-Host ('類別 1 有 ' + $srvList.Count + ' 筆，只檢查第一筆：' + $srv.Host) }
if ($srv.Reject) { Write-Host $srv.Reject; exit 3 }
$user = if ($srv.User) { $srv.User } else { 'webit3sc' }
if ($null -eq $srv.Sec) {
  if ($NonInteractive) { Write-Host 'WhatsUp 沒有可用的密碼（非互動模式不詢問）。'; exit 3 }
  $srv.Sec = Ask-In ("請輸入 WhatsUp 帳號 $user 的密碼（不會顯示）") -Secure
  if ($null -eq $srv.Sec -or $srv.Sec.Length -eq 0) { Write-Host ('沒有輸入密碼，這次不檢查 WhatsUp（' + $srv.Host + '）。') -ForegroundColor Yellow; exit 3 }
  $remember = ConvertFrom-SecureString -SecureString $srv.Sec   # 加密字串，登入成功後才問要不要記住
}
$base = 'https://' + $srv.Host + ':' + $Port + '/api/v1/'
$label = Label $srv 'WhatsUp'
Write-Host ("WhatsUp 主機：" + $label)

class AuthFail : System.Exception { AuthFail([string]$m) : base($m) {} }
function Curl-Call([string]$url, [string]$cfg, [int]$maxT) {
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $curl
  # -q 不讀 .curlrc；只允許 https；不跟轉址；帳密／token 從 stdin 給，不出現在命令列
  $psi.Arguments = '-q -s -S -k --proto "=https" --noproxy "*" --connect-timeout 15 --max-time ' + $maxT + ' --globoff' + $(if ($PinnedPubKey) { ' --pinnedpubkey "sha256//' + $PinnedPubKey + '"' } else { '' }) + ' -K - -H "Accept: application/json" -w "\n%{http_code}" "' + $url + '"'
  $psi.UseShellExecute = $false
  $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
  $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
  $pr = [Diagnostics.Process]::Start($psi)
  try {
    $pr.StandardInput.Write($cfg); $pr.StandardInput.Close()
    $et = $pr.StandardError.ReadToEndAsync(); $ot = $pr.StandardOutput.ReadToEndAsync()
    if (-not $pr.WaitForExit(($maxT + 15) * 1000)) { try { $pr.Kill() } catch {}; throw "超過 $($maxT + 15) 秒沒回應" }
    $out = $ot.Result; $er = $et.Result; $xc = $pr.ExitCode
  } finally { $pr.Dispose() }
  $i = $out.LastIndexOf("`n")
  $code = if ($i -ge 0) { $out.Substring($i + 1).Trim() } else { '' }
  $body = if ($i -ge 0) { $out.Substring(0, $i) } else { $out }
  if ($xc -ne 0) { $m = ($er -replace '\s+', ' ').Trim(); if ($m.Length -gt 160) { $m = $m.Substring(0, 160) }; throw ("連線／傳輸失敗（curl 代碼 $xc" + $(if ($code -and $code -ne '000') { "，HTTP $code" } else { '' }) + "）：" + $m) }
  return @{ Code = $code; Body = $body }
}
function ErrMsg([string]$body) { try { $j = $body | ConvertFrom-Json; $m = [string](@($j.message, $j.error.message, $j.error_description, $j.code) | Where-Object { $_ } | Select-Object -First 1); $m = ($m -replace '[\x00-\x1F]+', ' ').Trim(); if ($m.Length -gt 200) { $m = $m.Substring(0, 200) }; return $m } catch { return '' } }

# ---------------- 登入取 token
$b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($srv.Sec)
try { $cfg = 'data-urlencode = "grant_type=password"' + "`n" + 'data-urlencode = "username=' + (CfgQ $user) + '"' + "`n" + 'data-urlencode = "password=' + (CfgQ ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($b))) + '"' + "`n" }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
Write-Host '  [1/7] 登入'; Set-Step 'WhatsUp 1/7 登入'
try { $tk = Curl-Call ($base + 'token') $cfg 30 } finally { $cfg = $null }
if ($tk.Code -in '400', '401') { throw [AuthFail]::new("登入被拒（HTTP $($tk.Code)）：帳號或密碼不對，或帳號被停用；為避免鎖帳號不重試。" + (ErrMsg $tk.Body)) }
if ($tk.Code -ne '200') { throw ("登入失敗（HTTP $($tk.Code)）" + $(if (ErrMsg $tk.Body) { '：' + (ErrMsg $tk.Body) } else { '' })) }
$token = [string](($tk.Body | ConvertFrom-Json).access_token); $tk = $null
if (-not $token) { throw '登入回應沒有 access_token' }
if ($token -notmatch '^[A-Za-z0-9._~+/=-]+$') { throw '登入回應的 token 含不允許的字元，不採用' }
$hdr = 'header = "Authorization: Bearer ' + (CfgQ $token) + '"' + "`n"

function Api([string]$path, [int]$maxT = 60) {
  $res = Curl-Call ($base + $path) $hdr $maxT
  if ($res.Code -eq '401') { throw [AuthFail]::new('token 被拒（HTTP 401）') }
  if ($res.Code -eq '403') { throw ("權限不足（HTTP 403）：$user 缺這一項的讀取權限" + $(if (ErrMsg $res.Body) { '：' + (ErrMsg $res.Body) } else { '' })) }
  if ($res.Code -ne '200') { throw ("HTTP $($res.Code)" + $(if (ErrMsg $res.Body) { '：' + (ErrMsg $res.Body) } else { '' })) }
  try { return ($res.Body | ConvertFrom-Json) } catch { throw '回來的不是 JSON' }
}
function DataRows($j) {   # WhatsUp 回 { data: [...] } 或 { data: { 某清單: [...] } }
  if ($null -eq $j -or $null -eq $j.PSObject.Properties['data']) { throw '回應沒有 data 欄位，格式不對' }
  $d0 = $j.data
  if ($null -eq $d0) { return @() }
  if ($d0 -is [array]) { return @($d0) }
  $arr = @($d0.PSObject.Properties | Where-Object { $_.Value -is [array] })
  if ($arr.Count -eq 1) { return @($arr[0].Value) }
  return @($d0)
}
function ApiAll([string]$path, [string]$label = '', [int]$maxSec = 0) {   # 分頁讀完；回傳 @{ Rows; Complete; Pages; TimedOut }
  # $label：有給就每讀一頁印一行進度（畫面不會全黑）；$maxSec：有給就是這一步的時間上限，到了先用已讀到的部分（Complete＝false）
  $rows = New-Object System.Collections.Generic.List[object]
  $pg = ''; $seenPg = @{}; $sw = [Diagnostics.Stopwatch]::StartNew()
  $maxPg = if ($maxSec -gt 0) { 2000 } else { 400 }   # WhatsUp 一頁實際只回 50 筆（不理 limit=250）；有時間上限的步驟靠時間擋，頁數放寬
  for ($n = 1; $n -le $maxPg; $n++) {
    $sep = if ($path.Contains('?')) { '&' } else { '?' }
    $mt = 60
    if ($maxSec -gt 0) {
      $left = $maxSec - $sw.Elapsed.TotalSeconds
      if ($left -lt 10 -and $n -gt 1) { return @{ Rows = $rows.ToArray(); Complete = $false; Pages = $n - 1; TimedOut = $true } }   # 剩不到 10 秒就不再發新請求
      $mt = [int][Math]::Max(10, [Math]::Min(60, $left))
    }
    try { $j = Api ($path + $sep + 'limit=250' + $(if ($pg) { '&pageId=' + [Uri]::EscapeDataString($pg) } else { '' })) $mt }
    catch {   # 有時間上限時，某一頁逾時或失敗：保留前面已讀的頁，回傳部分結果（帳密錯誤照樣往外丟）
      if ($_.Exception -is [AuthFail] -or $maxSec -le 0) { throw }
      if ($label) { Write-Host ("    … $label：第 $n 頁讀取失敗（" + $_.Exception.Message + '），先用已讀到的部分') }
      return @{ Rows = $rows.ToArray(); Complete = $false; Pages = $n - 1; TimedOut = $true }
    }
    foreach ($x in (DataRows $j)) { if ($null -ne $x) { $rows.Add($x) } }
    $pg = if ($j.paging -and $null -ne $j.paging.nextPageId -and "$($j.paging.nextPageId)" -ne '') { [string]$j.paging.nextPageId } else { '' }
    if ($label) { $msg = "$label：已讀 $n 頁、$($rows.Count) 筆（$([int]$sw.Elapsed.TotalSeconds) 秒）"; Write-Host ('    … ' + $msg); Set-Step ('WhatsUp ' + $msg) }
    if (-not $pg) { return @{ Rows = $rows.ToArray(); Complete = $true; Pages = $n; TimedOut = $false } }
    if ($seenPg.ContainsKey($pg)) { throw "分頁游標重複（$pg），資料可能不完整" }
    $seenPg[$pg] = 1
    if ($maxSec -gt 0 -and $sw.Elapsed.TotalSeconds -ge $maxSec) { return @{ Rows = $rows.ToArray(); Complete = $false; Pages = $n; TimedOut = $true } }
  }
  return @{ Rows = $rows.ToArray(); Complete = $false; Pages = $maxPg; TimedOut = $false }
}

$G = @{}
foreach ($k in 'Down', 'Maint', 'Cpu', 'Mem', 'Swap', 'Disk', 'Part', 'Miss', 'Gaps') { $G[$k] = New-Object System.Collections.Generic.List[object] }
$st = [ordered]@{ Down = '不知道'; Maint = '不知道'; Cpu = '不知道'; Mem = '不知道'; Swap = '不知道'; Disk = '不知道' }; $swapWhy = '沒執行到這一步'
function Gap([string]$item, [string]$why) { $G.Gaps.Add([pscustomobject]@{ 項目 = $item; 原因 = $why }); Write-Host ("    ⚠ $item：$why") -ForegroundColor Yellow }
function DevTxt($x) { $ip = [string]$x.networkAddress; $nm = [string]$x.name; if ($ip -and $nm -and $ip -ne $nm) { return "$ip($nm)" } elseif ($ip) { return $ip } else { return $nm } }

# ---------------- 群組
Write-Host '  [2/7] 群組'; Set-Step 'WhatsUp 2/7 群組'
$grp = @{}
function GNorm([string]$n) { return (($n -replace '\s+', '') -replace '（', '(' -replace '）', ')').ToLowerInvariant() }
try {
  $gl = ApiAll 'device-groups/-'
  foreach ($x in $gl.Rows) { $gk = GNorm ([string]$x.name); if ($gk -and "$($x.id)" -match '^\d+$') { if (-not $grp.ContainsKey($gk)) { $grp[$gk] = New-Object System.Collections.Generic.List[string] }; $grp[$gk].Add([string]$x.id) } }
  $grpDone = [bool]$gl.Complete
  if (-not $grpDone) { Gap '群組' '群組清單沒讀完，名稱比對可能不準' }
} catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '群組' $_.Exception.Message }
function GroupId([string]$name, [string]$item) {
  if ($name -match '^\d+$') { return $name }   # 直接給群組 ID
  [string[]]$hit = if ($grp.ContainsKey((GNorm $name))) { $grp[(GNorm $name)].ToArray() } else { @() }   # 注意：不可用 @(List) 或讓單一字串被索引成第一個字元
  if ($hit.Count -gt 1) { Gap $item ("群組名稱「$name」對到 " + $hit.Count + " 個群組（ID " + ($hit -join ',') + "），不猜；請改用群組 ID"); return $null }
  if ($hit.Count -eq 1) { if (-not $grpDone) { Gap $item '群組清單不完整，無法確認名稱唯一' ; return $null }; return [string]$hit[0] }
  Gap $item ("找不到裝置群組「$name」（帳號看得到的群組 " + $grp.Count + " 個）；請確認群組名稱或帳號的群組讀取權限"); return $null
}
$rootId = GroupId $RootGroup '離線／維護'

# ---------------- 1 離線（Device Down）＋ 參考：部分監控停擺
Write-Host '  [3/7] 離線裝置'; Set-Step 'WhatsUp 3/7 離線裝置'
if ($rootId) {
  try {
    $dn = ApiAll ("device-groups/$rootId/devices/-?view=overview&state=Down&returnHierarchy=true")
    $seen = @{}; $noId = 0
    foreach ($x in $dn.Rows) {
      if ("$($x.id)" -eq '') { $noId++; continue }
      if ($seen.ContainsKey([string]$x.id)) { continue }; $seen[[string]$x.id] = 1
      $G.Down.Add([pscustomobject]@{ 裝置 = (DevTxt $x); IP = $x.networkAddress; 名稱 = $x.name; 角色 = $x.role; 停擺監控 = ((@($x.downActiveMonitors) | Where-Object { $_ }) -join '、'); 監控數 = $x.totalActiveMonitors; 停擺數 = $x.totalActiveMonitorsDown; 狀態 = $x.worstState; 裝置ID = $x.id })
    }
    if ($noId) { Gap '離線裝置' "$noId 筆沒有裝置 ID" }
    # 標記「重要」：離線裝置是否在重要群組裡（總覽只有重要的才上「馬上處理」）
    $impFile = Join-Path $here '重要群組.txt'
    $impNames = if (Test-Path $impFile) { @((Read-TextAuto $impFile) -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') }) } else { @($CpuGroup) }
    $impIds = @{}; $impOk = $true
    foreach ($gn in $impNames) {
      $gid = GroupId $gn '重要群組'
      if (-not $gid) { $impOk = $false; continue }
      try { $ig = ApiAll ("device-groups/$gid/devices/-?view=overview&state=Down&returnHierarchy=true"); foreach ($x in $ig.Rows) { if ("$($x.id)") { $impIds[[string]$x.id] = 1 } }; if (-not $ig.Complete) { $impOk = $false } }
      catch { if ($_.Exception -is [AuthFail]) { throw }; $impOk = $false; Gap '重要群組' $_.Exception.Message }
    }
    foreach ($r in $G.Down) { $r | Add-Member -NotePropertyName 重要 -NotePropertyValue $(if ($impIds.ContainsKey([string]$r.裝置ID)) { '是' } elseif ($impOk) { '否' } else { '不知道' }) -Force }
    $st.Down = if (-not $dn.Complete) { Gap '離線裝置' '資料太多，沒讀完'; '不知道' } elseif ($G.Down.Count -or $noId) { '異常' } else { '正常' }
  } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '離線裝置' $_.Exception.Message }
  try {
    $up = ApiAll ("device-groups/$rootId/devices/-?view=overview&state=UpWithDownMonitors&returnHierarchy=true")
    $seen = @{}; $noId = 0
    foreach ($x in $up.Rows) {
      if ("$($x.id)" -eq '') { $noId++; continue }
      if ($seen.ContainsKey([string]$x.id)) { continue }; $seen[[string]$x.id] = 1
      $G.Part.Add([pscustomobject]@{ 裝置 = (DevTxt $x); IP = $x.networkAddress; 名稱 = $x.name; 停擺監控 = ((@($x.downActiveMonitors) | Where-Object { $_ }) -join '、'); 監控數 = $x.totalActiveMonitors; 停擺數 = $x.totalActiveMonitorsDown; 裝置ID = $x.id })
    }
  } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '部分監控停擺（參考）' $_.Exception.Message }
}

# ---------------- 2 維護（Maintenance）：以裝置狀態為準，維護報表補上開始時間／原因
Write-Host '  [4/7] 維護裝置'; Set-Step 'WhatsUp 4/7 維護裝置'
if ($rootId) {
  try {
    $mt = ApiAll ("device-groups/$rootId/devices/-?view=overview&state=Maintenance&returnHierarchy=true")
    $info = @{}; $mr = $null
    try { $mr = ApiAll ("device-groups/$rootId/devices/reports/device-maintenance-mode?returnHierarchy=true"); foreach ($x in $mr.Rows) { $info[[string]$x.id] = $x } }
    catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '維護報表（開始時間／原因）' $_.Exception.Message }
    $seen = @{}; $noId = 0
    foreach ($x in $mt.Rows) {
      if ("$($x.id)" -eq '') { $noId++; continue }
      if ($seen.ContainsKey([string]$x.id)) { continue }; $seen[[string]$x.id] = 1
      $m = $info[[string]$x.id]
      $G.Maint.Add([pscustomobject]@{ 裝置 = (DevTxt $x); IP = $x.networkAddress; 名稱 = $x.name; 角色 = $x.role; 開始 = $(if ($m) { LocalT $m.startTimeUtc } else { '' }); 已維護小時 = $(if ($m -and (NumOk $m.durationSeconds)) { [math]::Round((Num $m.durationSeconds) / 3600, 1) } else { $null }); 設定人 = $(if ($m) { $m.userName } else { '' }); 原因 = $(if ($m) { $m.reason } else { '' }); 裝置ID = $x.id })
    }
    if ($noId) { Gap '維護裝置' "$noId 筆沒有裝置 ID" }
    if ($mr -and -not $mr.Complete) { Gap '維護報表（開始時間／原因）' '沒讀完，部分裝置的開始時間／原因空白' }
    $st.Maint = if (-not $mt.Complete) { Gap '維護裝置' '資料太多，沒讀完'; '不知道' } elseif ($G.Maint.Count) { '注意' } else { '正常' }
  } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap '維護裝置' $_.Exception.Message }
}

# ---------------- 3 CPU、4 記憶體：上次輪詢值
function Pct01([object]$v) {   # API 比例（1.0＝100%，已跟網頁畫面對過）→ 百分比；不合理回 $null
  if (-not (NumOk $v)) { return $null }
  $d = Num $v
  if ([double]::IsNaN($d) -or [double]::IsInfinity($d) -or $d -lt 0 -or $d -gt 1.05) { return $null }
  return 100 * $d
}
$cover = @{}
function DiskName($x) { foreach ($p in 'disk', 'diskName', 'name', 'displayName', 'monitorName', 'instance') { $pp = $x.PSObject.Properties[$p]; if ($pp -and $pp.Value) { return [string]$pp.Value } }; return '' }
function DiskId($x) { $pp = $x.PSObject.Properties['diskId']; if ($pp -and $null -ne $pp.Value) { return [string]$pp.Value }; return '' }
function Util([string]$kind, [string]$group, [double]$pct, [string]$item, $list, [bool]$PerDisk = $false) {
  $gid = GroupId $group $item
  if (-not $gid) { return '不知道' }
  try {
    $rp = ApiAll ("device-groups/$gid/devices/reports/$kind" + "?range=lastPolled&returnHierarchy=true" + $(if ($PerDisk) { '' } else { '&rollupByDevice=true' })) $item $(if ($PerDisk) { $DiskMaxSec } else { 0 })
    $core = @{}   # 每台最高單核心（網頁預設逐顆 CPU 顯示）；讀不到不影響判定
    if ($Detail -and $kind -eq 'cpu-utilization') {
      try { $pc = ApiAll ("device-groups/$gid/devices/reports/$kind" + "?range=lastPolled&returnHierarchy=true&rollupByDevice=false")
            foreach ($x in $pc.Rows) { $v = Pct01 $x.avgPercent; $k2 = [string]$x.id; if ($null -ne $v -and $k2 -and (-not $core.ContainsKey($k2) -or $v -gt $core[$k2])) { $core[$k2] = $v } } }
      catch { if ($_.Exception -is [AuthFail]) { throw }; Gap "$item（逐核心參考）" $_.Exception.Message }
    }
    $by = @{}; $badRow = 0
    $skipDisk = 0
    foreach ($x in $rp.Rows) {
      if ($PerDisk -and $DiskExclude -and ((DiskName $x) -match $DiskExclude)) { $skipDisk++; continue }
      $key = [string]$x.id
      $v = Pct01 $x.avgPercent
      if (-not $key -or $null -eq $v) { $badRow++; continue }
      if ($PerDisk) { $key += '|' + $(if (DiskId $x) { DiskId $x } else { DiskName $x }) }   # 硬碟一顆一筆（跟 WhatsUp 硬碟告警通知一樣）
      if (-not $by.ContainsKey($key) -or $v -gt $by[$key].V) { $by[$key] = @{ V = $v; X = $x } }
    }
    $bad = 0; $stale = 0; $staleDM = 0; $staleDev = @{}
    # 維護中、離線的主機 WhatsUp 本來就不輪詢：資料過期另外算，不列缺口
    $dmWhy = @{}; foreach ($r0 in $G.Maint) { if ("$($r0.裝置ID)") { $dmWhy[[string]$r0.裝置ID] = '維護中' } }; foreach ($r0 in $G.Down) { if ("$($r0.裝置ID)") { $dmWhy[[string]$r0.裝置ID] = '離線' } }
    foreach ($e in $by.Values) {
      $x = $e.X
      $age = if (NumOk $x.timeFromLastPollSeconds) { Num $x.timeFromLastPollSeconds } else { $null }
      $old = ($null -eq $age -or $age -gt $StaleMin * 60)
      $over = ($e.V -ge $pct)   # 用未四捨五入的值判定；等於門檻也算超出
      $dmw = $dmWhy[[string]$x.id]
      if ($over) { $bad++ } elseif ($old) { if ($dmw) { $staleDM++ } else { $stale++; $staleDev[[string]$x.id] = 1 } }
      $mx = Pct01 $x.maxPercent; $mn = Pct01 $x.minPercent
      $list.Add([pscustomobject]@{ 裝置 = $x.deviceName; 磁碟 = $(if ($PerDisk) { DiskName $x } else { $null }); 磁碟ID = $(if ($PerDisk) { DiskId $x } else { $null }); 原始值 = $(if ($PerDisk) { [string]$x.avgPercent } else { $null }); 級別 = $(if ($PerDisk) { if ($e.V -ge $DiskPct) { '異常' } elseif ($over) { '參考' } else { '' } } else { $null }); 上次輪詢值 = [math]::Round($e.V, $(if ($PerDisk) { 2 } else { 1 })); 最高單核心 = $(if ($core.ContainsKey([string]$x.id)) { [math]::Round($core[[string]$x.id], 1) } else { $null }); 最高 = $(if ($null -ne $mx) { [math]::Round($mx, 1) } else { $null }); 最低 = $(if ($null -ne $mn) { [math]::Round($mn, 1) } else { $null })
        輪詢時間 = (LocalT $x.pollTimeUtc); 距上次輪詢分 = $(if ($null -ne $age) { [math]::Round($age / 60, 0) } else { $null }); 判定 = $(if ($over) { "超過 $pct%" } elseif ($old -and $dmw) { "資料過期（$dmw）" } elseif ($old) { '資料過期' } else { '正常' }); 裝置ID = $x.id })
    }
    # 群組成員裡報表沒出現的（監控被拿掉也不會報錯）→ 列參考，不改判定
    if ($Detail) { try {
      $mem = ApiAll ("device-groups/$gid/devices/-?view=overview&returnHierarchy=true")
      $have = @{}; foreach ($x in $rp.Rows) { if ("$($x.id)") { $have[[string]$x.id] = 1 } }
      $mseen = @{}
      foreach ($x in $mem.Rows) { $mk = [string]$x.id; if (-not $mk -or $mseen.ContainsKey($mk)) { continue }; $mseen[$mk] = 1
        if (-not $have.ContainsKey($mk)) { $G.Miss.Add([pscustomobject]@{ 項目 = $item; 裝置 = (DevTxt $x); 角色 = $x.role; 狀態 = $x.worstState; 裝置ID = $x.id }) } }
      $script:cover[$item] = "群組 $($mseen.Count) 台，有資料 $($by.Count) 台"
    } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap "$item（成員對帳參考）" $_.Exception.Message } }
    if ($skipDisk) { Gap $item "依 -DiskExclude 略過 $skipDisk 筆磁碟資料（不列入判定）" }
    if ($badRow) { Gap $item "$badRow 筆沒有有效數值或裝置 ID（可能尚未輪詢），未列入判定" }
    $unit = if ($PerDisk) { '顆' } else { '台' }
    if ($stale) { Gap $item ("$stale $unit" + $(if ($PerDisk) { "（$($staleDev.Count) 台主機）" } else { '' }) + "超過 $StaleMin 分鐘沒有輪詢，資料過期（不是維護中、也不是離線，請到 WhatsUp 確認監控有沒有在跑）") }
    if ($staleDM) { Gap "$item（參考，不影響判定）" "另有 $staleDM $unit屬於維護中或離線的主機，WhatsUp 本來就不輪詢，沒算進資料過期" }
    if (-not $rp.Complete) { Gap $item $(if ($rp.TimedOut) { "超過 $DiskMaxSec 秒只讀了 $($rp.Pages) 頁、$(@($rp.Rows).Count) 筆，其餘沒讀（查不到（部分）；要讀完可加 -DiskMaxSec 或縮小 -DiskGroup）" } else { '資料太多，沒讀完' }); return $(if ($bad) { '異常' } else { '不知道' }) }
    if ($by.Count -eq 0) { Gap $item "群組「$group」上次輪詢沒有任何資料"; return '不知道' }
    if ($bad) { return '異常' } elseif ($badRow -or $stale) { return '不知道' } else { return '正常' }
  } catch { if ($_.Exception -is [AuthFail]) { throw }; Gap $item $_.Exception.Message; return '不知道' }
}
Write-Host '  [5/7] CPU'; Set-Step 'WhatsUp 5/7 CPU'
$st.Cpu = Util 'cpu-utilization' $CpuGroup $CpuPct 'CPU' $G.Cpu
Write-Host '  [6/7] 記憶體'; Set-Step 'WhatsUp 6/7 記憶體'
$st.Mem = Util 'memory-utilization' $MemGroup $MemPct '記憶體' $G.Mem

# ---- SWAP：REST API 沒有自訂效能監控數值，改登入 WhatsUp 網頁讀「自訂效能監控工具」報表（同一組帳密；cookie 只存在暫存檔，用完刪掉）
Write-Host '  [6/7] SWAP（WhatsUp 網頁的自訂效能監控報表）'; Set-Step 'WhatsUp 6/7 SWAP（網頁報表）'
$st.Swap = '不知道'; $swapWhy = ''; $swTrunc = $false
$ck = Join-Path ([IO.Path]::GetTempPath()) ('dc_wug_' + [guid]::NewGuid().ToString('N') + '.txt')
try {
  $web = 'https://' + $srv.Host + $(if ($WebPort -ne 443) { ':' + $WebPort } else { '' }) + '/NmConsole/'
  [IO.File]::WriteAllText($ck, ($srv.Host + "`tFALSE`t/`tTRUE`t0`tAspxAutoDetectCookieSupport`t1`n"), (New-Object Text.UTF8Encoding($false)))
  $ckc = 'cookie = "' + (CfgQ $ck) + '"' + "`n" + 'cookie-jar = "' + (CfgQ $ck) + '"' + "`n"
  $b2 = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($srv.Sec)
  try { $cfg2 = $ckc + 'data-urlencode = "username=' + (CfgQ $user) + '"' + "`n" + 'data-urlencode = "password=' + (CfgQ ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($b2))) + '"' + "`n" }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b2) }
  try { $lg = Curl-Call ($web + 'User/LoginAjax') $cfg2 30 } finally { $cfg2 = $null }
  $ok = $false; try { $au = ($lg.Body | ConvertFrom-Json).authenticated; $ok = ($lg.Code -eq '200' -and $au -is [bool] -and $au) } catch {}
  if (-not $ok) { throw ("網頁登入沒成功（HTTP $($lg.Code)" + $(if ($lg.Code -eq '200') { '，帳密被拒或帳號沒有網頁登入權限' } else { '，網頁登入網址不對或網頁服務沒開' }) + "；帳號 $user）") }
  $q = 'range=LastPolled&n=0&startDate=&endDate=&businessHoursId=0&id=-1&isDevice=false&recurse=true&thresholdFilterIsApplied=false&overThreshold=true&thresholdValue=0&monitorId=-1&page=1&start=0&limit=20000&sortBy=' + [Uri]::EscapeDataString('[{"property":"Avg","direction":"DESC"}]')
  $rr = Curl-Call ($web + 'api/core/ReportCustomPerfMonitor?' + $q) $ckc 120
  if ($rr.Code -ne '200') { throw ("讀自訂效能監控報表失敗（HTTP $($rr.Code)）") }
  $jj = $null; try { $jj = $rr.Body | ConvertFrom-Json } catch { throw '自訂效能監控報表回來的不是 JSON' }
  $all = @($jj.Data)
  if ($null -eq $jj.PSObject.Properties['Data']) { throw '自訂效能監控報表格式不對（沒有 Data 欄位）' }
  $swTrunc = ($null -ne $jj.InlineCount -and [int]$jj.InlineCount -gt $all.Count)
  if ($swTrunc) { Gap 'SWAP' ("報表共 $($jj.InlineCount) 筆，只讀到 $($all.Count) 筆，其餘沒讀（查不到（部分））") }
  $swDmMap = @{}; foreach ($r0 in $G.Maint) { if ("$($r0.裝置ID)") { $swDmMap[[string]$r0.裝置ID] = '維護中' } }; foreach ($r0 in $G.Down) { if ("$($r0.裝置ID)") { $swDmMap[[string]$r0.裝置ID] = '離線' } }
  $inv2 = [Globalization.CultureInfo]::InvariantCulture; $bad2 = 0; $stale2 = 0
  $swBy = @{}; foreach ($x in @($all | Where-Object { [string]$_.Monitor -eq $SwapMonitor })) { $k0 = if ("$($x.DeviceId)") { [string]$x.DeviceId } else { 'n|' + [string]$x.DeviceName }; $t0 = 0.0; [void][double]::TryParse([string]$x.Last, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$t0); if (-not $swBy.ContainsKey($k0) -or $t0 -gt $swBy[$k0].T) { $swBy[$k0] = @{ T = $t0; X = $x } } }
  foreach ($x in @($swBy.Values | ForEach-Object { $_.X })) {
    $v = 0.0; if (-not [double]::TryParse([string]$x.Last, [Globalization.NumberStyles]::Float, $inv2, [ref]$v) -or [double]::IsNaN($v) -or $v -lt 0 -or $v -gt 105) { $bad2++; continue }
    $age = 0.0; $hasAge = [double]::TryParse([string]$x.TimeFromLastPoll, [Globalization.NumberStyles]::Float, $inv2, [ref]$age) -and -not [double]::IsNaN($age) -and -not [double]::IsInfinity($age) -and $age -ge 0
    $old = (-not $hasAge -or $age -gt $StaleMin * 60); $over = ($v -ge $SwapPct); $dmw = $swDmMap[[string]$x.DeviceId]
    if ($old -and -not $over -and -not $dmw) { $stale2++ }   # 維護中／離線的本來就不輪詢，不算
    $mx = 0.0; $hasMx = [double]::TryParse([string]$x.Max, [Globalization.NumberStyles]::Float, $inv2, [ref]$mx)
    $G.Swap.Add([pscustomobject]@{ 裝置 = [string]$x.DeviceName; 監控 = [string]$x.Monitor; 上次輪詢值 = [math]::Floor($v * 100) / 100; 最高 = $(if ($hasMx) { [math]::Round($mx, 2) } else { $null }); 輪詢時間 = ([string]$x.PollTime -replace 'T', ' ')
      距上次輪詢分 = $(if ($hasAge) { [math]::Round($age / 60, 0) } else { $null }); 判定 = $(if ($over) { "超過 $SwapPct%" } elseif ($old -and $dmw) { "資料過期（$dmw）" } elseif ($old) { '資料過期' } else { '正常' }); 裝置ID = [string]$x.DeviceId })
  }
  if ($bad2) { Gap 'SWAP' "$bad2 筆沒有有效數值，未列入判定" }
  if ($G.Swap.Count -eq 0) { throw ("網頁報表裡沒有「$SwapMonitor」監控工具的資料（名稱不同可用 -SwapMonitor 指定）") }
  $nOver = @($G.Swap | Where-Object { $_.判定 -like '超過*' }).Count
  Write-Host ("    SWAP：$($G.Swap.Count) 台，≥$SwapPct% 有 $nOver 台" + $(if ($stale2) { "，資料過期 $stale2 台" } else { '' }))
  $nFresh = @($G.Swap | Where-Object { $_.判定 -eq '正常' }).Count
  if ($stale2) { Gap 'SWAP' "$stale2 台超過 $StaleMin 分鐘沒有輪詢，資料過期（請到 WhatsUp 確認 $SwapMonitor 監控有沒有在跑）" }
  $st.Swap = if ($nOver) { '異常' } elseif ($swTrunc -or $stale2 -or $bad2 -or $nFresh -eq 0) { '不知道' } else { '正常' }   # 跟 CPU／記憶體一致：有過期或壞值就不能說正常
  if ($st.Swap -eq '不知道') { $swapWhy = $(if ($swTrunc) { '報表沒讀完' } elseif ($nFresh -eq 0) { "$SwapMonitor 沒有任何有效的新資料" } else { '有主機資料過期或讀值無效，見收集缺口' }) }
} catch {
  if ($_.Exception -is [AuthFail]) { throw }
  $swapWhy = $_.Exception.Message; Gap 'SWAP' ($swapWhy + '；本項請照紙本人工檢查')
} finally { if (Test-Path -LiteralPath $ck) { Remove-Item -LiteralPath $ck -Force -ErrorAction SilentlyContinue } }
Write-Host '  [7/7] 硬碟（全部設備，一顆一筆）'; Set-Step 'WhatsUp 7/7 硬碟（全部設備，一顆一筆）'
$stDisk = Util 'disk-utilization' $DiskGroup $DiskWarnPct '硬碟' $G.Disk $true
# 硬碟前次比較：%LOCALAPPDATA%\DailyCheck\disk_history.csv（每台電腦各一份，留 40 天）；比的是「上一次有跑的那天」，不一定是昨天
function Disk-Hist($list) {
  $f = Join-Path (Join-Path $env:LOCALAPPDATA 'DailyCheck') 'disk_history.csv'
  $inv = [Globalization.CultureInfo]::InvariantCulture
  $today = (Get-Date).ToString('yyyy-MM-dd', $inv); $cut = (Get-Date).AddDays(-40).ToString('yyyy-MM-dd', $inv)
  $mtx = New-Object Threading.Mutex($false, 'Local\DailyCheck_disk_history'); $got = $false
  try { $got = $mtx.WaitOne(30000) } catch [Threading.AbandonedMutexException] { $got = $true }
  try {
    $old = @(); if (Test-Path $f) { $old = @(Import-Csv $f -Encoding UTF8 | Where-Object { [string]$_.日期 -match '^\d{4}-\d{2}-\d{2}$' -and [string]$_.日期 -ge $cut -and "$($_.裝置ID)" -ne '' }) }
    # 前次＝上一個有跑的日子（不是這顆最後有值的日子）；那天這顆沒讀到就照實寫
    $pd = ''; foreach ($h in $old) { if ([string]$h.日期 -lt $today -and [string]$h.日期 -gt $pd) { $pd = [string]$h.日期 } }
    $prev = @{}; foreach ($h in $old) { if ([string]$h.日期 -eq $pd) { $prev[[string]$h.裝置ID + '|' + [string]$h.磁碟] = $h } }
    # 估計滿載：用近 7 天內最早一筆有效值當基準（只有前次就用前次），算每天平均漲幅
    $w7 = (Get-Date).AddDays(-7).ToString('yyyy-MM-dd', $inv); $base = @{}
    foreach ($h in $old) { $d0 = [string]$h.日期; if ($d0 -ge $today) { continue }; $k0 = [string]$h.裝置ID + '|' + [string]$h.磁碟; $t0 = 0.0
      if (-not [double]::TryParse([string]$h.值, [Globalization.NumberStyles]::Float, $inv, [ref]$t0) -or [double]::IsNaN($t0) -or [double]::IsInfinity($t0) -or $t0 -lt 0 -or $t0 -gt 105) { continue }
      $dt0 = [datetime]::MinValue; if (-not [datetime]::TryParseExact($d0, 'yyyy-MM-dd', $inv, [Globalization.DateTimeStyles]::None, [ref]$dt0)) { continue }
      $ok0 = ($d0 -ge $w7 -or $d0 -eq $pd)
      if ($ok0 -and (-not $base.ContainsKey($k0) -or $d0 -lt $base[$k0].D)) { $base[$k0] = @{ D = $d0; V = $t0 } } }
    foreach ($x in $list) {
      $p = $prev[[string]$x.裝置ID + '|' + [string]$x.磁碟]; $pv = $null; $t = 0.0
      if ($p -and [double]::TryParse([string]$p.值, [Globalization.NumberStyles]::Float, $inv, [ref]$t) -and $t -ge 0 -and $t -le 105) { $pv = $t }
      $x | Add-Member -NotePropertyName 前次 -NotePropertyValue $(if ($null -ne $pv) { $pd.Substring(5) + ' ' + $pv.ToString('0.##', $inv) + '%' } elseif ($pd) { $pd.Substring(5) + ' 沒讀到這顆' } else { '沒資料' }) -Force
      $x | Add-Member -NotePropertyName 成長 -NotePropertyValue $(if ($null -ne $pv) { ([double]$x.上次輪詢值 - $pv).ToString('+0.00;-0.00;0.00', $inv) + ' 百分點' } else { '' }) -Force
      $b = $base[[string]$x.裝置ID + '|' + [string]$x.磁碟]; $est = ''; $nv = [double]$x.上次輪詢值
      if ($null -ne $x.距上次輪詢分 -and [double]$x.距上次輪詢分 -gt $StaleMin) { $est = '輪詢資料過期，不估算' }
      elseif ($nv -ge 100) { $est = '已滿' }
      elseif ($b) {
        $dd = [math]::Max(1, ([datetime]::ParseExact($today, 'yyyy-MM-dd', $inv) - [datetime]::ParseExact($b.D, 'yyyy-MM-dd', $inv)).Days)
        $dv = $nv - $b.V
        $est = if ([math]::Abs($dv) -lt 0.005)  { "無異動（近 $dd 天）" } elseif ($dv -lt 0) { "下降中（近 $dd 天 " + $dv.ToString('0.00', $inv) + '），不估算' } else {
          $n = (100 - $nv) / ($dv / $dd)
          $(if ($n -gt 365) { '一年以上' } elseif ($n -lt 1) { '1 天內' } else { '約 ' + [math]::Floor($n) + ' 天' }) + "（近 $dd 天平均每天 +" + $(if ($dv / $dd -lt 0.005) { '<0.01' } else { ($dv / $dd).ToString('0.00', $inv) }) + '）' }
      }
      $x | Add-Member -NotePropertyName 估計滿載 -NotePropertyValue $est -Force
    }
    if (-not $got) { return '另一個程式正在寫硬碟紀錄，今天的值這次沒存' }
    $sb = New-Object Text.StringBuilder; [void]$sb.AppendLine('"日期","裝置ID","磁碟","值"')
    $q = { param($v) '"' + ([string]$v -replace '"', '""') + '"' }
    $mine = @{}; foreach ($x in $list) { if (-not ($null -ne $x.距上次輪詢分 -and [double]$x.距上次輪詢分 -gt $StaleMin)) { $mine[[string]$x.裝置ID + '|' + [string]$x.磁碟] = 1 } }   # 同日重跑：只換掉這次有讀到的磁碟，沒讀到的保留稍早的值
    foreach ($h in $old) { if ([string]$h.日期 -ne $today -or -not $mine.ContainsKey([string]$h.裝置ID + '|' + [string]$h.磁碟)) { [void]$sb.AppendLine((& $q $h.日期) + ',' + (& $q $h.裝置ID) + ',' + (& $q $h.磁碟) + ',' + (& $q $h.值)) } }
    foreach ($x in $list) { if ("$($x.裝置ID)" -ne '' -and -not ($null -ne $x.距上次輪詢分 -and [double]$x.距上次輪詢分 -gt $StaleMin)) { [void]$sb.AppendLine((& $q $today) + ',' + (& $q $x.裝置ID) + ',' + (& $q $x.磁碟) + ',' + (& $q (([double]$x.上次輪詢值).ToString('0.##', $inv)))) } }
    New-Item -ItemType Directory -Force -Path (Split-Path $f) | Out-Null
    $tmp = $f + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($tmp, $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
    Move-Item -Force $tmp $f
    return ''
  } finally { if ($got) { try { $mtx.ReleaseMutex() } catch {} }; $mtx.Dispose() }
}
# 同一台有兩顆以上同名磁碟（名稱抓不到時會退回監控名稱）：名稱後面加磁碟ID，歷史與例外才不會串在一起
$dn = @{}; foreach ($x in $G.Disk) { $k = [string]$x.裝置ID + '|' + [string]$x.磁碟; $dn[$k] = 1 + [int]$dn[$k] }
foreach ($x in $G.Disk) { if ($dn[[string]$x.裝置ID + '|' + [string]$x.磁碟] -gt 1 -and [string]$x.磁碟ID) { $x.磁碟 = [string]$x.磁碟 + ' [' + $x.磁碟ID + ']' } }
try { $dhNote = Disk-Hist $G.Disk; if ($dhNote) { Gap '前次比較（參考，不影響判定）' $dhNote } } catch { Gap '前次比較（參考，不影響判定）' $_.Exception.Message }
foreach ($x in $G.Disk) { if ($null -eq $x.PSObject.Properties['前次']) { $x | Add-Member -NotePropertyName 前次 -NotePropertyValue '沒資料' -Force; $x | Add-Member -NotePropertyName 成長 -NotePropertyValue '' -Force; $x | Add-Member -NotePropertyName 估計滿載 -NotePropertyValue '' -Force } }
$st.Disk = if ($stDisk -eq '異常') { if (@($G.Disk | Where-Object { $_.級別 -eq '異常' }).Count) { '異常' } else { '注意' } } else { $stDisk }
$authErr = $null
} catch {
  if ($_.Exception -is [AuthFail] -or -not $G) { $authErr = $_.Exception.Message; Write-Host ('停止：' + $authErr) -ForegroundColor Red; if (-not $G) { $G = @{}; foreach ($k in 'Down', 'Maint', 'Cpu', 'Mem', 'Swap', 'Disk', 'Part', 'Miss', 'Gaps') { $G[$k] = New-Object System.Collections.Generic.List[object] }; $st = [ordered]@{ Down = '不知道'; Maint = '不知道'; Cpu = '不知道'; Mem = '不知道'; Swap = '不知道'; Disk = '不知道' }; $swapWhy = '沒執行到這一步' }; $G.Gaps.Add([pscustomobject]@{ 項目 = '登入／連線'; 原因 = $authErr }) }
  else { throw }
}
try {
# ================================================================ 結論與檢查表文字（照紙本 5 項）
function DaysN([string]$t) {   # 估計滿載 → 排序用天數（越快滿越小；不會滿／不知道排最後）
  if ($t -match '^已滿') { return 0 } elseif ($t -match '^1 天內') { return 0.5 } elseif ($t -match '^約 (\d+) 天') { return [double]$Matches[1] }
  elseif ($t -match '^一年以上') { return 400 } elseif ($t -match '^(無異動|下降中)') { return 9999 } else { return 99999 }
}
function Txt([string]$s, $rows, [scriptblock]$fmt) {
  if ($s -eq '正常') { return '無' }
  if ($s -eq '不知道') { return '查不到（請人工檢查，原因見收集缺口）' }
  return ((@($rows | ForEach-Object { & $fmt $_ })) -join "`n")
}
$sheet = @(
  [pscustomobject]@{ 項次 = 1; 項目 = '離線裝置：Device Down'; 判定 = $st.Down; 處置 = $(switch ($st.Down) { '異常' { '須發信通知' } '正常' { '—' } default { '須人工檢查' } }); 數量 = $(if ($st.Down -ne '不知道') { $G.Down.Count } else { $null })
    檢查表文字 = (Txt $st.Down $G.Down { param($x) $x.裝置 + ' | Device Down' + $(if ($x.停擺監控) { ' | ' + $x.停擺監控 } elseif ($null -ne $x.停擺數) { ' | 停擺監控 ' + $x.停擺數 + '/' + $x.監控數 } else { '' }) }); 頁 = 'tD' }
  [pscustomobject]@{ 項次 = 2; 項目 = '維護裝置：Maintenance Device'; 判定 = $st.Maint; 處置 = $(switch ($st.Maint) { '注意' { '須記錄' } '正常' { '—' } default { '須人工檢查' } }); 數量 = $(if ($st.Maint -ne '不知道') { $G.Maint.Count } else { $null })
    檢查表文字 = (Txt $st.Maint $G.Maint { param($x) $x.裝置 + ' | 維護' + $(if ($x.開始) { ' | 自 ' + $x.開始 } else { '' }) + $(if ($x.原因) { ' | ' + $x.原因 } else { '' }) }); 頁 = 'tM' }
  [pscustomobject]@{ 項次 = 3; 項目 = "CPU 超出告警：CPU Exceeds($CpuPct%)"; 判定 = $st.Cpu; 處置 = $(switch ($st.Cpu) { '異常' { '須截圖發信通知' } '正常' { '—' } default { '須人工檢查' } }); 數量 = $(if ($st.Cpu -ne '不知道') { @($G.Cpu | Where-Object { $_.判定 -like '超過*' }).Count } else { $null })
    檢查表文字 = (Txt $st.Cpu @($G.Cpu | Where-Object { $_.判定 -like '超過*' } | Sort-Object 上次輪詢值 -Descending) { param($x) $x.裝置 + ' 上次輪詢值 ' + $x.上次輪詢值 + '%' }) + $(if ($cover['CPU']) { "`n（" + $cover['CPU'] + '）' } else { '' }); 頁 = 'tC' }
  [pscustomobject]@{ 項次 = 4; 項目 = "記憶體超出告警：Memory Exceeds($MemPct%)"; 判定 = $st.Mem; 處置 = $(switch ($st.Mem) { '異常' { '須截圖發信通知' } '正常' { '—' } default { '須人工檢查' } }); 數量 = $(if ($st.Mem -ne '不知道') { @($G.Mem | Where-Object { $_.判定 -like '超過*' }).Count } else { $null })
    檢查表文字 = (Txt $st.Mem @($G.Mem | Where-Object { $_.判定 -like '超過*' } | Sort-Object 上次輪詢值 -Descending) { param($x) $x.裝置 + ' 上次輪詢值 ' + $x.上次輪詢值 + '%' }) + $(if ($cover['記憶體']) { "`n（" + $cover['記憶體'] + '）' } else { '' }); 頁 = 'tR' }
  [pscustomobject]@{ 項次 = 5; 項目 = "Linux_SWAP 超出告警（$SwapPct%）"; 判定 = $(if ($st.Swap -eq '不知道') { '人工' } else { $st.Swap }); 處置 = $(switch ($st.Swap) { '異常' { '須截圖發信通知' } '正常' { '—' } default { '請照紙本步驟人工檢查' } }); 數量 = $(if ($st.Swap -ne '不知道') { @($G.Swap | Where-Object { $_.判定 -like '超過*' }).Count } else { $null })
    檢查表文字 = $(if ($st.Swap -eq '不知道') { '（SWAP 這次沒讀到：' + $swapWhy + '；本項請人工檢查）' } else { Txt $st.Swap @($G.Swap | Where-Object { $_.判定 -like '超過*' } | Sort-Object 上次輪詢值 -Descending) { param($x) $x.裝置 + ' 上次輪詢值 ' + $x.上次輪詢值 + '%' } }); 頁 = 'tW' }
  [pscustomobject]@{ 項次 = 6; 項目 = "硬碟使用率超出告警：Disk Exceeds($DiskPct%，參考 $DiskWarnPct%)"; 判定 = $st.Disk; 處置 = $(switch ($st.Disk) { '異常' { '須截圖發信通知' } '注意' { '須記錄（參考）' } '正常' { '—' } default { '須人工檢查' } }); 數量 = $(if ($st.Disk -ne '不知道') { @($G.Disk | Where-Object { $_.判定 -like '超過*' }).Count } else { $null })
    檢查表文字 = (Txt $st.Disk @($G.Disk | Where-Object { $_.判定 -like '超過*' } | Sort-Object @{ e = { if ([double]$_.上次輪詢值 -ge 90) { 0 } else { 1 } } }, @{ e = { DaysN ([string]$_.估計滿載) } }, @{ e = { [double]$_.上次輪詢值 }; Descending = $true }) { param($x) $x.裝置 + $(if ($x.磁碟) { ' ' + $x.磁碟 } else { '' }) + ' 上次輪詢值 ' + $x.上次輪詢值 + '%（' + $(if ($x.級別 -eq '異常') { '異常' } else { '參考' }) + '）｜前次 ' + $x.前次 + $(if ($x.成長) { '（' + $x.成長 + '）' } else { '' }) + $(if ($x.估計滿載) { '｜估計滿載 ' + $x.估計滿載 } else { '' }) }) + $(if ($cover['硬碟']) { "`n（" + $cover['硬碟'] + '）' } else { '' }); 頁 = 'tK' }
)
$vals = @(@($st.Keys) | Where-Object { $_ -ne 'Swap' -or $st.Swap -ne '不知道' } | ForEach-Object { $st[$_] })
$okLbl = if ($st.Swap -eq '不知道') { '自動 5 項正常' } else { '自動 6 項全部正常' }
$overall = if ($authErr) { '查不到' } elseif ($vals -contains '異常') { '異常' } elseif ($vals -contains '不知道') { '須補查' } elseif ($vals -contains '注意') { '注意' } else { $okLbl }
$exitCode = switch (($overall -replace '＋另有項目須補查$', '')) { '異常' { 2 } '注意' { 4 } '自動 5 項正常' { 1 } '自動 6 項全部正常' { 1 } default { 3 } }
$diskGap = (@($G.Gaps | Where-Object { [string]$_.項目 -like '硬碟*' }).Count -gt 0)
if ((($overall -eq '異常') -and (($vals -contains '不知道') -or $diskGap)) -or (($overall -eq '注意') -and $diskGap)) { $overall += '＋另有項目須補查' }
if ($st.Swap -eq '不知道') { $overall += '（SWAP 待人工檢查）' }

# ================================================================ 輸出
$outDir = Join-Path $logDir ($runStart.ToString('yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0, 6))
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$COLS = [ordered]@{
  Sheet = @('項次', '項目', '判定', '處置', '數量', '檢查表文字'); Down = @('裝置', 'IP', '名稱', '角色', '重要', '停擺監控', '監控數', '停擺數', '狀態', '裝置ID')
  Maint = @('裝置', 'IP', '名稱', '角色', '開始', '已維護小時', '設定人', '原因', '裝置ID'); Cpu = @('裝置', '上次輪詢值', '最高單核心', '最高', '最低', '輪詢時間', '距上次輪詢分', '判定', '裝置ID')
  Mem = @('裝置', '上次輪詢值', '最高', '最低', '輪詢時間', '距上次輪詢分', '判定', '裝置ID'); Swap = @('裝置', '監控', '上次輪詢值', '最高', '輪詢時間', '距上次輪詢分', '判定', '裝置ID'); Disk = @('裝置', '磁碟', '磁碟ID', '上次輪詢值', '前次', '成長', '估計滿載', '原始值', '最高', '最低', '輪詢時間', '距上次輪詢分', '判定', '級別', '裝置ID'); Part = @('裝置', 'IP', '名稱', '停擺監控', '監控數', '停擺數', '裝置ID'); Miss = @('項目', '裝置', '角色', '狀態', '裝置ID'); Gaps = @('項目', '原因')
}
$FILE = @{ Sheet = '00_檢查表文字.csv'; Down = '01_離線裝置.csv'; Maint = '02_維護裝置.csv'; Cpu = '03_CPU.csv'; Mem = '04_記憶體.csv'; Swap = '08_SWAP.csv'; Disk = '07_硬碟.csv'; Part = '05_參考_部分監控停擺.csv'; Miss = '06_參考_群組內沒有效能資料.csv'; Gaps = '09_收集缺口.csv' }
# 注意：PS 5.1 對 @(泛型 List) 會丟「引數類型不相容」，一律先轉成陣列
$DATA = @{ Sheet = $sheet; Down = $G.Down.ToArray(); Maint = $G.Maint.ToArray(); Cpu = @($G.Cpu | Sort-Object 上次輪詢值 -Descending); Mem = @($G.Mem | Sort-Object 上次輪詢值 -Descending); Swap = @($G.Swap | Sort-Object 上次輪詢值 -Descending); Disk = @($G.Disk | Sort-Object 上次輪詢值 -Descending); Part = $G.Part.ToArray(); Miss = $G.Miss.ToArray(); Gaps = $G.Gaps.ToArray() }
foreach ($k in $COLS.Keys) {
  $sb = New-Object Text.StringBuilder
  [void]$sb.AppendLine((($COLS[$k] | ForEach-Object { '"' + $_ + '"' }) -join ','))
  foreach ($row in @($DATA[$k])) { [void]$sb.AppendLine((($COLS[$k] | ForEach-Object { '"' + ([string](CsvSafe $row.$_) -replace '"', '""') + '"' }) -join ',')) }
  [IO.File]::WriteAllText((Join-Path $outDir $FILE[$k]), $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
}
function RowCls([string]$v) { switch -Wildcard ($v) { '異常' { 'bad' } '超過*' { 'bad' } '注意' { 'warn' } '不知道' { 'unk' } '資料過期*' { 'unk' } '人工' { 'unk' } default { '' } } }
function Table([string]$k, [string]$pre, [string]$id) {
  $c = $COLS[$k]; $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<table class='t' id='$id'><thead><tr><th>編號</th>"); foreach ($h in $c) { [void]$sb.Append('<th>' + (Esc $h) + '</th>') }; [void]$sb.Append('</tr></thead><tbody>')
  $n = 0
  foreach ($row in @($DATA[$k])) {
    $n++; [void]$sb.Append("<tr class='" + $(if ($k -eq 'Disk' -and [string]$row.級別 -eq '參考') { 'warn' } else { RowCls ([string]$row.判定) }) + "'><td data-v='$n'>$pre$n</td>")
    foreach ($h in $c) { $v = $row.$h; $dv = if ($v -is [double] -or $v -is [int]) { " data-v='" + ([double]$v).ToString([Globalization.CultureInfo]::InvariantCulture) + "'" } else { '' }; [void]$sb.Append("<td$dv>" + (Esc $v) + '</td>') }
    [void]$sb.Append('</tr>')
  }
  if ($n -eq 0) { [void]$sb.Append("<tr class='empty'><td colspan='" + ($c.Count + 1) + "'>沒有資料</td></tr>") }
  [void]$sb.Append('</tbody></table>'); return $sb.ToString()
}
$cards = ($sheet | ForEach-Object { "<div class='card " + (RowCls $_.判定) + "' data-go='" + $_.頁 + "'><span>" + $_.項次 + '. ' + (Esc $_.項目) + "</span><b>" + $(if ($null -ne $_.數量) { $_.數量 } else { Esc $_.判定 }) + "</b><i>" + (Esc $_.判定) + '｜' + (Esc $_.處置) + "</i></div>" }) -join ''
$sheetRows = ($sheet | ForEach-Object { "<tr class='" + (RowCls $_.判定) + "'><td data-v='" + $_.項次 + "'>W" + $_.項次 + "</td><td>" + (Esc $_.項目) + "</td><td><b>" + (Esc $_.判定) + "</b></td><td>" + (Esc $_.處置) + "</td><td class='cp'>" + (Esc $_.檢查表文字) + "</td><td><button class='copy'>複製</button></td></tr>" }) -join ''
$color = switch -Wildcard ($overall) { '異常*' { '#B3261E' } '自動*' { '#0C6B37' } '注意*' { '#8A6D00' } default { '#6B5E00' } }
$tabs = @(@('tS', '檢查表'), @('tD', "1 離線（$($G.Down.Count)）"), @('tM', "2 維護（$($G.Maint.Count)）"), @('tC', '3 CPU'), @('tR', '4 記憶體'), @('tW', '5 SWAP'), @('tK', '6 硬碟'), @('tP', "參考：部分監控停擺（$($G.Part.Count)）"), @('tN', "參考：沒有效能資料（$($G.Miss.Count)）"), @('tG', "收集缺口（$($G.Gaps.Count)）"))
$nav = ($tabs | ForEach-Object { "<button data-for='" + $_[0] + "'>" + (Esc $_[1]) + '</button>' }) -join ''
$html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>WhatsUp 監控檢查 $($runStart.ToString('yyyy-MM-dd HH:mm'))</title>
<style>body{font-family:"Microsoft JhengHei",sans-serif;margin:0;background:#f6f7f9}header{background:$color;color:#fff;padding:12px 16px}h1{margin:0;font-size:20px}.m{font-size:13px}
nav{background:#fff;border-bottom:1px solid #ddd;padding:6px 16px;position:sticky;top:0}nav button{border:1px solid #ccc;background:#fff;padding:5px 10px;margin:2px;cursor:pointer;border-radius:4px}nav button.on{background:#0C6B37;color:#fff;border-color:#0C6B37}
section{display:none;padding:12px 16px}section.on{display:block}.cards{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}.card{background:#fff;border:1px solid #ddd;border-radius:6px;padding:8px 12px;min-width:170px;cursor:pointer}
.card span{display:block;font-size:13px}.card b{display:block;font-size:24px}.card i{font-style:normal;font-size:12px;color:#555}.card.bad b{color:#B3261E}.card.warn b{color:#8A6D00}.card.unk b{color:#6B5E00}
table{border-collapse:collapse;background:#fff;width:100%;font-size:13px}th{background:#eef2ef;cursor:pointer}td,th{border:1px solid #ddd;padding:4px 6px;vertical-align:top}
tr.bad td{background:#fde8e8}tr.warn td{background:#fff6dc}tr.unk td{background:#efefef}td.cp{white-space:pre-wrap}.cpt{white-space:pre-wrap;line-height:1.6}.cpt.fold{display:none}.cpt .al{color:#B3261E;font-weight:700}.cpt .am{color:#8A6D00;font-weight:700}button.more{display:inline-block;margin:2px 0;padding:4px 10px;border:1px solid #9AA5A0;border-radius:12px;background:#F4F6F5;cursor:pointer;font-weight:700}</style></head><body>
<header><h1>1-WhatsUp 監控檢查　結論：$(Esc $overall)</h1><div class="m">WhatsUp $(Esc $label)｜執行 $($runStart.ToString('yyyy-MM-dd HH:mm:ss'))｜執行人 $(Esc "$env:USERDOMAIN\$env:USERNAME")｜$ToolVersion｜CPU 群組「$(Esc $CpuGroup)」上次輪詢值 ≥$CpuPct%、記憶體群組「$(Esc $MemGroup)」≥$MemPct% 為超出（上次輪詢；超過 $StaleMin 分鐘沒輪詢＝資料過期）</div></header>
<nav>$nav</nav>
<section id="tS"><div class="cards">$cards</div><h3>檢查表文字（按「複製」貼進每日檢查表「異常訊息」欄）</h3>
<table class="t" id="sT"><thead><tr><th>編號</th><th>項目</th><th>判定</th><th>處置</th><th>檢查表文字</th><th></th></tr></thead><tbody>$sheetRows</tbody></table></section>
<section id="tD">$(Table 'Down' 'D' 'xD')</section><section id="tM">$(Table 'Maint' 'M' 'xM')</section><section id="tC"><p>判定用「上次輪詢值」（WhatsUp 最近一次輪詢的整台數值）；「最高單核心」是網頁逐顆 CPU 畫面上最高的那一顆，供對照。</p>$(Table 'Cpu' 'C' 'xC')</section>
<section id="tR">$(Table 'Mem' 'R' 'xR')</section><section id="tW"><p>來源：WhatsUp 網頁「分析 → 效能 → 自訂監控工具」報表（監控工具「$(Esc $SwapMonitor)」），判定用上次輪詢值，≥$SwapPct% 為異常。</p>$(Table 'Swap' 'S' 'xW')</section><section id="tK"><p>範圍：WhatsUp 群組「$(Esc $DiskGroup)」裡有磁碟監控資料的設備（沒裝磁碟監控的設備不會出現在這裡）。判定用「上次輪詢值」；一顆磁碟一筆，數量是「顆」（跟 WhatsUp 硬碟告警通知對得上）。≥$DiskPct% 是異常，$DiskWarnPct%～$DiskPct% 列參考。「前次」是上一次有跑的那天（星期一會比星期五），那天沒讀到這顆就照實寫；成長單位是百分點。</p>$(Table 'Disk' 'K' 'xK')</section><section id="tP"><p>裝置本身還在，但有部分監控項目停擺（不算紙本的 Device Down，供參考）。</p>$(Table 'Part' 'P' 'xP')</section><section id="tN"><p>群組裡有、但這次 CPU／記憶體報表沒有資料的裝置（例如監控被拿掉、沒有效能監控）。不影響判定，請確認是否應該有監控。</p>$(Table 'Miss' 'N' 'xN')</section><section id="tG">$(Table 'Gaps' 'G' 'xG')</section>
<script>(function(){var secs=document.querySelectorAll('section'),nav=document.querySelector('nav');
function show(id){secs.forEach(function(s){s.classList.toggle('on',s.id==id)});nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-for')==id)})}
nav.querySelectorAll('button').forEach(function(b){b.addEventListener('click',function(){show(b.getAttribute('data-for'))})});
document.querySelectorAll('.card').forEach(function(c){c.addEventListener('click',function(){var g=c.getAttribute('data-go');if(g)show(g)})});
document.querySelectorAll('table.t th').forEach(function(th){th.addEventListener('click',function(){var tb=th.closest('table').tBodies[0],i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
 th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');
 var rows=Array.prototype.slice.call(tb.rows).filter(function(r){return !r.classList.contains('empty')});
 rows.sort(function(a,b){var x=a.cells[i],y=b.cells[i];if(!x||!y)return 0;var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var r;
  if(p!==null&&q!==null&&!isNaN(parseFloat(p))&&!isNaN(parseFloat(q))){r=parseFloat(p)-parseFloat(q)}else{r=x.textContent.localeCompare(y.textContent,'zh-Hant',{numeric:true})}return asc?r:-r});
 rows.forEach(function(r){tb.appendChild(r)})})});
document.querySelectorAll('td.cp').forEach(function(td){var t=td.textContent,n=t.split('\n').filter(function(x){return x.trim()}).length;td.textContent='';var d=document.createElement('div');d.className='cpt';var rx=/⚠|（異常）|[：:]\s*red\b|查不到|^\s*\d+\.\s/;t.split('\n').forEach(function(l,i,a){var s=document.createElement('span');s.textContent=l+(i<a.length-1?'\n':'');if(rx.test(l))s.className='al';else if(l.indexOf('△')>=0)s.className='am';d.appendChild(s)});if(n>3){d.classList.add('fold');var b=document.createElement('button');b.type='button';b.className='more';var lb=function(f){b.textContent=f?'共 '+n+' 行，點開看':'收合（共 '+n+' 行）'};lb(true);td.appendChild(b);b.addEventListener('click',function(){lb(d.classList.toggle('fold'))})}td.appendChild(d)});
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t=b.closest('tr').querySelector('td.cp .cpt').textContent;if(t.indexOf('\n')>=0)t='"'+t.split('"').join('""')+'"';
 var done=function(){b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)};
 if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,fb)}else{fb()}
 function fb(){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{if(document.execCommand('copy')){done()}else{b.textContent='複製失敗，請手動選取'}}catch(e){b.textContent='複製失敗，請手動選取'}document.body.removeChild(a)}})});
show('tS');})();</script></body></html>
"@
[IO.File]::WriteAllText((Join-Path $outDir 'report.html'), $html, (New-Object Text.UTF8Encoding($true)))
$manifest = [ordered]@{ tool = $ToolVersion; scriptSha256 = (Get-FileHash -Algorithm SHA256 -Path $MyInvocation.MyCommand.Path).Hash; started = $runStart.ToString('o'); finished = (Get-Date).ToString('o')
  runner = "$env:USERDOMAIN\$env:USERNAME"; server = $srv.Host; overall = $overall; params = @{ CpuPct = $CpuPct; MemPct = $MemPct; SwapPct = $SwapPct; SwapMonitor = $SwapMonitor; WebPort = $WebPort; SwapState = $st.Swap; DiskPct = $DiskPct; DiskWarnPct = $DiskWarnPct; DiskGroup = $DiskGroup; CpuGroup = $CpuGroup; MemGroup = $MemGroup; RootGroup = $RootGroup; Port = $Port } }
[IO.File]::WriteAllText((Join-Path $outDir 'manifest.json'), ($manifest | ConvertTo-Json -Depth 3), (New-Object Text.UTF8Encoding($false)))
Write-Host ''
Write-Host '======== 1-WhatsUp 監控檢查 ========'
foreach ($x in $sheet) { Write-Host ('{0}. {1}：{2}｜{3}' -f $x.項次, $x.項目, $x.判定, $x.檢查表文字) }
Write-Host ("結論：" + $overall)
Write-Host ("報告：" + (Join-Path $outDir 'report.html'))
if (-not $NoOpen) { try { Start-Process (Join-Path $outDir 'report.html') } catch {} }
} finally {
  $token = $null; $hdr = $null
  if ($transcript) { try { Stop-Transcript | Out-Null } catch {} }
}
if ($remember -and -not $authErr) { Ask-Remember $here @($srv.Line) $remember 'WhatsUp' }
$remember = $null
exit $exitCode

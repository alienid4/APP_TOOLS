﻿# ADTime v1.0.0 (2026-11-17)
# 每日檢查「4. 其他：AD net time」：對 設備清單.csv 裡類別 4 的每台 DC，
#   1) 照紙本執行 net time \\IP（留存原文當證據）
#   2) 用 w32tm /stripchart 量本機與 DC 的時間差（精確到毫秒，取 3 次中位數）
# 只讀時間，不改任何設定、不校時。
# 判定：時間差 ≤ WarnSec 秒＝正常；≤ BadSec 秒＝注意；超過＝異常（Kerberos 預設容許 5 分鐘）；查不到＝查不到。
param(
  [ValidateRange(0.1, 300)][double]$WarnSec = 2,
  [ValidateRange(1, 3600)][double]$BadSec = 60,
  [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
$ToolVersion = 'ADTime v1.0.2'
if ($WarnSec -gt $BadSec) { Write-Host '門檻設定錯誤：WarnSec 不可大於 BadSec'; exit 3 }
$here = $PSScriptRoot
. (Join-Path $here 'devlist.ps1')
$dcs = Read-DevList $here '4'
if ($null -eq $dcs) { exit 3 }
if ($dcs.Count -eq 0) { Write-Host '設備清單.csv 裡沒有類別 4（AD net time）的 DC。'; exit 3 }

function Run([string]$exe, [string]$argLine, [int]$timeoutMs) {
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $exe; $psi.Arguments = $argLine; $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
  $psi.StandardOutputEncoding = [Text.Encoding]::GetEncoding([Console]::OutputEncoding.CodePage)
  $pr = [Diagnostics.Process]::Start($psi)
  try {
    $o = $pr.StandardOutput.ReadToEndAsync(); $e = $pr.StandardError.ReadToEndAsync()
    if (-not $pr.WaitForExit($timeoutMs)) { try { $pr.Kill() } catch {}; return @{ Ok = $false; Text = "超過 $([int]($timeoutMs/1000)) 秒沒有回應" } }
    return @{ Ok = ($pr.ExitCode -eq 0); Text = ($o.Result + ' ' + $e.Result).Trim() }
  } finally { $pr.Dispose() }
}
function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }

$runStart = Get-Date
$rows = New-Object System.Collections.Generic.List[object]
$sys32 = Join-Path $env:SystemRoot 'System32'
foreach ($d in $dcs) {
  $label = Label $d ''
  Write-Host ("──── " + $d.No + " / " + $dcs.Count + "：" + $label)
  if ($d.Reject) { $rows.Add([pscustomobject]@{ 項次 = $d.No; 項目 = $label; IP = $d.Host; 時間差秒 = $null; 判定 = '查不到'; netTime原文 = ''; 說明 = $d.Reject }); continue }
  $ntBefore = Get-Date
  # net time 走 445；先花 2 秒試連，不通就不等它 30 秒（例如防火牆只開 UDP 123）
  $p445 = $false; try { $tc = New-Object Net.Sockets.TcpClient; $p445 = $tc.ConnectAsync($d.Host, 445).Wait(2000); $tc.Close() } catch {}
  $nt = if ($p445) { Run (Join-Path $sys32 'net.exe') ("time \\" + $d.Host) 30000 } else { @{ Ok = $false; Text = 'TCP 445 不通，略過 net time' } }
  $ntAt = Get-Date
  $ntLine = (($nt.Text -split "`r?`n") | Where-Object { $_.Trim() } | Select-Object -First 1)
  $wt = Run (Join-Path $sys32 'w32tm.exe') ("/stripchart /computer:" + $d.Host + " /samples:3 /dataonly") 45000
  $offs = @([regex]::Matches($wt.Text, '([+-]\d+\.\d+)s') | ForEach-Object { [double]::Parse($_.Groups[1].Value, [Globalization.CultureInfo]::InvariantCulture) } | Sort-Object)
  if ($offs.Count) {
    $med = -1 * $offs[[int][math]::Floor(($offs.Count - 1) / 2)]   # w32tm 回的是 DC 減本機，統一成本機減 DC
    $abs = [math]::Abs($med)
    $lvl = if ($abs -le $WarnSec) { '正常' } elseif ($abs -le $BadSec) { '注意' } else { '異常' }
    $why = "w32tm 取樣 $($offs.Count) 次，中位數"
    if (-not $nt.Ok) { $why += "；net time 失敗：" + $ntLine }
  } elseif ($nt.Ok -and ($ntLine -match '(\d{4})/(\d{1,2})/(\d{1,2})\s*(上午|下午|AM|PM)?\s*(\d{1,2}):(\d{2}):(\d{2})')) {
    # w32tm 不通時，改用 net time（紙本做法，精度到秒）
    $hh = [int]$Matches[5]; if ($Matches[4] -in '下午', 'PM' -and $hh -lt 12) { $hh += 12 }; if ($Matches[4] -in '上午', 'AM' -and $hh -eq 12) { $hh = 0 }
    $dcT = Get-Date -Year ([int]$Matches[1]) -Month ([int]$Matches[2]) -Day ([int]$Matches[3]) -Hour $hh -Minute ([int]$Matches[6]) -Second ([int]$Matches[7]) -Millisecond 0
    $mid = $ntBefore.AddTicks(($ntAt - $ntBefore).Ticks / 2)
    $err = ($ntAt - $ntBefore).TotalSeconds / 2 + 1          # 指令往返的一半＋net time 只到秒
    $med = ($mid - $dcT).TotalSeconds
    $abs = [math]::Abs($med)
    if ($abs + $err -le $WarnSec) { $lvl = '正常' } elseif ($abs - $err -gt $BadSec) { $lvl = '異常' } elseif ($abs - $err -gt $WarnSec) { $lvl = '注意' } else { $lvl = '查不到' }
    $why = 'w32tm 沒有回應，改用 net time 計算（誤差約 ±' + ('{0:0.0}' -f $err) + ' 秒）' + $(if ($lvl -eq '查不到') { '；誤差範圍跨過門檻，無法確定，請人工確認' } else { '' })
  } else {
    $med = $null; $lvl = '查不到'
    $why = "w32tm 沒有回應（UDP 123）：" + (($wt.Text -replace '\s+', ' ').Trim() -replace '^(.{0,120}).*$', '$1') + $(if ($nt.Ok) { '；net time 有回應（見原文）' } else { '；net time 也失敗' })
  }
  $rows.Add([pscustomobject]@{ 項次 = $d.No; 項目 = $label; IP = $d.Host; 時間差秒 = $(if ($null -ne $med) { [math]::Round($med, 4) } else { $null }); 判定 = $lvl; netTime原文 = $ntLine; 說明 = $why })
  Write-Host ("  時間差 " + $(if ($null -ne $med) { '{0:+0.0000;-0.0000} 秒' -f $med } else { '不知道' }) + "｜" + $lvl)
}

# 結論與檢查表文字
$bad = @($rows | Where-Object { $_.判定 -in '異常', '查不到' })
$warn = @($rows | Where-Object { $_.判定 -eq '注意' })
$ok = @($rows | Where-Object { $_.判定 -eq '正常' })
$maxRow = $rows | Where-Object { $null -ne $_.時間差秒 } | Sort-Object { [math]::Abs($_.時間差秒) } -Descending | Select-Object -First 1
$overall = if (@($rows | Where-Object { $_.判定 -eq '異常' }).Count) { '異常' } elseif (@($rows | Where-Object { $_.判定 -eq '查不到' }).Count) { '須補查' } elseif ($warn.Count) { '注意' } else { '正常' }
$sheet = "AD net time：$($rows.Count) 台 DC，正常 $($ok.Count)" + $(if ($warn.Count) { "、注意 $($warn.Count)" } else { '' }) + $(if ($bad.Count) { "、異常／查不到 $($bad.Count)（" + (($bad | ForEach-Object { $_.IP + ' ' + $_.判定 }) -join '、') + "）" } else { '' }) +
         $(if ($maxRow) { "｜最大時間差 " + ('{0:0.000}' -f [math]::Abs($maxRow.時間差秒)) + " 秒（$($maxRow.IP)）" } else { '' }) + "｜門檻 $WarnSec/$BadSec 秒｜ADTime " + $runStart.ToString('MM-dd HH:mm')
if ($overall -eq '正常') { $sheet = '正常。' + $sheet }

$outDir = Join-Path (Join-Path $here 'ad_out') ($runStart.ToString('yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0, 6))
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$cols = @('項次', '項目', 'IP', '時間差秒', '判定', 'netTime原文', '說明')
$sb = New-Object Text.StringBuilder
[void]$sb.AppendLine((($cols | ForEach-Object { '"' + $_ + '"' }) -join ','))
foreach ($r in $rows) { [void]$sb.AppendLine((($cols | ForEach-Object { $v = [string]$r.$_; if ($v -match '^[=+\-@]' -and $_ -ne '時間差秒') { $v = "'" + $v }; '"' + ($v -replace '"', '""') + '"' }) -join ',')) }
[IO.File]::WriteAllText((Join-Path $outDir 'AD_net_time.csv'), $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
$trs = ($rows | ForEach-Object {
  $cls = switch ($_.判定) { '異常' { 'bad' } '查不到' { 'unk' } '注意' { 'warn' } default { '' } }
  "<tr class='$cls'><td data-v='$($_.項次)'>D$($_.項次)</td><td>" + (Esc $_.項目) + "</td><td>" + (Esc $_.IP) + "</td><td class=n data-v='" + $(if ($null -ne $_.時間差秒) { [math]::Abs($_.時間差秒) } else { 999999 }) + "'>" + $(if ($null -ne $_.時間差秒) { Esc ('{0:+0.0000;-0.0000}' -f $_.時間差秒) } else { '<span class=u>不知道</span>' }) + "</td><td><b>" + (Esc $_.判定) + "</b></td><td>" + (Esc $_.netTime原文) + "</td><td>" + (Esc $_.說明) + "</td></tr>"
}) -join ''
$color = switch ($overall) { '異常' { '#B3261E' } '須補查' { '#6B5E00' } default { '#0C6B37' } }
$html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>AD net time $($runStart.ToString('yyyy-MM-dd HH:mm'))</title>
<style>body{font-family:"Microsoft JhengHei",sans-serif;margin:0;background:#f6f7f9}header{background:$color;color:#fff;padding:12px 16px}h1{margin:0;font-size:20px}.m{font-size:13px}
main{padding:12px 16px}table{border-collapse:collapse;background:#fff;width:100%;font-size:13px}th{background:#eef2ef;cursor:pointer}td,th{border:1px solid #ddd;padding:4px 6px}td.n{text-align:right}
tr.bad td{background:#fde8e8}tr.warn td{background:#fff6dc}tr.unk td{background:#efefef}.u{color:#999}.cp{background:#fff;border:1px solid #ccc;padding:8px;margin:8px 0}</style></head><body>
<header><h1>AD net time　結論：$(Esc $overall)</h1><div class="m">執行 $($runStart.ToString('yyyy-MM-dd HH:mm:ss'))｜執行人 $(Esc "$env:USERDOMAIN\$env:USERNAME")｜$ToolVersion｜門檻：≤$WarnSec 秒正常、≤$BadSec 秒注意、超過異常</div></header>
<main><h3>檢查表文字（按「複製」貼進每日檢查表）</h3><div class="cp" id="cp">$(Esc $sheet)</div><button id="cb">複製</button>
<h3>各 DC</h3><table id="t"><thead><tr><th>項次</th><th>項目</th><th>IP</th><th>時間差（秒，本機減 DC）</th><th>判定</th><th>net time 原文</th><th>說明</th></tr></thead><tbody>$trs</tbody></table></main>
<script>(function(){document.getElementById('cb').addEventListener('click',function(){var t=document.getElementById('cp').textContent,b=this;
var done=function(){b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)};
if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done)}else{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();document.execCommand('copy');document.body.removeChild(a);done()}});
document.querySelectorAll('#t th').forEach(function(th){th.addEventListener('click',function(){var tb=document.querySelector('#t tbody'),i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');var rows=Array.prototype.slice.call(tb.rows);
rows.sort(function(a,b){var p=a.cells[i].getAttribute('data-v'),q=b.cells[i].getAttribute('data-v');var r=(p!==null&&q!==null)?parseFloat(p)-parseFloat(q):a.cells[i].textContent.localeCompare(b.cells[i].textContent,'zh-Hant',{numeric:true});return asc?r:-r});
rows.forEach(function(r){tb.appendChild(r)})})})})();</script></body></html>
"@
[IO.File]::WriteAllText((Join-Path $outDir 'report.html'), $html, (New-Object Text.UTF8Encoding($true)))
Write-Host ''
Write-Host ("結論：" + $overall)
Write-Host ("檢查表文字：" + $sheet)
Write-Host ("報告：" + (Join-Path $outDir 'report.html'))
if (-not $NoOpen) { try { Start-Process (Join-Path $outDir 'report.html') } catch {} }
exit $(switch ($overall) { '正常' { 0 } '注意' { 1 } '異常' { 2 } default { 3 } })

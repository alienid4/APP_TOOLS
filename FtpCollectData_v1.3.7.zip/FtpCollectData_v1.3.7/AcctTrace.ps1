﻿#requires -Version 5.1
<#
  AcctTrace v1.2.0 (2026-11-13) -- 帳號追蹤（唯讀）
  在 FTP 主機上雙擊「帳號追蹤.bat」：輸入帳號、日期 → 讀那天的 FileZilla log，產出這個帳號的行為報告：
  每小時／尖峰每分鐘上傳下載、來源 IP（各自上傳下載幾次）、下載了哪些檔與次數（完整 CSV）、失敗與續傳、原始樣本（含來源行號）。
  只讀 log、不改任何東西；結果寫在本工具旁邊（不能寫就改到暫存資料夾）。
  v1.1.0（AI30：Claude 30＋GPT 30 題）：串流讀檔（記憶體固定）、UTF-8、讀不懂的行要列出來（不能默默當成沒紀錄）、
  只讀 log 檔（排除本工具產物與壓縮檔）、完整檔案／IP 清單另存 CSV、尖峰每分鐘、失敗／續傳、今天標「非完整日」、報告寫入版本與參數。
#>
param([string]$Account = '', [string]$Dates = '', [string]$LogDir = '')
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$VERSION = '1.2.0 (2026-11-13)'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Write-Host "帳號追蹤 AcctTrace $VERSION（只讀 log，不改任何東西）" -ForegroundColor Green
Write-Host ''

if (-not $LogDir) {
    foreach ($c in @("${env:ProgramFiles(x86)}\FileZilla Server\Logs", "$env:ProgramFiles\FileZilla Server\Logs", "$env:ProgramData\filezilla-server\logs")) {
        if ($c -and (Test-Path -LiteralPath $c -PathType Container)) { $LogDir = $c; break }
    }
    $ans = Read-Host "log 資料夾（直接按 Enter＝$(if ($LogDir) { $LogDir } else { '找不到，請輸入' })）"
    if ($ans.Trim()) { $LogDir = $ans.Trim().Trim('"') }
}
if (-not $LogDir -or -not (Test-Path -LiteralPath $LogDir -PathType Container)) { Write-Host "找不到 log 資料夾（或不是資料夾）：$LogDir" -ForegroundColor Yellow; exit 3 }
if (-not $Account) { $Account = (Read-Host '要追蹤的帳號（例如 ftp11-1）').Trim() }
if (-not $Account) { Write-Host '沒有輸入帳號，結束。' -ForegroundColor Yellow; exit 3 }
$now = Get-Date
if (-not $Dates) {
    $d1 = $now.AddDays(-1).ToString('yyyy-MM-dd'); $d0 = $now.ToString('yyyy-MM-dd')
    $Dates = (Read-Host "日期（可多個，用逗號分開；直接按 Enter＝昨天 $d1 和今天 $d0）").Trim()
    if (-not $Dates) { $Dates = "$d1,$d0" }
}
try { $dayList = @($Dates -split '[,，\s]+' | Where-Object { $_ } | ForEach-Object { ([datetime]::Parse($_)).ToString('yyyy-MM-dd') } | Select-Object -Unique) }
catch { Write-Host "看不懂的日期：$Dates（請用 2026-11-12 這種寫法）" -ForegroundColor Yellow; exit 3 }

# 0.9：(000123)2026/11/13 下午 13:16:05 - user01 (192.0.2.31)> STOR x
# 1.x：2026-11-13T13:16:05.123Z == [FTP Session 1234 192.0.2.3 user01] Command: STOR x（1.x 的時間是 UTC）
$rx09 = New-Object regex('^\((\d+)\)\s*(\d{4}/\d{1,2}/\d{1,2})\s+(?:(上午|下午|AM|PM)\s+)?(\d{1,2}):(\d{2}):(\d{2})\s*(?:(上午|下午|AM|PM)\s*)?-\s*(.*?)\s*\(([0-9A-Fa-f:.]+)\)>\s?(.*)$', 'Compiled')
$rx1 = New-Object regex('^(\d{4}-\d{2}-\d{2})[T ](\d{2}):(\d{2}):(\d{2})\S*\s+\S+\s+\[[^\]]*?Session\s+(\d+)\s+([0-9A-Fa-f:.]+)\s+([^\]]*)\]\s*(?:Command:\s*|Response:\s*)?(.*)$', 'Compiled')
$rxLog = New-Object regex('\.(log|txt)(\.(part|split)\d+)?$', 'IgnoreCase')   # 只讀 log 檔（不讀 .zip／.gz、不讀本工具產物）
$acctL = $Account.ToLowerInvariant()
# v1.2.0：「整個檔逐行找含帳號的行」改用記憶體編譯的 C#（PowerShell 逐行約每秒 1 MB，一天 800 MB 要 15 分鐘）；
# PowerShell 只處理挑出來的行。主機不允許編譯時自動用原本的寫法（結果相同、只是慢）。
$script:ATFast = $false
try {
    if (-not ('AcctTraceFast' -as [type])) {
        Add-Type -ErrorAction Stop -TypeDefinition @'
public static class AcctTraceFast {
    // 讀到下一個含帳號名稱的行就回傳；c[0]=讀了幾行 c[1]=目前行號；每 50 萬行沒找到就回 "" 並設 c[2]=1（讓外面印進度）；檔尾回 null
    public static string Next(System.IO.StreamReader sr, string acct, long[] c) {
        int k = 0; string line;
        while ((line = sr.ReadLine()) != null) {
            c[0]++; c[1]++;
            if (line.IndexOf(acct, System.StringComparison.OrdinalIgnoreCase) >= 0) return line;
            if (++k >= 500000) { c[2] = 1; return ""; }
        }
        return null;
    }
}
'@
    }
    $script:ATFast = $true
} catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$tag = '{0}_{1}_{2}' -f ($Account -replace '[\\/:*?"<>|]', '_'), $now.ToString('yyyyMMdd_HHmmss'), ([guid]::NewGuid().ToString('N').Substring(0, 4))
$sb = New-Object Text.StringBuilder
function Out([string]$s) { [void]$sb.AppendLine($s); Write-Host $s }
function Inc($h, $k) { if ($h.ContainsKey($k)) { $h[$k]++ } else { $h[$k] = 1 } }
$csvRows = New-Object System.Collections.Generic.List[string]   # 下載檔案完整清單
$ipRows = New-Object System.Collections.Generic.List[string]
function Q([string]$s) { '"' + ($s -replace '"', '""') + '"' }

Out "帳號追蹤報告　帳號：$Account　主機：$env:COMPUTERNAME　產生：$($now.ToString('yyyy/MM/dd HH:mm:ss'))"
Out "工具：AcctTrace $VERSION（$(if ($script:ATFast) { '快速模式' } else { '一般模式' })）　PowerShell $($PSVersionTable.PSVersion)　log 資料夾：$LogDir　日期：$($dayList -join '、')"
Out '說明：只讀 log。上傳＝STOR／APPE，下載＝RETR（另列失敗與續傳）。同一個檔被下載很多次，代表觀察到重複下載；'
Out '　　　是不是整個目錄定時重抓，要對照「每個檔第一次／最後一次被抓的時間」與目錄內容判斷，本報告不代下結論。'
Out ''

foreach ($day in $dayList) {
    $dt = [datetime]::ParseExact($day, 'yyyy-MM-dd', $null)
    $files = @(Get-ChildItem -LiteralPath $LogDir -File | Where-Object {
            ($_.Name -like ("*{0}*" -f $day) -or $_.Name -like ("*{0}*" -f $dt.ToString('yyyyMMdd'))) -and $rxLog.IsMatch($_.Name) -and $_.Name -notlike '帳號追蹤_*' } | Sort-Object Name)
    $partial = ($dt.Date -eq $now.Date)
    Out ("========== {0}{1} ==========" -f $day, $(if ($partial) { '（今天：只到 ' + $now.ToString('HH:mm') + '，非完整日）' } else { '' }))
    foreach ($f in $files) { Out ("　log 檔：{0}　{1:N0} 位元組　修改 {2}" -f $f.FullName, $f.Length, $f.LastWriteTime.ToString('yyyy/MM/dd HH:mm:ss')) }
    if (-not $files.Count) { Out '　這天沒有 log 檔（檔名要含日期、副檔名 .log／.txt）。'; Out ''; continue }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $hourUp = @{}; $hourDown = @{}; $minDown = @{}; $ipLines = @{}; $ipUp = @{}; $ipDown = @{}; $retr = @{}; $rFirst = @{}; $rLast = @{}; $sess = @{}
    $nRead = [long]0; $nCand = 0; $nBad = 0; $nLine = 0; $nUp = 0; $nDown = 0; $nOk226 = 0; $nLogin = 0; $nRest = 0; $nFail = 0
    $first = ''; $last = ''; $badEx = New-Object System.Collections.Generic.List[string]
    $sample = New-Object System.Collections.Generic.List[string]; $pendRetr = @{}
    foreach ($f in $files) {
        Write-Host ("　讀取 {0} …" -f $f.Name)
        $fs = $null; $sr = $null
        try {
            $fs = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
            $sr = New-Object IO.StreamReader($fs, (New-Object Text.UTF8Encoding($false)), $true, 1048576)
        } catch {
            if ($fs) { $fs.Close() }
            Out ("　【讀不到】{0}：{1}（請在 bat 上按右鍵「以系統管理員身分執行」）" -f $f.Name, $_.Exception.Message); continue
        }
        $flen = [Math]::Max(1, $fs.Length); $pw = [Diagnostics.Stopwatch]::StartNew(); $plast = 0; $ln = 0; $cnt = New-Object long[] 3
        try {
            while ($true) {
                if ($script:ATFast) {
                    $line = [AcctTraceFast]::Next($sr, $Account, $cnt)
                    if ($null -eq $line) { break }
                    $ln = $cnt[1]
                    $tick = ($cnt[2] -eq 1); $cnt[2] = 0
                } else {
                    $line = $sr.ReadLine(); if ($null -eq $line) { break }
                    $ln++; $cnt[0]++; $tick = (($ln % 200000) -eq 0)
                }
                if ($tick -and ($pw.ElapsedMilliseconds - $plast) -ge 5000) {
                    $plast = $pw.ElapsedMilliseconds
                    Write-Host ("`r　　{0}%（{1:N0} / {2:N0} MB）" -f [int](100 * $fs.Position / $flen), ($fs.Position / 1MB), ($flen / 1MB)) -NoNewline
                }
                if ($line.Length -eq 0 -or $line.IndexOf($Account, [StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
                $nCand++
                $user = ''; $ip = ''; $sid = ''; $msg = ''; $hh = -1; $mm = ''; $ts = ''
                $g = $rx09.Match($line)
                if ($g.Success) {
                    $sid = $g.Groups[1].Value; $hh = [int]$g.Groups[4].Value
                    $ap = $(if ($g.Groups[3].Success) { $g.Groups[3].Value } elseif ($g.Groups[7].Success) { $g.Groups[7].Value } else { '' })
                    if (($ap -eq '下午' -or $ap -eq 'PM') -and $hh -lt 12) { $hh += 12 } elseif (($ap -eq '上午' -or $ap -eq 'AM') -and $hh -eq 12) { $hh = 0 }
                    $mm = $g.Groups[5].Value; $ts = '{0:00}:{1}:{2}' -f $hh, $mm, $g.Groups[6].Value
                    $user = $g.Groups[8].Value.Trim(); $ip = $g.Groups[9].Value; $msg = $g.Groups[10].Value
                } else {
                    $g = $rx1.Match($line)
                    if (-not $g.Success) { $nBad++; if ($badEx.Count -lt 3) { $badEx.Add(('{0}:{1}  {2}' -f $f.Name, $ln, $line.Substring(0, [Math]::Min(160, $line.Length)))) }; continue }
                    $hh = [int]$g.Groups[2].Value; $mm = $g.Groups[3].Value; $ts = '{0}:{1}:{2}' -f $g.Groups[2].Value, $mm, $g.Groups[4].Value
                    $sid = $g.Groups[5].Value; $ip = $g.Groups[6].Value; $user = $g.Groups[7].Value.Trim(); $msg = $g.Groups[8].Value
                }
                if ($user.ToLowerInvariant() -ne $acctL) { continue }   # 只算這個帳號（名字只是「含有」不算）
                $nLine++
                if (-not $first -or [string]::CompareOrdinal($ts, $first) -lt 0) { $first = $ts }
                if (-not $last -or [string]::CompareOrdinal($ts, $last) -gt 0) { $last = $ts }
                $sess[$sid] = 1
                if ($ip) { Inc $ipLines $ip }
                $t = $msg.Trim(); $verb = ($t -split '\s+', 2)[0].ToUpperInvariant(); $arg = $(if ($t.IndexOf(' ') -gt 0) { $t.Substring($t.IndexOf(' ') + 1).Trim() } else { '' })
                if ($verb -eq 'RETR') {
                    $nDown++; Inc $hourDown $hh; Inc $minDown ('{0:00}:{1}' -f $hh, $mm); Inc $retr $arg; if ($ip) { Inc $ipDown $ip }
                    if (-not $rFirst.ContainsKey($arg)) { $rFirst[$arg] = $ts }; $rLast[$arg] = $ts
                    $pendRetr[$sid] = 1
                } elseif ($verb -eq 'STOR' -or $verb -eq 'APPE') {
                    $nUp++; Inc $hourUp $hh; if ($ip) { Inc $ipUp $ip }
                } elseif ($verb -eq 'REST') { $nRest++ }
                elseif ($t -match '^230') { $nLogin++ }
                elseif ($t -match '^226') { $nOk226++; $pendRetr.Remove($sid) }
                elseif ($t -match '^(4\d\d|5\d\d)') { if ($pendRetr.ContainsKey($sid)) { $nFail++; $pendRetr.Remove($sid) } }
                if ($sample.Count -lt 30) { $sample.Add(('{0}:{1}  {2}' -f $f.Name, $ln, ($line -replace '(?i)(PASS\s+)\S.*$', '$1***'))) }
            }
        } finally { $sr.Close(); $fs.Close(); $nRead += $cnt[0] }
        if ($plast) { Write-Host '' }
    }
    Out ("　讀了 {0:N0} 行，含帳號名稱的 {1:N0} 行，其中屬於這個帳號的 {2:N0} 行；讀檔花 {3:N0} 秒" -f $nRead, $nCand, $nLine, $sw.Elapsed.TotalSeconds)
    if ($nBad) {
        Out ("　【注意】有 {0:N0} 行含帳號名稱但格式看不懂，沒有算進來；數字可能偏少，請把下面例子給維護的人：" -f $nBad)
        foreach ($x in $badEx) { Out ('　　' + $x) }
    }
    if (-not $nLine) { Out $(if ($nBad) { '　這天沒有看懂的紀錄（見上面注意），不能確定這個帳號沒有活動。' } else { '　這天沒有這個帳號的紀錄。' }); Out ''; continue }
    Out ("　連線（session）{0:N0} 個；登入成功 {1:N0} 次；第一筆 {2}，最後一筆 {3}" -f $sess.Count, $nLogin, $first, $last)
    Out ("　上傳 {0:N0} 次；下載 {1:N0} 次（其中失敗 {2:N0} 次）；傳輸成功回應（226）{3:N0} 次；續傳指令（REST）{4:N0} 次" -f $nUp, $nDown, $nFail, $nOk226, $nRest)
    Out '　【每小時】時：上傳／下載'
    for ($h = 0; $h -lt 24; $h++) { $u = $(if ($hourUp.ContainsKey($h)) { $hourUp[$h] } else { 0 }); $d = $(if ($hourDown.ContainsKey($h)) { $hourDown[$h] } else { 0 }); if ($u -or $d) { Out ('　　{0:00} 點：{1:N0}／{2:N0}' -f $h, $u, $d) } }
    if ($minDown.Count) {
        $pk = $minDown.GetEnumerator() | Sort-Object @{e = { $_.Value }; Descending = $true }, @{e = { $_.Key } } | Select-Object -First 1
        Out ("　【尖峰】下載最多的一分鐘：{0}，{1:N0} 次" -f $pk.Key, $pk.Value)
    }
    Out ("　【來源 IP】共 {0} 個（列出前 50 個；完整清單在 CSV）" -f $ipLines.Count)
    foreach ($kv in ($ipLines.GetEnumerator() | Sort-Object @{e = { $_.Value }; Descending = $true }, @{e = { $_.Key } } | Select-Object -First 50)) {
        $iu = $(if ($ipUp.ContainsKey($kv.Key)) { $ipUp[$kv.Key] } else { 0 }); $id = $(if ($ipDown.ContainsKey($kv.Key)) { $ipDown[$kv.Key] } else { 0 })
        Out ('　　{0}　上傳 {1:N0}　下載 {2:N0}　（{3:N0} 行）' -f $kv.Key, $iu, $id, $kv.Value)
    }
    foreach ($kv in $ipLines.GetEnumerator()) { $ipRows.Add(('{0},{1},{2},{3},{4}' -f $day, (Q $kv.Key), $(if ($ipUp.ContainsKey($kv.Key)) { $ipUp[$kv.Key] } else { 0 }), $(if ($ipDown.ContainsKey($kv.Key)) { $ipDown[$kv.Key] } else { 0 }), $kv.Value)) }
    $rep = @($retr.Values | Where-Object { $_ -gt 1 }).Count
    $maxr = $(if ($retr.Count) { ($retr.Values | Measure-Object -Maximum).Maximum } else { 0 })
    Out ("　【下載的檔】不同檔名 {0:N0} 個；被下載超過 1 次的 {1:N0} 個；同一個檔最多被下載 {2:N0} 次；平均每檔 {3:N1} 次（完整清單在 CSV）" -f $retr.Count, $rep, $maxr, ($nDown / [Math]::Max(1, $retr.Count)))
    if ($retr.Count) {
        Out '　　下載次數最多的 20 個檔（次數　第一次～最後一次　檔名）：'
        foreach ($kv in ($retr.GetEnumerator() | Sort-Object @{e = { $_.Value }; Descending = $true }, @{e = { $_.Key } } | Select-Object -First 20)) { Out ('　　{0:N0} 次　{1}～{2}　{3}' -f $kv.Value, $rFirst[$kv.Key], $rLast[$kv.Key], $kv.Key) }
        foreach ($kv in $retr.GetEnumerator()) { $csvRows.Add(('{0},{1},{2},{3},{4}' -f $day, (Q $kv.Key), $kv.Value, $rFirst[$kv.Key], $rLast[$kv.Key])) }
    }
    Out '　【原始紀錄樣本】前 30 行（log 檔:行號；密碼已遮）'
    foreach ($s in $sample) { Out ('　　' + $s) }
    Out ''
}

$enc = New-Object Text.UTF8Encoding($true)
function Save([string]$name, [string]$text) {
    $p = Join-Path $here $name
    try { [IO.File]::WriteAllText($p, $text, $enc) } catch { $p = Join-Path $env:TEMP $name; [IO.File]::WriteAllText($p, $text, $enc) }
    return $p
}
$p1 = Save ("帳號追蹤_{0}.txt" -f $tag) $sb.ToString()
$p2 = Save ("帳號追蹤_{0}_下載檔案.csv" -f $tag) ("日期,檔名,下載次數,第一次,最後一次`r`n" + ($csvRows -join "`r`n"))
$p3 = Save ("帳號追蹤_{0}_來源IP.csv" -f $tag) ("日期,來源IP,上傳,下載,行數`r`n" + ($ipRows -join "`r`n"))
Write-Host ''
Write-Host "報告：$p1" -ForegroundColor Green
Write-Host "下載檔案清單：$p2" -ForegroundColor Green
Write-Host "來源 IP 清單：$p3" -ForegroundColor Green
exit 0

@echo off
rem ============================================================
rem  vCOps 手動收集選單（放在 vCOps 跳板機、跟 aria_*.ps1 同一個資料夾，雙擊執行）
rem  只讀 vCOps，不改任何東西；收完的批次在 aria_relay，要複製到中繼 PC 的 aria_out 再按 run2_926.bat 送 WEBIT
rem  VcopsMenu v1.0.0（2026-11-16）
rem ============================================================
chcp 65001 >nul
setlocal
cd /d "%~dp0"
rem vCOps 位址不寫在檔案裡：第一次執行時輸入，存在同資料夾 aria_host.txt
set "ARIA="
if exist aria_host.txt set /p ARIA=<aria_host.txt
if not defined ARIA set /p ARIA=第一次使用：請輸入 vCOps 的位址（IP 或主機名）：
if not defined ARIA (echo 沒有輸入位址，結束。& pause & goto end)
if not exist aria_host.txt (>aria_host.txt echo %ARIA%)

:menu
cls
echo ============================================================
echo   vCOps 手動收集選單 v1.0.0      目前資料夾：%CD%
echo ============================================================
echo   01  開盤尖峰（今天 09:00-09:30 的 ESXi CPU，09:30 之後再跑）
echo   02  VMware 每日檢查（ESXi 台數、LUN、警示）＝立刻補跑 06:00 排程
echo   03  VM 清單（取代 RVTools，約 5-10 分鐘）
echo   04  開啟輸出資料夾 aria_relay
echo   05  看最近收到的批次（每種最新 3 批）
echo   06  看排程狀態（上次跑、結果、下次跑）
echo   07  怎麼送到 WEBIT（說明）
echo   00  離開
echo ============================================================
set "c="
set /p c=請輸入編號後按 Enter：
if "%c%"=="01" goto probe
if "%c%"=="1"  goto probe
if "%c%"=="02" goto daily
if "%c%"=="2"  goto daily
if "%c%"=="03" goto inv
if "%c%"=="3"  goto inv
if "%c%"=="04" goto open
if "%c%"=="4"  goto open
if "%c%"=="05" goto recent
if "%c%"=="5"  goto recent
if "%c%"=="06" goto tasks
if "%c%"=="6"  goto tasks
if "%c%"=="07" goto howto
if "%c%"=="7"  goto howto
if "%c%"=="00" goto end
if "%c%"=="0"  goto end
echo 沒有這個編號。& pause & goto menu

:probe
rem 優先用 aria_probe.ps1（PC 11-15 更新的版本），沒有才用 v11／v7
set "P="
for %%f in (aria_probe.ps1 aria_probe_v11.ps1 aria_probe_v7.ps1) do if not defined P if exist "%%f" set "P=%%f"
if not defined P (echo 找不到 aria_probe 腳本，請確認放在這個資料夾。& pause & goto menu)
echo 執行 %P% ……（約 1-3 分鐘）
powershell -NoProfile -File "%P%" -AriaHost %ARIA%
echo.
echo 完成。最新批次在 aria_relay 裡最新的 ariahost_ 資料夾（選 07 看怎麼送 WEBIT）。
pause & goto menu

:daily
echo 找 VMware 每日檢查的排程並立刻執行……
powershell -NoProfile -Command "$t=Get-ScheduledTask | Where-Object { ($_.Actions | ForEach-Object { $_.Arguments + ' ' + $_.Execute }) -match 'aria_daily_snap' }; if(-not $t){'找不到 aria_daily_snap 的排程，請改用手動：看說明 07'; exit 1}; foreach($x in $t){ Start-ScheduledTask -InputObject $x; '已啟動排程：' + $x.TaskName }"
echo 排程在背景跑（最多約 45 分鐘），跑完選 05 看有沒有新的 ariadc_ 批次。
pause & goto menu

:inv
if not exist aria_inventory.ps1 (echo 找不到 aria_inventory.ps1。& pause & goto menu)
echo 執行 aria_inventory.ps1 ……（約 5-10 分鐘）
powershell -NoProfile -File aria_inventory.ps1 -AriaHost %ARIA%
echo.
echo 完成。最新批次在 aria_relay 裡最新的 ariainv_ 資料夾。
pause & goto menu

:open
if not exist aria_relay mkdir aria_relay
start "" explorer "%CD%\aria_relay"
goto menu

:recent
powershell -NoProfile -Command "foreach($k in 'ariahost_','ariadc_','ariainv_'){ ''; '== ' + $k; Get-ChildItem -Directory -Path aria_relay -Filter ($k+'*') -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 3 | ForEach-Object { '  ' + $_.LastWriteTime.ToString('MM-dd HH:mm') + '  ' + $_.Name } }"
echo.
pause & goto menu

:tasks
powershell -NoProfile -Command "Get-ScheduledTask | Where-Object { ($_.Actions | ForEach-Object { $_.Arguments + ' ' + $_.Execute }) -match 'aria' } | ForEach-Object { $i = $_ | Get-ScheduledTaskInfo; '{0,-30} 上次 {1:MM-dd HH:mm}  結果 {2}  下次 {3:MM-dd HH:mm}' -f $_.TaskName,$i.LastRunTime,$i.LastTaskResult,$i.NextRunTime }"
echo （結果 0＝成功；沒有列出任何排程＝這台沒有排 vCOps 收集）
pause & goto menu

:howto
echo.
echo  送到 WEBIT 的步驟：
echo   1. 選 04 開 aria_relay，把剛產生的最新資料夾（ariahost_／ariadc_／ariainv_ 開頭）複製。
echo   2. 到中繼 PC 的 WEBIT3\aria_out 資料夾貼上。
echo   3. 在中繼 PC 同一層資料夾雙擊 run2_926.bat，看到「…OK」就是送到了。
echo   4. WEBIT 約 1-2 分鐘內匯入（盤中時段會等收盤後才匯入）。
echo.
pause & goto menu

:end
endlocal

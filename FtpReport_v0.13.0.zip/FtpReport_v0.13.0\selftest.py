# -*- coding: utf-8 -*-
"""FtpReport 自我測試：產生假資料 → 跑報表兩次 → 檢查數字、AP 版遮蔽、xlsx 結構、HTML 不連外、輸入沒被改。
用法：python selftest.py [暫存資料夾]（預設在系統 TEMP 底下新建）"""
import hashlib
import inspect
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_fixture  # noqa: E402
import ftp_report  # noqa: E402

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
FAILS = []


def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond:
        FAILS.append(msg)


def tree_hash(root):
    h = hashlib.sha256()
    for dp, dn, fn in sorted(os.walk(root)):
        dn.sort()
        if os.path.basename(dp).startswith('盤點報表_'):
            continue
        for f in sorted(fn):
            p = os.path.join(dp, f)
            if '盤點報表_' in p:
                continue
            st = os.stat(p)
            h.update(p.encode('utf-8'))
            h.update(str(st.st_mtime_ns).encode())
            with open(p, 'rb') as fh:
                h.update(fh.read())
    return h.hexdigest()


def read_sheets(path):
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in ('[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml'):
            ET.fromstring(z.read(n))   # 都要是合法 XML
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        names = [s.get('name') for s in wb.iter(NS + 'sheet')]
        for i, name in enumerate(names):
            root = ET.fromstring(z.read('xl/worksheets/sheet%d.xml' % (i + 1)))
            rows = []
            for r in root.iter(NS + 'row'):
                cells = {}
                for c in r.iter(NS + 'c'):
                    col = re.match(r'[A-Z]+', c.get('r')).group()
                    idx = 0
                    for ch in col:
                        idx = idx * 26 + (ord(ch) - 64)
                    t = c.find(NS + 'is')
                    v = ''.join(x.text or '' for x in t.iter(NS + 't')) if t is not None else (c.findtext(NS + 'v') or '')
                    cells[idx - 1] = v
                width = max(cells) + 1 if cells else 0
                rows.append([cells.get(k, '') for k in range(width)])
            hdr = rows[0] if rows else []
            out[name] = [dict(zip(hdr, r + [''] * (len(hdr) - len(r)))) for r in rows[1:]], hdr
    return out


def run_report(fx):
    rc = ftp_report.main([fx])
    outs = sorted(d for d in os.listdir(fx) if d.startswith('盤點報表_'))
    return rc, os.path.join(fx, outs[-1])


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix='ftpreport_selftest_')
    fx = os.path.join(base, 'fixture')
    make_fixture.make(fx)
    make_fixture.make_acct_lookup(fx)
    make_fixture.make_host_sys(fx)
    before = tree_hash(fx)
    print('== 第 1 次')
    rc, out1 = run_report(fx)
    check(rc == 0, '回傳 0')
    files = sorted(os.listdir(out1))
    check(len(files) == 4 and any(f.startswith('盤點清單_SP_') for f in files) and any(f.startswith('盤點清單_AP_') for f in files) and any(f.startswith('總覽_') for f in files) and any(f.startswith('AP簡易盤點表_') for f in files), '產出 4 個檔：%s' % files)
    sp = read_sheets(os.path.join(out1, [f for f in files if f.startswith('盤點清單_SP_')][0]))
    ap = read_sheets(os.path.join(out1, [f for f in files if f.startswith('盤點清單_AP_')][0]))
    check(list(sp.keys()) == ['主表', '使用明細', '移轉對照表', '部門統計', '共用／同名', '主機', '傳輸量', '協定', 'AD 帳號提醒（不轉置）', '說明'], 'SP 工作表：%s' % list(sp.keys()))
    rows, hdr = sp['主表']
    check(all(c in hdr for c in ('A1 列ID', 'B10 證據品質', 'C1 觀察結果', 'D1 續用／停用／待確認', 'E1 AP主管簽認')), '主表欄位含 A1/B10/C1/D1/E1')
    dept_rows, _ = sp['部門統計']
    main_rows, _ = sp['主表']
    n_acct = len(set((x['A2 主機IP'], x['A4 舊帳號']) for x in main_rows))
    check(sum(int(x['帳號數']) for x in dept_rows) == n_acct and all(x['項次'].startswith('P') for x in dept_rows) and any(x['部門'] == ftp_report.NO_DEPT for x in dept_rows), '部門統計：各部門帳號數加總＝主表帳號數 %d，未記載部門另列' % n_acct)
    check(ftp_report.dept_summary([{'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP01', 'A4 部門': 'A部'}, {'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP01', 'A4 部門': 'A部'}, {'A2 主機IP': '192.0.2.2', 'A4 舊帳號': 'FTP15', 'A4 部門': 'A部'}])[0]['帳號數'] == 2, '同帳號多個目錄只算一次')
    dd = ftp_report.dept_summary([{'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP01', 'A4 部門': 'A部', 'A4 姓名': '李大', 'C1 觀察結果': '有傳輸'},
                                  {'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'FTP15', 'A4 部門': 'A部', 'A4 姓名': '王二', 'C1 觀察結果': '僅登入'},
                                  {'A2 主機IP': '192.0.2.2', 'A4 舊帳號': 'FTP22', 'A4 部門': 'A部', 'A4 姓名': ''}])[0]
    check(dd['部門'] == 'A部' and dd['帳號數'] == 3 and dd['有在用'] == 1 and dd['期間內沒用'] == 2 and dd['沒有姓名(NA)'] == 1 and dd['有在用帳號'] == '李大FTP01@192.0.2.1' and dd['沒在用帳號'] == '王二FTP15@192.0.2.1(僅登入)\nFTP22@192.0.2.2(NA)', '部門統計：3 個帳號；在用 %s；沒用 %s' % (dd['有在用帳號'], dd['沒在用帳號']))

    def row(ip, acct, vpath):
        m = [r for r in rows if r['A2 主機IP'] == ip and r['A4 舊帳號'] == acct and r['A5 虛擬路徑'] == vpath]
        return m[0] if len(m) == 1 else None

    A = '192.0.2.10'
    accts = sorted(set(r['A4 舊帳號'] for r in rows if r['A2 主機IP'] == A))
    check('<system user>' not in accts and 'anonymous' not in accts, '內建 <system user> 與 anonymous 不列帳號：%s' % accts)
    r = row(A, 'ap_user1', '/in')
    check(r is not None and r['A4 部門'] == 'B部' and r['A4 姓名'] == '測試丙' and r['A4 部門來源'] == '帳號主檔（待 AP 確認）', '帳號對照補部門（IP 補 0、帳號大小寫也對得上）：%s/%s/%s' % (r.get('A4 部門'), r.get('A4 姓名'), r.get('A4 部門來源')))
    check(r is not None and r['B7 上傳'] == '2' and r['B7 其他操作'] == '2' and r['A5 目錄層級'] == '第一層子目錄', 'ap_user1 /in：上傳 2（含輪替檔接續 CWD）、其他 2（LIST＋DELE），失敗的 STOR 不算')
    r = row(A, 'ap_user1', '/')
    check(r is not None and r['B7 上傳'] == '1' and r['B7 其他操作'] == '1' and r['B9 期間內檔數'] == '120', 'ap_user1 根目錄：上傳 1、建目錄 1、目錄摘要 120 檔')
    r = row(A, 'ap_user1', '/out')
    check(r is not None and r['B7 下載'] == '1', 'ap_user1 /out：下載 1')
    r = row(A, 'ap_user1', '/share')
    check(r is not None and 'group:grp1' in r['B2 權限來源'] and r['B7 上傳'] == '0', 'ap_user1 /share：群組來的掛載點，權限來源 group:grp1')
    r = row(A, 'ap_user1', '/in')
    check(r['B5 登入成功'] == '1' and r['B5 登入失敗'] == '1' and '198.51.100.5' in r['B6 成功來源IP'] and '203.0.113.9' in r['B6 失敗來源IP'], 'ap_user1 登入成功 1／失敗 1，來源 IP 分列')
    check(r['B4 最後成功登入'] == '2026-11-10 02:30' and '02時' in r['B8 傳輸時段'] and '06時' in r['B8 傳輸時段'], 'UTC→當地時間（+8）：最後登入 %s、時段 %s' % (r['B4 最後成功登入'], r['B8 傳輸時段']))
    check(r['C1 觀察結果'] == '有傳輸', 'ap_user1 /in C1＝有傳輸')
    r = row(A, 'ap_user2', '/')
    check(r is not None and r['B7 下載'] == '1' and '停用' in r['B1 設定狀態'] and '唯讀' in r['B2 權限（解讀）'], 'ap_user2：根目錄下載 1、設定停用、唯讀')
    r = row(A, 'idle_user', '/')
    check(r is not None and r['C1 觀察結果'] == '僅登入', 'idle_user C1＝僅登入')
    r = row(A, 'never_user', '/')
    check(r is not None and r['C1 觀察結果'] == '期間內未觀察到活動' and r['B9 期間外舊檔數'] == '40', 'never_user C1＝期間內未觀察到活動，期間外舊檔 40')
    r = row(A, 'grp_only', '/share')
    check(r is not None and r['B7 下載'] == '1', 'grp_only /share 下載 1')
    r = [x for x in rows if x['A2 主機IP'] == A and x['A4 舊帳號'] == 'grp_only' and x['A5 目錄層級'] == '帳號級']
    check(len(r) == 1 and r[0]['B7 下載'] == '1' and r[0]['B7 統計層級'] == '帳號級', 'grp_only 歸不到掛載點的下載 → 帳號級列')
    B = [x for x in rows if x['A2 主機IP'] == '192.0.2.11']
    check(len(B) == 1 and B[0]['A5 虛擬路徑'] == '/in' and B[0]['C1 觀察結果'] == '有傳輸' and '31 天' in B[0]['C2 依據'] and '上傳 1 次' in B[0]['C2 依據'],
          '31 天主機：有上傳仍判有傳輸，依據註記天數不足')
    C = [x for x in rows if x['A2 主機IP'] == '192.0.2.12']
    check(len(C) == 1 and C[0]['C1 觀察結果'] == '證據不足', 'Serv-U（舊 ini、沒有 log）：設定裡的帳號列出（HomeDir＋Access 同目錄合併成 1 列），C1 證據不足')
    # Serv-U 15：.Archive 帳號＋zh-TW log
    E = '192.0.2.14'
    Erows = [x for x in rows if x['A2 主機IP'] == E]
    check(sorted(set(x['A4 舊帳號'] for x in Erows)) == ['dup', 'su_a', 'su_b'], 'Serv-U 主表只有本機帳號（AD 帳號不列）：%s' % sorted(set(x['A4 舊帳號'] for x in Erows)))
    r = row(E, 'su_a', '/in')
    check(r is not None and r['B7 上傳'] == '3' and r['C1 觀察結果'] == '有傳輸' and r['B8 傳輸天數'] == '3',
          'su_a /in：上傳 3（含連線關閉後重用編號、沒有登入行、靠路徑歸戶的 1 筆）、傳輸 3 天：%s' % (r and r['B7 上傳']))
    r = row(E, 'su_a', '/out')
    check(r is not None and r['B7 下載'] == '1' and '下載失敗 1' in r['B7 其他明細'] and r['B7 其他操作'] == '0', 'su_a /out：下載 1，失敗記在其他明細、不算操作')
    check(r is not None and r['B5 登入成功'] == '2' and 'SFTP(1)' in r['B6 協定'] and 'FTP(1)' in r['B6 協定'] and '192.0.2.50' in r['B6 成功來源IP'], 'su_a 登入 2、協定 SFTP/FTP（埠 22/21）、來源 IP')
    check(r is not None and r['B4 期間內首次活動'] == '2026-11-08 04:10' and r['B4 最後成功登入'] == '2026-11-10 02:10' and '累計上傳 539' in r['C2 依據'], 'su_a 首次／最後活動（當地時間不換算）、C2 附帳號檔累計')
    nv = [x for x in rows if x['A4 舊帳號'] == 'never_user']
    check(nv and nv[0]['A4 部門'] == '' and nv[0]['A4 部門來源'] == '', '帳號對照寫「待追查」不算有部門')
    cf = ftp_report.dept_summary([{'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'ftptest', 'A4 部門': '', 'A4 姓名': ''}, {'A2 主機IP': '192.0.2.2', 'A4 舊帳號': 'FTPTEST', 'A4 部門': '', 'A4 姓名': ''}], {'ftptest'})[0]
    check('同名衝突' in cf['沒在用帳號'] and cf['沒在用帳號'].count('同名衝突') == 2, '同名帳號在部門統計標［同名衝突］：%s' % cf['沒在用帳號'])
    check(ftp_report.owner_codes('/1234567890_上版程式') == ['1234567890'] and ftp_report.owner_codes('/8881-20261025報表') == ['8881'] and ftp_report.owner_codes('/warrants') == [], '共用代碼：員編、單位代碼抓得到，日期不算：%s' % ftp_report.owner_codes('/8881-20261025報表'))
    rk = ftp_report.risk_summary([{'A2 主機IP': '192.0.2.1', 'A4 舊帳號': 'ftptest', 'A4 部門': '', 'C1 觀察結果': '有傳輸'}, {'A2 主機IP': '192.0.2.2', 'A4 舊帳號': 'ftptest', 'A4 部門': '', 'C1 觀察結果': ''}], {'ftptest'}, {('192.0.2.1', 'ftptest'): ['1234567890', '8881']})
    check([x['類型'] for x in rk] == ['多台伺服器登入', '同名衝突'] and '1234567890\n8881' in rk[0]['說明'] and rk[1]['主機IP'] == '192.0.2.1\n192.0.2.2' and '192.0.2.1：是' in rk[1]['有在用'], '共用／同名統計：%s' % [(x['類型'], x['說明']) for x in rk])
    sa = [x for x in rows if x['A4 舊帳號'] == 'su_a']
    check(sa and all('多台伺服器登入（帳號共 2 台），本目錄：' in x['A4 多台伺服器登入（待AP確認）'] and '請 AP 確認' in x['A4 多台伺服器登入（待AP確認）'] for x in sa) and any('APPSRV01（SYS-A）' in x['A4 多台伺服器登入（待AP確認）'] for x in sa) and sa[0]['A5 同帳號目錄數'] == str(len(sa)), 'su_a：帳號共 2 台、每列只列動到本目錄的伺服器：%s' % [x['A5 虛擬路徑'] + '→' + x['A4 多台伺服器登入（待AP確認）'] for x in sa])
    sb = [x for x in rows if x['A4 舊帳號'] == 'su_b']
    check(sb and sb[0]['B1 設定狀態'] == '啟用（帳號檔沒有停用設定）' and not sb[0]['A4 多台伺服器登入（待AP確認）'], 'Serv-U 帳號檔沒有停用設定＝啟用；沒多台電腦不標共用：%s' % (sb[0]['B1 設定狀態'] if sb else ''))
    check(ftp_report.PERSONAL_PC.match('w1234567') and ftp_report.PERSONAL_PC.match('W12-345-678') and not ftp_report.PERSONAL_PC.match('appsrv') and not ftp_report.PERSONAL_PC.match('SRVHOST001') and not ftp_report.PERSONAL_PC.match('web01'), '個人電腦只認 W 開頭接數字；系統主機名不算')
    hm = {'_nets': []}
    import ipaddress
    hm['_nets'].append((ipaddress.ip_network('198.51.100.0/24'), '跳板機')); hm['appsrv01'] = 'SYS-A'
    check(ftp_report.host_system(hm, '', '198.51.100.31') == '跳板機' and ftp_report.host_system(hm, 'APPSRV01.x', '192.0.2.9') == 'SYS-A' and ftp_report.host_system(hm, '', '192.0.2.9') is None, '主機系統對照：網段、電腦名稱、對不到')
    check(ftp_report.TEST_ACCT.search('ftptest') and ftp_report.TEST_ACCT.search('DB2TEST') and not ftp_report.TEST_ACCT.search('ap_user1'), '測試帳號判斷（ftptest／db2test）')
    check(r is not None and r.get('A4 主機記載使用者') == '測試甲' and r.get('A4 部門') == '', 'su_a A4 主機記載使用者＝帳號檔全名；非 員編-部門-姓名 格式不拆')
    check(ftp_report.split_fullname('E000000000001-測試部-王小明') == ('E000000000001', '測試部', '王小明') and ftp_report.split_fullname('1000000002-資訊部-陳一') == ('1000000002', '資訊部', '陳一'), '全名拆成 員編／部門／姓名')
    dup = {x['A3 Domain']: x for x in Erows if x['A4 舊帳號'] == 'dup' and x['A5 虛擬路徑'] in ('/', '/in')}
    check(set(dup) == {'DOM', 'DOM2'} and dup['DOM2']['A5 虛擬路徑'] == '/in' and dup['DOM2']['B7 上傳'] == '1' and dup['DOM']['B7 上傳'] == '0'
          and dup['DOM2']['B5 登入成功'] == '0', '同名帳號 dup：傳輸靠路徑歸 DOM2，登入分不出 → 不算給任何一個：%s' % {k: (v['A5 虛擬路徑'], v['B7 上傳'], v['B5 登入成功']) for k, v in dup.items()})
    check(not any(x['A4 舊帳號'] == 'ad.casual' for x in rows), '重用的連線編號、登出後的傳輸都沒有沿用舊帳號（ad.casual）')
    gen, _st = ftp_report.parse_servu_logs(ftp_report.load_host([os.path.join(fx, d) for d in os.listdir(fx) if d.startswith('run_local_192.0.2.14_')][0]))
    check(inspect.isgenerator(gen), 'Serv-U log 解析是邊讀邊交出（generator），不先存整份事件')
    r = [x for x in Erows if x['A4 舊帳號'] == 'su_a' and x['A5 目錄層級'] == '帳號級']
    check(len(r) == 1 and r[0]['B7 上傳'] == '1', 'su_a 家目錄外的上傳 → 帳號級列')
    r = row(E, 'su_b', '/')
    check(r is not None and r['C1 觀察結果'] == '僅登入' and '帳號檔' in r['C2 依據'] and '（帳號檔）' in r['B4 最後成功登入'], 'su_b：log 沒活動，但帳號檔最後登入在期間內 → 僅登入：%s' % (r and r['C2 依據']))
    adr, adh = sp['AD 帳號提醒（不轉置）']
    check(adh == ['項次', '主機IP', '主機名', '帳號', '傳檔天數', '常見時段', '上傳/下載次數', '來源 IP', '說明'], 'AD 提醒欄位：%s' % adh)
    check(len(adr) == 1 and adr[0]['帳號'] == 'ad.sched' and adr[0]['項次'] == 'AD1' and adr[0]['傳檔天數'] == '6' and adr[0]['常見時段'].startswith('03時')
          and '不列入轉置' in adr[0]['說明'] and '下載 6' in adr[0]['上傳/下載次數'], 'AD 提醒只列 ad.sched（6 天、03 時）；ad.irregular（時段不固定）、ad.casual（1 天）不列')
    hrows, hh = sp['主機']
    hrows0, rows0 = hrows, rows
    check(len(hrows) == 5 and [x['項次'] for x in hrows] == ['H1', 'H2', 'H3', 'H4', 'H5'], '主機頁 5 台、項次 H1..H5')
    ha = [x for x in hrows if x['主機IP'] == A][0]
    check('anonymous' in ha['備註'] and '失敗 1' in ha['備註'], '不存在帳號的嘗試記在主機備註：%s' % ha['備註'])
    he = [x for x in hrows if x['主機IP'] == E][0]
    check('另有 3 個非本機帳號登入' in he['備註'] and '其中 1 個疑似寫進排程' in he['備註'], 'Serv-U 主機備註：AD 登入只一行計數：%s' % he['備註'])
    check('未歸戶事件 2 筆' in he['備註'] and '同名帳號' in he['備註'] and '沒有登入行' in he['備註'], 'Serv-U 主機備註：未歸戶 2 筆（同名登入 1、登出後傳輸 1），不猜：%s' % he['備註'])
    check(any(x['收集狀態'] == 'FAIL' for x in hrows) and any('Serv-U 沒有收到 log' in x['備註'] for x in hrows), 'FAIL 主機與 Serv-U 沒有 log 的註記都在主機頁')
    # v0.13.0 協定統計
    FR = ftp_report
    EX = FR.PROTO_EX
    hb = [x for x in hrows if x['主機IP'] == '192.0.2.11'][0]
    check(hh[hh.index('版本') + 1:hh.index('版本') + 4] == [FR.SFTP_COL, '監聽埠', '對應協定'], '主機頁：版本後面多「產品支援 SFTP（原廠）」「監聽埠」「對應協定」三欄')
    check(ha['監聽埠'] == '21, 14148' and ha['對應協定'] == '21：FTP／FTPS(顯式)、14148：其他（FTP 服務程式開的埠）' and ha[FR.SFTP_COL] == FR.SFTP_NO,
          '主機 A（FileZilla）只開 21（IPv4／IPv6 不重複算）＋FTP 服務程式的其他埠；產品不支援 SFTP：%s｜%s' % (ha['監聽埠'], ha['對應協定']))
    check(he['監聽埠'] == '21, 22' and he['對應協定'] == '21：FTP／FTPS(顯式)、22：SFTP' and he[FR.SFTP_COL] == FR.SFTP_SERVU, '主機 E（Serv-U）開 21＋22；產品支援 SFTP＝依版別待確認：%s｜%s' % (he['監聽埠'], he['對應協定']))
    check(hb['監聽埠'] == '21, 22' and hb['對應協定'] == '21：FTP／FTPS(顯式)、22：SFTP〔由 sshd 開，不是 FTP 服務程式〕' and hb[FR.SFTP_COL] == FR.SFTP_NO,
          '主機 B（FileZilla）：22 是 sshd 開的要註記，產品確認不支援 SFTP：%s' % hb['對應協定'])
    hc = [x for x in hrows if x['主機IP'] == '192.0.2.12'][0]
    check(hc['監聽埠'] == '' and hc['對應協定'] == FR.NO_LISTEN, '沒有 listen 列的主機：監聽埠空白、對應協定寫沒有資料')
    prow, ph = sp['協定']
    check(ph == ['項次', '主機IP', '主機名', '環境', '產品', '版本', '產品支援 SFTP（原廠）', '監聽埠', '對應協定', '帳號數', '只走埠 21', '只走埠 22', '埠 21 與 22 都用', '其他組合',
                 'FileZilla（log 摘要無協定資訊）', '期間內無成功登入', '只走非標準埠或未歸戶', '有走埠 989／990（可與其他欄重疊）'], '協定頁欄位（一律以埠命名）：%s' % ph)
    check(not any('只用' in c or 'FTPS' in c for c in ph[9:]), '協定頁帳號欄位沒有「只用 FTP／SFTP」「有 FTPS」這種說法')
    check([x['項次'] for x in prow] == ['T1', 'T2', 'T3', 'T4', 'T5'], '協定頁每台主機一列、項次 T1..T5')
    check(all(sum(int(x[c]) for c in EX) == int(x['帳號數']) for x in prow), '協定頁每一列：只走 21＋只走 22＋都用＋其他組合＋三種無法判斷＝帳號數')
    pe = [x for x in prow if x['主機IP'] == E][0]
    check(pe['帳號數'] == '3' and pe[FR.P_BOTH] == '1' and pe[FR.U_NOLOGIN] == '1' and pe[FR.U_ODD] == '1' and pe[FR.P_989] == '0',
          '主機 E：帳號 3（su_a 21、22 都用；su_b 期間內無成功登入；dup 同名兩個 domain、登入未歸戶）：%s' % [pe[c] for c in ph[9:]])
    pa = [x for x in prow if x['主機IP'] == A][0]
    check(pa['帳號數'] == '5' and pa[FR.U_FZ] == '5' and pa[FR.P_21] == '0', 'FileZilla 主機 A：5 個帳號全部列「FileZilla（log 摘要無協定資訊）」（不猜）')
    nacc = len(set((x['A2 主機IP'], x['A4 舊帳號']) for x in rows))
    check(sum(int(x['帳號數']) for x in prow) == nacc, '協定頁帳號數合計＝主表不重複的「主機＋帳號」數 %d' % nacc)
    pc = FR.proto_class
    check(pc({'proto': {'FTP'}, 'ok': 1}) == (FR.P_21, False) and pc({'proto': {'SFTP'}, 'ok': 1}) == (FR.P_22, False) and pc({'proto': {'FTP', 'SFTP', 'FTPS'}, 'ok': 3}) == (FR.P_BOTH, True)
          and pc({'proto': {'FTPS'}, 'ok': 1}) == (FR.P_OTHER, True) and pc({'proto': {'FTP', 'FTPS'}, 'ok': 2}) == (FR.P_OTHER, True) and pc({'proto': {'FTP', 'port 2121'}, 'ok': 2}) == (FR.P_OTHER, False)
          and pc({'proto': set(), 'ok': 0, 'fz': True}) == (FR.U_FZ, False) and pc({'proto': set(), 'ok': 0}) == (FR.U_NOLOGIN, False) and pc(None) == (FR.U_NOLOGIN, False)
          and pc({'proto': {'port 2121'}, 'ok': 1}) == (FR.U_ODD, False) and pc({'proto': set(), 'ok': 0, 'unattr': True}) == (FR.U_ODD, False) and pc({'proto': set(), 'ok': 2}) == (FR.U_ODD, False),
          '協定分類：7 種互斥分類＋「有走埠 989／990」標記')
    pp = FR.parse_listen_port
    check([pp(x) for x in ('0.0.0.0:21', '[::]:22', ':::21', '::1:14148', '*:990', ' 192.0.2.1:65535 ')] == [21, 22, 21, 14148, 990, 65535], '監聽列讀得出埠：host:port、[v6]:port、收集程式的「:::21」寫法')
    check([pp(x) for x in ('fe80::1', '::1', '21', '0.0.0.0:0', '0.0.0.0:65536', '0.0.0.0:99999', '0.0.0.0:123456', '0.0.0.0:２１', '0.0.0.0:21 x', 'zz::1:21', '', None)] == [None] * 12,
          '監聽列讀不出埠就不收：沒有埠的 IPv6、超出 1..65535、全形數字、多餘文字')
    li = FR.listen_info
    L = lambda n, v: {'item': 'listen', 'name': n, 'value': v}
    x0, x1, x2 = li([]), li([L('pid 7 other', '0.0.0.0:20')]), li([L('pid 7', '0.0.0.0:990'), L('pid 7', '0.0.0.0:989')])
    check((x0['has'], x0['ports'], x0['text'], x0['p22']) == (False, [], FR.NO_LISTEN, 'nodata') and (x1['has'], x1['ports'], x1['text'], x1['p22']) == (True, [], '', 'none')
          and x2['ports'] == [989, 990] and x2['text'] == '989：FTPS(隱式)〔開的程式不明〕、990：FTPS(隱式)〔開的程式不明〕',
          '監聽埠：沒有資料／有資料但沒有 FTP 相關埠（埠 20 別的程式開的不列）／989、990')
    x3 = li([{'item': 'service', 'name': None, 'value': None}, {'item': 'service', 'name': 'Serv-U', 'value': 'pid=77'}, L('PID=77', '0.0.0.0:22'), L(None, None)])
    check(x3['p22'] == 'ftp' and x3['bad'] == 1 and x3['text'] == '22：SFTP；監聽列 1 筆解析失敗', 'listen_info：name／value 是 None 不會壞；PID 大小寫、「PID=N」寫法都認：%s' % x3['text'])
    check([x['項次'] for x in rows] == ['R%d' % (i + 1) for i in range(len(rows))], '主表項次 R1..R%d 連號' % len(rows))
    check(len(sp['使用明細'][0]) == 0 and len(sp['移轉對照表'][0]) == 0, '使用明細／移轉對照表是空白範本')
    # AP 版
    arows, ahdr = ap['主表']
    check('B6 失敗來源IP' not in ahdr and 'A3 服務實例（設定檔）' not in ahdr, 'AP 版沒有失敗來源 IP、設定檔路徑欄')
    with zipfile.ZipFile(os.path.join(out1, [f for f in files if f.startswith('盤點清單_AP_')][0])) as z:
        blob = b''.join(z.read(n) for n in z.namelist())
    check(b'203.0.113.9' not in blob, 'AP 版任何地方都沒有失敗嘗試 IP')
    check(b'ad.sched' not in blob and b'ad.casual' not in blob, 'AP 版沒有任何 AD 帳號')
    check([x['A1 列ID'] for x in arows] == [x['A1 列ID'] for x in rows], 'AP 與 SP 列 ID 相同、順序相同')
    # HTML
    hp = os.path.join(out1, [f for f in files if f.startswith('總覽_')][0])
    with open(hp, encoding='utf-8') as f:
        doc = f.read()
    check(not re.search(r'(?i)<(script|link|img)[^>]+(src|href)=|https?://', doc), 'HTML 不連任何外部資源')
    check('const DATA=' in doc and '"項次": "R1"' in doc and '"項次": "H1"' in doc and '"項次": "AD1"' in doc, 'HTML 內嵌資料含項次 R1、H1、AD1')
    check("{id:'xfer',name:'傳輸量'},{id:'proto',name:'協定'}" in doc and '"項次": "T1"' in doc and '"192.0.2.14|su_a": ["埠 21 與 22 都用", 0]' in doc
          and '不等於明文' in doc and 'FileZilla 主機的 log 摘要沒有協定資訊' in doc and '監聽埠＝收集當下主機實際開的埠' in doc and 'log 沒有確認是不是 FTPS' in doc and '_p22' in doc,
          'HTML 有「協定」分頁（排在傳輸量後）、項次 T1、帳號協定分類、四條說明')
    blob_js = doc[doc.index('const DATA=') + 11:doc.index('\nconst PAGE=')]
    check('<' not in blob_js and '"dup": []' in blob_js, 'HTML 內嵌資料沒有任何 <（全部跳脫）；沒有重複主機時不出現提醒')
    check(FR.json.loads(FR.json.dumps({'a': '<b></script><!--'}, ensure_ascii=False).replace('<', '\\u003c')) == {'a': '<b></script><!--'}, '< 跳脫成 \\u003c 後瀏覽器讀回來還是原字')
    aph_rows, aph = ap['主機']
    check(aph == ['項次', '主機IP', '主機名', '機房', '環境', '階段', '產品', '收集狀態', 'log 起', 'log 訖', '有 log 天數', '需要天數', '缺日數', '盤點列數', '上傳次數', '下載次數', '傳輸合計', '估每月傳輸（30 天）']
          and [aph_rows[0][c] for c in aph] == ['H1', '192.0.2.10', 'FZHOSTA', '', '', '', 'FileZilla', 'OK', '2026-08-11', '2026-11-10', '92', '90', '0', '9', '3', '4', '7', '2'],
          'AP 版「主機」工作表的欄位與第一列跟 v0.12.6 一模一樣（沒有欄位位移）')
    asheets = list(ap.keys())
    check('協定' not in asheets, 'AP 版沒有協定工作表（監聽埠只給 SP）：%s' % asheets)
    time.sleep(1.1)
    print('== 第 2 次（ID 要一樣）')
    rc2, out2 = run_report(fx)
    sp2 = read_sheets(os.path.join(out2, [f for f in os.listdir(out2) if f.startswith('盤點清單_SP_')][0]))
    check(rc2 == 0 and out2 != out1 and [x['A1 列ID'] for x in sp2['主表'][0]] == [x['A1 列ID'] for x in rows], '重跑：新資料夾、列 ID 完全相同')
    check(len(set(x['A1 列ID'] for x in rows)) == len(rows), '列 ID 不重複')
    check(tree_hash(fx) == before, '輸入資料沒有被修改')
    print('== 來源檔叫 X.log.part2 ＋ 收集程式自己切的分段：每個來源檔只讀一次')
    fp = os.path.join(base, 'fixture_parts')
    make_fixture.make_parts(fp)
    for d in sorted(os.listdir(fp)):
        h = ftp_report.load_host(os.path.join(fp, d))
        ev, st = ftp_report.parse_logs(h)
        rows = ftp_report.build_rows(h, ev, st)
        up = sum(int(r['B7 上傳'] or 0) for r in rows if r['A4 舊帳號'] == 'pt_user')
        reads = [os.path.basename(p) for _, parts in ftp_report.iter_log_files(h) for p in parts]
        check(up == 3 and len(reads) == len(set(reads)), '%s：上傳 %d（期望 3）、讀的檔 %s' % (h['hostname'], up, reads))
    print('== 協定統計反例（22 埠是誰開的、監聽列讀不出來、各種埠組合、同名／大小寫不同的帳號）')
    FR = ftp_report
    fq = os.path.join(base, 'fixture_proto')
    make_fixture.make_proto(fq)
    rcq, outq = run_report(fq)
    spq = read_sheets(os.path.join(outq, [f for f in os.listdir(outq) if f.startswith('盤點清單_SP_')][0]))
    qrows, qh = spq['協定']
    mrows = spq['主表'][0]
    Q = {x['主機IP']: x for x in qrows}
    LI = {}
    for d in sorted(os.listdir(fq)):
        if d.startswith('run_local_'):
            hq = FR.load_host(os.path.join(fq, d))
            LI[hq['ip']] = hq['listen']
    check(rcq == 0 and [x['項次'] for x in qrows] == ['T%d' % (i + 1) for i in range(11)], '反例 11 台、項次 T1..T11')
    check(all(sum(int(x[c]) for c in FR.PROTO_EX) == int(x['帳號數']) for x in qrows), '每一列：只走 21＋只走 22＋都用＋其他組合＋三種無法判斷＝帳號數')
    macc = {}
    for x in mrows:
        macc.setdefault(x['A2 主機IP'], set()).add(x['A4 舊帳號'])
    check(all(int(x['帳號數']) == len(macc.get(x['主機IP'], ())) for x in qrows), '每一台的帳號數＝主表那台不重複的帳號（同一個 key：主機IP＋A4 舊帳號原樣）')
    p3 = Q['192.0.2.23']
    check({'CaseX', 'casex', 'twin'} <= macc['192.0.2.23'] and len(macc['192.0.2.23']) == 10 and p3['帳號數'] == '10',
          'P3：大小寫不同的 CaseX／casex 主表是兩個帳號、兩個 domain 的 twin 主表是一個帳號，協定頁也是 10 個：%s' % p3['帳號數'])
    check([p3[c] for c in FR.PROTO_CLS] == ['1', '1', '1', '2', '0', '1', '4', '1'],
          'P3：只走 21＝1、只走 22＝1、都用＝1、其他組合＝2（21＋非標準埠、只走 990）、無成功登入＝1、非標準埠或未歸戶＝4、走 989／990＝1：%s' % [p3[c] for c in FR.PROTO_CLS])
    p1 = Q['192.0.2.21']
    check(LI['192.0.2.21']['p22'] == 'other' and p1[FR.SFTP_COL] == FR.SFTP_NO and 'sshd' in p1['對應協定'] and p1[FR.U_FZ] == '1',
          'P1 FileZilla＋sshd 開 22：落在「22 埠由其他程式開」＋「產品確認不支援 SFTP」：%s' % p1['對應協定'])
    check(LI['192.0.2.22']['p22'] == 'nodata' and LI['192.0.2.22']['has'] is False and Q['192.0.2.22']['監聽埠'] == '' and Q['192.0.2.22']['對應協定'] == FR.NO_LISTEN + '；監聽列 1 筆解析失敗',
          'P2 唯一一筆監聽列讀不出埠：落在「監聽埠資料缺」：%s' % Q['192.0.2.22']['對應協定'])
    check(LI['192.0.2.23']['p22'] == 'ftp' and p3['監聽埠'] == '21, 22, 990, 2121', 'P3：22 埠由 FTP 服務程式開；監聽埠 %s' % p3['監聽埠'])
    check(LI['192.0.2.24']['p22'] == 'unknown' and Q['192.0.2.24']['對應協定'] == '21：FTP／FTPS(顯式)、22：SFTP〔由 sshd 開，不是 FTP 服務程式；另有程式不明的監聽〕',
          'P4 同一個 22 埠一筆 sshd、一筆程式不明：兩個事實都留著：%s' % Q['192.0.2.24']['對應協定'])
    check(LI['192.0.2.25']['p22'] == 'nodata' and Q['192.0.2.25']['監聽埠'] == '21' and Q['192.0.2.25']['對應協定'].endswith('；監聽列 1 筆解析失敗'),
          'P5 有一筆讀不出來又沒看到 22：算資料缺，不說「未觀測到 22」：%s' % Q['192.0.2.25']['對應協定'])
    check(LI['192.0.2.26']['p22'] == 'none' and Q['192.0.2.26'][FR.SFTP_COL] == FR.SFTP_YES, 'P6 服務顯示名字面上有 MFT：支援（MFT 版）；只開 21：未觀測到 22 埠')
    from collections import Counter as _C
    c22 = _C(v['p22'] for v in LI.values())
    check(sum(c22.values()) == 11 and dict(c22) == {'other': 1, 'nodata': 7, 'ftp': 1, 'unknown': 1, 'none': 1}, '22 埠五種狀態互斥、加起來＝主機數 11：%s' % dict(c22))
    check(_C(x[FR.SFTP_COL] for x in qrows) == _C({FR.SFTP_NO: 6, FR.SFTP_SERVU: 4, FR.SFTP_YES: 1}), '產品支援 SFTP：不支援 6（FileZilla）、依版別待確認 4、支援（MFT 版）1')
    print('== 同一台主機重收（兩個資料夾、同一個 IP）：只採用最新一份')
    fd = os.path.join(base, 'fixture_dup')
    make_fixture.make(fd)
    make_fixture.make_acct_lookup(fd)
    make_fixture.make_host_sys(fd)
    src = os.path.join(fd, 'run_local_192.0.2.14_SUHOST2_20261111_020000')
    old = os.path.join(fd, 'run_local_192.0.2.14_SUHOST2_20261101_020000')
    shutil.copytree(src, old)
    with open(os.path.join(old, '_run_info.txt'), 'w', encoding='utf-8-sig', newline='') as f:
        f.write('SOC 通知單號：TEST\r\n開始：2026/11/01 02:00:00\r\n收集工具：FtpCollect.ps1 1.1.1 (2026-11-11)\r\n')
    os.remove(os.path.join(old, '192.0.2.14', 'servu_users.csv'))   # 舊的那份內容不一樣：要是被採用，su_b 的判定會變
    rcd, outd = run_report(fd)
    spd = read_sheets(os.path.join(outd, [f for f in os.listdir(outd) if f.startswith('盤點清單_SP_')][0]))
    dh, dm = spd['主機'][0], spd['主表'][0]
    acc_n = lambda rr: len(set((x['A2 主機IP'], x['A4 舊帳號']) for x in rr))
    ups = lambda hr: (sum(int(x['上傳次數']) for x in hr), sum(int(x['下載次數']) for x in hr))
    check(rcd == 0 and len(dh) == len(hrows0) == 5 and acc_n(dm) == acc_n(rows0) and len(dm) == len(rows0) and ups(dh) == ups(hrows0),
          '重收後：主機 %d 台、帳號 %d 個、盤點 %d 列、上傳／下載 %s，都跟沒有重複時一樣' % (len(dh), acc_n(dm), len(dm), ups(dh)))
    check([x['C1 觀察結果'] for x in dm] == [x['C1 觀察結果'] for x in rows0], '採用的是最新那一份（判定結果跟沒有重複時逐列相同）')
    dnote = '同一台主機有 2 份收集結果，只採用最新一份：192.0.2.14 略過 run_local_192.0.2.14_SUHOST2_20261101_020000'
    with open(os.path.join(outd, [f for f in os.listdir(outd) if f.startswith('總覽_')][0]), encoding='utf-8') as f:
        ddoc = f.read()
    check(dnote in ddoc and 'DATA.dup.length' in ddoc and any(dnote in x['備註'] for x in dh if x['主機IP'] == '192.0.2.14'), '網頁總覽與主機備註都寫出略過了哪個資料夾')
    hx = [{'ip': '192.0.2.99', 'run_name': 'run_b', 'start': None, 'notes': []}, {'ip': '192.0.2.099', 'run_name': 'run_c', 'start': None, 'notes': []}, {'ip': '', 'run_name': 'x1', 'notes': []}, {'ip': '', 'run_name': 'x2', 'notes': []}]
    kx, nx = FR.dedupe_hosts(hx)
    check([x['run_name'] for x in kx] == ['run_c', 'x1', 'x2'] and len(nx) == 1 and 'run_b' in nx[0], '沒有收集時間就比資料夾名（192.0.2.099＝192.0.2.99）；沒有 IP 的不合併')
    print('結果：%s（%d 項失敗）' % ('PASS' if not FAILS else 'FAIL', len(FAILS)))
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())

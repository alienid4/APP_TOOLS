# -*- coding: utf-8 -*-
"""FtpReport 自我測試：產生假資料 → 跑報表兩次 → 檢查數字、AP 版遮蔽、xlsx 結構、HTML 不連外、輸入沒被改。
用法：python selftest.py [暫存資料夾]（預設在系統 TEMP 底下新建）"""
import hashlib
import os
import re
import sys
import tempfile
import time
import zipfile
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_fixture  # noqa: E402
import ftp_report  # noqa: E402

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
FAILS = []


def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond:
        FAILS.append(msg)


def tree_hash(root):
    h = hashlib.sha256()
    for dp, dn, fn in sorted(os.walk(root)):
        dn.sort()
        if os.path.basename(dp).startswith('盤點報表_'):
            continue
        for f in sorted(fn):
            p = os.path.join(dp, f)
            if '盤點報表_' in p:
                continue
            st = os.stat(p)
            h.update(p.encode('utf-8'))
            h.update(str(st.st_mtime_ns).encode())
            with open(p, 'rb') as fh:
                h.update(fh.read())
    return h.hexdigest()


def read_sheets(path):
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in ('[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml'):
            ET.fromstring(z.read(n))   # 都要是合法 XML
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        names = [s.get('name') for s in wb.iter(NS + 'sheet')]
        for i, name in enumerate(names):
            root = ET.fromstring(z.read('xl/worksheets/sheet%d.xml' % (i + 1)))
            rows = []
            for r in root.iter(NS + 'row'):
                cells = {}
                for c in r.iter(NS + 'c'):
                    col = re.match(r'[A-Z]+', c.get('r')).group()
                    idx = 0
                    for ch in col:
                        idx = idx * 26 + (ord(ch) - 64)
                    t = c.find(NS + 'is')
                    v = ''.join(x.text or '' for x in t.iter(NS + 't')) if t is not None else (c.findtext(NS + 'v') or '')
                    cells[idx - 1] = v
                width = max(cells) + 1 if cells else 0
                rows.append([cells.get(k, '') for k in range(width)])
            hdr = rows[0] if rows else []
            out[name] = [dict(zip(hdr, r + [''] * (len(hdr) - len(r)))) for r in rows[1:]], hdr
    return out


def run_report(fx):
    rc = ftp_report.main([fx])
    outs = sorted(d for d in os.listdir(fx) if d.startswith('盤點報表_'))
    return rc, os.path.join(fx, outs[-1])


def main():
    base = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix='ftpreport_selftest_')
    fx = os.path.join(base, 'fixture')
    make_fixture.make(fx)
    before = tree_hash(fx)
    print('== 第 1 次')
    rc, out1 = run_report(fx)
    check(rc == 0, '回傳 0')
    files = sorted(os.listdir(out1))
    check(len(files) == 3 and any(f.startswith('盤點清單_SP_') for f in files) and any(f.startswith('盤點清單_AP_') for f in files) and any(f.startswith('總覽_') for f in files), '產出 3 個檔：%s' % files)
    sp = read_sheets(os.path.join(out1, [f for f in files if f.startswith('盤點清單_SP_')][0]))
    ap = read_sheets(os.path.join(out1, [f for f in files if f.startswith('盤點清單_AP_')][0]))
    check(list(sp.keys()) == ['主表', '使用明細', '移轉對照表', '主機', '說明'], 'SP 工作表：%s' % list(sp.keys()))
    rows, hdr = sp['主表']
    check(all(c in hdr for c in ('A1 列ID', 'B10 證據品質', 'C1 觀察結果', 'D1 續用／停用／待確認', 'E1 AP主管簽認')), '主表欄位含 A1/B10/C1/D1/E1')

    def row(ip, acct, vpath):
        m = [r for r in rows if r['A2 主機IP'] == ip and r['A4 舊帳號'] == acct and r['A5 虛擬路徑'] == vpath]
        return m[0] if len(m) == 1 else None

    A = '192.0.2.10'
    accts = sorted(set(r['A4 舊帳號'] for r in rows if r['A2 主機IP'] == A))
    check('<system user>' not in accts and 'anonymous' not in accts, '內建 <system user> 與 anonymous 不列帳號：%s' % accts)
    r = row(A, 'ap_user1', '/in')
    check(r is not None and r['B7 上傳'] == '2' and r['B7 其他操作'] == '2' and r['A5 目錄層級'] == '第一層子目錄', 'ap_user1 /in：上傳 2（含輪替檔接續 CWD）、其他 2（LIST＋DELE），失敗的 STOR 不算')
    r = row(A, 'ap_user1', '/')
    check(r is not None and r['B7 上傳'] == '1' and r['B7 其他操作'] == '1' and r['B9 期間內檔數'] == '120', 'ap_user1 根目錄：上傳 1、建目錄 1、目錄摘要 120 檔')
    r = row(A, 'ap_user1', '/out')
    check(r is not None and r['B7 下載'] == '1', 'ap_user1 /out：下載 1')
    r = row(A, 'ap_user1', '/share')
    check(r is not None and 'group:grp1' in r['B2 權限來源'] and r['B7 上傳'] == '0', 'ap_user1 /share：群組來的掛載點，權限來源 group:grp1')
    r = row(A, 'ap_user1', '/in')
    check(r['B5 登入成功'] == '1' and r['B5 登入失敗'] == '1' and '198.51.100.5' in r['B6 成功來源IP'] and '203.0.113.9' in r['B6 失敗來源IP'], 'ap_user1 登入成功 1／失敗 1，來源 IP 分列')
    check(r['B4 最後成功登入'] == '2026-11-10 02:30' and '02時' in r['B8 傳輸時段'] and '06時' in r['B8 傳輸時段'], 'UTC→當地時間（+8）：最後登入 %s、時段 %s' % (r['B4 最後成功登入'], r['B8 傳輸時段']))
    check(r['C1 觀察結果'] == '有傳輸', 'ap_user1 /in C1＝有傳輸')
    r = row(A, 'ap_user2', '/')
    check(r is not None and r['B7 下載'] == '1' and '停用' in r['B1 設定狀態'] and '唯讀' in r['B2 權限（解讀）'], 'ap_user2：根目錄下載 1、設定停用、唯讀')
    r = row(A, 'idle_user', '/')
    check(r is not None and r['C1 觀察結果'] == '僅登入', 'idle_user C1＝僅登入')
    r = row(A, 'never_user', '/')
    check(r is not None and r['C1 觀察結果'] == '期間內未觀察到活動' and r['B9 期間外舊檔數'] == '40', 'never_user C1＝期間內未觀察到活動，期間外舊檔 40')
    r = row(A, 'grp_only', '/share')
    check(r is not None and r['B7 下載'] == '1', 'grp_only /share 下載 1')
    r = [x for x in rows if x['A2 主機IP'] == A and x['A4 舊帳號'] == 'grp_only' and x['A5 目錄層級'] == '帳號級']
    check(len(r) == 1 and r[0]['B7 下載'] == '1' and r[0]['B7 統計層級'] == '帳號級', 'grp_only 歸不到掛載點的下載 → 帳號級列')
    B = [x for x in rows if x['A2 主機IP'] == '192.0.2.11']
    check(len(B) == 1 and B[0]['A5 虛擬路徑'] == '/in' and B[0]['C1 觀察結果'] == '有傳輸' and '31 天' in B[0]['C2 依據'] and '上傳 1 次' in B[0]['C2 依據'],
          '31 天主機：有上傳仍判有傳輸，依據註記天數不足')
    C = [x for x in rows if x['A2 主機IP'] == '192.0.2.12']
    check(len(C) == 1 and C[0]['C1 觀察結果'] == '證據不足' and 'Serv-U' in C[0]['C2 依據'], 'Serv-U：設定裡的帳號列出（HomeDir＋Access 同目錄合併成 1 列），C1 證據不足')
    hrows, hh = sp['主機']
    check(len(hrows) == 4 and [x['項次'] for x in hrows] == ['H1', 'H2', 'H3', 'H4'], '主機頁 4 台、項次 H1..H4')
    ha = [x for x in hrows if x['主機IP'] == A][0]
    check('anonymous' in ha['備註'] and '失敗 1' in ha['備註'], '不存在帳號的嘗試記在主機備註：%s' % ha['備註'])
    check(any(x['收集狀態'] == 'FAIL' for x in hrows) and any('Serv-U 解析待' in x['備註'] for x in hrows), 'FAIL 主機與 Serv-U 註記都在主機頁')
    check([x['項次'] for x in rows] == ['R%d' % (i + 1) for i in range(len(rows))], '主表項次 R1..R%d 連號' % len(rows))
    check(len(sp['使用明細'][0]) == 0 and len(sp['移轉對照表'][0]) == 0, '使用明細／移轉對照表是空白範本')
    # AP 版
    arows, ahdr = ap['主表']
    check('B6 失敗來源IP' not in ahdr and 'A3 服務實例（設定檔）' not in ahdr, 'AP 版沒有失敗來源 IP、設定檔路徑欄')
    with zipfile.ZipFile(os.path.join(out1, [f for f in files if f.startswith('盤點清單_AP_')][0])) as z:
        blob = b''.join(z.read(n) for n in z.namelist())
    check(b'203.0.113.9' not in blob, 'AP 版任何地方都沒有失敗嘗試 IP')
    check([x['A1 列ID'] for x in arows] == [x['A1 列ID'] for x in rows], 'AP 與 SP 列 ID 相同、順序相同')
    # HTML
    hp = os.path.join(out1, [f for f in files if f.startswith('總覽_')][0])
    with open(hp, encoding='utf-8') as f:
        doc = f.read()
    check(not re.search(r'(?i)<(script|link|img)[^>]+(src|href)=|https?://', doc), 'HTML 不連任何外部資源')
    check('const DATA=' in doc and '"項次": "R1"' in doc and '"項次": "H1"' in doc, 'HTML 內嵌資料含項次 R1、H1')
    time.sleep(1.1)
    print('== 第 2 次（ID 要一樣）')
    rc2, out2 = run_report(fx)
    sp2 = read_sheets(os.path.join(out2, [f for f in os.listdir(out2) if f.startswith('盤點清單_SP_')][0]))
    check(rc2 == 0 and out2 != out1 and [x['A1 列ID'] for x in sp2['主表'][0]] == [x['A1 列ID'] for x in rows], '重跑：新資料夾、列 ID 完全相同')
    check(len(set(x['A1 列ID'] for x in rows)) == len(rows), '列 ID 不重複')
    check(tree_hash(fx) == before, '輸入資料沒有被修改')
    print('結果：%s（%d 項失敗）' % ('PASS' if not FAILS else 'FAIL', len(FAILS)))
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main())

﻿# UnityCheck v1.0.0 (2026-11-17)
# 唯讀檢查一台 Dell EMC Unity：系統健康、未處理告警、今天的錯誤事件（Error Log）、Pool、告警寄信設定。
# 只用 HTTP GET 讀 Unity REST API，不改任何設定。密碼每次執行時輸入，不存檔、不寫進結果。
param([string]$UnityHost)
$ErrorActionPreference = 'Stop'

$here = $PSScriptRoot
$hostFile = Join-Path $here 'unity_host.txt'
if (-not $UnityHost) {
  if (Test-Path $hostFile) { $UnityHost = (Get-Content $hostFile -TotalCount 1).Trim() }
  if (-not $UnityHost) { $UnityHost = (Read-Host '請輸入 Unity 管理位址（IP 或主機名）').Trim() }
}
if (-not $UnityHost) { Write-Host '沒有輸入位址，結束。'; exit 1 }
if (-not (Test-Path $hostFile)) { Set-Content -Path $hostFile -Value $UnityHost -Encoding ASCII }

$user = Read-Host '帳號（直接 Enter＝webit3sc）'
if (-not $user) { $user = 'webit3sc' }
$sec = Read-Host '密碼（不會顯示）' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
try { $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
$basic = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($user + ':' + $plain))
$plain = $null

[Net.ServicePointManager]::SecurityProtocol = 'Tls12'
# Unity 多為自簽憑證：只對這一台放行憑證檢查，其他網站照舊檢查
$H = $UnityHost
[Net.ServicePointManager]::ServerCertificateValidationCallback = { param($a, $b, $c, $e) $e -eq 'None' -or $a.RequestUri.Host -eq $H }

$base = "https://$UnityHost/api"
$hdr = @{ 'X-EMC-REST-CLIENT' = 'true'; 'Accept' = 'application/json' }
$script:sess = $null

function Get-U([string]$path) {
  $u = "$base/$path"
  if ($script:sess) { return Invoke-RestMethod -Uri $u -Method Get -Headers $hdr -WebSession $script:sess -TimeoutSec 60 }
  $h2 = $hdr.Clone(); $h2['Authorization'] = "Basic $basic"
  $r = Invoke-RestMethod -Uri $u -Method Get -Headers $h2 -SessionVariable s -TimeoutSec 60
  $script:sess = $s
  return $r
}

$SEV = @{0='EMERGENCY';1='ALERT';2='CRITICAL';3='ERROR';4='WARNING';5='NOTICE';6='INFO';7='DEBUG';8='OK'}
$HLT = @{0='UNKNOWN';5='OK';7='OK_BUT';10='DEGRADED';15='MINOR';20='MAJOR';25='CRITICAL';30='NON_RECOVERABLE'}
function Sev($n) { if ($null -ne $n -and $SEV.ContainsKey([int]$n)) { $SEV[[int]$n] } else { "$n" } }
function Hlt($h) {
  if ($null -eq $h) { return '不知道' }
  $v = [int]$h.value
  $t = if ($HLT.ContainsKey($v)) { $HLT[$v] } else { "$v" }
  $d = ((@($h.descriptions) -join ' ') -replace '\s+', ' ').Trim()
  if ($d) { return "$t（$d）" } else { return $t }
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmm'
$outDir = Join-Path $here 'unity_check_out'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$safe = ($UnityHost -replace '[^0-9A-Za-z\.-]', '_')
$rep = Join-Path $outDir ("unity_" + $safe + "_" + $stamp + ".txt")
$lines = New-Object System.Collections.Generic.List[string]
function Say([string]$t) { Write-Host $t; $lines.Add($t) }

$script:verdict = '正常'
$order = @{'正常'=0; '注意'=1; '異常'=2; '查不到'=3}
function Bump([string]$v) { if ($order[$v] -gt $order[$script:verdict]) { $script:verdict = $v } }

Say ("Unity 每日檢查　" + (Get-Date -Format 'yyyy-MM-dd HH:mm') + "　設備：$UnityHost　帳號：$user")
Say ('=' * 60)

# 1. 登入＋系統健康
try {
  $null = Get-U 'types/loginSessionInfo/instances'
  $sys = @((Get-U 'types/system/instances?compact=true&fields=name,model,serialNumber,health').entries | ForEach-Object { $_.content })
  foreach ($x in $sys) {
    Say ("[1] 系統：" + $x.name + "　型號 " + $x.model + "　健康：" + (Hlt $x.health))
    if ([int]$x.health.value -ge 10) { Bump '異常' } elseif ([int]$x.health.value -eq 7) { Bump '注意' }
  }
} catch {
  Say ("[1] 登入或讀系統失敗：" + $_.Exception.Message)
  Say '    → 檢查：位址對不對、帳號密碼、這台到設備 443 通不通。後面不再查。'
  $lines | Set-Content -Path $rep -Encoding UTF8
  Write-Host ""
  Write-Host "結論：查不到　（結果檔：$rep）"
  exit 2
}

# 2. 未處理告警（警示訊息；設備寄出的異常通知信也是這些告警）
try {
  $al = @((Get-U 'types/alert/instances?compact=true&per_page=1000&fields=timestamp,severity,message,isAcknowledged').entries | ForEach-Object { $_.content })
  $open = @($al | Where-Object { -not $_.isAcknowledged })
  $bad = @($open | Where-Object { [int]$_.severity -le 3 })
  $warn = @($open | Where-Object { [int]$_.severity -eq 4 })
  Say ("[2] 未處理告警：" + $open.Count + " 筆（ERROR 以上 " + $bad.Count + "、WARNING " + $warn.Count + "）；全部告警共 " + $al.Count + " 筆")
  $i = 0
  foreach ($a in ($open | Sort-Object -Property @{ Expression = { [int]$_.severity }; Ascending = $true }, @{ Expression = 'timestamp'; Descending = $true } | Select-Object -First 20)) {
    $i++
    Say ("    {0,2}. {1}  {2,-9} {3}" -f $i, $a.timestamp, (Sev $a.severity), ($a.message -replace '\s+', ' '))
  }
  if ($open.Count -gt 20) { Say ("    …另有 " + ($open.Count - 20) + " 筆，見 CSV") }
  $open | Select-Object timestamp, @{n='severity'; e={ Sev $_.severity }}, message |
    Export-Csv -Path (Join-Path $outDir ("unity_" + $safe + "_" + $stamp + "_alerts.csv")) -NoTypeInformation -Encoding UTF8
  if ($bad.Count) { Bump '異常' } elseif ($warn.Count) { Bump '注意' }
} catch { Say ("[2] 讀告警失敗：" + $_.Exception.Message); Bump '查不到' }

# 3. 今天的錯誤事件（Error Log）：今天 00:00 起、ERROR 以上
try {
  $since = (Get-Date).Date
  $ev = @((Get-U 'types/event/instances?compact=true&per_page=500&orderby=creationTime%20desc&fields=creationTime,severity,message,category').entries | ForEach-Object { $_.content })
  $today = @($ev | Where-Object { ([datetime]$_.creationTime).ToLocalTime() -ge $since })
  $err = @($today | Where-Object { [int]$_.severity -le 3 })
  Say ("[3] 今天事件：" + $today.Count + " 筆，其中 ERROR 以上 " + $err.Count + " 筆（讀最近 " + $ev.Count + " 筆事件）")
  if ($ev.Count -ge 500 -and $today.Count -ge 500) { Say '    ⚠ 今天事件超過 500 筆，只看了最近 500 筆'; Bump '注意' }
  $i = 0
  foreach ($e in ($err | Select-Object -First 20)) {
    $i++
    Say ("    {0,2}. {1}  {2,-9} {3}" -f $i, ([datetime]$e.creationTime).ToLocalTime().ToString('HH:mm:ss'), (Sev $e.severity), ($e.message -replace '\s+', ' '))
  }
  $today | Select-Object creationTime, @{n='severity'; e={ Sev $_.severity }}, category, message |
    Export-Csv -Path (Join-Path $outDir ("unity_" + $safe + "_" + $stamp + "_events_today.csv")) -NoTypeInformation -Encoding UTF8
  if ($err.Count) { Bump '異常' }
} catch { Say ("[3] 讀事件失敗：" + $_.Exception.Message); Bump '查不到' }

# 4. Pool 健康與使用率
try {
  $pl = @((Get-U 'types/pool/instances?compact=true&fields=name,health,sizeTotal,sizeUsed').entries | ForEach-Object { $_.content })
  foreach ($p in $pl) {
    $pct = 0
    if ([double]$p.sizeTotal -gt 0) { $pct = [math]::Round(100 * [double]$p.sizeUsed / [double]$p.sizeTotal, 1) }
    Say ("[4] Pool {0}：健康 {1}　使用 {2}%（{3:N0} / {4:N0} GB）" -f $p.name, (Hlt $p.health), $pct, ([double]$p.sizeUsed / 1GB), ([double]$p.sizeTotal / 1GB))
    if ([int]$p.health.value -ge 10) { Bump '異常' } elseif ([int]$p.health.value -eq 7 -or $pct -ge 85) { Bump '注意' }
  }
  if ($pl.Count -eq 0) { Say '[4] Pool：沒有讀到任何 Pool' }
} catch { Say ("[4] 讀 Pool 失敗：" + $_.Exception.Message); Bump '查不到' }

# 5. 告警寄信設定（Mail 異常通知有沒有設、寄到幾個信箱、多嚴重才寄）
try {
  $ac = @((Get-U 'types/alertConfig/instances?compact=true&fields=destinationEmails,minEmailNotificationSeverity').entries | ForEach-Object { $_.content })
  foreach ($c in $ac) {
    $n = @($c.destinationEmails | Where-Object { $_ }).Count
    Say ("[5] 告警寄信：收件信箱 " + $n + " 個；" + (Sev $c.minEmailNotificationSeverity) + " 以上才寄")
    if ($n -eq 0) { Say '    → 沒設定收件信箱：設備出事不會寄信'; Bump '注意' }
  }
} catch { Say ("[5] 讀寄信設定失敗：" + $_.Exception.Message); Bump '查不到' }

Say ('=' * 60)
Say ("結論：" + $script:verdict)
$lines | Set-Content -Path $rep -Encoding UTF8
Write-Host "結果檔：$rep"

﻿#requires -Version 5.1
<#
  PeakCheck v1.0.0 (2026-11-13) -- 尖峰核對（唯讀）
  雙擊「尖峰核對.bat」：輸入帳號、日期、哪一分鐘（HH:mm）→ 從那天的 FileZilla log 數出這一分鐘的下載（RETR）：
  總數、每個來源 IP 各幾次、下載最多那台每一秒幾次、每個 IP 的主機名稱、10 行原始紀錄。只讀 log，不改任何東西。
#>
param([string]$Account = '', [string]$Date = '', [string]$Minute = '', [string]$LogDir = '')
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$VERSION = '1.0.0 (2026-11-13)'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
Write-Host "尖峰核對 PeakCheck $VERSION（只讀 log，不改任何東西）" -ForegroundColor Green
Write-Host ''
if (-not $LogDir) {
    foreach ($c in @("${env:ProgramFiles(x86)}\FileZilla Server\Logs", "$env:ProgramFiles\FileZilla Server\Logs")) { if (Test-Path -LiteralPath $c -PathType Container) { $LogDir = $c; break } }
    $a = Read-Host "log 資料夾（直接按 Enter＝$LogDir）"; if ($a.Trim()) { $LogDir = $a.Trim().Trim('"') }
}
if (-not $Account) { $Account = (Read-Host '帳號（直接按 Enter＝ftp11-1）').Trim(); if (-not $Account) { $Account = 'ftp11-1' } }
if (-not $Date) { $Date = (Read-Host '日期（直接按 Enter＝2026-11-12）').Trim(); if (-not $Date) { $Date = '2026-11-12' } }
if (-not $Minute) { $Minute = (Read-Host '哪一分鐘 HH:mm（直接按 Enter＝19:37）').Trim(); if (-not $Minute) { $Minute = '19:37' } }
try { $Date = ([datetime]::Parse($Date)).ToString('yyyy-MM-dd') } catch { Write-Host "看不懂的日期：$Date" -ForegroundColor Yellow; exit 3 }
if ($Minute -notmatch '^\d{1,2}:\d{2}$') { Write-Host "分鐘要寫成 19:37 這種格式：$Minute" -ForegroundColor Yellow; exit 3 }
$hh, $mm = $Minute.Split(':'); $Minute = '{0:00}:{1}' -f [int]$hh, $mm

$files = @(Get-ChildItem -LiteralPath $LogDir -File | Where-Object { $_.Name -like "*$Date*" -and $_.Name -match '\.(log|txt)(\.(part|split)\d+)?$' } | Sort-Object Name)
if (-not $files.Count) { Write-Host "找不到 $Date 的 log 檔（$LogDir）" -ForegroundColor Yellow; exit 3 }
$pat = ' ' + [regex]::Escape($Minute) + ':(\d\d) - ' + [regex]::Escape($Account) + ' \(([0-9A-Fa-f:.]+)\)> RETR '
$rx = New-Object regex($pat, 'IgnoreCase')
$sb = New-Object Text.StringBuilder
function Out([string]$s) { [void]$sb.AppendLine($s); Write-Host $s }
Out "尖峰核對報告　帳號：$Account　日期：$Date　分鐘：$Minute　主機：$env:COMPUTERNAME　產生：$((Get-Date).ToString('yyyy/MM/dd HH:mm:ss'))"
Out "工具：PeakCheck $VERSION　只數「下載指令 RETR」那一行；時間是 log 上記的時間（精確到秒）"
foreach ($f in $files) { Out ("log 檔：{0}　{1:N0} 位元組" -f $f.FullName, $f.Length) }
Out ''
Write-Host '讀取中（一天 800 MB 約 1～2 分鐘）…'
$sw = [Diagnostics.Stopwatch]::StartNew()
# 快速讀法：逐行找「這一分鐘」的行交給 C#（PowerShell 逐行一天要十幾分鐘）；主機不允許編譯就用一般讀法
$fast = $false
try {
    if (-not ('PeakCheckFast' -as [type])) {
        Add-Type -ErrorAction Stop -TypeDefinition @'
public static class PeakCheckFast {
    public static string Next(System.IO.StreamReader sr, string key, long[] c) {
        int k = 0; string line;
        while ((line = sr.ReadLine()) != null) {
            c[0]++;
            if (line.IndexOf(key, System.StringComparison.Ordinal) >= 0) return line;
            if (++k >= 500000) return "";
        }
        return null;
    }
}
'@
    }
    $fast = $true
} catch { }
$byIp = @{}; $bySec = @{}; $sample = New-Object System.Collections.Generic.List[string]; $total = 0
foreach ($f in $files) {
    $fs = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
    $sr = New-Object IO.StreamReader($fs, (New-Object Text.UTF8Encoding($false)), $true, 1048576)
    try {
        $key = ' ' + $Minute + ':'; $cnt = New-Object long[] 3
        while ($true) {
            if ($fast) { $line = [PeakCheckFast]::Next($sr, $key, $cnt); if ($null -eq $line) { break }; if ($line.Length -eq 0) { continue } }
            else { $line = $sr.ReadLine(); if ($null -eq $line) { break }; if ($line.IndexOf($key, [StringComparison]::Ordinal) -lt 0) { continue } }
            $m = $rx.Match($line); if (-not $m.Success) { continue }
            $total++; $sec = $m.Groups[1].Value; $ip = $m.Groups[2].Value
            if ($byIp.ContainsKey($ip)) { $byIp[$ip]++ } else { $byIp[$ip] = 1 }
            $k = $ip + '|' + $sec; if ($bySec.ContainsKey($k)) { $bySec[$k]++ } else { $bySec[$k] = 1 }
            if ($sample.Count -lt 10) { $sample.Add($line) }
        }
    } finally { $sr.Close(); $fs.Close() }
}
Out ("【總數】{0} 這一分鐘，{1} 下載 {2:N0} 次（讀檔花 {3:N0} 秒）" -f $Minute, $Account, $total, $sw.Elapsed.TotalSeconds)
if (-not $total) { Out '這一分鐘沒有下載紀錄（確認帳號、日期、分鐘是否正確）。' }
else {
    Out ("【每個來源 IP】共 {0} 台；平均每台這一分鐘 {1:N0} 次（約每秒 {2:N1} 次）" -f $byIp.Count, ($total / $byIp.Count), ($total / $byIp.Count / 60.0))
    $names = @{}
    foreach ($ip in $byIp.Keys) { try { $names[$ip] = [Net.Dns]::GetHostEntry($ip).HostName } catch { $names[$ip] = '（查不到名稱）' } }
    foreach ($kv in ($byIp.GetEnumerator() | Sort-Object @{e = { $_.Value }; Descending = $true }, @{e = { $_.Key } })) { Out ('　{0}　{1:N0} 次　主機名稱：{2}' -f $kv.Key, $kv.Value, $names[$kv.Key]) }
    $top = ($byIp.GetEnumerator() | Sort-Object @{e = { $_.Value }; Descending = $true }, @{e = { $_.Key } } | Select-Object -First 1).Key
    Out ("【每一秒】下載最多的 {0} 在 {1} 這一分鐘，每一秒下載幾次：" -f $top, $Minute)
    for ($s = 0; $s -lt 60; $s++) { $k = '{0}|{1:00}' -f $top, $s; if ($bySec.ContainsKey($k)) { Out ('　{0}:{1:00}　{2} 次' -f $Minute, $s, $bySec[$k]) } }
    Out '【原始紀錄】前 10 行'
    foreach ($x in $sample) { Out ('　' + $x) }
}
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $here ('尖峰核對_{0}_{1}_{2}_{3}.txt' -f ($Account -replace '[\\/:*?"<>|]', '_'), $Date, ($Minute -replace ':', ''), (Get-Date).ToString('HHmmss'))
try { [IO.File]::WriteAllText($out, $sb.ToString(), (New-Object Text.UTF8Encoding($true))) } catch { $out = Join-Path $env:TEMP (Split-Path $out -Leaf); [IO.File]::WriteAllText($out, $sb.ToString(), (New-Object Text.UTF8Encoding($true))) }
Write-Host ''
Write-Host "報告已存：$out" -ForegroundColor Green
exit 0

@echo off
chcp 65001 >nul
setlocal
rem PeakCheck v1.0.0 - count one minute of downloads for one FTP account in the FileZilla log (read-only).
set "PSModuleAnalysisCachePath=NUL"
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PeakCheck.ps1" %*
echo.
pause

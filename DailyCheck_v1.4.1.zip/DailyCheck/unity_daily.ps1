﻿# UnityDaily v1.4.1 (2026-11-17)：檢查表文字、重點整理、選單
# Dell EMC Unity 每日檢查（唯讀）。對應紙本「檢查警示訊息、Error Log、Mail 異常通知，有異常發信回報」，另附 LUN／檔案系統空間報告。
# 只用 HTTP GET 讀 Unity REST API；不確認告警、不改任何設定。定位：值班輔助與取證，不取代人工判斷。
#
# 設備清單.csv（跟本程式同資料夾，Excel 可編輯）：類別,地點,廠牌,型號,IP,帳號,密碼,備註。本程式讀類別 3（Storage/San Switch）。
#   帳號留空＝webit3sc；密碼留空＝開跑時問一次（共用）；明文密碼第一次執行後自動換成 Windows DPAPI 加密字串。
# 輸出：unity_out\<執行編號>\ report.html ＋ 各類 CSV ＋ manifest.json；先寫到 .partial，全部完成才改名。
# 結束代碼：0 全部正常且完整、1 有注意、2 有異常（資料完整）、3 有設備查不到／資料不完整／整批中止。
# 參數：-Menu＝顯示選單挑設備；-Only "1,3"＝只檢查 ip.list 的第 1、3 台（照順序編號）；
#       -Since "2026-11-15 08:00"＝補查指定時間起的事件（不會改動下次的事件起點）；-NonInteractive＝缺密碼不詢問、直接列查不到。
param(
  [ValidateRange(1, 100)][double]$PoolWarnPct = 85,
  [ValidateRange(1, 100)][double]$PoolBadPct = 95,
  [ValidateRange(1, 100)][double]$FsWarnPct = 85,
  [ValidateRange(1, 100)][double]$FsBadPct = 95,
  [ValidateRange(1, 30)][int]$MaxLookbackDays = 7,
  [string]$Since = '',
  [ValidateRange(10, 1000)][int]$MaxCallsPerDevice = 200,
  [ValidateRange(0, 5000)][int]$CallGapMs = 200,
  [ValidateRange(60, 3600)][int]$DeviceDeadlineSec = 600,
  [switch]$NonInteractive,
  [switch]$Menu,
  [string]$Only = '',
  [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
$ToolVersion = 'UnityDaily v1.4.1'
if ($PoolWarnPct -gt $PoolBadPct -or $FsWarnPct -gt $FsBadPct) { Write-Host '門檻設定錯誤：注意門檻不可大於異常門檻'; exit 3 }
$RulesVersion = "R3.3｜只算 Active 告警｜Pool $PoolWarnPct/$PoolBadPct%｜檔案系統 $FsWarnPct/$FsBadPct%｜告警：未確認 ERROR 以上＝異常、已確認 ERROR 以上或未確認 WARNING＝注意｜期間 ERROR 事件＝注意（待覆核）｜LUN 配置率僅供參考｜事件只看 ERROR 以上、最多 $MaxLookbackDays 天"
$here = $PSScriptRoot
$stateFile = Join-Path $here 'unity_state.json'
$namesFile = Join-Path $here 'unity_names.json'
$lockFile = Join-Path $here 'unity_daily.lock'

# ================================================================ 共用小工具
function Esc([object]$v) { if ($null -eq $v) { return '' }; return [System.Net.WebUtility]::HtmlEncode([string]$v) }
function CsvSafe([object]$v) {   # 防 Excel 公式注入：去掉前導控制字元後若以 = + - @ 開頭就加 '
  if ($null -eq $v) { return '' }
  if ($v -isnot [string]) { return $v }
  $s = $v -replace '^[\x00-\x1F]+', ''
  if ($s -match '^[=+\-@]') { return "'" + $s }
  return $s
}
function NumOk([object]$v) {     # 有效、有限、非負的數字
  if ($null -eq $v -or "$v" -eq '') { return $false }
  $d = 0.0
  if (-not [double]::TryParse([string]$v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { return $false }
  return (-not [double]::IsNaN($d) -and -not [double]::IsInfinity($d) -and $d -ge 0)
}
function Num([object]$v) { return [double]::Parse([string]$v, [Globalization.CultureInfo]::InvariantCulture) }
function GiB([object]$bytes) { if (-not (NumOk $bytes)) { return $null }; return [math]::Round((Num $bytes) / 1073741824, 1) }
function Ratio([object]$a, [object]$b) {   # 原始比值（0~1+），不先四捨五入；判定用
  if (-not (NumOk $a) -or -not (NumOk $b) -or (Num $b) -le 0) { return $null }
  return (Num $a) / (Num $b)
}
function PctShow([object]$r) { if ($null -eq $r) { return $null }; return [math]::Round(100 * $r, 1) }
function IntOk([object]$v) { if ($null -eq $v -or "$v" -eq '') { return $false }; $i = 0; return [int]::TryParse([string]$v, [ref]$i) }
$SEV = @{0='EMERGENCY';1='ALERT';2='CRITICAL';3='ERROR';4='WARNING';5='NOTICE';6='INFO';7='DEBUG';8='OK'}
$HLT = @{0='UNKNOWN';5='OK';7='OK_BUT';10='DEGRADED';15='MINOR';20='MAJOR';25='CRITICAL';30='NON_RECOVERABLE'}
function SevOk($n) { return ((IntOk $n) -and $SEV.ContainsKey([int]$n)) }
function SevText($n) { if (SevOk $n) { return $SEV[[int]$n] }; if ($null -eq $n) { return '不知道' }; return "不知道（$n）" }
function HltText($h) {
  if ($null -eq $h -or -not (IntOk $h.value)) { return '不知道' }
  $v = [int]$h.value
  $t = if ($HLT.ContainsKey($v)) { $HLT[$v] } else { "不認得的值 $v" }
  $d = ((@($h.descriptions) -join ' ') -replace '\s+', ' ').Trim()
  if ($d) { return "$t（$d）" } else { return $t }
}
function HltLevel($h) {   # 健康值 → 正常／注意／異常／不知道（不認得的值＝不知道，不猜）
  if ($null -eq $h -or -not (IntOk $h.value)) { return '不知道' }
  switch ([int]$h.value) { 5 { '正常' } 7 { '注意' } 0 { '不知道' } { $_ -in 10, 15, 20, 25, 30 } { '異常' } default { '不知道' } }
}
# 設備狀態的輕重。完整度另外算，不混在這裡（異常不可以蓋掉「沒查完」，反之亦然）
$SV = @{'正常'=0; '注意'=1; '不知道'=2; '異常'=3}
function Worse([string]$x, [string]$y) { if ($SV[$y] -gt $SV[$x]) { return $y } else { return $x } }
function ParseUtc([object]$s) {   # Unity 時間是 ISO 8601（帶 Z 或位移）
  if ($null -eq $s -or "$s" -eq '') { return $null }
  $d = [DateTimeOffset]::MinValue
  if ([DateTimeOffset]::TryParse([string]$s, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal, [ref]$d)) { return $d.ToUniversalTime() }
  return $null
}
function Local([object]$dto) { if ($null -eq $dto) { return '' }; return $dto.ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss') }

# ================================================================ 鎖（同一資料夾同時只跑一份）
try { $lock = [IO.File]::Open($lockFile, 'OpenOrCreate', 'ReadWrite', 'None') }
catch { Write-Host '另一個 UnityDaily 正在這個資料夾執行（或上次沒結束），請等它跑完再試。'; exit 3 }

$exitCode = 3
$jarDir = $null
$logDir = Join-Path $here 'unity_out'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir ('run_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.log')
try { Start-Transcript -Path $logFile -Append | Out-Null; $transcript = $true } catch { $transcript = $false }
$stateFail = $null
try {
# ================================================================ 讀 設備清單.csv（類別 3＝Storage/San Switch）
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
. (Join-Path $here 'devlist.ps1')
$targets = Read-DevList $here '3'
if ($null -eq $targets) { exit 3 }
if ($targets.Count -eq 0) { Write-Host '設備清單.csv 裡沒有類別 3（Storage/San Switch）的設備，結束。'; exit 3 }
foreach ($tg in $targets) { if (-not $tg.User) { $tg.User = 'webit3sc' } }
# ---------------- 選單（-Menu）／挑選（-Only）
$names = @{}
if (Test-Path $namesFile) { try { (Get-Content $namesFile -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $names[$_.Name] = [string]$_.Value } } catch {} }
if ($Menu -and -not $Only) {
  Write-Host ''
  Write-Host '==== 每日檢查選單 ===='
  Write-Host ' 3. Storage/San Switch 檢查（目前支援 Dell EMC Unity）'
  Write-Host ' 4. 其他：AD net time'
  Write-Host ' 0. 離開'
  $c1 = (Read-Host '請選').Trim()
  if ($c1 -eq '4') { & (Join-Path $here 'ad_time.ps1') -NoOpen:$NoOpen; exit $LASTEXITCODE }
  if ($c1 -ne '3') { Write-Host '離開。'; exit 0 }
  Write-Host ''
  Write-Host '==== 3. Storage/San Switch 檢查：選設備 ===='
  foreach ($tg in $targets) { Write-Host ('{0,3}. {1,-6} {2,-16} {3}' -f $tg.No, $tg.Loc, $tg.Host, $(if ($names.ContainsKey($tg.Host)) { $names[$tg.Host] } elseif ($tg.Reject) { '（' + $tg.Reject + '）' } else { '' })) }
  $allNo = $targets.Count + 1
  Write-Host ('{0,3}. 全部' -f $allNo)
  $Only = (Read-Host '請選（可多選，例如 1,3,5；直接 Enter＝全部）').Trim()
  if ($Only -eq "$allNo") { $Only = '' }
}
if ($Only) {
  $want = @($Only -split '[,，\s]+' | Where-Object { $_ } | ForEach-Object { $n = 0; if ([int]::TryParse($_, [ref]$n)) { $n } else { Write-Host "看不懂的選項：$_"; exit 3 } })
  $bad = @($want | Where-Object { $_ -lt 1 -or $_ -gt $targets.Count })
  if ($bad.Count) { Write-Host ('沒有這幾號：' + ($bad -join ',')); exit 3 }
  $targets = [System.Collections.Generic.List[object]]@($targets | Where-Object { $want -contains $_.No })
  Write-Host ('只檢查：' + (($targets | ForEach-Object { $_.Host }) -join '、'))
}
$needAsk = @($targets | Where-Object { -not $_.Reject -and $null -eq $_.Sec })
if ($needAsk.Count) {
  if ($NonInteractive) { foreach ($tg in $needAsk) { $tg.Reject = '沒有可用的密碼（非互動模式不詢問）' } }
  else {
    $shared = Read-Host ("有 " + $needAsk.Count + " 台沒有可用的密碼，請輸入共用密碼（不會顯示）") -AsSecureString
    foreach ($tg in $needAsk) { $tg.Sec = $shared }
    $shared = $null
  }
}
Write-Host ("設備共 " + $targets.Count + " 台")

# ================================================================ 連線（Windows 內建 curl.exe）
# 不用 PowerShell 憑證回呼：它在背景執行緒沒有 Runspace，對 Unity 會「基礎連接已關閉」（2026-11-17 實測）。
$curl = Join-Path $env:SystemRoot 'System32\curl.exe'
if (-not (Test-Path $curl)) { Write-Host '找不到 Windows 內建 curl.exe（需要 Windows 10 1803／Server 2019 以上），結束。'; exit 3 }
$jarDir = Join-Path $env:TEMP ('unitydaily_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $jarDir | Out-Null
& icacls.exe $jarDir /inheritance:r /grant:r ("*{0}:(OI)(CI)F" -f $sid) | Out-Null

class AuthFail : System.Exception { AuthFail([string]$m) : base($m) {} }
class DeviceStop : System.Exception { DeviceStop([string]$m) : base($m) {} }
function IsStop($e) { return ($e -is [AuthFail] -or $e -is [DeviceStop]) }

function Invoke-UnityGet($dev, [string]$path) {
  if ($dev.Calls -ge $MaxCallsPerDevice) { throw [DeviceStop]::new("已達每台 $MaxCallsPerDevice 次呼叫上限，停止讀這台") }
  if (((Get-Date) - $dev.Start).TotalSeconds -gt $DeviceDeadlineSec) { throw [DeviceStop]::new("這台已超過 $DeviceDeadlineSec 秒，停止讀這台") }
  $dev.Calls++
  if ($CallGapMs -gt 0) { Start-Sleep -Milliseconds $CallGapMs }
  $url = "https://" + $dev.Host + "/api/" + $path
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $curl
  # -q 不讀 .curlrc；--noproxy 直連；只允許 https；轉址最多 3 次（Unity 登入會轉址），最後須回到同一台
  $psi.Arguments = '-q -s -S -k -L --max-redirs 3 --proto "=https" --proto-redir "=https" --noproxy "*" --connect-timeout 15 --max-time 90 -K - -H "X-EMC-REST-CLIENT: true" -H "Accept: application/json" -b "' + $dev.Jar + '" -c "' + $dev.Jar + '" -w "\n%{http_code} %{num_redirects} %{url_effective}" "' + $url + '"'
  $psi.UseShellExecute = $false
  $psi.RedirectStandardInput = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
  $pr = [Diagnostics.Process]::Start($psi)
  try {
    if (-not $dev.HaveCookie) { $pr.StandardInput.WriteLine('header = "Authorization: Basic ' + $dev.Basic + '"') }
    $pr.StandardInput.Close()
    $errTask = $pr.StandardError.ReadToEndAsync()     # stderr 另外排空，避免管線互卡
    $outTask = $pr.StandardOutput.ReadToEndAsync()
    if (-not $pr.WaitForExit(120000)) { try { $pr.Kill() } catch {}; throw '單次呼叫超過 120 秒，已中止' }
    $out = $outTask.Result; $er = $errTask.Result
    $xc = $pr.ExitCode
  } finally { $pr.Dispose() }
  $i = $out.LastIndexOf("`n")
  $tail = if ($i -ge 0) { $out.Substring($i + 1).Trim() -split ' ', 3 } else { @() }
  $code = if ($tail.Count -ge 1) { $tail[0] } else { '' }
  if ($tail.Count -ge 2 -and (IntOk $tail[1])) { $dev.Requests += [int]$tail[1] }
  $dev.Requests++
  if ($code -eq '401') { throw [AuthFail]::new('HTTP 401：帳號或密碼被拒（為避免鎖帳號，整批停止、不重試）') }   # 401 先判，任何情況都整批停
  if ($xc -ne 0 -and $code -in '', '000') { $m = ($er -replace '\s+', ' ').Trim(); if ($m.Length -gt 160) { $m = $m.Substring(0, 160) }; throw ("連線失敗（curl 代碼 " + $xc + "）：" + $m) }
  $eff = if ($tail.Count -ge 3) { $tail[2] } else { '' }
  try { $effHost = ([Uri]$eff).Host } catch { $effHost = '' }
  if ($effHost -and $effHost -ne $dev.Host) { throw "被轉到別的位址（$effHost），為安全起見不採用" }
  $body = if ($i -ge 0) { $out.Substring(0, $i) } else { $out }
  if ($code -eq '403') { throw 'HTTP 403：這個帳號沒有權限讀這一項' }
  if ($code -ne '200') {
    $msg = ''
    try { $msg = ((($body | ConvertFrom-Json).error.messages) | ForEach-Object { $_.'en-US' }) -join ' ' } catch {}
    if ($msg.Length -gt 120) { $msg = $msg.Substring(0, 120) }
    throw ("HTTP " + $code + $(if ($msg) { "：" + $msg } else { '' }))   # 只留設備的錯誤訊息，不收原始內容
  }
  if ($xc -ne 0) { throw ("傳輸未完成（curl 代碼 " + $xc + "）") }
  try { $j = $body | ConvertFrom-Json } catch { throw '回來的不是 JSON（可能被導到登入頁），不採用' }
  if (Test-Path $dev.Jar) { if (@(Get-Content $dev.Jar | Where-Object { $_ -and ($_ -notmatch '^#' -or $_ -match '^#HttpOnly_') }).Count) { $dev.HaveCookie = $true } }
  return $j
}

# 讀一整類（分頁讀完）。回傳 @{ Rows; Complete; Note }
function Get-All($dev, [string]$type, [string]$fields, [int]$per = 250, [int]$maxPages = 20, [string]$extra = '', [scriptblock]$StopWhen = $null) {
  $rows = New-Object System.Collections.Generic.List[object]
  for ($page = 1; $page -le $maxPages; $page++) {
    Write-Host ("    讀 $type 第 $page 頁（目前 " + $rows.Count + " 筆，已用 " + [math]::Round(((Get-Date) - $dev.Start).TotalSeconds) + " 秒）") -ForegroundColor DarkGray
    $j = Invoke-UnityGet $dev ("types/$type/instances?compact=true&per_page=$per&page=$page&fields=$fields$extra")
    if ($null -eq $j.PSObject.Properties['entries']) { throw "回應沒有 entries 欄位，格式不對" }
    $ents = @(@($j.entries) | Where-Object { $null -ne $_ })
    $got = @($ents | ForEach-Object { $_.content })
    if ($got.Count -ne $ents.Count -or @($got | Where-Object { $null -eq $_ }).Count) { throw "回應的 entries 少了 content，格式不對" }
    foreach ($g in $got) { $rows.Add($g) }
    if ($StopWhen -and $got.Count -and (& $StopWhen $got[-1])) { return @{ Rows = $rows.ToArray(); Complete = $true; Note = '' } }
    # 用 entryCount 或「這頁不滿」判斷讀完（設備可能把 per_page 壓低，不能只看是否小於要求的筆數）
    $total = $null; if ($j.PSObject.Properties['entryCount'] -and (IntOk $j.entryCount)) { $total = [int]$j.entryCount }
    if ($null -ne $total) { if ($rows.Count -ge $total) { return @{ Rows = $rows.ToArray(); Complete = $true; Note = '' } } }
    elseif ($got.Count -lt $per) { return @{ Rows = $rows.ToArray(); Complete = $true; Note = '' } }
    if ($got.Count -eq 0) { return @{ Rows = $rows.ToArray(); Complete = $false; Note = "$type 分頁回空頁但總數未到" } }
  }
  return @{ Rows = $rows.ToArray(); Complete = $false; Note = "$type 超過 $($per * $maxPages) 筆，只讀了前面 $($rows.Count) 筆" }
}

# ================================================================ 狀態檔（事件從上次「事件完整讀到」的時間開始）
$state = @{}
if (Test-Path $stateFile) {
  try { (Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $state[$_.Name] = [string]$_.Value } }
  catch { Write-Host "（unity_state.json 讀不懂，這次事件改看最近 $MaxLookbackDays 天）" }
}
$manualSince = $null
if ($Since) {
  $tmpD = [datetime]::MinValue
  if (-not [datetime]::TryParse($Since, [ref]$tmpD)) { Write-Host "-Since 時間看不懂：$Since"; exit 3 }
  $manualSince = ([DateTimeOffset]$tmpD).ToUniversalTime()
  Write-Host ("補查模式：事件從 " + $tmpD.ToString('yyyy-MM-dd HH:mm') + " 起（不會改動下次的事件起點）")
}

# ================================================================ 結果容器
$R = @{}
foreach ($k in 'Summary', 'Alerts', 'Events', 'Pools', 'Luns', 'Fs', 'Hw', 'Rep', 'Mail', 'Gaps', 'Focus', 'Sheet') { $R[$k] = New-Object System.Collections.Generic.List[object] }
$runStart = Get-Date
$runUtc = [DateTimeOffset]::UtcNow
$runId = $runStart.ToString('yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0, 6)
$abort = $null
$newState = @{}; foreach ($k in $state.Keys) { $newState[$k] = $state[$k] }

function NewSummary($tg) {
  return [ordered]@{ 項次 = $tg.No; 項目 = ''; 設備 = $tg.Host; 地點 = $tg.Loc; 名稱 = ''; 型號 = ''; 序號 = ''; 版本 = ''; 帳號角色 = ''; 系統健康 = '不知道'
    未處理告警 = $null; 告警ERROR以上 = $null; 期間錯誤事件 = $null; 事件期間 = ''; Pool注意 = $null; LUN數 = $null; 檔案系統注意 = $null
    硬體異常 = $null; 複寫異常 = $null; 寄信設定 = '不知道'; 設備狀態 = '不知道'; 完整度 = '查不到'; 處置 = '須補查'; 說明 = ''; 耗時秒 = $null; 呼叫數 = 0 }
}

foreach ($tg in $targets) {
  Write-Host ""
  Write-Host ("──── " + $tg.No + " / " + $targets.Count + "：" + $tg.Host + " ────")
  $sum = NewSummary $tg
  if ($abort) { $sum.項目 = Label $tg ''; $sum.完整度 = '沒檢查'; $sum.說明 = '前面的設備帳密被拒，整批停止'; $R.Summary.Add([pscustomobject]$sum); continue }
  if ($tg.Reject) { $sum.項目 = Label $tg ''; $sum.說明 = $tg.Reject; $R.Summary.Add([pscustomobject]$sum); $R.Gaps.Add([pscustomobject]@{ 設備 = $tg.Host; 項目 = '設備清單'; 必要 = '是'; 原因 = $tg.Reject }); Write-Host $tg.Reject; continue }
  $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($tg.Sec)
  try { $basic = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($tg.User + ':' + [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b))) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
  $dev = [pscustomobject]@{ Host = $tg.Host; Basic = $basic; Jar = (Join-Path $jarDir ("d" + $tg.No + ".cookie")); HaveCookie = $false; Calls = 0; Requests = 0; Start = (Get-Date)
                            Notes = New-Object System.Collections.Generic.List[string] }
  $basic = $null
  $status = '正常'; $stopped = $null
  $required = [ordered]@{ 系統 = $false; 告警 = $false; 事件 = $false; Pool = $false }
  function Gap([string]$item, [string]$why, [bool]$must) {
    $R.Gaps.Add([pscustomobject]@{ 設備 = $tg.Host; 項目 = $item; 必要 = $(if ($must) { '是' } else { '否' }); 原因 = $why })
  }
  try {
    # 0. 登入＋系統（必要）
    Write-Host '  [1/9] 登入、系統健康'
    $s = Get-All $dev 'system' 'id,name,model,serialNumber,health'
    if (@($s.Rows).Count -eq 0) { throw '讀不到 system' }
    $s0 = $s.Rows[0]
    $sum.名稱 = $s0.name; $sum.型號 = $s0.model; $sum.序號 = $s0.serialNumber
    $sum.系統健康 = HltText $s0.health
    $status = Worse $status (HltLevel $s0.health)
    $required.系統 = $true
    try { $bi = Get-All $dev 'basicSystemInfo' 'softwareVersion'; if (@($bi.Rows).Count) { $sum.版本 = $bi.Rows[0].softwareVersion } }
    catch { if (IsStop $_.Exception) { throw }; Gap '版本' $_.Exception.Message $false }
    try {
      $who = Invoke-UnityGet $dev 'types/loginSessionInfo/instances?compact=true&fields=roles'
      $roles = @(@($who.entries) | ForEach-Object { $_.content.roles } | ForEach-Object { $_.id } | Where-Object { $_ }) -join ','
      $sum.帳號角色 = if ($roles) { $roles } else { '不知道' }
      if ($roles -and $roles -ne 'operator') { $dev.Notes.Add("⚠ 這個帳號的角色是 $roles，不是唯讀 Operator（違反最小權限）"); $status = Worse $status '注意' }
      if (-not $roles) { Gap '帳號角色' '讀不到角色，無法確認是唯讀帳號' $false }
    } catch { if (IsStop $_.Exception) { throw }; Gap '帳號角色' $_.Exception.Message $false }
    $key = if ($s0.serialNumber) { [string]$s0.serialNumber } else { 'host:' + $tg.Host }

    # 1. 告警（必要）
    Write-Host '  [2/9] 告警'
    try {
      $al = Get-All $dev 'alert' 'id,timestamp,severity,message,isAcknowledged,state'
      if (-not $al.Complete) { Gap '告警' $al.Note $true } else { $required.告警 = $true }
      $nOpen = 0; $nBad = 0
      foreach ($a in $al.Rows) {
        $ack = $a.isAcknowledged
        $stTxt = switch ("$($a.state)") { '0' { 'Active_Manual' } '1' { 'Active_Auto' } '2' { 'Inactive（已解除）' } default { "不知道（$($a.state)）" } }
        $active = ("$($a.state)" -in '0', '1')
        if ("$($a.state)" -eq '2') { $lvl = '已解除'; $why = '設備已標示不再發生（Unisphere 預設不顯示）' }
        elseif (-not $active) { $lvl = '不知道'; $why = '狀態碼讀不懂' }
        elseif ($ack -isnot [bool]) { $lvl = '不知道'; $why = '已確認欄位格式不對' }
        elseif (-not (SevOk $a.severity)) { $lvl = '不知道'; $why = '嚴重度讀不懂' }
        else {
          $sevN = [int]$a.severity
          if (-not $ack -and $sevN -le 3) { $lvl = '異常'; $why = '未確認的 ERROR 以上' }
          elseif ($ack -and $sevN -le 3) { $lvl = '注意'; $why = '已確認，但不代表已恢復' }
          elseif (-not $ack -and $sevN -eq 4) { $lvl = '注意'; $why = '未確認的 WARNING' }
          else { $lvl = '資訊'; $why = '—' }
        }
        if ($active -and $ack -is [bool] -and -not $ack) { $nOpen++ }
        if ($lvl -eq '異常') { $nBad++ }
        if ($lvl -in '異常', '注意', '不知道') { $status = Worse $status $lvl }
        $R.Alerts.Add([pscustomobject]@{ 設備 = $tg.Host; 時間 = (Local (ParseUtc $a.timestamp)); 嚴重度 = (SevText $a.severity); 已確認 = $(if ($ack -is [bool]) { $(if ($ack) { '是' } else { '否' }) } else { '不知道' }); 狀態 = $stTxt; 判定 = $lvl; 原因 = $why; 訊息 = $a.message; 告警ID = $a.id })
      }
      $sum.未處理告警 = $nOpen; $sum.告警ERROR以上 = $nBad
    } catch { if (IsStop $_.Exception) { throw }; Gap '告警' $_.Exception.Message $true }

    Write-Host '  [3/9] 事件（Error Log）'
    # 2. 事件（Error Log，必要）：只看 ERROR 以上、最多 $MaxLookbackDays 天（使用者 11-17：LOG 太多，查 7 天內就好）。
    #    期間 [起點, 本次開始)；請設備端先篩選（filter），設備不支援才退回逐頁讀。只有完整讀到才前進下次起點。
    try {
      $evFrom = $null; $evBad = $null
      if ($manualSince) { $evFrom = $manualSince }
      elseif ($state.ContainsKey($key)) {
        $w = ParseUtc $state[$key]
        if ($w -and $w -le $runUtc) { $evFrom = $w.AddMinutes(-10) }
        else { $evBad = '上次事件起點不合理（未來時間或讀不懂），這次只看最近回溯時間，請人工確認期間是否有漏' }
      }
      $floor = $runUtc.AddDays(-$MaxLookbackDays)
      if (-not $evFrom) { $evFrom = $floor }
      elseif ($evFrom -lt $floor) { $dev.Notes.Add("上次檢查超過 $MaxLookbackDays 天，更早的事件不看"); $evFrom = $floor }
      $sum.事件期間 = (Local $evFrom) + ' ～ ' + (Local $runUtc)
      $script:stopAt = $evFrom
      $stop = { param($last) $t = ParseUtc $last.creationTime; return ($null -ne $t -and $t -lt $script:stopAt) }
      $flt = 'severity le 3 and creationTime ge "' + $evFrom.ToString('yyyy-MM-ddTHH:mm:ss.fffZ', [Globalization.CultureInfo]::InvariantCulture) + '"'
      try { $ev = Get-All $dev 'event' 'id,creationTime,severity,message,category' 250 40 ('&orderby=creationTime%20desc&filter=' + [Uri]::EscapeDataString($flt)) $stop }
      catch {
        if (IsStop $_.Exception) { throw }
        $dev.Notes.Add('設備不接受事件篩選（' + $_.Exception.Message + '），改逐頁讀，可能較慢')
        $ev = Get-All $dev 'event' 'id,creationTime,severity,message,category' 250 40 '&orderby=creationTime%20desc' $stop
      }
      $bad = 0; $parseFail = 0
      foreach ($e in $ev.Rows) {
        $t = ParseUtc $e.creationTime
        if (-not $t) { $parseFail++; continue }
        if ($t -lt $evFrom -or $t -ge $runUtc) { continue }
        if (-not (SevOk $e.severity)) { $lvl = '不知道'; $parseFail++ } elseif ([int]$e.severity -le 3) { $lvl = '待覆核'; $bad++ } elseif ([int]$e.severity -eq 4) { $lvl = '參考' } else { $lvl = '資訊' }
        $R.Events.Add([pscustomobject]@{ 設備 = $tg.Host; 時間 = (Local $t); 嚴重度 = (SevText $e.severity); 判定 = $lvl; 類別碼 = $e.category; 訊息 = $e.message; 事件ID = $e.id })
      }
      $sum.期間錯誤事件 = $bad
      if ($bad) { $status = Worse $status '注意' }
      if ($evBad) { Gap '事件' $evBad $true }
      elseif ($parseFail) { Gap '事件' "$parseFail 筆事件的時間或嚴重度讀不懂，期間統計可能不完整" $true }
      elseif (-not $ev.Complete) { Gap '事件' ($ev.Note + '；期間沒有完整讀到') $true }
      else {
        $required.事件 = $true
        if (-not $manualSince) { $newState[$key] = $runUtc.ToString('o') }   # 完整讀到才前進
      }
    } catch { if (IsStop $_.Exception) { throw }; Gap '事件（Error Log）' $_.Exception.Message $true }

    Write-Host '  [4/9] 寄信設定'
    # 3. 告警寄信設定（選用；只能證明有設定，不能證明信寄得到）
    try {
      $ac = Get-All $dev 'alertEmailConfig' 'id,emailAddress'
      $mails = @(@($ac.Rows) | ForEach-Object { $_.emailAddress } | Where-Object { $_ })
      $n = $mails.Count
      $sum.寄信設定 = if ($n) { "$n 個收件信箱" } else { '沒有收件信箱' }
      $R.Mail.Add([pscustomobject]@{ 設備 = $tg.Host; 收件信箱數 = $n; 判定 = $(if ($n) { '正常' } else { '注意' }); 說明 = '只代表設定存在；信件是否送達需查信箱' })
      if (-not $n) { $status = Worse $status '注意' }
    } catch { if (IsStop $_.Exception) { throw }; Gap '告警寄信設定' $_.Exception.Message $false }

    # 4. Pool（必要）
    Write-Host '  [5/9] Pool'
    $poolName = @{}
    try {
      $pl = Get-All $dev 'pool' 'id,name,health,sizeTotal,sizeUsed,sizeFree,sizeSubscribed'
      if (@($pl.Rows).Count -eq 0) { Gap 'Pool' '一個 Pool 都沒讀到（Unity 至少要有一個）' $true }
      elseif (-not $pl.Complete) { Gap 'Pool' $pl.Note $true }
      else { $required.Pool = $true }
      $pw = 0
      foreach ($p in $pl.Rows) {
        $poolName[[string]$p.id] = $p.name
        $u = Ratio $p.sizeUsed $p.sizeTotal
        $lvl = HltLevel $p.health
        if ($null -eq $u) { $lvl = Worse $lvl '不知道' } elseif ($u -ge $PoolBadPct / 100) { $lvl = Worse $lvl '異常' } elseif ($u -ge $PoolWarnPct / 100) { $lvl = Worse $lvl '注意' }
        if ($lvl -ne '正常') { $pw++ }
        $status = Worse $status $lvl
        $R.Pools.Add([pscustomobject]@{ 設備 = $tg.Host; Pool = $p.name; 健康 = (HltText $p.health); 總量GiB = (GiB $p.sizeTotal); 已用GiB = (GiB $p.sizeUsed); 剩餘GiB = (GiB $p.sizeFree); 使用率 = (PctShow $u); 超額配置率 = (PctShow (Ratio $p.sizeSubscribed $p.sizeTotal)); 判定 = $lvl; 總量bytes = $p.sizeTotal; 已用bytes = $p.sizeUsed; 剩餘bytes = $p.sizeFree })
      }
      $sum.Pool注意 = $pw
    } catch { if (IsStop $_.Exception) { throw }; Gap 'Pool' $_.Exception.Message $true }

    Write-Host '  [6/9] LUN 空間'
    # 5. LUN 空間（參考資訊：設備看到的配置量；VMware 資料存放區實際剩多少要看 vCenter／vCOps）
    try {
      $hostName = @{}
      try { $hl0 = Get-All $dev 'host' 'id,name'; if (-not $hl0.Complete) { Gap '主機名稱' $hl0.Note $false }; foreach ($h in $hl0.Rows) { $hostName[[string]$h.id] = $h.name } }
      catch { if (IsStop $_.Exception) { throw }; Gap '主機名稱' $_.Exception.Message $false }
      $lu = Get-All $dev 'lun' 'id,name,health,sizeTotal,sizeAllocated,isThinEnabled,pool,hostAccess'
      if (-not $lu.Complete) { Gap 'LUN' $lu.Note $false }
      $sum.LUN數 = @($lu.Rows).Count
      foreach ($x in $lu.Rows) {
        $hs = @(@($x.hostAccess) | Where-Object { $_ -and $_.host } | ForEach-Object { $hid = [string]$_.host.id; if ($hostName.ContainsKey($hid)) { $hostName[$hid] } else { $hid } }) -join '、'
        $lvl = HltLevel $x.health
        $status = Worse $status $lvl
        $pn = if ($x.pool -and $poolName.ContainsKey([string]$x.pool.id)) { $poolName[[string]$x.pool.id] } elseif ($x.pool) { $x.pool.id } else { '不知道' }
        $R.Luns.Add([pscustomobject]@{ 設備 = $tg.Host; LUN = $x.name; Pool = $pn; 健康 = (HltText $x.health); 判定 = $lvl; 大小GiB = (GiB $x.sizeTotal); 已配置GiB = (GiB $x.sizeAllocated); 配置率參考 = (PctShow (Ratio $x.sizeAllocated $x.sizeTotal)); 精簡配置 = $(if ($x.isThinEnabled -is [bool]) { $(if ($x.isThinEnabled) { '是' } else { '否' }) } else { '不知道' }); 配置給主機 = $(if ($hs) { $hs } else { '（沒有）' }); LUNID = $x.id; 大小bytes = $x.sizeTotal; 已配置bytes = $x.sizeAllocated })
      }
    } catch { if (IsStop $_.Exception) { throw }; Gap 'LUN' $_.Exception.Message $false }

    Write-Host '  [7/9] 檔案系統'
    # 6. 檔案系統（NAS；沒有 NAS 時 0 筆是正常）
    try {
      $fsl = Get-All $dev 'filesystem' 'id,name,health,sizeTotal,sizeUsed,pool'
      if (-not $fsl.Complete) { Gap '檔案系統' $fsl.Note $false }
      $fw = 0
      foreach ($f in $fsl.Rows) {
        $u = Ratio $f.sizeUsed $f.sizeTotal
        $lvl = HltLevel $f.health
        if ($null -eq $u) { $lvl = Worse $lvl '不知道' } elseif ($u -ge $FsBadPct / 100) { $lvl = Worse $lvl '異常' } elseif ($u -ge $FsWarnPct / 100) { $lvl = Worse $lvl '注意' }
        if ($lvl -ne '正常') { $fw++ }
        $status = Worse $status $lvl
        $pn = if ($f.pool -and $poolName.ContainsKey([string]$f.pool.id)) { $poolName[[string]$f.pool.id] } else { '不知道' }
        $R.Fs.Add([pscustomobject]@{ 設備 = $tg.Host; 檔案系統 = $f.name; Pool = $pn; 健康 = (HltText $f.health); 大小GiB = (GiB $f.sizeTotal); 已用GiB = (GiB $f.sizeUsed); 使用率 = (PctShow $u); 判定 = $lvl; 大小bytes = $f.sizeTotal; 已用bytes = $f.sizeUsed })
      }
      $sum.檔案系統注意 = $fw
    } catch { if (IsStop $_.Exception) { throw }; Gap '檔案系統' $_.Exception.Message $false }

    Write-Host '  [8/9] 硬體元件'
    # 7. 硬體元件（選用；只列不是 OK 的）。讀不到的類型列在收集缺口；系統健康仍會反映整體硬體狀況
    $hwBad = 0; $hwRead = 0
    foreach ($ty in 'storageProcessor', 'disk', 'battery', 'powerSupply', 'fan', 'dae', 'dpe', 'lcc', 'memoryModule', 'ssd', 'sfp', 'ioModule') {
      try {
        $hw0 = Get-All $dev $ty 'id,name,health'
        if (-not $hw0.Complete) { Gap ("硬體：" + $ty) $hw0.Note $false }
        foreach ($it in $hw0.Rows) {
          $hl = HltLevel $it.health
          if ($hl -ne '正常') { $hwBad++; $R.Hw.Add([pscustomobject]@{ 設備 = $tg.Host; 類型 = $ty; 名稱 = $(if ($it.name) { $it.name } else { $it.id }); 健康 = (HltText $it.health); 判定 = $hl }); $status = Worse $status $hl }
        }
        $hwRead++
      } catch { if (IsStop $_.Exception) { throw }; Gap ("硬體：" + $ty) $_.Exception.Message $false }
    }
    $hwTotal = 12
    $sum.硬體異常 = if (-not $hwRead) { $null } elseif ($hwRead -lt $hwTotal) { "$hwBad（$($hwTotal - $hwRead)/$hwTotal 類沒讀到）" } else { $hwBad }

    Write-Host '  [9/9] 複寫'
    # 8. 複寫（選用；沒設定時 0 筆是正常）
    try {
      $rs = Get-All $dev 'replicationSession' 'id,name,health,syncState,lastSyncTime'
      if (-not $rs.Complete) { Gap '複寫' $rs.Note $false }
      $rb = 0
      foreach ($rw in $rs.Rows) {
        $hl = HltLevel $rw.health
        if ($hl -ne '正常') { $rb++ }
        $status = Worse $status $hl
        $R.Rep.Add([pscustomobject]@{ 設備 = $tg.Host; 複寫 = $rw.name; 健康 = (HltText $rw.health); 同步狀態碼 = $rw.syncState; 最後同步 = (Local (ParseUtc $rw.lastSyncTime)); 判定 = $hl })
      }
      $sum.複寫異常 = $rb
    } catch { if (IsStop $_.Exception) { throw }; Gap '複寫' $_.Exception.Message $false }
  } catch {
    if ($_.Exception -is [AuthFail]) { $abort = $tg.Host + '：' + $_.Exception.Message }
    $stopped = $_.Exception.Message
    $dev.Notes.Insert(0, $_.Exception.Message)
    if (-not $required.系統) { Gap '連線／系統' $_.Exception.Message $true }
  }
  $missing = @($required.Keys | Where-Object { -not $required[$_] })
  $sum.設備狀態 = if ($required.系統) { $status } else { '不知道' }
  $optGaps = @($R.Gaps | Where-Object { $_.設備 -eq $tg.Host -and $_.必要 -eq '否' }).Count
  $sum.完整度 = if (-not $required.系統) { '查不到' } elseif ($stopped -and -not $missing.Count) { '不完整（中途停止：' + $stopped + '）' } elseif ($missing.Count) { '不完整（缺 ' + ($missing -join '、') + '）' } elseif ($optGaps) { "完整（另有 $optGaps 個選用項目讀不到）" } else { '完整' }
  $full = ($sum.完整度 -like '完整*')
  $sum.處置 = if ($sum.設備狀態 -eq '異常') { $(if ($full) { '須回報' } else { '須回報＋須補查' }) } elseif (-not $full -or $sum.設備狀態 -eq '不知道') { '須補查' } elseif ($sum.期間錯誤事件 -gt 0) { '須覆核' } elseif ($sum.設備狀態 -eq '注意' -or $optGaps) { '可結案（有注意事項）' } else { '可結案' }
  $sum.說明 = ($dev.Notes -join '；')
  $sum.項目 = Label $tg $sum.型號
  $sum.耗時秒 = [math]::Round(((Get-Date) - $dev.Start).TotalSeconds, 1)
  $sum.呼叫數 = $dev.Requests
  $R.Summary.Add([pscustomobject]$sum)
  Write-Host ("設備狀態：" + $sum.設備狀態 + "｜完整度：" + $sum.完整度 + "｜處置：" + $sum.處置 + "（HTTP 請求 " + $dev.Requests + " 次）")
  $dev.Basic = $null; $tg.Sec = $null
}
if ($abort) { Write-Host ""; Write-Host ("整批停止：" + $abort) }

# ================================================================ 輸出（先寫 .partial，完成才改名）
$outRoot = Join-Path $here 'unity_out'
$tmpDir = Join-Path $outRoot ($runId + '.partial')
$finDir = Join-Path $outRoot $runId
New-Item -ItemType Directory -Path $tmpDir | Out-Null

$COLS = @{
  Summary = @('項次','項目','設備','地點','名稱','型號','序號','版本','帳號角色','系統健康','未處理告警','告警ERROR以上','期間錯誤事件','事件期間','Pool注意','LUN數','檔案系統注意','硬體異常','複寫異常','寄信設定','設備狀態','完整度','處置','說明','耗時秒','呼叫數')
  Alerts = @('設備','時間','嚴重度','狀態','已確認','判定','原因','訊息','告警ID'); Events = @('設備','時間','嚴重度','判定','類別碼','訊息','事件ID')
  Pools = @('設備','Pool','健康','總量GiB','已用GiB','剩餘GiB','使用率','超額配置率','判定','總量bytes','已用bytes','剩餘bytes')
  Luns = @('設備','LUN','Pool','健康','判定','大小GiB','已配置GiB','配置率參考','精簡配置','配置給主機','LUNID','大小bytes','已配置bytes')
  Fs = @('設備','檔案系統','Pool','健康','大小GiB','已用GiB','使用率','判定','大小bytes','已用bytes'); Hw = @('設備','類型','名稱','健康','判定')
  Rep = @('設備','複寫','健康','同步狀態碼','最後同步','判定'); Mail = @('設備','收件信箱數','判定','說明'); Gaps = @('設備','項目','必要','原因')
}
function Save-Csv([string]$k, [string]$name) {
  $path = Join-Path $tmpDir $name
  $cols = $COLS[$k]
  $sb = New-Object Text.StringBuilder
  [void]$sb.AppendLine((($cols | ForEach-Object { '"' + ($_ -replace '"', '""') + '"' }) -join ','))
  foreach ($r0 in $R[$k]) {
    $vals = foreach ($c in $cols) { $v = CsvSafe $r0.$c; '"' + ([string]$v -replace '"', '""') + '"' }
    [void]$sb.AppendLine(($vals -join ','))
  }
  [IO.File]::WriteAllText($path, $sb.ToString(), (New-Object Text.UTF8Encoding($true)))
}
Save-Csv 'Summary' '01_總表.csv'; Save-Csv 'Alerts' '02_告警.csv'; Save-Csv 'Events' '03_事件.csv'; Save-Csv 'Pools' '04_Pool.csv'; Save-Csv 'Luns' '05_LUN空間.csv'
Save-Csv 'Fs' '06_檔案系統.csv'; Save-Csv 'Hw' '07_硬體異常.csv'; Save-Csv 'Rep' '08_複寫.csv'; Save-Csv 'Mail' '09_寄信設定.csv'; Save-Csv 'Gaps' '10_收集缺口.csv'

$report = @($R.Summary | Where-Object { $_.處置 -like '須回報*' })
$recheck = @($R.Summary | Where-Object { $_.處置 -like '*須補查' })
$review = @($R.Summary | Where-Object { $_.處置 -eq '須覆核' })
$overall = if ($report.Count) { '須回報' } elseif ($recheck.Count -or $abort) { '須補查' } elseif ($review.Count) { '須覆核' } elseif (@($R.Summary | Where-Object { $_.處置 -ne '可結案' }).Count) { '可結案（有注意事項）' } else { '可結案' }
$hdrColor = switch ($overall) { '須回報' { '#B3261E' } '須補查' { '#6B5E00' } default { '#0C6B37' } }
$who = "$env:USERDOMAIN\$env:USERNAME"

function StatCls([string]$v) { switch -Wildcard ($v) { '⚠影響營運*' { 'bad' } '已恢復' { '' } '處理一次' { 'warn' } '立即處理' { 'bad' } '本週追蹤' { 'warn' } '異常' { 'bad' } '須回報*' { 'bad' } '須覆核' { 'warn' } '注意' { 'warn' } '待覆核' { 'warn' } '不知道' { 'unk' } '查不到' { 'unk' } '沒檢查' { 'unk' } '須補查' { 'unk' } '是' { 'unk' } default { '' } } }
function Cell([object]$v) {
  if ($null -eq $v -or "$v" -eq '') { return '<td><span class=u>不知道</span></td>' }
  if ($v -is [int] -or $v -is [double] -or $v -is [long] -or $v -is [decimal]) { return "<td class=n data-v='" + (Esc $v) + "'>" + (Esc $v) + '</td>' }
  return '<td>' + (Esc $v) + '</td>'
}
function Table([string]$k, [string]$prefix, [string[]]$cols, [string]$stCol = '判定') {
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<table class='t'><thead><tr><th>項次</th>")
  foreach ($c in $cols) { [void]$sb.Append('<th>' + (Esc $c) + '</th>') }
  [void]$sb.Append('</tr></thead><tbody>')
  $n = 0
  foreach ($r0 in $R[$k]) {
    $n++
    [void]$sb.Append("<tr class='" + (StatCls ([string]$r0.$stCol)) + "' data-dev='" + (Esc $r0.設備) + "' data-st='" + (Esc $r0.$stCol) + "'><td data-v='$n'>$prefix$n</td>")
    foreach ($c in $cols) { [void]$sb.Append((Cell $r0.$c)) }
    [void]$sb.Append('</tr>')
  }
  if ($n -eq 0) { [void]$sb.Append("<tr class='empty'><td colspan='" + ($cols.Count + 1) + "'>沒有資料（如果這一項讀取失敗，會列在「收集缺口」）</td></tr>") }
  [void]$sb.Append('</tbody></table>')
  return $sb.ToString()
}
function Jump([string]$tab, [string]$dev, [object]$val) {
  if ($null -eq $val -or "$val" -eq '') { return '<td><span class=u>不知道</span></td>' }
  return "<td class=n data-v='" + (Esc $val) + "'><a href='#' class='jump' data-tab='$tab' data-dev='" + (Esc $dev) + "'>" + (Esc $val) + '</a></td>'
}
$sumRows = New-Object Text.StringBuilder
$k2 = 0
foreach ($s in $R.Summary) {
  $k2++
  [void]$sumRows.Append("<tr class='" + (StatCls $s.處置) + "' data-st='" + (Esc $s.處置) + "' data-dev='" + (Esc $s.設備) + "'><td data-v='$k2'>S$k2</td>" + (Cell $s.項目) + (Cell $s.名稱) + (Cell $s.處置) + (Cell $s.設備狀態) + (Cell $s.完整度) + (Cell $s.系統健康))
  [void]$sumRows.Append((Jump 'tA' $s.設備 $s.未處理告警) + (Jump 'tA' $s.設備 $s.告警ERROR以上) + (Jump 'tE' $s.設備 $s.期間錯誤事件) + (Jump 'tP' $s.設備 $s.Pool注意) + (Jump 'tL' $s.設備 $s.LUN數) + (Jump 'tF' $s.設備 $s.檔案系統注意) + (Jump 'tH' $s.設備 $s.硬體異常) + (Jump 'tH' $s.設備 $s.複寫異常))
  [void]$sumRows.Append((Cell $s.寄信設定) + (Cell $s.帳號角色) + "<td class=s>" + (Esc $s.說明) + '</td></tr>')
}
# ---------------- 重點整理（同類合併、算次數、分三級）＋檢查表文字 ----------------
function Norm([string]$m) { return (([string]$m) -replace '\d+', '#' -replace '\s+', ' ').Trim() }
function Size([object]$gib) { if ($null -eq $gib) { return '不知道' }; if ([double]$gib -ge 1024) { return ('{0:N1} TiB' -f ([double]$gib / 1024)) }; return ('{0:N1} GiB' -f [double]$gib) }
$TIER = @{ '立即處理' = 0; '本週追蹤' = 1; '處理一次' = 2; '已恢復' = 3; '可忽略' = 4 }
$OBJT = @{ fs = '檔案系統'; pool = 'Pool'; rep = '複寫'; rephost = '複寫對端'; res = '儲存資源'; lun = 'LUN'; hw = '硬體'; udoctor = '軟體更新通知'; system = '系統'; gap = '收集缺口'; msg = '其他' }
$IMPACT_ANY = @('hw', 'rep', 'rephost')   # 這幾類只要還沒處理（立即處理或本週追蹤）都標影響營運
$IMPACT = @{ fs = '空間滿了寫不進去，用它的服務會中斷'; pool = '空間滿了寫不進去，用它的服務會中斷'; res = '空間滿了寫不進去，用它的服務會中斷'; lun = '掛它的主機可能讀寫失敗'
            hw = '硬體零件（硬碟／電源／GBIC／風扇等）異常，備援減少，再壞一個可能停機'; rep = '複寫同步失敗，異地備援失效'; rephost = '複寫同步失敗，異地備援失效'; system = '影響範圍不明，先當影響營運處理' }
$ADVICE = @{ fs = '擴充檔案系統容量或清理資料'; pool = '擴充 Pool 或搬移資料'; rep = '檢查複寫連線與對端設備'; rephost = '檢查複寫連線與對端設備'; res = '檢查儲存資源用量'; lun = '檢查 LUN 狀態'; hw = '報修更換'
            udoctor = '在 Unisphere 告警頁按 Acknowledge，或排程安裝更新'; system = '登入 Unisphere System View 查看原因'; gap = '人工登入 Unisphere 確認'; msg = '登入 Unisphere 確認' }
function ObjOf([string]$m) {
  # 從設備訊息抓出講的是哪個物件（同一物件的告警、事件、狀態合併成一件）
  $pats = @(@('fs', '(?i)file system (\S+)'), @('pool', '(?i)storage pool (\S+)'), @('rep', '(?i)replication session (\S+)'),
            @('rephost', '(?i)replication host (\S+)'), @('res', '(?i)storage resource (\S+)'), @('lun', '(?i)\bLUN (\S+)'))
  foreach ($p in $pats) { if ($m -match $p[1]) { return @($p[0], ($Matches[1] -replace '[\.,;:]+$', '')) } }
  # 硬體零件（硬碟、電源、GBIC/SFP、風扇、電池、SP、I/O 模組）：出問題不處理會拖垮系統
  $hwp = @('(?i)\b(power supply|PSU)\b[^,.;]{0,25}', '(?i)\b(SFP|GBIC)\b[^,.;]{0,25}', '(?i)\b(disk|drive)\b[^,.;]{0,25}', '(?i)\bfan\b[^,.;]{0,25}',
           '(?i)\bbattery\b[^,.;]{0,25}', '(?i)\b(storage processor|SP [AB])\b[^,.;]{0,15}', '(?i)\bI/O module\b[^,.;]{0,25}')
  foreach ($h in $hwp) { if ($m -match $h) { return @('hw', $Matches[0].Trim()) } }
  if ($m -match '(?i)UDoctor') { return @('udoctor', 'UDoctor') }
  if ($m -match '(?i)^System \S+ (has experienced|is operating)') { return @('system', '系統') }
  return $null
}
foreach ($s in $R.Summary) {
  $dv = $s.設備
  $fsT = @{}; foreach ($x in @($R.Fs | Where-Object { $_.設備 -eq $dv })) { $fsT[([string]$x.檔案系統).ToLower()] = $x }
  $plT = @{}; foreach ($x in @($R.Pools | Where-Object { $_.設備 -eq $dv })) { $plT[([string]$x.Pool).ToLower()] = $x }
  $luT = @{}; foreach ($x in @($R.Luns | Where-Object { $_.設備 -eq $dv })) { $luT[([string]$x.LUN).ToLower()] = $x }
  $rpT = @{}; foreach ($x in @($R.Rep | Where-Object { $_.設備 -eq $dv })) { $rpT[([string]$x.複寫).ToLower()] = $x }
  $repAllOk = ($rpT.Count -gt 0 -and -not @($rpT.Values | Where-Object { $_.判定 -ne '正常' }).Count)
  function NowOf([string]$t, [string]$n) {
    $k = $n.ToLower()
    if ($t -in 'fs', 'res' -and $fsT.ContainsKey($k)) { $x = $fsT[$k]; return @{ Known = $true; Lv = $x.判定; Desc = "$($x.檔案系統) 已用 $($x.已用GiB)/$($x.大小GiB) GiB（$($x.使用率)%），健康 $((([string]$x.健康) -split '（')[0])" } }
    if ($t -in 'pool' -and $plT.ContainsKey($k)) { $x = $plT[$k]; return @{ Known = $true; Lv = $x.判定; Desc = "Pool $($x.Pool) 已用 $($x.使用率)%，剩 $(Size $x.剩餘GiB)" } }
    if ($t -in 'lun', 'res' -and $luT.ContainsKey($k)) { $x = $luT[$k]; return @{ Known = $true; Lv = $x.判定; Desc = "LUN $($x.LUN) 健康 $((([string]$x.健康) -split '（')[0])" } }
    if ($t -eq 'rep' -and $rpT.ContainsKey($k)) { $x = $rpT[$k]; return @{ Known = $true; Lv = $x.判定; Desc = "複寫 $($x.複寫) 健康 $((([string]$x.健康) -split '（')[0])，最後同步 $($x.最後同步)" } }
    if ($t -eq 'rephost' -and $rpT.Count) { return @{ Known = $true; Lv = $(if ($repAllOk) { '正常' } else { '異常' }); Desc = "複寫 $($rpT.Count) 條目前$(if ($repAllOk) { '全部正常' } else { '有異常' })" } }
    return @{ Known = $false; Lv = $null; Desc = '' }
  }
  $iss = [ordered]@{}
  function Touch([string]$key, [string]$t, [string]$n) {
    if (-not $iss.Contains($key)) { $iss[$key] = [pscustomobject]@{ T = $t; N = $n; Msg = ''; Al = 0; AlAct = 0; AlErr = 0; Ev = 0; First = ''; Last = ''; Fixed = $null } }
    return $iss[$key]
  }
  function Stamp($o, [string]$tm) { if ($tm) { if (-not $o.First -or $tm -lt $o.First) { $o.First = $tm }; if (-not $o.Last -or $tm -gt $o.Last) { $o.Last = $tm } } }
  # 1) 目前狀態不正常的物件
  foreach ($x in $fsT.Values) { if ($x.判定 -ne '正常') { [void](Touch ('fs|' + ([string]$x.檔案系統).ToLower()) 'fs' $x.檔案系統) } }
  foreach ($x in $plT.Values) { if ($x.判定 -ne '正常') { [void](Touch ('pool|' + ([string]$x.Pool).ToLower()) 'pool' $x.Pool) } }
  foreach ($x in $luT.Values) { if ($x.判定 -ne '正常') { [void](Touch ('lun|' + ([string]$x.LUN).ToLower()) 'lun' $x.LUN) } }
  foreach ($x in $rpT.Values) { if ($x.判定 -ne '正常') { [void](Touch ('rep|' + ([string]$x.複寫).ToLower()) 'rep' $x.複寫) } }
  foreach ($x in @($R.Hw | Where-Object { $_.設備 -eq $dv })) { $o = Touch ('hw|' + $x.類型 + '|' + $x.名稱) 'hw' "$($x.類型) $($x.名稱)"; $o.Fixed = @('立即處理', "$($x.類型) $($x.名稱) 健康 $($x.健康)") }
  foreach ($x in @($R.Gaps | Where-Object { $_.設備 -eq $dv -and $_.必要 -eq '是' })) { $o = Touch ('gap|' + $x.項目) 'gap' $x.項目; $o.Fixed = @('立即處理', "$($x.項目) 沒讀到：$($x.原因)") }
  # 2) 告警、事件掛到物件上
  foreach ($a in @($R.Alerts | Where-Object { $_.設備 -eq $dv })) {
    $ob = ObjOf ([string]$a.訊息)
    $o = if ($ob) { Touch ($ob[0] + '|' + $ob[1].ToLower()) $ob[0] $ob[1] } else { Touch ('msg|' + (Norm $a.訊息)) 'msg' (Norm $a.訊息) }
    if (-not $o.Msg) { $o.Msg = $a.訊息 }
    $o.Al++; if ($a.判定 -in '異常', '注意', '不知道') { $o.AlAct++; $o.Msg = $a.訊息 }; if ($a.判定 -eq '異常') { $o.AlErr++ }
    Stamp $o $a.時間
  }
  foreach ($e in @($R.Events | Where-Object { $_.設備 -eq $dv })) {
    $ob = ObjOf ([string]$e.訊息)
    $o = if ($ob) { Touch ($ob[0] + '|' + $ob[1].ToLower()) $ob[0] $ob[1] } else { Touch ('msg|' + (Norm $e.訊息)) 'msg' (Norm $e.訊息) }
    if (-not $o.Msg) { $o.Msg = $e.訊息 }
    $o.Ev++; Stamp $o $e.時間
  }
  # 3) 自動判讀每一件
  $rows = New-Object System.Collections.Generic.List[object]
  foreach ($key in @($iss.Keys)) {
    $o = $iss[$key]
    if ($o.T -eq 'system') { continue }   # 系統層級最後處理
    $now = NowOf $o.T $o.N
    if ($o.Fixed) { $lvl = $o.Fixed[0]; $desc = $o.Fixed[1] }
    elseif ($o.T -eq 'udoctor') { $lvl = $(if ($o.AlAct) { '處理一次' } else { '可忽略' }); $desc = '軟體更新通知（不是故障）' }
    elseif ($now.Known) {
      $desc = $now.Desc
      $lvl = switch ($now.Lv) { '異常' { '立即處理' } '注意' { '本週追蹤' } '不知道' { '本週追蹤' } default { $(if ($o.AlAct) { '本週追蹤' } else { '已恢復' }) } }
      if ($now.Lv -eq '正常' -and $o.AlAct) { $desc += '；目前已正常，但告警仍是 Active，請在 Unisphere 確認' }
      if ($lvl -eq '已恢復') { $desc += '（工具已自動確認目前正常）' }
    } else {
      $desc = $o.Msg
      $lvl = if ($o.AlErr) { '立即處理' } elseif ($o.AlAct) { '本週追蹤' } elseif ($o.Ev) { '本週追蹤' } else { '可忽略' }
      if ($lvl -eq '本週追蹤' -and -not $o.AlAct) { $desc += '（設備沒有對應的現況可比對，請確認）' }
      if ($lvl -eq '可忽略') { $desc += '（告警已解除）' }
    }
    $basis = @(); if ($o.Al) { $basis += "告警 $($o.Al) 筆（還在發生 $($o.AlAct)）" }; if ($o.Ev) { $basis += "Error Log $($o.Ev) 筆" }; if ($now.Known) { $basis += '目前狀態' }; if ($o.Fixed) { $basis += '目前狀態' }
    $imp = if ($IMPACT.ContainsKey($o.T) -and ($lvl -eq '立即處理' -or ($lvl -eq '本週追蹤' -and $o.T -in $IMPACT_ANY))) { '⚠影響營運：' + $IMPACT[$o.T] } else { '' }
    $rows.Add([pscustomobject]@{ 等級 = $lvl; 影響營運 = $imp; 設備 = $dv; 物件 = "$($OBJT[$o.T]) $(if ($o.T -notin 'msg', 'udoctor') { $o.N })".Trim(); 現況 = $desc; 依據 = ($basis -join '、'); 第一次 = $o.First; 最後一次 = $o.Last; 建議 = $(if ($lvl -in '已恢復', '可忽略') { '不用處理' } else { $ADVICE[$o.T] }) })
  }
  # 系統健康：有具體原因就併進去，沒有才單列
  $hsCode = ([string]$s.系統健康 -split '（')[0]
  $causes = @($rows | Where-Object { $_.等級 -in '立即處理', '本週追蹤' -and $_.物件 -notlike '收集缺口*' })
  if ($s.設備狀態 -ne '不知道' -and $hsCode -and $hsCode -ne 'OK') {
    if ($causes.Count) { $sysNote = "系統 $hsCode，原因：" + (($causes | Select-Object -First 3 | ForEach-Object { $_.物件 }) -join '、') }
    else { $rows.Add([pscustomobject]@{ 等級 = $(if ($hsCode -eq 'OK_BUT') { '本週追蹤' } else { '立即處理' }); 影響營運 = $(if ($hsCode -eq 'OK_BUT') { '' } else { '⚠影響營運：' + $IMPACT['system'] }); 設備 = $dv; 物件 = '系統'; 現況 = "系統健康 $hsCode，工具找不到具體原因"; 依據 = '系統健康'; 第一次 = ''; 最後一次 = ''; 建議 = $ADVICE['system'] }); $sysNote = '' }
  } else { $sysNote = '' }
  if ($iss.Contains('system|系統')) {
    $o = $iss['system|系統']
    $rows.Add([pscustomobject]@{ 等級 = $(if ($hsCode -eq 'OK') { '已恢復' } else { '可忽略' }); 影響營運 = ''; 設備 = $dv; 物件 = '系統'; 現況 = $(if ($hsCode -eq 'OK') { '系統目前 OK（工具已自動確認）' } else { "系統降級訊息，已併入上列原因" }); 依據 = "告警 $($o.Al) 筆、Error Log $($o.Ev) 筆"; 第一次 = $o.First; 最後一次 = $o.Last; 建議 = '不用另外處理' })
  }
  foreach ($it in ($rows | Sort-Object @{ Expression = { $TIER[$_.等級] } }, @{ Expression = { -not $_.影響營運 } }, 物件)) { $R.Focus.Add($it) }
  # 一句話結論
  $now1 = @($rows | Where-Object { $_.等級 -eq '立即處理' }); $wk = @($rows | Where-Object { $_.等級 -eq '本週追蹤' })
  $once = @($rows | Where-Object { $_.等級 -eq '處理一次' }); $rec = @($rows | Where-Object { $_.等級 -eq '已恢復' })
  $parts = @()
  $impN = @($now1 | Where-Object { $_.影響營運 })
  if ($now1.Count) { $parts += $(if ($impN.Count) { "【⚠影響營運 $($impN.Count) 件】" } else { '' }) + "$($now1.Count) 件要處理：" + (($now1 | Sort-Object { -not $_.影響營運 } | ForEach-Object { $(if ($_.影響營運) { '⚠' } else { '' }) + $_.現況 + '→' + $_.建議 }) -join '；') }
  if ($sysNote) { $parts += $sysNote }
  if ($wk.Count) { $parts += "$($wk.Count) 件本週追蹤：" + (($wk | Select-Object -First 3 | ForEach-Object { $_.物件 }) -join '、') + $(if ($wk.Count -gt 3) { ' 等' } else { '' }) }
  if ($once.Count) { $parts += "處理一次：" + (($once | ForEach-Object { $_.物件 + '（' + $_.建議 + '）' }) -join '、') }
  if ($rec.Count) { $parts += "$($rec.Count) 件已自動確認恢復：" + (($rec | Select-Object -First 3 | ForEach-Object { $_.物件 }) -join '、') + $(if ($rec.Count -gt 3) { ' 等' } else { '' }) }
  $concl = if ($parts.Count) { '結論：' + ($parts -join '。') + '。' } else { '結論：沒有要處理的事項。' }
  $s | Add-Member -NotePropertyName 結論 -NotePropertyValue $concl -Force
  $s | Add-Member -NotePropertyName 影響營運 -NotePropertyValue $impN.Count -Force

  # 檢查表文字：照紙本檢查重點逐項寫（System Health／Pool／當日告警／Error Log／Mail）
  if ($s.完整度 -eq '查不到' -or $s.完整度 -eq '沒檢查') {
    $txt = "無法檢查：" + $s.說明 + "，請人工登入確認"
  } else {
    $hs = ([string]$s.系統健康 -split '（')[0]
    $worst = @($R.Fs | Where-Object { $_.設備 -eq $dv -and $_.判定 -ne '正常' } | Sort-Object { [double]$_.使用率 } -Descending | Select-Object -First 2 | ForEach-Object { "$($_.檔案系統) $($_.已用GiB)/$($_.大小GiB) GiB $($_.使用率)%" })
    $p1 = "System Health：$hs" + $(if ($worst.Count -and $hs -ne 'OK') { "（" + ($worst -join '、') + "）" } else { '' })
    $pools = @($R.Pools | Where-Object { $_.設備 -eq $dv } | ForEach-Object { "$($_.Pool) 剩 $(Size $_.剩餘GiB)（已用 $($_.使用率)%）" })
    $p2 = "Pool：" + $(if ($pools.Count) { $pools -join '、' } else { '不知道' })
    $gapItems = @($R.Gaps | Where-Object { $_.設備 -eq $dv -and $_.必要 -eq '是' } | ForEach-Object { $_.項目 })
    $alGap = @($gapItems | Where-Object { $_ -like '告警*' }).Count
    $evGap = @($gapItems | Where-Object { $_ -like '事件*' }).Count
    $act = @($R.Alerts | Where-Object { $_.設備 -eq $dv -and $_.狀態 -like 'Active*' })
    $unkSt = @($R.Alerts | Where-Object { $_.設備 -eq $dv -and $_.狀態 -like '不知道*' }).Count
    $actErr = @($act | Where-Object { $_.判定 -eq '異常' }).Count
    $p3 = "告警：" + $(if ($null -eq $s.未處理告警) { '不知道' } elseif ($alGap) { "未完整讀取（已讀到進行中至少 $($act.Count) 筆）" } elseif ($act.Count) { "進行中 $($act.Count) 筆（未確認 ERROR $actErr）" } else { '無進行中告警' }) + $(if ($unkSt) { "、狀態不明 $unkSt 筆" } else { '' })
    $p4 = "Error Log（" + $(if ($s.事件期間) { ($s.事件期間 -split ' ～ ')[0].Substring(5, 11) + ' 起' } else { '' }) + "）：" + $(if ($null -eq $s.期間錯誤事件) { '不知道' } elseif ($evGap) { "未完整讀取（已讀到 ERROR 至少 $($s.期間錯誤事件) 筆）" } elseif ($s.期間錯誤事件) { "ERROR $($s.期間錯誤事件) 筆" } else { '無 ERROR' })
    $p5 = "Mail：" + $(if ($s.寄信設定 -eq '不知道') { '設定讀不到' } else { $s.寄信設定 }) + "（送達需查信箱）"
    $pre = if ($s.處置 -eq '可結案') { '正常。' } elseif ($s.完整度 -notlike '完整*') { '【未完整讀取，須補查：' + $s.完整度 + '】' } else { '' }
    $txt = $pre + $s.結論 + '｜' + (@($p1, $p2, $p3, $p4, $p5) -join '｜')
  }
  $txt += "｜UnityDaily " + $runStart.ToString('MM-dd HH:mm')
  $R.Sheet.Add([pscustomobject]@{ 項目 = $s.項目; 設備 = $dv; 名稱 = $s.名稱; 處置 = $s.處置; 檢查表文字 = $txt })
}
$COLS['Focus'] = @('等級','影響營運','設備','物件','現況','依據','第一次','最後一次','建議')
$COLS['Sheet'] = @('項目','設備','名稱','處置','檢查表文字')
Save-Csv 'Focus' '00_重點整理.csv'; Save-Csv 'Sheet' '00_檢查表文字.csv'
$sheetRows = New-Object Text.StringBuilder
$k4 = 0
foreach ($x in $R.Sheet) {
  $k4++
  [void]$sheetRows.Append("<tr class='" + (StatCls $x.處置) + "'><td data-v='$k4'>T$k4</td>" + (Cell $x.項目) + (Cell $x.名稱) + "<td class='cp'>" + (Esc $x.檢查表文字) + "</td><td><button class='copy'>複製</button></td></tr>")
}
$focusCnt = @{}; foreach ($t in '立即處理', '本週追蹤', '處理一次', '已恢復', '可忽略') { $focusCnt[$t] = @($R.Focus | Where-Object { $_.等級 -eq $t }).Count }

$cnt = @{ '須回報' = $report.Count; '須補查' = @($R.Summary | Where-Object { $_.處置 -eq '須補查' }).Count; '須覆核' = $review.Count
         '可結案（有注意事項）' = @($R.Summary | Where-Object { $_.處置 -eq '可結案（有注意事項）' }).Count; '可結案' = @($R.Summary | Where-Object { $_.處置 -eq '可結案' }).Count }
# 回報草稿（值班人員可直接複製進信件）
$draft = New-Object Text.StringBuilder
[void]$draft.AppendLine("主旨：［儲存設備每日檢查］" + $runStart.ToString('yyyy-MM-dd') + "　" + $overall)
[void]$draft.AppendLine("檢查時間：" + $runStart.ToString('yyyy-MM-dd HH:mm') + "　檢查人：" + $who + "　工具：" + $ToolVersion)
[void]$draft.AppendLine("設備共 " + $R.Summary.Count + " 台：須回報 " + $cnt['須回報'] + "、須補查 " + $recheck.Count + "、須覆核 " + $cnt['須覆核'] + "、可結案 " + ($cnt['可結案'] + $cnt['可結案（有注意事項）']))
$i3 = 0
foreach ($s in $report) {
  $i3++
  $hs = [string]$s.系統健康; if ($hs.Length -gt 60) { $hs = $hs.Substring(0, 60) + '…' }
  [void]$draft.AppendLine("$i3. " + $s.項目 + "（" + $s.名稱 + "）" + $s.結論)
  [void]$draft.AppendLine("   系統健康：" + $hs + "；還在發生的未確認 ERROR 以上告警 " + $s.告警ERROR以上 + " 筆；明細：")
  foreach ($a in @($R.Alerts | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '異常' } | Select-Object -First 5)) { [void]$draft.AppendLine("   - 告警 " + $a.時間 + " " + $a.嚴重度 + " " + $a.訊息) }
  foreach ($x in @($R.Pools | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '異常' })) { [void]$draft.AppendLine("   - Pool " + $x.Pool + " 使用率 " + $x.使用率 + "%（剩 " + $x.剩餘GiB + " GiB）健康 " + $x.健康) }
  foreach ($x in @($R.Fs | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '異常' })) { [void]$draft.AppendLine("   - 檔案系統 " + $x.檔案系統 + " 使用率 " + $x.使用率 + "% 健康 " + $x.健康) }
  foreach ($x in @($R.Luns | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '異常' })) { [void]$draft.AppendLine("   - LUN " + $x.LUN + " 健康 " + $x.健康) }
  foreach ($x in @($R.Hw | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '異常' })) { [void]$draft.AppendLine("   - 硬體 " + $x.類型 + " " + $x.名稱 + " " + $x.健康) }
  foreach ($x in @($R.Rep | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '異常' })) { [void]$draft.AppendLine("   - 複寫 " + $x.複寫 + " " + $x.健康) }
  foreach ($x in @($R.Events | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '待覆核' } | Select-Object -First 5)) { [void]$draft.AppendLine("   - 期間錯誤事件（待覆核）" + $x.時間 + " " + $x.訊息) }
  if ($s.處置 -like '*須補查') { [void]$draft.AppendLine("   - 另外資料沒查完整（" + $s.完整度 + "），請人工登入確認") }
}
foreach ($s in @($recheck | Where-Object { $_.處置 -eq '須補查' })) { $i3++; [void]$draft.AppendLine("$i3. " + $s.項目 + " 無法完成檢查（" + $s.完整度 + "）：" + $s.說明 + " → 請人工登入確認") }
foreach ($s in $review) {
  $i3++; [void]$draft.AppendLine("$i3. " + $s.項目 + "（" + $s.名稱 + "）期間有 " + $s.期間錯誤事件 + " 筆錯誤事件（Error Log），待人工覆核是否已恢復：")
  foreach ($x in @($R.Events | Where-Object { $_.設備 -eq $s.設備 -and $_.判定 -eq '待覆核' } | Select-Object -First 5)) { [void]$draft.AppendLine("   - " + $x.時間 + " " + $x.嚴重度 + " " + $x.訊息) }
}
[void]$draft.AppendLine("Mail 異常通知：本工具只確認寄信設定，實際信件請查收件信箱。")

$html = @"
<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Unity 每日檢查 $runId</title>
<style>
body{font-family:"Microsoft JhengHei",sans-serif;margin:0;background:#f6f7f9;color:#222}
header{background:$hdrColor;color:#fff;padding:12px 16px}header h1{margin:0;font-size:20px}header .m{font-size:13px;opacity:.92}
nav{display:flex;flex-wrap:wrap;gap:4px;padding:8px 16px;background:#fff;border-bottom:1px solid #ddd;position:sticky;top:0;z-index:2}
nav button{border:1px solid #ccc;background:#fff;padding:6px 10px;cursor:pointer;border-radius:4px}nav button.on{background:#0C6B37;color:#fff;border-color:#0C6B37}
section{display:none;padding:12px 16px}section.on{display:block}
.cards{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 12px}.card{background:#fff;border:1px solid #ddd;border-radius:6px;padding:8px 14px;min-width:96px;cursor:pointer}
.card b{display:block;font-size:24px}.card.bad b{color:#B3261E}.card.unk b{color:#6B5E00}
table.t{border-collapse:collapse;background:#fff;width:100%;font-size:13px}table.t th{background:#eef2ef;cursor:pointer;user-select:none}
table.t td,table.t th{border:1px solid #ddd;padding:4px 6px;vertical-align:top}td.n{text-align:right}td.s{font-size:12px;color:#555;max-width:420px}
tr.bad td{background:#fde8e8}tr.warn td{background:#fff6dc}tr.unk td{background:#efefef}.u{color:#999}
td.cp{font-size:13px;max-width:900px}button.copy{cursor:pointer}.filter{margin:6px 0;font-size:13px}.note{font-size:13px;color:#444;line-height:1.7}textarea{width:100%;height:180px;font-family:inherit;font-size:13px}
</style></head><body>
<header><h1>Unity 每日檢查　結論：$(Esc $overall)</h1>
<div class="m">執行 $($runStart.ToString('yyyy-MM-dd HH:mm:ss'))｜執行人 $(Esc $who)｜$ToolVersion｜規則 $(Esc $RulesVersion)$(if ($abort) { '｜⚠ 整批中止：' + (Esc $abort) })$(if ($manualSince) { '｜補查模式' })</div></header>
<nav id="nav"></nav>
<section id="tS" data-n="1 結論與處置">
<div class="cards">
<div class="card" data-f="">設備<b>$($R.Summary.Count)</b></div>
<div class="card bad" data-f="須回報">須回報<b>$($cnt['須回報'])</b></div>
<div class="card unk" data-f="須補查">須補查<b>$($cnt['須補查'])</b></div>
<div class="card" data-f="須覆核">須覆核<b>$($cnt['須覆核'])</b></div>
<div class="card" data-f="可結案（有注意事項）">可結案（有注意）<b>$($cnt['可結案（有注意事項）'])</b></div>
<div class="card" data-f="可結案">可結案<b>$($cnt['可結案'])</b></div></div>
<p class="note">處置規則：設備狀態「異常」→ 須回報；資料沒查完整或有讀不懂的 → 須補查（請人工登入確認）；期間有錯誤事件 → 須覆核（看「事件」分頁確認是否已恢復）；其餘可結案。「Mail 異常通知」本工具無法確認信件是否送達，請另查收件信箱。非 Unity 的儲存設備不在本工具範圍，仍需人工檢查。</p>
<table class="t" id="sumT"><thead><tr><th>項次</th><th>項目（地點_廠牌_型號_IP）</th><th>名稱</th><th>處置</th><th>設備狀態</th><th>完整度</th><th>系統健康</th><th>未處理告警</th><th>告警ERROR以上</th><th>期間錯誤事件</th><th>Pool注意</th><th>LUN數</th><th>檔案系統注意</th><th>硬體異常</th><th>複寫異常</th><th>寄信設定</th><th>帳號角色</th><th>說明</th></tr></thead><tbody>$($sumRows.ToString())</tbody></table>
<h3>檢查表文字（按「複製」後貼進每日檢查表的「異常訊息」欄）</h3>
<table class="t"><thead><tr><th>項次</th><th>項目（地點_廠牌_型號_IP）</th><th>名稱</th><th>檢查表文字</th><th></th></tr></thead><tbody>$($sheetRows.ToString())</tbody></table>
<h3>重點整理：<span style="color:#B3261E">⚠影響營運 $(@($R.Focus | Where-Object { $_.影響營運 }).Count)</span>、立即處理 $($focusCnt['立即處理'])、本週追蹤 $($focusCnt['本週追蹤'])、處理一次 $($focusCnt['處理一次'])、已自動確認恢復 $($focusCnt['已恢復'])、可忽略 $($focusCnt['可忽略'])　→ 看「重點整理」分頁</h3>
<h3>回報草稿（可直接複製進信件）</h3><textarea readonly>$(Esc $draft.ToString())</textarea></section>
<section id="tK" data-n="1.5 重點整理"><p class="note">工具自動判讀：同一個物件（檔案系統、Pool、複寫、LUN…）的告警、Error Log 與目前狀態合併成一件，並用「目前狀態」自動確認是否已恢復。⚠影響營運＝立即處理且會讓服務中斷或備援失效的（空間將滿、硬體、複寫、LUN、原因不明的系統降級）。立即處理＝目前異常；本週追蹤＝目前注意或無法自動比對；處理一次＝非故障但需人確認一次（例：UDoctor 更新）；已恢復＝工具已比對目前狀態正常；可忽略＝已解除。</p>$(Table 'Focus' 'K' $COLS.Focus '等級')</section>
<section id="tA" data-n="2 告警"><div class="filter"></div><p class="note">只有狀態 Active（還在發生）的告警列入判定，筆數會跟 Unisphere 告警頁預設畫面一致；Inactive 是設備標示已解除的舊告警，列出供參考。已確認（acknowledged）只代表有人看過，不代表已恢復，所以仍列「注意」。</p>$(Table 'Alerts' 'A' $COLS.Alerts)</section>
<section id="tE" data-n="3 事件（Error Log）"><div class="filter"></div><p class="note">只列 ERROR 以上的事件（最多 $MaxLookbackDays 天內），列「待覆核」：可能已恢復，請對照告警與系統健康判斷是否仍存在。</p>$(Table 'Events' 'E' $COLS.Events)</section>
<section id="tP" data-n="4 Pool"><div class="filter"></div>$(Table 'Pools' 'P' $COLS.Pools)</section>
<section id="tL" data-n="5 LUN 空間"><div class="filter"></div><p class="note">這裡是儲存設備看到的「配置量」，僅供參考、不列入判定。VMware 資料存放區實際還剩多少（紙本「LUN 低於 600」）要看 vCenter／vCOps。單位 GiB（1 GiB＝1,073,741,824 bytes）。</p>$(Table 'Luns' 'L' $COLS.Luns)</section>
<section id="tF" data-n="6 檔案系統"><div class="filter"></div>$(Table 'Fs' 'F' $COLS.Fs)</section>
<section id="tH" data-n="7 硬體／複寫"><div class="filter"></div><h3>硬體元件（只列不是 OK 的）</h3>$(Table 'Hw' 'H' $COLS.Hw)<h3>複寫</h3>$(Table 'Rep' 'R' $COLS.Rep)</section>
<section id="tM" data-n="8 寄信設定"><div class="filter"></div><p class="note">只代表設備上有設定收件信箱，信件是否真的送達需查收件信箱。</p>$(Table 'Mail' 'M' $COLS.Mail)</section>
<section id="tG" data-n="9 收集缺口"><div class="filter"></div><p class="note">這些項目沒讀到，報告上顯示「不知道」，不可當成正常。「必要＝是」的缺口會讓該設備變成「須補查」。</p>$(Table 'Gaps' 'G' $COLS.Gaps '必要')</section>
<script>
(function(){
var secs=document.querySelectorAll('section'),nav=document.getElementById('nav');
function show(id){secs.forEach(function(s){s.classList.toggle('on',s.id==id)});nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-for')==id)})}
secs.forEach(function(s){var b=document.createElement('button');b.textContent=s.getAttribute('data-n');b.setAttribute('data-for',s.id);b.addEventListener('click',function(){show(s.id)});nav.appendChild(b)});
function onlyDev(tab,dev){show(tab);var sec=document.getElementById(tab);
 sec.querySelectorAll('table.t tbody tr').forEach(function(r){if(r.classList.contains('empty'))return;r.style.display=(!dev||r.getAttribute('data-dev')===dev)?'':'none'});
 var f=sec.querySelector('.filter');if(f){f.textContent='';if(dev){f.appendChild(document.createTextNode('只看 '+dev+'　'));var a=document.createElement('a');a.href='#';a.textContent='看全部';a.addEventListener('click',function(e){e.preventDefault();onlyDev(tab,'')});f.appendChild(a)}}}
document.querySelectorAll('a.jump').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();onlyDev(a.getAttribute('data-tab'),a.getAttribute('data-dev'))})});
document.querySelectorAll('.card').forEach(function(c){c.addEventListener('click',function(){var v=c.getAttribute('data-f');
 document.querySelectorAll('#sumT tbody tr').forEach(function(r){r.style.display=(!v||r.getAttribute('data-st')===v)?'':'none'})})});
document.querySelectorAll('table.t th').forEach(function(th){th.addEventListener('click',function(){var tb=th.closest('table').tBodies[0],i=Array.prototype.indexOf.call(th.parentNode.children,th),asc=th.getAttribute('data-a')!=='1';
 th.parentNode.querySelectorAll('th').forEach(function(x){x.removeAttribute('data-a')});th.setAttribute('data-a',asc?'1':'0');
 var rows=Array.prototype.slice.call(tb.rows).filter(function(r){return !r.classList.contains('empty')});
 rows.sort(function(a,b){var x=a.cells[i],y=b.cells[i];if(!x||!y)return 0;var p=x.getAttribute('data-v'),q=y.getAttribute('data-v');var r;
  if(p!==null&&q!==null&&!isNaN(parseFloat(p))&&!isNaN(parseFloat(q))){r=parseFloat(p)-parseFloat(q)}else{r=x.textContent.localeCompare(y.textContent,'zh-Hant',{numeric:true})}return asc?r:-r});
 rows.forEach(function(r){tb.appendChild(r)})})});
document.querySelectorAll('button.copy').forEach(function(b){b.addEventListener('click',function(){var t=b.closest('tr').querySelector('td.cp').textContent;
 var done=function(){b.textContent='已複製';setTimeout(function(){b.textContent='複製'},1500)};
 if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,function(){fallback()})}else{fallback()}
 function fallback(){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');done()}catch(e){}document.body.removeChild(a)}})});
show('tS');
})();
</script></body></html>
"@
[IO.File]::WriteAllText((Join-Path $tmpDir 'report.html'), $html, (New-Object Text.UTF8Encoding($true)))
$hash = (Get-FileHash -Algorithm SHA256 -Path $MyInvocation.MyCommand.Path).Hash
$manifest = [ordered]@{ tool = $ToolVersion; scriptSha256 = $hash; rules = $RulesVersion; started = $runStart.ToString('o'); finished = (Get-Date).ToString('o'); runner = $who
  overall = $overall; aborted = $abort; manualSince = $(if ($manualSince) { $manualSince.ToString('o') } else { $null }); devices = $R.Summary.Count
  params = @{ PoolWarnPct = $PoolWarnPct; PoolBadPct = $PoolBadPct; FsWarnPct = $FsWarnPct; FsBadPct = $FsBadPct; MaxLookbackDays = $MaxLookbackDays; MaxCallsPerDevice = $MaxCallsPerDevice; DeviceDeadlineSec = $DeviceDeadlineSec } }
[IO.File]::WriteAllText((Join-Path $tmpDir 'manifest.json'), ($manifest | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding($false)))
Move-Item -Path $tmpDir -Destination $finDir
try { foreach ($x in $R.Summary) { if ($x.名稱) { $names[$x.設備] = $x.名稱 } }; [IO.File]::WriteAllText($namesFile, ($names | ConvertTo-Json), (New-Object Text.UTF8Encoding($false))) } catch {}
if (-not $manualSince) {   # 狀態檔：寫暫存再換名，留一份上一版
  try {
    $stTmp = $stateFile + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($stTmp, ($newState | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
    if (Test-Path $stateFile) { Copy-Item -Force $stateFile ($stateFile + '.prev') }
    Move-Item -Force -Path $stTmp -Destination $stateFile
  } catch { $stateFail = $_.Exception.Message; Write-Host ('⚠ unity_state.json 寫不進去：' + $stateFail + '（下次事件會從上一次成功的起點開始）') }
}

Write-Host ""
Write-Host "======== 總表 ========"
$R.Summary | Select-Object 項次, 設備, 處置, 設備狀態, 完整度 | Format-Table -AutoSize | Out-String | Write-Host
Write-Host ("結論：" + $overall)
Write-Host ("報告：" + (Join-Path $finDir 'report.html'))
if (-not $NoOpen) { try { Start-Process (Join-Path $finDir 'report.html') } catch {} }
$incomplete = @($R.Summary | Where-Object { $_.完整度 -notlike '完整*' -or $_.設備狀態 -eq '不知道' }).Count
$exitCode = if ($abort -or $incomplete -or $stateFail) { 3 } elseif (@($R.Summary | Where-Object { $_.設備狀態 -eq '異常' }).Count) { 2 } elseif (@($R.Summary | Where-Object { $_.處置 -ne '可結案' }).Count) { 1 } else { 0 }
} finally {
  if ($jarDir) { Remove-Item -Recurse -Force -Path $jarDir -ErrorAction SilentlyContinue }
  if ($lock) { $lock.Close(); Remove-Item -Force $lockFile -ErrorAction SilentlyContinue }
  if ($transcript) { try { Stop-Transcript | Out-Null } catch {} }
}
exit $exitCode

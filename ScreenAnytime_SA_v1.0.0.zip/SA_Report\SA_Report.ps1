# ScreenAnytime Report v1.0.0
# Reads every run_* folder made by SA_Collect.ps1 (under -InputDir, any depth) + people/host lists,
# and writes ONE html dashboard. Read-only on inputs; writes only into -OutputFolder.
# Readable source. Ship build\SA_Report\SA_Report.ps1 (ASCII-only, made by src\build.ps1).
param(
[string]$InputDir = (Join-Path $PSScriptRoot 'collect'),
[string]$PeopleCsv = (Join-Path $PSScriptRoot 'ScreenAnytime_People.csv'),
[string]$HostsCsv = (Join-Path $PSScriptRoot 'ScreenAnytime_Hosts.csv'),
[string]$OutputFolder = (Join-Path $PSScriptRoot 'report'),
[int]$RecentDays = 14,
[int]$StaleDays = 4,
[int]$DiskWarn = 80,
[int]$DiskBad = 90,
[int]$RetainDays = 90,
[string]$HostPattern = '^[A-Za-z][A-Za-z0-9]*-\d{3}$',
[switch]$NoOpen
)
$Ver = '1.0.0'
function Get-HostKey([string]$seg) {
if ($seg -match '^\d{1,3}(\.\d{1,3}){3}$') { return (($seg.Split('.') | ForEach-Object { [int]$_ }) -join '.') }
if ($seg -match $HostPattern) { return $seg.ToUpper() }
return $null
}
function Done([int]$code) { if (-not $NoOpen) { Read-Host 'Press Enter to exit' | Out-Null }; exit $code }
Write-Host '=====' -ForegroundColor Cyan
Write-Host " ScreenAnytime Report v$Ver" -ForegroundColor Cyan
Write-Host '=====' -ForegroundColor Cyan
if (-not (Test-Path $InputDir)) { Write-Host "ERROR: collect folder not found: $InputDir" -ForegroundColor Red; Done 1 }
New-Item -ItemType Directory -Force -Path $OutputFolder | Out-Null

$Runs = New-Object System.Collections.ArrayList
$Disks = New-Object System.Collections.ArrayList
$Roots = New-Object System.Collections.ArrayList
$Svcs = New-Object System.Collections.ArrayList
$Areas = @{}
$U = @{}
$Skipped = 0
foreach ($ri in @(Get-ChildItem -Path $InputDir -Recurse -Filter 'run_info.csv' -ErrorAction SilentlyContinue)) {
    $dir = $ri.Directory
    if ($dir.Name -like '*.tmp') { $Skipped++; continue }
    $kv = @{}
    foreach ($r in (Import-Csv $ri.FullName)) { $kv[$r.Key] = $r.Value }
    if ($kv['SchemaVersion'] -ne '1') { Write-Host "Skip (unknown schema): $($dir.FullName)" -ForegroundColor Yellow; $Skipped++; continue }
    $pc = $kv['Computer']; $pk = $kv['HostKey']; if (-not $pk) { $pk = Get-HostKey $pc }; if (-not $pk) { $pk = $pc.ToUpper() }
    $t = $kv['StartTime']; $rid = $kv['RunId']
    if ($Runs | Where-Object { $_.id -eq $rid }) { continue }
    Write-Host "Reading $($dir.Name)"
    [void]$Runs.Add([pscustomobject]@{ id = $rid; pc = $pc; k = $pk; t = $t; st = $kv['Status']; why = $kv['Reasons']; ver = $kv['CollectorVersion']; svc = $kv['Services']; dirs = $kv['RecordDirs']; dir = $dir.Name })
    $f = Join-Path $dir.FullName 'disks.csv'
    if (Test-Path $f) { foreach ($r in @(Import-Csv $f)) { [void]$Disks.Add([pscustomobject]@{ k = $pk; t = $t; drv = $r.Drive; ty = $r.Type; tot = $r.TotalGB; free = $r.FreeGB; pct = $r.UsedPct; st = $r.Status }) } }
    $f = Join-Path $dir.FullName 'roots.csv'
    if (Test-Path $f) { foreach ($r in @(Import-Csv $f)) { [void]$Roots.Add([pscustomobject]@{ k = $pk; t = $t; root = $r.Root; ex = $r.Exists; files = $r.Files; mb = $r.SizeMB; rf = $r.RecFiles; rmb = $r.RecMB; old = $r.Oldest; new = $r.Newest; tr = $r.Truncated; err = $r.Errors }) } }
    $f = Join-Path $dir.FullName 'services.csv'
    if (Test-Path $f) { foreach ($r in @(Import-Csv $f)) { [void]$Svcs.Add([pscustomobject]@{ k = $pk; t = $t; n = $r.Name; dn = $r.DisplayName; st = $r.Status }) } }
    $f = Join-Path $dir.FullName 'daily.csv'
    if (Test-Path $f) {
        foreach ($r in @(Import-Csv $f)) {
            if (-not $r.Account) { continue }
            $files = [int]$r.Files; $mb = [double]::Parse($r.MB, [Globalization.CultureInfo]::InvariantCulture)
            $ak = "$rid|$($r.Root)|$($r.Area)"
            if (-not $Areas.ContainsKey($ak)) { $Areas[$ak] = [pscustomobject]@{ run = $rid; k = $pk; root = $r.Root; area = $r.Area; n = 0; mb = 0.0; hosts = @{} } }
            $a = $Areas[$ak]; $a.n += $files; $a.mb += $mb; $a.hosts[$r.Host] = 1
            $loc = 0; if ($r.Host -eq $pk) { $loc = 1 }
            $key = "$($r.Host)|$($r.Account.ToUpper())|$($r.Day)|$loc"
            $x = $U[$key]
            if (-not $x) { $U[$key] = [pscustomobject]@{ s = $r.Host; a = $r.Account; d = $r.Day; n = $files; mb = $mb; l = $r.Last; loc = $loc } }
            else { if ($files -gt $x.n) { $x.n = $files }; if ($mb -gt $x.mb) { $x.mb = $mb }; if ($r.Last -gt $x.l) { $x.l = $r.Last } }
        }
    }
}
if ($Runs.Count -eq 0) { Write-Host "ERROR: no run_ folder found under $InputDir" -ForegroundColor Red; Done 1 }
$DailyList = @($U.Values)
foreach ($x in $DailyList) { $x.mb = [math]::Round($x.mb, 2) }
$AreaList = @($Areas.Values | ForEach-Object { [pscustomobject]@{ run = $_.run; k = $_.k; root = $_.root; area = $_.area; n = $_.n; mb = [math]::Round($_.mb, 1); hosts = $_.hosts.Count } })
$People = @()
$PeopleDate = ''
if (Test-Path $PeopleCsv) {
    $PeopleDate = (Get-Item $PeopleCsv).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    $People = @(Import-Csv $PeopleCsv | Where-Object { $_.Account } | ForEach-Object {
        [pscustomobject]@{ a = $_.Account.Trim(); nm = $_.Name; dp = $_.Dept; g = $_.Group; nh = "$($_.NewHost)".Trim(); oh = "$($_.OldHosts)".Trim() } })
}
$HostRows = @()
$HostsDate = ''
if (Test-Path $HostsCsv) {
    $HostsDate = (Get-Item $HostsCsv).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    $HostRows = @(Import-Csv $HostsCsv | Where-Object { $_.Host } | ForEach-Object {
        [pscustomobject]@{ h = $_.Host.Trim(); role = $_.Role; g = $_.Group; ins = $_.Installed } })
}
$Now = Get-Date
$Data = [ordered]@{
    ver = $Ver; gen = $Now.ToString('yyyy-MM-dd HH:mm'); pc = $env:COMPUTERNAME; input = $InputDir
    recentDays = $RecentDays; staleDays = $StaleDays; diskWarn = $DiskWarn; diskBad = $DiskBad; retainDays = $RetainDays
    peopleCsv = $PeopleCsv; peopleDate = $PeopleDate; hostsCsv = $HostsCsv; hostsDate = $HostsDate; skipped = $Skipped
    runs = @($Runs); disks = @($Disks); roots = @($Roots); svcs = @($Svcs); areas = $AreaList
    daily = $DailyList; people = $People; hosts = $HostRows
}
$Json = ConvertTo-Json -InputObject $Data -Depth 4 -Compress
$Json = $Json.Replace('</', '<\/')
$Html = @'
<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ScreenAnytime Report</title>
<style>
:root{--bg:#f4f7f5;--card:#fff;--ink:#1d2b24;--mut:#66756d;--line:#dde4e0;--pri:#0C6B37;--pri2:#e3f1e8;--bad:#b42318;--bad2:#fdecea;--warn:#9a5800;--warn2:#fff2dc}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 "Microsoft JhengHei","Segoe UI",sans-serif}
header{background:var(--pri);color:#fff;padding:12px 20px}
header h1{margin:0;font-size:18px}
header .sub{opacity:.85;font-size:12px}
nav{display:flex;gap:2px;padding:0 12px;background:#fff;border-bottom:1px solid var(--line);overflow-x:auto;position:sticky;top:0;z-index:5}
nav button{border:0;background:none;padding:10px 14px;font:inherit;cursor:pointer;border-bottom:3px solid transparent;color:var(--mut);white-space:nowrap}
nav button.on{color:var(--pri);border-color:var(--pri);font-weight:bold}
main{padding:16px;max-width:1400px;margin:0 auto}
.tab{display:none}.tab.on{display:block}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:10px 12px;cursor:pointer}
.card:hover{border-color:var(--pri);box-shadow:0 1px 4px rgba(0,0,0,.08)}
.card .no{font-size:11px;color:var(--mut)}
.card .v{font-size:26px;font-weight:bold;line-height:1.2}
.card .l{color:var(--mut);font-size:13px}
.card.bad .v{color:var(--bad)}.card.warn .v{color:var(--warn)}.card.ok .v{color:var(--pri)}
.panel{background:#fff;border:1px solid var(--line);border-radius:8px;padding:12px 14px;margin-top:12px}
.panel h3{margin:0 0 6px;font-size:15px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:800px){.two{grid-template-columns:1fr}}
.todo{margin:0;padding-left:0;list-style:none}
.todo li{padding:3px 0;cursor:pointer}.todo li:hover{color:var(--pri);text-decoration:underline}
.todo b{display:inline-block;min-width:34px;color:var(--mut)}
.chart{display:flex;align-items:flex-end;gap:2px;height:70px;margin-top:6px}
.chart div{flex:1;background:var(--pri);opacity:.7;min-height:1px;cursor:pointer}
.chart div:hover{opacity:1}
.axis{display:flex;justify-content:space-between;color:var(--mut);font-size:11px}
.tw{overflow:auto;border:1px solid var(--line);border-radius:8px;max-height:60vh}
table{width:100%;border-collapse:collapse;background:#fff}
th,td{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}
th{background:#eef3f0;cursor:pointer;user-select:none;position:sticky;top:0}
th:hover{background:#e0ebe4}
th.sa:after{content:" \25B2";font-size:10px}th.sd:after{content:" \25BC";font-size:10px}
td.n,th.n{text-align:right}
td.no{color:var(--mut)}
td.wrap{white-space:normal;min-width:240px}
tr.ck{cursor:pointer}tr.ck:hover td{background:var(--pri2)}
.bar{display:flex;gap:10px;align-items:center;margin:6px 0 8px;flex-wrap:wrap}
.bar input{padding:6px 8px;border:1px solid var(--line);border-radius:6px;min-width:220px;font:inherit}
.pg button{padding:3px 10px;border:1px solid var(--line);background:#fff;border-radius:4px;cursor:pointer;font:inherit;margin:0 2px}
.pg button:disabled{opacity:.4;cursor:default}
.tag{display:inline-block;padding:0 6px;border-radius:4px;font-size:12px;background:#eef3f0}
.tag.bad{background:var(--bad2);color:var(--bad)}.tag.warn{background:var(--warn2);color:var(--warn)}.tag.ok{background:var(--pri2);color:var(--pri)}
.note{color:var(--mut);font-size:12px}
.sub2{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}
.sub2 button{border:1px solid var(--line);background:#fff;border-radius:14px;padding:3px 12px;cursor:pointer;font:inherit}
.sub2 button.on{background:var(--pri);color:#fff;border-color:var(--pri)}
#modal{position:fixed;inset:0;background:rgba(0,0,0,.4);display:none;align-items:center;justify-content:center;padding:16px;z-index:10}
#modal.on{display:flex}
#modal .box{background:#fff;border-radius:10px;max-width:1200px;width:100%;max-height:88vh;display:flex;flex-direction:column}
#modal .hd{display:flex;justify-content:space-between;align-items:center;padding:10px 16px;border-bottom:1px solid var(--line)}
#modal .bd{padding:10px 16px;overflow:auto}
#modal .bd h4{margin:10px 0 2px}
#modal .x{border:0;background:none;font-size:22px;cursor:pointer;line-height:1}
.help p,.help li{max-width:900px}
</style></head><body>
<header><h1 id="ttl"></h1><div class="sub" id="sub"></div></header>
<nav id="nav"></nav>
<main id="main"></main>
<div id="modal"><div class="box"><div class="hd"><b id="mt"></b><button class="x" onclick="closeM()">&times;</button></div><div class="bd" id="mb"></div></div></div>
<script>
const D=__DATA__;
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const arr=x=>x==null?[]:Array.isArray(x)?x:[x];
const RUNS=arr(D.runs),DISKS=arr(D.disks),ROOTS=arr(D.roots),SVCS=arr(D.svcs),AREAS=arr(D.areas),DAILY=arr(D.daily),PEOPLE_IN=arr(D.people),HOSTS_IN=arr(D.hosts);
const RD=D.recentDays;
const TYPE=a=>/^\d+$/.test(a)?'USER':/^sysinfra$/i.test(a)?'SYSTEM':/^administrator$/i.test(a)?'ADMIN':'OTHER';
const TZH={USER:'\u500B\u4EBA\u5E33\u865F',SYSTEM:'\u7CFB\u7D71\u5E33\u865F',ADMIN:'\u7BA1\u7406\u8005\u5E33\u865F',OTHER:'\u5176\u4ED6\u5E33\u865F'};
const ROLE={Shared:'\u65B0\u5171\u7528\u4E3B\u6A5F',Spare:'\u5099\u7528\u4E3B\u6A5F',Old:'\u820A\u8DF3\u677F\u6A5F'};
const hk=n=>{n=String(n||'').trim();if(/^\d+\.\d+\.\d+\.\d+$/.test(n))return n.split('.').map(Number).join('.');return n.toUpperCase();};
const GEN=new Date(D.gen.replace(' ','T')+':00');
const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const addD=(s,n)=>{const d=new Date(s+'T00:00:00');d.setDate(d.getDate()+n);return ymd(d);};
const TODAY=ymd(GEN);
const daysAgo=t=>t?Math.round((new Date(TODAY+'T00:00:00')-new Date(String(t).slice(0,10)+'T00:00:00'))/864e5):null;
const CUT=addD(TODAY,-(RD-1));
const agoTxt=n=>n==null?'\u2014':n<=0?'\u4ECA\u5929':n+' \u5929\u524D';
const ipKey=s=>/^\d+\.\d+\.\d+\.\d+$/.test(s)?s.split('.').map(x=>x.padStart(3,'0')).join('.'):'~'+s;
const byIp=(a,b)=>ipKey(a)<ipKey(b)?-1:ipKey(a)>ipKey(b)?1:0;
const mbTxt=x=>x==null||isNaN(x)?'\u2014':x>=1024?(x/1024).toFixed(1)+' GB':(+x).toFixed(1)+' MB';
const pctTxt=x=>x==null||isNaN(x)?'\u2014':Math.round(x)+'%';
const num=(a,p)=>{a.forEach((x,i)=>{x._no=p+(i+1);x._i=i;});return a;};
const N=x=>{const v=parseFloat(x);return isNaN(v)?null:v;};
const last=(a,f)=>a.reduce((m,x)=>(!m||f(x)>f(m))?x:m,null);

/* ---------- reference lists ---------- */
const HI=new Map();
for(const h of HOSTS_IN) HI.set(hk(h.h),{name:h.h,role:h.role||'',g:h.g||'',ins:h.ins||''});
const PP=new Map();
for(const p of PEOPLE_IN){const A=p.a.toUpperCase();if(!PP.has(A))PP.set(A,{a:p.a,nm:p.nm||'',dp:p.dp||'(\u672A\u586B\u90E8\u9580)',g:p.g||'',nh:hk(p.nh),nhName:p.nh||'',oh:(p.oh||'').split(/\s+/).filter(Boolean)});}
const hasPeople=PP.size>0;
const roleOf=k=>(HI.get(k)||{}).role||'';
const isNew=k=>{const r=roleOf(k);return r==='Shared'||r==='Spare';};
const hname=k=>{const i=HI.get(k);return i?i.name:k;};
const nmOf=a=>{const p=PP.get(String(a).toUpperCase());return p?p.nm:'';};

/* ---------- merge recordings: union of central (loc=0) and host-local (loc=1) by max ---------- */
const UM=new Map(),SYNC=new Map(),DAYTOT=new Map();
for(const r of DAILY){
  const A=r.a.toUpperCase(),k=r.s+'|'+A+'|'+r.d,n=+r.n,mb=+r.mb;
  const x=UM.get(k);
  if(!x)UM.set(k,{s:r.s,a:r.a,A,d:r.d,n,mb,l:r.l});else{if(n>x.n)x.n=n;if(mb>x.mb)x.mb=mb;if(r.l>x.l)x.l=r.l;}
  const sk=r.s+'|'+r.d;let y=SYNC.get(sk);if(!y){y={s:r.s,d:r.d,loc:0,cen:0,hasLoc:false,hasCen:false};SYNC.set(sk,y);}
  if(+r.loc===1){y.loc+=n;y.hasLoc=true;}else{y.cen+=n;y.hasCen=true;}
}
const ROWS=[...UM.values()];
const AC=new Map(),PR=new Map(),SV=new Map(),HD=new Map();
const newSv=k=>({k,n:0,mb:0,last:'',users:new Set(),recent:new Set()});
for(const r of ROWS){
  const recent=r.d>=CUT;
  let sv=SV.get(r.s);if(!sv){sv=newSv(r.s);SV.set(r.s,sv);}
  sv.n+=r.n;sv.mb+=r.mb;if(r.l>sv.last)sv.last=r.l;if(TYPE(r.a)==='USER'){sv.users.add(r.A);if(recent)sv.recent.add(r.A);}
  let ac=AC.get(r.A);if(!ac){ac={a:r.a,n:0,mb:0,first:r.d,last:'',hosts:new Set(),rNew:new Set(),rOld:new Set(),everNew:false,newDays:new Set(),asgDays:new Set()};AC.set(r.A,ac);}
  ac.n+=r.n;ac.mb+=r.mb;if(r.d<ac.first)ac.first=r.d;if(r.l>ac.last)ac.last=r.l;ac.hosts.add(r.s);
  const nw=isNew(r.s);if(nw){ac.everNew=true;ac.newDays.add(r.d);}
  const p=PP.get(r.A);if(p&&p.nh===r.s)ac.asgDays.add(r.d);
  if(recent){if(nw)ac.rNew.add(r.s);else ac.rOld.add(r.s);}
  const pk=r.s+'|'+r.A;let q=PR.get(pk);if(!q){q={s:r.s,a:r.a,n:0,mb:0,first:r.d,last:''};PR.set(pk,q);}
  q.n+=r.n;q.mb+=r.mb;if(r.d<q.first)q.first=r.d;if(r.l>q.last)q.last=r.l;
  const hdk=r.s+'|'+r.d;let h=HD.get(hdk);if(!h){h={s:r.s,d:r.d,n:0,mb:0,users:new Set()};HD.set(hdk,h);}h.n+=r.n;h.mb+=r.mb;h.users.add(r.A);
  let t=DAYTOT.get(r.d);if(!t){t={d:r.d,n:0,mb:0};DAYTOT.set(r.d,t);}t.n+=r.n;t.mb+=r.mb;
}

/* ---------- latest collection per host ---------- */
const LASTRUN=new Map();
for(const r of RUNS){const x=LASTRUN.get(r.k);if(!x||r.t>x.t)LASTRUN.set(r.k,r);}
const latestDisks=k=>{const r=LASTRUN.get(k);return r?DISKS.filter(d=>d.k===k&&d.t===r.t):[];};
const latestRoots=k=>{const r=LASTRUN.get(k);return r?ROOTS.filter(d=>d.k===k&&d.t===r.t&&d.ex==='Y'):[];};
const avgNew=(k,days)=>{let s=0;for(let i=1;i<=days;i++){const h=HD.get(k+'|'+addD(TODAY,-i));if(h)s+=h.mb;}return s/days;};

/* ---------- people P ---------- */
const hostList=s=>[...s].sort(byIp).map(hname).join(' ');
const ST={ok:'\u5DF2\u5728\u5206\u914D\u4E3B\u6A5F',both:'\u65B0\u820A\u4E26\u7528',other:'\u7528\u4E86\u975E\u5206\u914D\u65B0\u4E3B\u6A5F',old:'\u53EA\u5728\u820A\u4E3B\u6A5F',none:'\u65B0\u6A5F\u7121\u7D00\u9304',idle:'\u8FD1\u671F\u6C92\u4F7F\u7528',unl:'\u540D\u55AE\u5916',sys:'\u7CFB\u7D71/\u5171\u7528\u5E33\u865F'};
const allA=new Set([...PP.keys(),...AC.keys()]);
const people=num([...allA].sort().map(A=>{
  const p=PP.get(A),ac=AC.get(A),acct=p?p.a:ac.a,type=TYPE(acct);
  let st,cls,why='';
  if(!p){if(type==='USER'){st=ST.unl;cls='warn';why='\u6709\u9304\u5F71\uFF0C\u4F46\u4E0D\u5728\u4EBA\u54E1\u5C0D\u7167\u8868\uFF08\u65B0\u4EBA\u3001\u5916\u5305\u6216\u5C0D\u7167\u8868\u6C92\u66F4\u65B0\uFF09';}else{st=ST.sys;cls='';why='\u4E0D\u662F\u500B\u4EBA\u5DE5\u865F\uFF0C\u770B\u4E0D\u51FA\u5BE6\u969B\u64CD\u4F5C\u7684\u4EBA';}}
  else if(ac&&ac.rNew.size&&ac.rOld.size){st=ST.both;cls='warn';why='\u8FD1 '+RD+' \u5929\u65B0\u6A5F\uFF08'+hostList(ac.rNew)+'\uFF09\u548C\u820A\u6A5F\uFF08'+hostList(ac.rOld)+'\uFF09\u90FD\u6709\u9304\u5F71';}
  else if(ac&&ac.rNew.has(p.nh)){st=ST.ok;cls='ok';why=ac.rNew.size>1?'\u4E5F\u7528\u4E86 '+hostList([...ac.rNew].filter(k=>k!==p.nh)):'';}
  else if(ac&&ac.rNew.size){st=ST.other;cls='warn';why='\u61C9\u7528 '+p.nhName+'\uFF0C\u8FD1 '+RD+' \u5929\u5728 '+hostList(ac.rNew);}
  else if(ac&&ac.rOld.size){st=ST.old;cls='warn';why='\u61C9\u6539\u7528 '+p.nhName+'\uFF0C\u8FD1 '+RD+' \u5929\u53EA\u5728\u820A\u6A5F '+hostList(ac.rOld);}
  else if(ac&&ac.everNew){st=ST.idle;cls='';why='\u7528\u904E\u65B0\u6A5F\uFF0C\u6700\u5F8C\u4E00\u6B21 '+ac.last;}
  else{st=ST.none;cls='bad';why='\u65B0\u8DF3\u677F\u6A5F\u6C92\u6709\u9019\u500B\u5DE5\u865F\u7684\u9304\u5F71\uFF0C\u63A8\u5B9A\u4ECD\u5728\u7528\u500B\u4EBA\u8DF3\u677F\u6A5F'+(p.oh.length?'\uFF08'+p.oh.join('\u3001')+'\uFF09':'')+'\uFF1B\u61C9\u6539\u7528 '+p.nhName;}
  return {a:acct,A,nm:p?p.nm:'',dp:p?p.dp:'',g:p?p.g:'',nh:p?p.nh:'',nhName:p?p.nhName:'',type,tz:TZH[type],st,cls,why,inList:!!p,
    hosts:ac?ac.hosts.size:0,n:ac?ac.n:0,mb:ac?ac.mb:0,last:ac?ac.last:'',ago:ac?daysAgo(ac.last):null};
}),'P');
const PNO=new Map(people.map(x=>[x.A,x]));
const inList=people.filter(p=>p.inList);
const usedNew=p=>p.st===ST.ok||p.st===ST.both||p.st===ST.other;

/* ---------- hosts S ---------- */
const allK=new Set([...HI.keys(),...SV.keys(),...LASTRUN.keys()]);
const servers=num([...allK].sort(byIp).map(k=>{
  const info=HI.get(k)||{name:hname(k),role:'',g:'',ins:''},v=SV.get(k)||newSv(k),role=info.role,run=LASTRUN.get(k);
  const assigned=inList.filter(p=>p.nh===k),arrived=assigned.filter(p=>p.st===ST.ok).length;
  const ago=daysAgo(v.last);
  const dks=latestDisks(k),rts=latestRoots(k);
  const recDrv=rts.length?rts[0].root.slice(0,2).toUpperCase():'';
  const dk=dks.find(d=>d.drv.toUpperCase()===recDrv)||null;
  const pct=dk?N(dk.pct):null,maxPct=dks.reduce((m,d)=>Math.max(m,N(d.pct)||0),0);
  const svc=run?(run.svc||''):'';
  let gap=0;for(let i=2;i<=8;i++){const y=SYNC.get(k+'|'+addD(TODAY,-i));if(y&&y.hasLoc&&y.hasCen&&y.loc>y.cen)gap++;}
  const flags=[];let cls='ok';
  const bad=(t)=>{flags.push(t);cls='bad';},warn=(t)=>{flags.push(t);if(cls!=='bad')cls='warn';};
  if(role==='Old'){
    if(v.recent.size)warn('\u820A\u6A5F\u4ECD\u5728\u4F7F\u7528');
  }else{
    if(role==='Shared'&&!v.n&&!run)bad('\u6C92\u6709\u4EFB\u4F55\u8CC7\u6599');
    else if(role==='Shared'&&!v.n)bad('\u6C92\u6709\u9304\u5F71');
    else if(v.n&&ago>D.staleDays&&role!=='Spare')warn('\u4E45\u672A\u9304\u5F71');
    if(run&&role&&svc&&/=(?!Running)/.test(svc))bad('\u5074\u9304\u670D\u52D9\u672A\u57F7\u884C');
    if(gap)warn('\u540C\u6B65\u843D\u5DEE');
  }
  if(maxPct>=D.diskBad)bad('\u78C1\u789F\u2265'+D.diskBad+'%');else if(maxPct>=D.diskWarn)warn('\u78C1\u789F\u2265'+D.diskWarn+'%');
  if(run&&daysAgo(run.t)>7&&role!=='Old')warn('\u8D85\u904E 7 \u5929\u6C92\u6536\u96C6');
  let st=flags.join('\u3001');
  if(!st){if(role==='Old')st=v.n?(daysAgo(v.last)>30?'\u4E0B\u7DDA\u5019\u9078':'\u8FD1\u671F\u5DF2\u7121\u4F7F\u7528'):'\u7121\u8CC7\u6599';else st=v.n||run?'\u6B63\u5E38':'\u7121\u8CC7\u6599';}
  if(!flags.length&&(st==='\u7121\u8CC7\u6599'))cls='';
  return {k,name:info.name,role,rz:ROLE[role]||'\u672A\u5217\u7BA1',g:info.g,ins:info.ins||'\u2014',st,cls,assigned:assigned.length,arrived,
    recentUsers:v.recent.size,users:v.users.size,n:v.n,mb:v.mb,last:v.last,ago,pct,maxPct:dks.length?maxPct:null,
    lastRun:run?run.t:'',runAgo:run?daysAgo(run.t):null,svc:run?(svc||'\u672A\u627E\u5230\u670D\u52D9'):'\u2014',gap,avg7:avgNew(k,7)};
}),'S');
const SNO=new Map(servers.map(x=>[x.k,x]));

/* ---------- capacity C (host x recording folder) ---------- */
const cap=[];
for(const s of servers){
  const rts=latestRoots(s.k),dks=latestDisks(s.k);
  for(const r of rts){
    const drv=r.root.slice(0,2).toUpperCase(),dk=dks.find(d=>d.drv.toUpperCase()===drv)||{};
    const hist=ROOTS.filter(x=>x.k===s.k&&x.root===r.root&&x.ex==='Y').sort((a,b)=>a.t<b.t?-1:1);
    let net=null;if(hist.length>1){const a=hist[hist.length-2],b=hist[hist.length-1],dd=(new Date(b.t.replace(' ','T'))-new Date(a.t.replace(' ','T')))/864e5;if(dd>0.5)net=(N(b.mb)-N(a.mb))/dd;}
    const isCentral=AREAS.some(x=>x.root===r.root&&x.k===s.k&&x.hosts>1);
    let avg=0;
    if(isCentral){for(let i=1;i<=7;i++){const t=DAYTOT.get(addD(TODAY,-i));if(t)avg+=t.mb;}avg/=7;}else avg=s.avg7;
    const free=N(dk.free),pct=N(dk.pct);
    const dtf=avg>0&&free!=null?Math.floor(free*1024/avg):null;
    const oldAge=daysAgo(r.old);
    const flags=[];let cls='ok';
    if(pct!=null&&pct>=D.diskBad){flags.push('\u78C1\u789F\u2265'+D.diskBad+'%');cls='bad';}else if(pct!=null&&pct>=D.diskWarn){flags.push('\u78C1\u789F\u2265'+D.diskWarn+'%');cls='warn';}
    if(dtf!=null&&dtf<30){flags.push('\u4E0D\u6E05\u7406\u7D04 '+dtf+' \u5929\u6EFF');if(cls==='ok')cls='warn';}
    if(oldAge!=null&&oldAge>D.retainDays+3){flags.push('\u6700\u820A\u9304\u5F71 '+oldAge+' \u5929\uFF0C\u8D85\u904E\u4FDD\u7559 '+D.retainDays+' \u5929');if(cls==='ok')cls='warn';}
    if(r.tr==='Y'){flags.push('\u6383\u63CF\u672A\u5B8C\u6210');if(cls==='ok')cls='warn';}
    cap.push({k:s.k,name:s.name,rz:s.rz,root:r.root,kind:isCentral?'\u96C6\u4E2D':'\u672C\u6A5F',drv,tot:N(dk.tot),free,pct,size:N(r.mb),rmb:N(r.rmb),rf:+r.rf,old:r.old,oldAge,new:r.new,avg,net,dtf,st:flags.join('\u3001')||'\u6B63\u5E38',cls,t:r.t});
  }
}
num(cap,'C');

/* ---------- exceptions E ---------- */
const exc=[],SYSX=new Map();
for(const q of PR.values()){
  if(q.last.slice(0,10)<CUT)continue;
  const A=q.a.toUpperCase(),p=PP.get(A),t=TYPE(q.a);
  if(t!=='USER'){let x=SYSX.get(A);if(!x){x={kind:'\u7CFB\u7D71/\u5171\u7528\u5E33\u865F\u4F7F\u7528',cls:'warn',a:q.a,nm:'',dp:'',k:q.s,hs:[],n:0,last:''};SYSX.set(A,x);}x.hs.push(q.s);x.n+=q.n;if(q.last>x.last)x.last=q.last;}
  else if(!p)exc.push({kind:'\u540D\u55AE\u5916\u5DE5\u865F',cls:'warn',a:q.a,nm:'',dp:'',k:q.s,host:hname(q.s),n:q.n,last:q.last,detail:'\u4E0D\u5728\u4EBA\u54E1\u5C0D\u7167\u8868'});
  else if(isNew(q.s)&&q.s!==p.nh&&roleOf(q.s)==='Shared')exc.push({kind:'\u7528\u5225\u90E8\u9580\u4E3B\u6A5F',cls:'warn',a:q.a,nm:p.nm,dp:p.dp,k:q.s,host:hname(q.s),n:q.n,last:q.last,detail:'\u5206\u914D '+p.nhName+'\uFF0C\u537B\u7528 '+hname(q.s)+'\uFF08'+((HI.get(q.s)||{}).g||'')+'\uFF09'});
}
for(const x of SYSX.values()){x.hs.sort(byIp);x.host=x.hs.length+' \u53F0';x.detail='\u8FD1 '+RD+' \u5929\u5728 '+x.hs.map(hname).join(' ')+' \u4F7F\u7528\uFF1B\u770B\u4E0D\u51FA\u662F\u8AB0\u64CD\u4F5C\uFF0C\u8ACB\u78BA\u8A8D\u662F\u5426\u6709\u6838\u51C6\u8207\u4F7F\u7528\u7D00\u9304';exc.push(x);}
exc.sort((a,b)=>a.kind<b.kind?-1:a.kind>b.kind?1:(a.a<b.a?-1:1));
num(exc,'E');

/* ---------- collection runs R ---------- */
const runs=num(RUNS.slice().sort((a,b)=>a.t<b.t?1:-1).map(r=>Object.assign({},r,{name:hname(r.k),cls:r.st==='OK'?'ok':r.st==='PARTIAL'?'warn':'bad'})),'R');
const noRun=servers.filter(s=>(s.role==='Shared'||s.role==='Spare')&&(!s.lastRun||s.runAgo>7));

/* ---------- table component ---------- */
function mkTable(el,cols,rows,opt){
  opt=opt||{};const ps=opt.pageSize||50;const st={k:null,d:1,p:0,q:''};
  const C=[{k:'_no',l:'\u9805\u6B21',cls:'no'}].concat(cols);
  el.innerHTML='<div class="bar"><input placeholder="\u7BE9\u9078\uFF1A\u8F38\u5165\u4EFB\u4F55\u5B57"><span class="note"></span><span class="pg"></span></div><div class="tw"><table><thead></thead><tbody></tbody></table></div>';
  const inp=el.querySelector('input'),info=el.querySelector('.note'),pg=el.querySelector('.pg'),th=el.querySelector('thead'),tb=el.querySelector('tbody');
  const sv=(x,c)=>c.k==='_no'?x._i:(c.sv?c.sv(x):(x[c.k]==null?'':x[c.k]));
  const show=(x,c)=>c.f?c.f(x):esc(x[c.k]);
  let cur=[];
  function draw(){
    let r=rows;
    if(st.q)r=r.filter(x=>C.some(c=>String(c.k==='_no'?x._no:(x[c.k]==null?'':x[c.k])).toLowerCase().includes(st.q)));
    if(st.k!==null){const c=C[st.k];r=r.slice().sort((a,b)=>{const x=sv(a,c),y=sv(b,c);return(x<y?-1:x>y?1:0)*st.d;});}
    cur=r;const P=Math.max(1,Math.ceil(r.length/ps));if(st.p>=P)st.p=P-1;
    th.innerHTML='<tr>'+C.map((c,i)=>'<th data-i="'+i+'" class="'+(c.num?'n ':'')+(st.k===i?(st.d>0?'sa':'sd'):'')+'">'+esc(c.l)+'</th>').join('')+'</tr>';
    const page=r.slice(st.p*ps,st.p*ps+ps);
    tb.innerHTML=page.length?page.map((x,j)=>'<tr data-j="'+(st.p*ps+j)+'"'+(opt.click?' class="ck"':'')+'>'+C.map(c=>'<td class="'+(c.num?'n ':'')+(c.cls||'')+'">'+(c.k==='_no'?x._no:show(x,c))+'</td>').join('')+'</tr>').join(''):'<tr><td colspan="'+C.length+'" class="note">\u6C92\u6709\u8CC7\u6599</td></tr>';
    info.textContent='\u5171 '+r.length+' \u7B46'+(r.length!==rows.length?'\uFF08\u5168\u90E8 '+rows.length+'\uFF09':'');
    pg.innerHTML=P>1?'<button data-p="-1"'+(st.p===0?' disabled':'')+'>\u4E0A\u4E00\u9801</button> \u7B2C '+(st.p+1)+' / '+P+' \u9801 <button data-p="1"'+(st.p>=P-1?' disabled':'')+'>\u4E0B\u4E00\u9801</button>':'';
  }
  th.onclick=e=>{const t=e.target.closest('th');if(!t)return;const i=+t.dataset.i;if(st.k===i)st.d=-st.d;else{st.k=i;st.d=1;}draw();};
  inp.oninput=()=>{st.q=inp.value.trim().toLowerCase();st.p=0;draw();};
  pg.onclick=e=>{const b=e.target.closest('button');if(!b)return;st.p+=+b.dataset.p;draw();};
  if(opt.click)tb.onclick=e=>{const tr=e.target.closest('tr[data-j]');if(tr)opt.click(cur[+tr.dataset.j]);};
  draw();
}
/* ---------- columns ---------- */
const tag=(t,c)=>'<span class="tag '+(c||'')+'">'+esc(t)+'</span>';
const agoCol={k:'ago',l:'\u8DDD\u4ECA',num:1,sv:x=>x.ago==null?99999:x.ago,f:x=>agoTxt(x.ago)};
const rate=(a,b)=>b?Math.round(a*1000/b)/10:null;
const COL={
  people:[{k:'a',l:'\u5DE5\u865F'},{k:'nm',l:'\u59D3\u540D'},{k:'dp',l:'\u90E8\u9580'},{k:'nhName',l:'\u5206\u914D\u4E3B\u6A5F',sv:x=>ipKey(x.nh)},{k:'st',l:'\u4F7F\u7528\u72C0\u614B',f:x=>tag(x.st,x.cls)},{k:'hosts',l:'\u7528\u904E\u5E7E\u53F0',num:1},{k:'n',l:'\u9304\u5F71\u6578',num:1},{k:'mb',l:'\u5BB9\u91CF',num:1,f:x=>mbTxt(x.mb)},{k:'last',l:'\u6700\u5F8C\u4E00\u6B21'},agoCol,{k:'why',l:'\u8AAA\u660E',cls:'wrap'}],
  srv:[{k:'name',l:'\u4E3B\u6A5F',sv:x=>ipKey(x.k)},{k:'rz',l:'\u89D2\u8272'},{k:'g',l:'\u7FA4\u7D44\uFF0F\u90E8\u9580'},{k:'st',l:'\u72C0\u614B',f:x=>tag(x.st,x.cls)},{k:'assigned',l:'\u5206\u914D\u4EBA\u6578',num:1},{k:'arrived',l:'\u5DF2\u5230\u4F4D',num:1},{k:'recentUsers',l:'\u8FD1\u671F\u4F7F\u7528\u4EBA\u6578',num:1},{k:'last',l:'\u6700\u5F8C\u9304\u5F71'},agoCol,{k:'avg7',l:'\u8FD1 7 \u5929\u65E5\u5747\u65B0\u589E',num:1,f:x=>x.avg7?mbTxt(x.avg7):'\u2014'},{k:'maxPct',l:'\u78C1\u789F\u6700\u9AD8%',num:1,sv:x=>x.maxPct==null?-1:x.maxPct,f:x=>pctTxt(x.maxPct)},{k:'svc',l:'\u5074\u9304\u670D\u52D9'},{k:'lastRun',l:'\u6700\u5F8C\u6536\u96C6'},{k:'ins',l:'\u5074\u9304\u5B89\u88DD'}],
  dept:[{k:'dp',l:'\u90E8\u9580'},{k:'tot',l:'\u4EBA\u6578',num:1},{k:'ok',l:'\u5DF2\u5728\u5206\u914D\u4E3B\u6A5F',num:1},{k:'used',l:'\u5DF2\u7528\u65B0\u4E3B\u6A5F',num:1},{k:'none',l:'\u65B0\u6A5F\u7121\u7D00\u9304',num:1},{k:'old',l:'\u53EA\u5728\u820A\u6A5F\uFF0F\u4E26\u7528',num:1},{k:'r1',l:'\u79FB\u8F49\u7387',num:1,f:x=>x.r1==null?'\u2014':x.r1+'%'},{k:'r2',l:'\u5DF2\u7528\u65B0\u4E3B\u6A5F\u7387',num:1,f:x=>x.r2==null?'\u2014':x.r2+'%'}],
  hostmig:[{k:'name',l:'\u65B0\u4E3B\u6A5F',sv:x=>ipKey(x.k)},{k:'g',l:'\u7FA4\u7D44\uFF0F\u90E8\u9580'},{k:'tot',l:'\u5206\u914D\u4EBA\u6578',num:1},{k:'ok',l:'\u5DF2\u5230\u4F4D',num:1},{k:'none',l:'\u65B0\u6A5F\u7121\u7D00\u9304',num:1},{k:'r1',l:'\u5230\u4F4D\u7387',num:1,f:x=>x.r1==null?'\u2014':x.r1+'%'}],
  cap:[{k:'name',l:'\u4E3B\u6A5F',sv:x=>ipKey(x.k)},{k:'kind',l:'\u985E\u578B'},{k:'root',l:'\u9304\u5F71\u8CC7\u6599\u593E'},{k:'drv',l:'\u78C1\u789F'},{k:'pct',l:'\u4F7F\u7528\u7387',num:1,sv:x=>x.pct==null?-1:x.pct,f:x=>pctTxt(x.pct)},{k:'free',l:'\u53EF\u7528',num:1,f:x=>x.free==null?'\u2014':x.free.toFixed(0)+' GB'},{k:'size',l:'\u8CC7\u6599\u593E\u5927\u5C0F',num:1,f:x=>mbTxt(x.size)},{k:'avg',l:'\u8FD1 7 \u5929\u65E5\u5747\u65B0\u589E',num:1,f:x=>mbTxt(x.avg)},{k:'net',l:'\u8CC7\u6599\u593E\u6DE8\u8B8A\u5316\uFF0F\u5929',num:1,sv:x=>x.net==null?-1e12:x.net,f:x=>x.net==null?'\u9700\u5169\u6B21\u6536\u96C6':mbTxt(x.net)},{k:'dtf',l:'\u4E0D\u6E05\u7406\u5E7E\u5929\u6EFF',num:1,sv:x=>x.dtf==null?1e9:x.dtf,f:x=>x.dtf==null?'\u2014':x.dtf>365?'1 \u5E74\u4EE5\u4E0A':x.dtf+' \u5929'},{k:'old',l:'\u6700\u820A\u9304\u5F71'},{k:'st',l:'\u72C0\u614B',f:x=>tag(x.st,x.cls)},{k:'t',l:'\u6536\u96C6\u6642\u9593'}],
  exc:[{k:'kind',l:'\u985E\u5225',f:x=>tag(x.kind,x.cls)},{k:'a',l:'\u5DE5\u865F\uFF0F\u5E33\u865F'},{k:'nm',l:'\u59D3\u540D'},{k:'dp',l:'\u90E8\u9580'},{k:'host',l:'\u4E3B\u6A5F',sv:x=>ipKey(x.k)},{k:'n',l:'\u8FD1\u671F\u9304\u5F71\u6578',num:1},{k:'last',l:'\u6700\u5F8C\u4E00\u6B21'},{k:'detail',l:'\u8AAA\u660E',cls:'wrap'}],
  runs:[{k:'name',l:'\u4E3B\u6A5F'},{k:'pc',l:'\u96FB\u8166\u540D\u7A31'},{k:'t',l:'\u6536\u96C6\u6642\u9593'},{k:'st',l:'\u72C0\u614B',f:x=>tag(x.st,x.cls)},{k:'why',l:'\u539F\u56E0',cls:'wrap'},{k:'dirs',l:'\u6383\u63CF\u8CC7\u6599\u593E'},{k:'svc',l:'\u5074\u9304\u670D\u52D9'},{k:'ver',l:'\u7248\u672C'},{k:'dir',l:'\u7D50\u679C\u8CC7\u6599\u593E'}],
  areas:[{k:'run',l:'\u6536\u96C6'},{k:'root',l:'\u8CC7\u6599\u593E'},{k:'area',l:'\u5B50\u8CC7\u6599\u593E'},{k:'hosts',l:'\u542B\u5E7E\u53F0\u4E3B\u6A5F',num:1},{k:'n',l:'\u9304\u5F71\u6578',num:1},{k:'mb',l:'\u5BB9\u91CF',num:1,f:x=>mbTxt(x.mb)}],
  pair:[{k:'host',l:'\u4E3B\u6A5F',sv:x=>ipKey(x.s),f:x=>esc(x.host)+' <span class="note">'+esc((SNO.get(x.s)||{})._no||'')+'</span>'},{k:'rz',l:'\u89D2\u8272'},{k:'a',l:'\u5DE5\u865F',f:x=>esc(x.a)+' <span class="note">'+esc((PNO.get(x.a.toUpperCase())||{})._no||'')+'</span>'},{k:'nm',l:'\u59D3\u540D'},{k:'n',l:'\u9304\u5F71\u6578',num:1},{k:'mb',l:'\u5BB9\u91CF',num:1,f:x=>mbTxt(x.mb)},{k:'first',l:'\u7B2C\u4E00\u6B21'},{k:'last',l:'\u6700\u5F8C\u4E00\u6B21'}],
  hday:[{k:'d',l:'\u65E5\u671F'},{k:'n',l:'\u9304\u5F71\u6578',num:1},{k:'mb',l:'\u65B0\u589E\u5BB9\u91CF',num:1,f:x=>mbTxt(x.mb)},{k:'u',l:'\u4F7F\u7528\u4EBA\u6578',num:1},{k:'loc',l:'\u672C\u6A5F\u6A94\u6578',num:1},{k:'cen',l:'\u96C6\u4E2D\u7AEF\u6A94\u6578',num:1}],
  disk:[{k:'t',l:'\u6536\u96C6\u6642\u9593'},{k:'drv',l:'\u78C1\u789F'},{k:'ty',l:'\u985E\u578B'},{k:'tot',l:'\u7E3D\u91CF GB',num:1},{k:'free',l:'\u53EF\u7528 GB',num:1},{k:'pct',l:'\u4F7F\u7528\u7387',num:1,sv:x=>N(x.pct)==null?-1:N(x.pct),f:x=>pctTxt(N(x.pct))},{k:'st',l:'\u8B80\u53D6'}],
  day:[{k:'host',l:'\u4E3B\u6A5F',sv:x=>ipKey(x.s)},{k:'a',l:'\u5DE5\u865F'},{k:'nm',l:'\u59D3\u540D'},{k:'n',l:'\u9304\u5F71\u6578',num:1},{k:'mb',l:'\u5BB9\u91CF',num:1,f:x=>mbTxt(x.mb)},{k:'l',l:'\u7576\u5929\u6700\u5F8C\u4E00\u6B21'}]
};
/* ---------- modal / drill ---------- */
function openM(title,sections){
  $('#mt').textContent=title;const mb=$('#mb');mb.innerHTML='';
  for(const s of sections){
    if(s.h){const h=document.createElement('h4');h.textContent=s.h;mb.appendChild(h);}
    if(s.text){const p=document.createElement('p');p.className='note';p.textContent=s.text;mb.appendChild(p);}
    if(s.rows){const d=document.createElement('div');mb.appendChild(d);mkTable(d,s.cols,s.rows,{click:s.click,pageSize:20});}
  }
  $('#modal').classList.add('on');
}
function closeM(){$('#modal').classList.remove('on');}
$('#modal').onclick=e=>{if(e.target.id==='modal')closeM();};
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeM();});
const pairRows=f=>num([...PR.values()].filter(f).map(p=>Object.assign({},p,{host:hname(p.s),rz:ROLE[roleOf(p.s)]||'\u672A\u5217\u7BA1',nm:nmOf(p.a)})).sort((x,y)=>byIp(x.s,y.s)||(x.a<y.a?-1:1)),'');
function showP(a){
  const p=PNO.get(String(a).toUpperCase());if(!p)return;
  openM(p._no+'\u3000'+p.a+'\u3000'+(p.nm||'')+'\u3000'+(p.dp||''),[
    {text:'\u4F7F\u7528\u72C0\u614B\uFF1A'+p.st+(p.why?'\u3002'+p.why:'')},
    {h:'\u7528\u904E\u7684\u4E3B\u6A5F\uFF08\u9EDE\u4E00\u5217\u770B\u90A3\u53F0\u4E3B\u6A5F\uFF09',cols:COL.pair,rows:pairRows(x=>x.a.toUpperCase()===p.A),click:x=>showS(x.s)},
    {h:'\u6BCF\u5929\u5728\u54EA\u53F0\uFF08\u8FD1 30 \u5929\uFF09',cols:COL.day,rows:num(ROWS.filter(r=>r.A===p.A&&r.d>=addD(TODAY,-29)).sort((x,y)=>x.d<y.d?1:-1).map(r=>Object.assign({},r,{host:hname(r.s),nm:p.nm,day:r.d})),''),click:x=>showS(x.s)}]);
}
function hostDays(k){const out=[];for(let i=0;i<30;i++){const d=addD(TODAY,-i),h=HD.get(k+'|'+d),y=SYNC.get(k+'|'+d);out.push({d,n:h?h.n:0,mb:h?h.mb:0,u:h?h.users.size:0,loc:y&&y.hasLoc?y.loc:'\u2014',cen:y&&y.hasCen?y.cen:'\u2014'});}return num(out,'');}
function showS(k){
  const s=SNO.get(k);if(!s)return;
  const asg=inList.filter(p=>p.nh===k);
  const secs=[{text:'\u89D2\u8272\uFF1A'+s.rz+(s.g?'\u3000\u7FA4\u7D44\uFF1A'+s.g:'')+'\u3000\u72C0\u614B\uFF1A'+s.st+'\u3000\u5074\u9304\u670D\u52D9\uFF1A'+s.svc+'\u3000\u6700\u5F8C\u6536\u96C6\uFF1A'+(s.lastRun||'\u6C92\u6709\u6536\u96C6\u904E')}];
  if(asg.length)secs.push({h:'\u5206\u914D\u5230\u9019\u53F0\u7684\u4EBA\uFF08'+asg.length+' \u4EBA\uFF0C\u5DF2\u5230\u4F4D '+s.arrived+'\uFF09',cols:COL.people,rows:asg,click:x=>showP(x.a)});
  secs.push({h:'\u5728\u9019\u53F0\u6709\u9304\u5F71\u7684\u5DE5\u865F\uFF08\u9EDE\u4E00\u5217\u770B\u90A3\u500B\u4EBA\uFF09',cols:COL.pair,rows:pairRows(x=>x.s===k),click:x=>showP(x.a)});
  secs.push({h:'\u8FD1 30 \u5929\u6BCF\u65E5\u9304\u5F71\u8207\u540C\u6B65\uFF08\u672C\u6A5F\u6A94\u6578\uFF1D\u9019\u53F0\u81EA\u5DF1\u6536\u96C6\u770B\u5230\u7684\uFF1B\u96C6\u4E2D\u7AEF\uFF1D\u96C6\u4E2D\u9304\u5F71\u4E3B\u6A5F\u770B\u5230\u7684\uFF09',cols:COL.hday,rows:hostDays(k),click:x=>showDay(x.d,k)});
  const dk=DISKS.filter(d=>d.k===k).sort((a,b)=>a.t<b.t?1:-1);
  if(dk.length)secs.push({h:'\u78C1\u789F\uFF08\u6BCF\u6B21\u6536\u96C6\uFF09',cols:COL.disk,rows:num(dk.map(x=>Object.assign({},x)),'')});
  openM(s._no+'\u3000'+s.name,secs);
}
function showDay(d,k){
  const rows=num(ROWS.filter(r=>r.d===d&&(!k||r.s===k)).map(r=>Object.assign({},r,{host:hname(r.s),nm:nmOf(r.a)})).sort((x,y)=>byIp(x.s,y.s)||(x.a<y.a?-1:1)),'');
  openM(d+(k?' '+hname(k):'')+' \u7684\u9304\u5F71\uFF08\u5171 '+rows.reduce((t,r)=>t+r.n,0)+' \u500B\uFF09',[{cols:COL.day,rows,click:r=>showP(r.a)}]);
}
const pList=(t,rows,txt)=>()=>openM(t+'\uFF08'+rows.length+' \u4EBA\uFF09',[{text:txt||'',cols:COL.people,rows,click:x=>showP(x.a)}]);
const sList=(t,rows)=>()=>openM(t,[{cols:COL.srv,rows,click:x=>showS(x.k)}]);
const cList=(t,rows)=>()=>openM(t,[{cols:COL.cap,rows,click:x=>showS(x.k)}]);
const eList=(t,rows)=>()=>openM(t,[{cols:COL.exc,rows,click:x=>x.a&&PNO.has(x.a.toUpperCase())?showP(x.a):showS(x.k)}]);

/* ---------- aggregates for migration ---------- */
const groupBy=(rows,key)=>{const m=new Map();for(const r of rows){const k=key(r);if(!m.has(k))m.set(k,[]);m.get(k).push(r);}return m;};
const migStat=rows=>{const tot=rows.length,ok=rows.filter(p=>p.st===ST.ok).length,used=rows.filter(usedNew).length,none=rows.filter(p=>p.st===ST.none).length,old=rows.filter(p=>p.st===ST.old||p.st===ST.both).length;return {tot,ok,used,none,old,r1:rate(ok,tot),r2:rate(used,tot),rows};};
const depts=num([...groupBy(inList,p=>p.dp)].map(([dp,rows])=>Object.assign({dp},migStat(rows))).sort((a,b)=>a.dp<b.dp?-1:1),'D');
const hostMig=num(servers.filter(s=>s.assigned>0).map(s=>{const m=migStat(inList.filter(p=>p.nh===s.k));return Object.assign({k:s.k,name:s.name,g:s.g},m);}),'H');
/* trend: rolling RD-day window ending each day */
const trend=[];for(let i=29;i>=0;i--){const d=addD(TODAY,-i),from=addD(d,-(RD-1));let used=0,ok=0;
  for(const p of inList){const ac=AC.get(p.A);if(!ac)continue;let u=false,o=false;for(const x of ac.newDays){if(x>=from&&x<=d){u=true;break;}}for(const x of ac.asgDays){if(x>=from&&x<=d){o=true;break;}}if(u)used++;if(o)ok++;}
  trend.push({d,used,ok,r:rate(used,inList.length),r1:rate(ok,inList.length)});}

/* ---------- tabs ---------- */
const TABS=[['ov','\u7E3D\u89BD'],['mig','\u79FB\u8F49'],['p','\u4EBA\u54E1'],['s','\u4E3B\u6A5F'],['cap','\u5BB9\u91CF'],['exc','\u4F8B\u5916'],['run','\u6536\u96C6\u72C0\u6CC1'],['help','\u8AAA\u660E']];
function go(id){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===id));document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.id==='t-'+id));try{localStorage.setItem('sa_rep_tab',id);}catch(e){}}
$('#nav').innerHTML=TABS.map(t=>'<button data-t="'+t[0]+'">'+t[1]+'</button>').join('');
$('#nav').onclick=e=>{const b=e.target.closest('button');if(b)go(b.dataset.t);};
$('#main').innerHTML=TABS.map(t=>'<section class="tab" id="t-'+t[0]+'"></section>').join('');
$('#ttl').textContent='ScreenAnytime \u7BA1\u7406\u5831\u544A';
$('#sub').textContent='\u7522\u751F '+D.gen+'\u3000\u8CC7\u6599\u4F86\u6E90 '+RUNS.length+' \u6B21\u6536\u96C6\uFF08\u6700\u65B0 '+RUNS.reduce((m,r)=>r.t>m?r.t:m,'')+'\uFF09\u3000\u300C\u8FD1\u671F\u300D\uFF1D\u8FD1 '+RD+' \u5929\u3000\u7248\u672C '+D.ver;
const bars=(vals,labels,fmt,onclick)=>{const mx=Math.max(1e-9,...vals);return '<div class="chart">'+vals.map((v,i)=>'<div data-i="'+i+'" title="'+esc(labels[i]+'\uFF1A'+fmt(v))+'" style="height:'+Math.max(1,Math.round(v/mx*100))+'%"></div>').join('')+'</div><div class="axis"><span>'+esc(labels[0])+'</span><span>'+esc(labels[labels.length-1])+'</span></div>';};

/* overview */
(function(){
  const m=migStat(inList),by=st=>inList.filter(p=>p.st===st);
  const shared=servers.filter(s=>s.role==='Shared');
  const hostBad=servers.filter(s=>(s.role==='Shared'||s.role==='Spare')&&(s.cls==='bad'||s.cls==='warn'));
  const oldUsed=servers.filter(s=>s.st.indexOf('\u820A\u6A5F\u4ECD\u5728\u4F7F\u7528')>=0);
  const capBad=cap.filter(c=>c.cls!=='ok');
  const totNew7=(()=>{let t=0;for(let i=1;i<=7;i++){const x=DAYTOT.get(addD(TODAY,-i));if(x)t+=x.mb;}return t/7;})();
  const cards=[
    {v:m.r1==null?'\u2014':m.r1+'%',l:'\u79FB\u8F49\u7387\uFF08\u5DF2\u5728\u5206\u914D\u4E3B\u6A5F '+m.ok+'/'+m.tot+'\uFF09',c:'ok',fn:pList('\u5DF2\u5728\u5206\u914D\u4E3B\u6A5F',by(ST.ok))},
    {v:m.r2==null?'\u2014':m.r2+'%',l:'\u5DF2\u7528\u65B0\u4E3B\u6A5F\uFF08'+m.used+' \u4EBA\uFF09',c:'',fn:pList('\u5DF2\u7528\u65B0\u4E3B\u6A5F',inList.filter(usedNew))},
    {v:by(ST.none).length,l:'\u65B0\u6A5F\u7121\u7D00\u9304\uFF08\u63A8\u5B9A\u4ECD\u7528\u500B\u4EBA\u6A5F\uFF09',c:by(ST.none).length?'bad':'ok',fn:pList('\u65B0\u6A5F\u7121\u7D00\u9304',by(ST.none),'\u65B0\u8DF3\u677F\u6A5F\u4E0A\u6C92\u6709\u9019\u4E9B\u5DE5\u865F\u7684\u9304\u5F71\u3002\u4E5F\u53EF\u80FD\u662F\u8ACB\u5047\u3001\u4EBA\u54E1\u7570\u52D5\uFF0C\u6216\u5074\u9304\uFF0F\u540C\u6B65\u6709\u554F\u984C\uFF0C\u8ACB\u5148\u770B\u300C\u4E3B\u6A5F\u300D\u72C0\u614B\u3002')},
    {v:by(ST.both).length+by(ST.old).length,l:'\u9084\u5728\u7528\u820A\u6A5F\uFF08\u542B\u65B0\u820A\u4E26\u7528\uFF09',c:(by(ST.both).length+by(ST.old).length)?'warn':'ok',fn:pList('\u9084\u5728\u7528\u820A\u6A5F',by(ST.old).concat(by(ST.both)))},
    {v:by(ST.other).length,l:'\u7528\u4E86\u975E\u5206\u914D\u65B0\u4E3B\u6A5F',c:by(ST.other).length?'warn':'ok',fn:pList('\u7528\u4E86\u975E\u5206\u914D\u65B0\u4E3B\u6A5F',by(ST.other))},
    {v:by(ST.idle).length,l:'\u8FD1\u671F\u6C92\u4F7F\u7528',c:'',fn:pList('\u8FD1\u671F\u6C92\u4F7F\u7528',by(ST.idle))},
    {v:hostBad.length,l:'\u65B0\u4E3B\u6A5F\u6709\u72C0\u6CC1',c:hostBad.length?'bad':'ok',fn:sList('\u65B0\u4E3B\u6A5F\u6709\u72C0\u6CC1',hostBad)},
    {v:capBad.length,l:'\u5BB9\u91CF\u9700\u6CE8\u610F',c:capBad.length?'warn':'ok',fn:cList('\u5BB9\u91CF\u9700\u6CE8\u610F',capBad)},
    {v:mbTxt(totNew7),l:'\u8FD1 7 \u5929\u6BCF\u65E5\u65B0\u589E\u9304\u5F71',c:'',fn:()=>go('cap')},
    {v:exc.length,l:'\u4F8B\u5916\uFF08\u5F85\u6838\u5BE6\uFF09',c:exc.length?'warn':'ok',fn:eList('\u4F8B\u5916\uFF08\u5F85\u6838\u5BE6\uFF09',exc)},
    {v:oldUsed.length,l:'\u820A\u6A5F\u4ECD\u5728\u4F7F\u7528',c:oldUsed.length?'warn':'ok',fn:sList('\u820A\u6A5F\u4ECD\u5728\u4F7F\u7528',oldUsed)},
    {v:noRun.length,l:'\u65B0\u4E3B\u6A5F\u8D85\u904E 7 \u5929\u6C92\u6536\u96C6',c:noRun.length?'warn':'ok',fn:sList('\u65B0\u4E3B\u6A5F\u8D85\u904E 7 \u5929\u6C92\u6536\u96C6\uFF08\u6578\u5B57\u53EF\u80FD\u4E0D\u6E96\uFF09',noRun)}
  ];
  cards.forEach((c,i)=>c.no='K'+(i+1));
  const todo=[];
  const add=(n,txt,fn)=>{if(n)todo.push({txt,fn});};
  add(by(ST.none).length,'\u50AC\u79FB\u8F49\uFF1A'+by(ST.none).length+' \u4EBA\u65B0\u8DF3\u677F\u6A5F\u6C92\u6709\u7D00\u9304',cards[2].fn);
  add(by(ST.old).length+by(ST.both).length,'\u8FFD\u820A\u6A5F\u4F7F\u7528\uFF1A'+(by(ST.old).length+by(ST.both).length)+' \u4EBA\u9084\u5728\u7528\u820A\u8DF3\u677F\u6A5F',cards[3].fn);
  add(hostBad.filter(s=>s.cls==='bad').length,'\u67E5\u4E3B\u6A5F\uFF1A'+hostBad.filter(s=>s.cls==='bad').map(s=>s.name+' '+s.st).slice(0,3).join('\uFF1B'),sList('\u65B0\u4E3B\u6A5F\u56B4\u91CD\u72C0\u6CC1',hostBad.filter(s=>s.cls==='bad')));
  add(capBad.length,'\u5BB9\u91CF\uFF1A'+capBad.map(c=>c.name+' '+c.st).slice(0,3).join('\uFF1B'),cards[7].fn);
  add(exc.length,'\u6838\u5BE6\u4F8B\u5916\uFF1A'+exc.length+' \u7B46\uFF08\u7CFB\u7D71\u5E33\u865F\u3001\u540D\u55AE\u5916\u3001\u7528\u5225\u90E8\u9580\u4E3B\u6A5F\uFF09',cards[9].fn);
  add(noRun.length,'\u88DC\u6536\u96C6\uFF1A'+noRun.length+' \u53F0\u65B0\u4E3B\u6A5F\u8D85\u904E 7 \u5929\u6C92\u8DD1\u6536\u96C6',cards[11].fn);
  if(!hasPeople)todo.unshift({txt:'\u6C92\u8B80\u5230\u4EBA\u54E1\u5C0D\u7167\u8868\uFF0C\u79FB\u8F49\u7387\u7121\u6CD5\u8A08\u7B97\uFF08\u770B\u300C\u8AAA\u660E\u300D\uFF09',fn:()=>go('help')});
  const el=$('#t-ov');
  el.innerHTML='<div class="cards">'+cards.map((c,i)=>'<div class="card '+c.c+'" data-i="'+i+'"><div class="no">'+c.no+'</div><div class="v">'+esc(c.v)+'</div><div class="l">'+esc(c.l)+'</div></div>').join('')+'</div>'
   +'<div class="panel"><h3>\u9700\u8981\u8655\u7406\uFF08\u9EDE\u4E00\u884C\u770B\u540D\u55AE\uFF09</h3><ul class="todo">'+(todo.length?todo.map((t,i)=>'<li data-i="'+i+'"><b>T'+(i+1)+'</b>'+esc(t.txt)+'</li>').join(''):'<li>\u76EE\u524D\u6C92\u6709\u8981\u8655\u7406\u7684\u4E8B\u3002</li>')+'</ul></div>'
   +'<div class="two"><div class="panel"><h3>\u5DF2\u7528\u65B0\u4E3B\u6A5F\u6BD4\u4F8B\uFF08\u6BCF\u5929\u5F80\u56DE '+RD+' \u5929\uFF0C\u9EDE\u67F1\u5B50\u770B\u7576\u5929\uFF09</h3><div id="ch1"></div></div><div class="panel"><h3>\u5168\u90E8\u4E3B\u6A5F\u6BCF\u65E5\u65B0\u589E\u9304\u5F71\uFF08\u9EDE\u67F1\u5B50\u770B\u7576\u5929\uFF09</h3><div id="ch2"></div></div></div>';
  el.querySelector('.cards').onclick=e=>{const c=e.target.closest('.card');if(c)cards[+c.dataset.i].fn();};
  el.querySelector('.todo').onclick=e=>{const li=e.target.closest('li[data-i]');if(li)todo[+li.dataset.i].fn();};
  const days=trend.map(t=>t.d);
  $('#ch1').innerHTML=bars(trend.map(t=>t.r||0),days,v=>v+'%');
  $('#ch1').onclick=e=>{const b=e.target.closest('div[data-i]');if(b)showDay(days[+b.dataset.i]);};
  const v2=days.map(d=>(DAYTOT.get(d)||{mb:0}).mb);
  $('#ch2').innerHTML=bars(v2,days,v=>mbTxt(v));
  $('#ch2').onclick=e=>{const b=e.target.closest('div[data-i]');if(b)showDay(days[+b.dataset.i]);};
})();
/* migration tab with sub views */
(function(){
  const el=$('#t-mig');
  const views=[['\u90E8\u9580','dept'],['\u65B0\u4E3B\u6A5F','host'],['\u672A\u79FB\u8F49\u540D\u55AE','list'],['\u6BCF\u65E5\u8DA8\u52E2','trend']];
  el.innerHTML='<div class="sub2">'+views.map((v,i)=>'<button data-v="'+v[1]+'"'+(i?'':' class="on"')+'>'+v[0]+'</button>').join('')+'</div><div id="migv"></div>';
  const show=v=>{el.querySelectorAll('.sub2 button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));const c=$('#migv');
    if(v==='dept')mkTable(c,COL.dept,depts,{click:x=>pList(x.dp,x.rows)()});
    if(v==='host')mkTable(c,COL.hostmig,hostMig,{click:x=>showS(x.k)});
    if(v==='list'){const rows=inList.filter(p=>!usedNew(p)||p.st===ST.both);mkTable(c,COL.people,rows,{click:x=>showP(x.a)});}
    if(v==='trend')mkTable(c,[{k:'d',l:'\u65E5\u671F'},{k:'used',l:'\u5DF2\u7528\u65B0\u4E3B\u6A5F\u4EBA\u6578',num:1},{k:'r',l:'\u5DF2\u7528\u65B0\u4E3B\u6A5F\u7387',num:1,f:x=>x.r==null?'\u2014':x.r+'%'},{k:'ok',l:'\u5728\u5206\u914D\u4E3B\u6A5F\u4EBA\u6578',num:1},{k:'r1',l:'\u5728\u5206\u914D\u4E3B\u6A5F\u7387',num:1,f:x=>x.r1==null?'\u2014':x.r1+'%'}],num(trend.slice().reverse(),''),{click:x=>showDay(x.d)});
  };
  el.querySelector('.sub2').onclick=e=>{const b=e.target.closest('button');if(b)show(b.dataset.v);};
  show('dept');
})();
mkTable($('#t-p'),COL.people,people,{click:x=>showP(x.a)});
mkTable($('#t-s'),COL.srv,servers,{click:x=>showS(x.k)});
mkTable($('#t-cap'),COL.cap,cap,{click:x=>showS(x.k)});
mkTable($('#t-exc'),COL.exc,exc,{click:x=>x.a&&PNO.has(x.a.toUpperCase())?showP(x.a):showS(x.k)});
(function(){
  const el=$('#t-run');
  el.innerHTML='<div class="panel"><h3>\u6BCF\u6B21\u6536\u96C6</h3><div id="rv1"></div></div><div class="panel"><h3>\u65B0\u4E3B\u6A5F\u8D85\u904E 7 \u5929\u6C92\u6536\u96C6</h3><div id="rv2"></div></div><div class="panel"><h3>\u9304\u5F71\u5728\u54EA\u4E9B\u5B50\u8CC7\u6599\u593E\uFF08\u540C\u4E00\u4EFD\u9304\u5F71\u51FA\u73FE\u5728\u5169\u500B\u5B50\u8CC7\u6599\u593E\u6642\uFF0C\u5831\u544A\u53D6\u8F03\u5927\u7684\u4E00\u4EFD\uFF0C\u4E0D\u91CD\u8907\u52A0\u7E3D\uFF09</h3><div id="rv3"></div></div>';
  mkTable($('#rv1'),COL.runs,runs,{click:x=>showS(x.k)});
  mkTable($('#rv2'),COL.srv,noRun,{click:x=>showS(x.k)});
  mkTable($('#rv3'),COL.areas,num(AREAS.slice().sort((a,b)=>a.run<b.run?1:-1),'A'));
})();
$('#t-help').innerHTML='<div class="panel help"><h3>\u6578\u5B57\u600E\u9EBC\u7B97</h3><ol>'
 +'<li>\u6536\u96C6\u7A0B\u5F0F\u53EA\u8B80\u9304\u5F71\u6A94\uFF08*.svl\uFF09\u7684\u540D\u7A31\u3001\u5927\u5C0F\u3001\u6642\u9593\uFF0C\u4E0D\u958B\u6A94\u3001\u4E0D\u6539\u3001\u4E0D\u522A\u3002\u5DE5\u865F\uFF1D\u6A94\u540D\u7B2C\u4E00\u6BB5\uFF1B\u4E3B\u6A5F\uFF1D\u8DEF\u5F91\u4E2D\u7B2C\u4E00\u500B\u50CF\u300C\u82F1\u6587-\u4E09\u4F4D\u6578\u300D\uFF08\u4F8B\u5982 HOST-001\uFF09\u6216 IP \u7684\u8CC7\u6599\u593E\uFF0C\u6C92\u6709\u5C31\u7B97\u6536\u96C6\u90A3\u53F0\u81EA\u5DF1\u3002</li>'
 +'<li>\u540C\u4E00\u4E3B\u6A5F\u3001\u5DE5\u865F\u3001\u65E5\u671F\uFF0C\u96C6\u4E2D\u9304\u5F71\u4E3B\u6A5F\u548C\u4E3B\u6A5F\u672C\u6A5F\u90FD\u770B\u5230\u6642\u53D6\u8F03\u5927\u7684\u4E00\u4EFD\uFF0C\u4E0D\u91CD\u8907\u52A0\u7E3D\u3002</li>'
 +'<li>\u4F7F\u7528\u72C0\u614B\u770B\u8FD1 '+RD+' \u5929\uFF1A\u5DF2\u5728\u5206\u914D\u4E3B\u6A5F\uFF0F\u65B0\u820A\u4E26\u7528\uFF0F\u7528\u4E86\u975E\u5206\u914D\u65B0\u4E3B\u6A5F\uFF0F\u53EA\u5728\u820A\u4E3B\u6A5F\uFF0F\u65B0\u6A5F\u7121\u7D00\u9304\uFF08\u63A8\u5B9A\u4ECD\u7528\u500B\u4EBA\u8DF3\u677F\u6A5F\uFF09\uFF0F\u8FD1\u671F\u6C92\u4F7F\u7528\u3002</li>'
 +'<li>\u79FB\u8F49\u7387\uFF1D\u5DF2\u5728\u5206\u914D\u4E3B\u6A5F \u00F7 \u5C0D\u7167\u8868\u4EBA\u6578\uFF1B\u5DF2\u7528\u65B0\u4E3B\u6A5F\u7387\uFF1D\u6709\u5728\u4EFB\u4F55\u65B0\u4E3B\u6A5F\u9304\u5F71\uFF08\u542B\u65B0\u820A\u4E26\u7528\uFF09\u00F7 \u5C0D\u7167\u8868\u4EBA\u6578\u3002</li>'
 +'<li>\u300C\u65B0\u6A5F\u7121\u7D00\u9304\u300D\u4E5F\u53EF\u80FD\u662F\u8ACB\u5047\u3001\u7570\u52D5\u3001\u5074\u9304\u6216\u540C\u6B65\u7570\u5E38\uFF0C\u6240\u4EE5\u5148\u770B\u300C\u4E3B\u6A5F\u300D\u5206\u9801\u6709\u6C92\u6709\u7D05\u71C8\u3002</li>'
 +'<li>\u6BCF\u65E5\u65B0\u589E\u91CF\u4F9D\u9304\u5F71\u6A94\u65E5\u671F\u56DE\u63A8\uFF0C\u7B2C\u4E00\u6B21\u6536\u96C6\u5C31\u6709\u8FD1 90 \u5929\u8DA8\u52E2\uFF1B\u300C\u8CC7\u6599\u593E\u6DE8\u8B8A\u5316\u300D\u8981\u6536\u96C6\u5169\u6B21\u4EE5\u4E0A\u624D\u7B97\u5F97\u51FA\uFF0C\u6703\u88AB 90 \u5929\u6E05\u7406\u62B5\u92B7\u3002</li>'
 +'<li>\u4E0D\u6E05\u7406\u5E7E\u5929\u6EFF\uFF1D\u78C1\u789F\u53EF\u7528\u7A7A\u9593 \u00F7 \u8FD1 7 \u5929\u65E5\u5747\u65B0\u589E\uFF0C\u662F\u4FDD\u5B88\u4F30\u8A08\u3002\u78C1\u789F\u9580\u6ABB '+D.diskWarn+'%\uFF0F'+D.diskBad+'%\uFF1B\u4FDD\u7559 '+D.retainDays+' \u5929\u3002</li>'
 +'<li>\u4ECA\u5929\u7684\u6578\u5B57\u9084\u5728\u589E\u52A0\uFF0C\u5C6C\u66AB\u5B9A\u3002</li>'
 +'<li>\u4F8B\u5916\u662F\u300C\u5F85\u6838\u5BE6\u300D\uFF0C\u4E0D\u662F\u9055\u898F\u7D50\u8AD6\u3002</li>'
 +'<li>\u9805\u6B21\u56FA\u5B9A\uFF1AK \u5361\u7247\u3001T \u5F85\u8FA6\u3001D \u90E8\u9580\u3001H \u65B0\u4E3B\u6A5F\u3001P \u4EBA\u54E1\u3001S \u4E3B\u6A5F\u3001C \u5BB9\u91CF\u3001E \u4F8B\u5916\u3001R \u6536\u96C6\uFF1B\u91CD\u65B0\u6392\u5E8F\u865F\u78BC\u4E0D\u8B8A\u3002</li></ol>'
 +'<h3>\u5C0D\u7167\u8CC7\u6599</h3><p>\u4EBA\u54E1\u5C0D\u7167\u8868\uFF1A'+esc(D.peopleCsv)+'\u3000'+(hasPeople?PP.size+' \u4EBA\uFF0C\u6A94\u6848\u65E5\u671F '+esc(D.peopleDate):'<b>\u6C92\u8B80\u5230</b>')+'<br>\u4E3B\u6A5F\u6E05\u55AE\uFF1A'+esc(D.hostsCsv)+'\u3000'+(HI.size?HI.size+' \u53F0\uFF0C\u6A94\u6848\u65E5\u671F '+esc(D.hostsDate):'<b>\u6C92\u8B80\u5230</b>')+'<br>\u6536\u96C6\u8CC7\u6599\u593E\uFF1A'+esc(D.input)+'\uFF08\u7565\u904E '+D.skipped+' \u500B\u672A\u5B8C\u6210\u6216\u7248\u672C\u4E0D\u7B26\u7684\uFF09</p></div>';
let t0='ov';try{t0=localStorage.getItem('sa_rep_tab')||'ov';}catch(e){}
go(TABS.some(t=>t[0]===t0)?t0:'ov');
</script></body></html>
'@
$Html = $Html.Replace('__DATA__', $Json)
$Out = Join-Path $OutputFolder ('ScreenAnytime_Report_' + $Now.ToString('yyyyMMdd_HHmm') + '.html')
[IO.File]::WriteAllText($Out, $Html, (New-Object Text.UTF8Encoding $true))
Write-Host ''
Write-Host 'COMPLETED' -ForegroundColor Green
Write-Host "Runs: $($Runs.Count)  Recording rows: $($DailyList.Count)  People: $($People.Count)  Hosts: $($HostRows.Count)"
if ($People.Count -eq 0) { Write-Host "People list not found: $PeopleCsv" -ForegroundColor Yellow }
Write-Host "Report: $Out" -ForegroundColor Yellow
if (-not $NoOpen) { Invoke-Item $Out }
Done 0

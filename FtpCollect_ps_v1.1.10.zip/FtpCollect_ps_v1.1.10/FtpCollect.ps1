﻿<#
.SYNOPSIS
  FtpCollect v1.1.10 -- FTP 主機本機唯讀收集（Serv-U／FileZilla，Windows PowerShell 5.1，不需 Python）。
  在 FTP 主機「上面」執行：設定檔遮密碼後複製、近 N 天 log、帳號／目錄／權限、目錄摘要（不帶完整檔名）、
  證據品質、時區、服務身分、監聽埠、防火牆、排程、NTFS ACL、SMB 分享、憑證到期日。

.USAGE
  雙擊 run.bat（會問 SOC 通知單號與存放目錄），或：
    run.bat -SocTicket SOC-123 [-OutDir D:\FtpCollect\out] [-Days 90] [-MaxMB 500] [-MaxLogGB 1] [-ExtraPaths 'D:\FTPLog;E:\x']
  結束代碼：0＝OK、1＝PARTIAL、2＝FAIL、3＝沒開始跑（參數或環境問題）。

.RULES
  - 不刪、不改主機上任何東西：不呼叫 Remove/Move/Set/Stop/Start、不寫登錄檔、不改 ACL、不改執行原則
    （run.bat 用單次 -ExecutionPolicy Bypass）。不用 Add-Type 編譯（會在 TEMP 寫檔）。
  - 來源一律唯讀開檔、共用 ReadWrite+Delete，不鎖 FTP 服務正在寫的 log。
  - 所有輸出都用「只建新檔」(CreateNew) 寫在本次新開的結果資料夾裡；寫之前檢查路徑在結果資料夾內（Assert-InRun），
    附加寫入只限本次自己建立的檔。
  - 結果資料夾建立之前就中止時（例如沒填通知單號），錯誤只顯示在畫面上，不寫任何檔案。
    存放目錄（預設＝工具資料夾\out）若不存在會建立它（這是唯一在結果資料夾以外建立的東西）。
  - 設定檔：XML／JSON／INI 解析後依「欄位名」遮（字詞邊界，不看帳號值）＋值內的連線字串／URL 帳密／私鑰區塊；
    Serv-U .Archive（屬性區塊格式：欄位名／Val／值／<< 欄位名）依欄位名逐區塊遮：Password* 等密碼區塊整段換成 ***，
    其他值再過一次值內帳密遮罩＋長串（≥32 字元 base64／hex）遮罩；看不懂的 .Archive 才退回白名單模式並標示「需人工抽看」。
    排除：Serv-U\Client\（網頁介面範本）、*.Archive.Backup（備份，會讓帳號數重複）。
    FileZilla log 預設 slim：逐行讀，只留登入、傳輸／檔案操作、CWD 與它們的回應（依連線編號配對，丟掉的指令連回應一起丟），
    報表算出的次數與原檔相同；-FzLogMode raw 改回整份複製。Serv-U log 一律整份。
    log 複製時遮掉 PASS 指令、Password=、URL 帳密；超過 -MaxMB 的 log 分段存，不丟。遮完再自我檢查，殘留就整檔不落地。
    二進位、編碼不明、無法解析者不落地，只記在 manifest。解析錯誤訊息不寫原文（避免帶出值）。

.OUTPUTS  （run_local_<IP>_<主機名>_<時間>\）
  _run_info.txt、_run.csv（狀態＋原因）、_run_log.txt、_error_log.txt
  <IP>\manifest.csv      每個來源檔：kind,status,source_path,size,mtime,out_path,out_bytes,sha256,format,note
  <IP>\accounts.csv      帳號／群組（產品、domain、啟用、群組、允許／拒絕 IP）
  <IP>\dirs.csv          帳號／群組的虛擬路徑→實體路徑與原始權限（含權限來源 user/group）
  <IP>\subdir_summary.csv  每個帳號目錄的第一層子目錄小計（-Days 期間內檔數、大小、樣式前 5；最新修改時間；舊檔數）
  <IP>\servu_users.csv  Serv-U 帳號檔：姓名、家目錄、累計上下傳檔數／位元組、統計起點、最後登入（Unix 秒→當地時間；不含密碼）
  <IP>\dir_summary.csv   每個實體目錄：-Days 期間內的檔數、大小、檔名樣式前 10；整個目錄最新修改時間；期間外舊檔數；是否截斷
  <IP>\evidence_quality.csv、log_coverage.csv、log_settings.csv
  <IP>\host_info.csv（OS、IP、時區、時鐘、服務與執行身分、監聽埠）、firewall.csv、tasks.csv、acl.csv、shares.csv、certs.csv
  <IP>\<磁碟>\...        遮罩後設定檔與 log 的副本（保留原始路徑）

.STATUS
  FAIL    ：找不到 Serv-U／FileZilla 目錄，或沒收到任何主設定檔，或中途中止。
  PARTIAL ：主設定檔有收到，但有任一項：錯誤、未收集檔、讀取／複製不完整、沒解析出帳號、用白名單遮罩（需人工抽看）、
            沒有 log、最新 log 早於 2 天前、log 解析未完成、目錄摘要截斷或讀不到、設定的目錄不存在、目錄路徑無法展開。
            原因寫在 _run.csv。
  OK      ：以上都沒有。
#>
[CmdletBinding()]
param(
    [string]$SocTicket = '',
    [string]$OutDir = '',
    [ValidateRange(1, 400)][int]$Days = 90,
    [ValidateRange(10, 20000)][int]$MaxMB = 500,
    [string]$ExtraPaths = '',
    [ValidateSet('slim', 'raw')][string]$FzLogMode = 'slim',   # FileZilla log：slim＝只留報表要用的行（預設）；raw＝原樣（遮密碼）整份複製，排查用
    [switch]$FzDropListing,                                     # slim 時連 LIST/NLST/MLSD 也不留（更小，但報表就看不到「列目錄」）
    [ValidateRange(0, 1000)][double]$MaxLogGB = 1               # log 讀取上限（來源位元組）：從最新的檔往回挑到這個量為止；0＝不限。正式機忙碌時避免讀好幾小時
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

$VERSION = '1.1.10 (2026-11-12)'
$SCHEMA = '1.1'
$CHUNK = 1MB
$MIN_FREE = 2GB
$MAX_CONFIG = 20MB
$MAX_CERT = 1MB
$ROOT_WALK_MAX = 50000          # 安裝／log 目錄：最多列幾個項目
$ROOT_WALK_SEC = 120
$SUM_MAX_FILES = 300000         # 家目錄摘要：每個目錄最多看幾個項目（檔＋子目錄）
$SUM_DIR_SEC = 120              # 每個目錄最多幾秒
$SUM_TOTAL_SEC = 1200           # 全部目錄合計最多幾秒
$LOG_PARSE_SEC = 900            # log 解析合計最多幾秒
$MAX_PATTERNS = 5000
$MAX_SUBS = 500   # 每個帳號目錄最多記幾個第一層子目錄小計

$UTF8 = New-Object Text.UTF8Encoding($false)
$UTF8BOM = New-Object Text.UTF8Encoding($true)

$DEFAULT_ROOTS = @()
foreach ($b in @($env:ProgramData, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if ($b) { $DEFAULT_ROOTS += @((Join-Path $b 'RhinoSoft\Serv-U'), (Join-Path $b 'Serv-U'), (Join-Path $b 'FileZilla Server'), (Join-Path $b 'filezilla-server')) }
}
$PRODUCT_RX = '(?i)serv-?u|rhinosoft|filezilla'
$MAIN_CONFIG = '(?i)^(serv-u\.archive|servudaemon\.ini|filezilla server\.xml|users\.xml|groups\.xml|settings\.xml)$'
$CONFIG_EXT = @('.xml', '.ini', '.archive', '.config', '.cfg', '.json')
$CERT_EXT = @('.pem', '.crt', '.cer', '.der')
$LOG_NAME = '(?i)\.log(\.\d{1,3}|\.\d{4}-?\d{2}-?\d{2})?$'
$PRIVATE_KEY_MARK = '-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----'

function Ts($t) { if ($t) { ([datetime]$t).ToString('yyyy/MM/dd HH:mm:ss') } else { '' } }

# ======================= 安全寫入（只在結果資料夾內新建） =======================
$script:RunDir = $null
$script:LongOK = $false
$script:Created = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)

function Test-Inside([string]$child, [string]$parent) {
    $c = [IO.Path]::GetFullPath((ConvertFrom-LongPath $child)).TrimEnd('\') + '\'
    $p = [IO.Path]::GetFullPath((ConvertFrom-LongPath $parent)).TrimEnd('\') + '\'
    return $c.StartsWith($p, [StringComparison]::OrdinalIgnoreCase)
}
function ConvertFrom-LongPath([string]$p) {   # 去掉長路徑前綴（顯示／比對用）
    if ($p.StartsWith('\\?\UNC\')) { return '\\' + $p.Substring(8) }
    if ($p.StartsWith('\\?\')) { return $p.Substring(4) }
    return $p
}
function ConvertTo-LongPath([string]$p) {   # 加長路徑前綴（實際開檔用；不支援時原樣）
    if (-not $script:LongOK -or $p.StartsWith('\\?\')) { return $p }
    $f = [IO.Path]::GetFullPath($p)
    if ($f.StartsWith('\\')) { return '\\?\UNC\' + $f.Substring(2) }
    return '\\?\' + $f
}
function Assert-InRun([string]$path) {
    if (-not $script:RunDir -or -not (Test-Inside $path $script:RunDir)) { throw "STOP:安全檢查：要寫入的位置不在結果資料夾內（$path），中止" }
}
function New-RunSubDir([string]$path) {
    Assert-InRun $path
    [void][IO.Directory]::CreateDirectory((ConvertTo-LongPath $path))
}
function New-OutFile([string]$path, [byte[]]$bytes) {
    $path = [IO.Path]::GetFullPath($path)
    Assert-InRun $path
    if ($script:Created.Contains($path)) { throw "STOP:內部錯誤：重複建立 $path" }
    New-RunSubDir ([IO.Path]::GetDirectoryName($path))
    $fs = [IO.File]::Open((ConvertTo-LongPath $path), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)   # 已存在就失敗，不覆蓋
    try { if ($bytes -and $bytes.Length) { $fs.Write($bytes, 0, $bytes.Length) } } finally { $fs.Close() }
    [void]$script:Created.Add($path)
}
function Add-OutText([string]$path, [string]$text) {
    $path = [IO.Path]::GetFullPath($path)
    if (-not $script:Created.Contains($path)) { New-OutFile $path $UTF8BOM.GetPreamble() }
    Assert-InRun $path
    $b = $UTF8.GetBytes($text)
    $fs = [IO.File]::Open((ConvertTo-LongPath $path), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)   # 只附加到本次自己建的檔
    try { $fs.Write($b, 0, $b.Length) } finally { $fs.Close() }
}
function Csv([string]$path, [object[]]$cells) {
    $line = (@($cells) | ForEach-Object { '"' + ([string]$_).Replace('"', '""') + '"' }) -join ','
    Add-OutText $path ($line + "`r`n")
}

# ======================= 執行 LOG 與 ERROR LOG =======================
$script:LogFile = $null; $script:ErrFile = $null
$script:LogBuf = New-Object System.Collections.Generic.List[string]
$script:ErrBuf = New-Object System.Collections.Generic.List[string]
$script:ErrCount = 0
function Write-LogLine([bool]$isErr, [string]$line) {
    try {
        if ($script:LogFile) {
            if ($isErr) { Add-OutText $script:ErrFile ($line + "`r`n") } else { Add-OutText $script:LogFile ($line + "`r`n") }
        } elseif ($isErr) { $script:ErrBuf.Add($line) } else { $script:LogBuf.Add($line) }
    } catch { Write-Host "（寫執行紀錄失敗：$($_.Exception.Message)）" }
}
function Log([string]$msg, [string]$color = '') {
    if ($color) { Write-Host $msg -ForegroundColor $color } else { Write-Host $msg }
    Write-LogLine $false ("{0}  {1}" -f (Get-Date).ToString('yyyy/MM/dd HH:mm:ss'), $msg)
}
function ErrLog([string]$msg) {
    $script:ErrCount++
    Log "[ERROR] $msg" 'Yellow'
    Write-LogLine $true ("{0}  {1}" -f (Get-Date).ToString('yyyy/MM/dd HH:mm:ss'), $msg)
}
function Open-RunLogs([string]$dir) {
    $lf = Join-Path $dir '_run_log.txt'; $ef = Join-Path $dir '_error_log.txt'
    New-OutFile $lf $UTF8BOM.GetPreamble(); New-OutFile $ef $UTF8BOM.GetPreamble()   # 沒錯誤時 _error_log 是空檔
    $script:LogFile = $lf; $script:ErrFile = $ef
    foreach ($l in $script:LogBuf) { Add-OutText $lf ($l + "`r`n") }
    foreach ($l in $script:ErrBuf) { Add-OutText $ef ($l + "`r`n") }
    $script:LogBuf.Clear(); $script:ErrBuf.Clear()
}
function Stop-Early([string]$msg) {
    # 結果資料夾還沒建好前就中止：只顯示在畫面上，不寫任何檔案
    ErrLog $msg
    if (-not $script:LogFile) { Write-Host '（結果資料夾尚未建立，未寫任何檔案；請看上面的錯誤訊息）' }
    exit 3
}

# ======================= 遮罩（依欄位名，字詞邊界） =======================
$SECRET_WORDS = @('pass', 'password', 'passwd', 'passphrase', 'pwd', 'pw', 'pin', 'salt', 'hash', 'hashed', 'secret', 'token',
    'credential', 'credentials', 'apikey', 'privatekey', 'otp', 'hmac', 'digest', 'md5', 'sha', 'sha1', 'sha256', 'sha512', 'ntlm', 'cookie')
$SECRET_SUB = '(?i)password|passwd|passphrase|secret|credential|apikey|privatekey|accesskey|token'
$KEY_PREFIX = @('private', 'api', 'secret', 'access', 'encryption', 'ssh', 'shared', 'pre', 'master', 'session')
$KV_ELEMENTS = @('option', 'item', 'setting', 'param', 'parameter', 'property', 'add', 'entry', 'field', 'var', 'variable', 'pair')
$ACCOUNT_ELEMENTS = @('user', 'users', 'group', 'groups', 'domain', 'domains', 'account', 'accounts', 'member', 'login', 'client', 'mount_point', 'permission')
$script:MaskHits = 0

$RX_PEMKEY = New-Object regex('(?s)-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?(-----END [A-Z0-9 ]*PRIVATE KEY-----|$)')
$RX_KV = New-Object regex('(?i)(\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:][ \t]*)((?:"(?:[^"]|"")*"|''(?:[^'']|'''')*''|\{(?:[^}]|\}\})*\})?[^;&\r\n]*)')
# 殘留檢查：密碼鍵之後必須正好是 *** 再接分隔符號或結尾（不靠同一條 regex 自我驗證）
$RX_KV_LEFT = New-Object regex('(?i)\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:](?![ \t]*\*\*\*[ \t]*(?:[;&\r\n]|$))')
$RX_URLCRED = New-Object regex('(?i)\b([a-z][a-z0-9+.\-]*://[^:/@\s"''<>]*:)([^@\s"''<>/]+)@')
$RX_CLI = New-Object regex('(?i)((?:^|\s)(?:-pw|--?password|/password|/pass|/pw|-passphrase)(?:\s+|=|:))("(?:\\.|""|[^"\\])*"?|''(?:\\.|''''|[^''\\])*''?|\S+)')

function Get-KeyTokens([string]$name) {
    $s = [regex]::Replace($name, '([a-z0-9])([A-Z])', '$1 $2')
    $s = [regex]::Replace($s, '([A-Z]+)([A-Z][a-z])', '$1 $2')
    return @(($s.ToLowerInvariant() -split '[^a-z0-9]+') | Where-Object { $_ })
}
function Test-SecretKey([string]$name) {
    # 依「欄位名」判斷，切成字詞後比對：bypass_ap、passive_mode 不會被當成密碼欄位
    if (-not $name) { return $false }
    $t = @(Get-KeyTokens $name)
    for ($i = 0; $i -lt $t.Count; $i++) {
        $w = $t[$i]
        if ($SECRET_WORDS -contains $w) { return $true }
        if ($w -match $SECRET_SUB) { return $true }
        if ($w -eq 'key' -and $i -gt 0 -and ($KEY_PREFIX -contains $t[$i - 1])) { return $true }
    }
    return $false
}
function Test-ValueClean([string]$v) {
    # 值經過 Protect-Value 不會再變＝沒有殘留（不計次）
    $h = $script:MaskHits; $r = ((Protect-Value $v) -ceq $v); $script:MaskHits = $h
    if ($r -and $RX_KV_LEFT.IsMatch($v)) { $r = $false }
    return $r
}
function Protect-Value([string]$v) {
    # 值裡面的：私鑰區塊、Password=...;、URL 帳密、命令列 -pw xxx
    if (-not $v) { return $v }
    $o = $RX_PEMKEY.Replace($v, '***(private key removed)***')
    $o = $RX_KV.Replace($o, '${1}***')
    $o = $RX_URLCRED.Replace($o, '${1}***@')
    $o = $RX_CLI.Replace($o, '${1}***')
    if ($o -ne $v) { $script:MaskHits++ }
    return $o
}

# ---------- XML ----------
function Get-KvKeyAttr($el) {
    # 「鍵值」型元素（<Option Name="Pass">、<add key=.. value=..>）回傳存放鍵名的屬性名；帳號類元素永遠不是
    $ln = $el.LocalName.ToLowerInvariant()
    if ($ACCOUNT_ELEMENTS -contains $ln) { return '' }
    $isKv = ($KV_ELEMENTS -contains $ln) -or $el.HasAttribute('value')
    if (-not $isKv) {
        foreach ($c in $el.ChildNodes) { if ($c.NodeType -eq [Xml.XmlNodeType]::Element) { return '' } }
        $isKv = $true   # 葉節點且有 name 屬性，也當鍵值
    }
    foreach ($k in @('name', 'Name', 'NAME', 'key', 'Key', 'id', 'Id')) { if ($el.HasAttribute($k)) { return $k } }
    return ''
}
function Hide-XmlNode($node, [string]$keepAttr) {
    if ($node.Attributes) {
        foreach ($a in @($node.Attributes)) {
            if ($a.Name -eq 'xmlns' -or $a.Prefix -eq 'xmlns' -or ($keepAttr -and $a.Name -eq $keepAttr)) { continue }
            if ($a.Value) { $a.Value = '***'; $script:MaskHits++ }
        }
    }
    $hasEl = $false
    foreach ($c in $node.ChildNodes) { if ($c.NodeType -eq [Xml.XmlNodeType]::Element) { $hasEl = $true } }
    foreach ($c in @($node.ChildNodes)) {
        $t = $c.NodeType
        if ($t -eq [Xml.XmlNodeType]::Element) { Hide-XmlNode $c '' }
        elseif ($t -eq [Xml.XmlNodeType]::Text -or $t -eq [Xml.XmlNodeType]::CDATA -or $t -eq [Xml.XmlNodeType]::Comment) {
            if ($c.Value) { $c.Value = '***'; $script:MaskHits++ }   # 連全空白的密碼也遮
        } elseif (-not $hasEl -and ($t -eq [Xml.XmlNodeType]::Whitespace -or $t -eq [Xml.XmlNodeType]::SignificantWhitespace) -and $c.Value) {
            [void]$node.ReplaceChild($node.OwnerDocument.CreateTextNode('***'), $c); $script:MaskHits++
        }
    }
}
function Protect-XmlTree($node) {
    # 同一元素底下被切成多段的 Text／CDATA：合起來看，有帳密就整段換掉
    $tx = @($node.ChildNodes | Where-Object { $_.NodeType -eq [Xml.XmlNodeType]::Text -or $_.NodeType -eq [Xml.XmlNodeType]::CDATA })
    if ($tx.Count -gt 1) {
        $joined = (@($tx | ForEach-Object { $_.Value }) -join '')
        $m = Protect-Value $joined
        if ($m -cne $joined) { $tx[0].Value = $m; for ($i = 1; $i -lt $tx.Count; $i++) { $tx[$i].Value = '' } }
    }
    foreach ($c in @($node.ChildNodes)) {
        $t = $c.NodeType
        if ($t -eq [Xml.XmlNodeType]::Element) {
            if (Test-SecretKey $c.LocalName) { Hide-XmlNode $c ''; continue }
            $ka = Get-KvKeyAttr $c
            if ($ka -and (Test-SecretKey $c.GetAttribute($ka))) { Hide-XmlNode $c $ka; continue }
            foreach ($a in @($c.Attributes)) {
                if ($a.Name -eq 'xmlns' -or $a.Prefix -eq 'xmlns') { continue }
                if (Test-SecretKey $a.LocalName) { if ($a.Value) { $a.Value = '***'; $script:MaskHits++ } }
                else { $a.Value = Protect-Value $a.Value }
            }
            Protect-XmlTree $c
        } elseif ($t -eq [Xml.XmlNodeType]::Text -or $t -eq [Xml.XmlNodeType]::CDATA -or $t -eq [Xml.XmlNodeType]::Comment) {
            $c.Value = Protect-Value $c.Value   # 混合內容、CDATA、註解都逐一處理
        }
    }
}
function Read-XmlDoc([byte[]]$bytes, [string]$text) {
    $rs = New-Object Xml.XmlReaderSettings
    $rs.DtdProcessing = [Xml.DtdProcessing]::Ignore
    $rs.XmlResolver = $null
    $doc = New-Object Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.XmlResolver = $null
    $ok = $false
    if ($null -ne $bytes) {   # 先照檔頭 BOM／encoding 宣告讀
        try { $r = [Xml.XmlReader]::Create([IO.MemoryStream]::new($bytes), $rs); try { $doc.Load($r); $ok = $true } finally { $r.Close() } } catch { $ok = $false }
    }
    if (-not $ok) {
        if (-not $text) { throw 'XML 解析失敗（編碼或格式）' }
        $doc = New-Object Xml.XmlDocument; $doc.PreserveWhitespace = $true; $doc.XmlResolver = $null
        try { $r = [Xml.XmlReader]::Create((New-Object IO.StringReader($text)), $rs); try { $doc.Load($r) } finally { $r.Close() } }
        catch { throw ('XML 解析失敗（{0}）' -f $_.Exception.GetType().Name) }   # 不帶原文訊息
    }
    return $doc
}
function ConvertTo-XmlBytes($doc) {
    foreach ($n in @($doc.ChildNodes)) { if ($n.NodeType -eq [Xml.XmlNodeType]::XmlDeclaration) { $n.Encoding = 'utf-8' } }   # 宣告與實際位元組一致
    $ms = New-Object IO.MemoryStream
    $ws = New-Object Xml.XmlWriterSettings
    $ws.Encoding = $UTF8
    $w = [Xml.XmlWriter]::Create($ms, $ws)
    try { $doc.Save($w) } finally { $w.Close() }
    return , $ms.ToArray()
}
function Add-XmlPairs($el, [string]$parent, $list) {
    $ka = Get-KvKeyAttr $el
    $comp = $el.LocalName
    $key = $el.LocalName
    if ($ka) { $key = $el.GetAttribute($ka); $comp = $el.LocalName + ':' + $key }
    $path = "$parent/$comp"
    foreach ($a in @($el.Attributes)) {
        if ($a.Name -eq 'xmlns' -or $a.Prefix -eq 'xmlns' -or ($ka -and $a.Name -eq $ka)) { continue }
        $k = $a.LocalName; if ($ka) { $k = $key }
        $list.Add([pscustomobject]@{ Path = "$path/@$($a.LocalName)"; Key = $k; Value = $a.Value; Comps = "$path" })
    }
    $txt = ''
    foreach ($c in $el.ChildNodes) {
        if ($c.NodeType -eq [Xml.XmlNodeType]::Text -or $c.NodeType -eq [Xml.XmlNodeType]::CDATA) { $txt += $c.Value }
    }
    if ($txt.Trim()) { $list.Add([pscustomobject]@{ Path = $path; Key = $key; Value = $txt.Trim(); Comps = $path }) }
    foreach ($c in $el.ChildNodes) { if ($c.NodeType -eq [Xml.XmlNodeType]::Element) { Add-XmlPairs $c $path $list } }
}

# ---------- JSON ----------
Add-Type -AssemblyName System.Web.Extensions   # 載入既有組件（不編譯、不寫檔）
function New-JsonSer { $s = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $s.MaxJsonLength = [int]::MaxValue; $s.RecursionLimit = 512; return $s }
function Protect-JsonObj($o) {
    if ($null -eq $o) { return $null }
    if ($o -is [string]) { return (Protect-Value $o) }
    if ($o -is [System.Collections.IDictionary]) {
        foreach ($k in @($o.Keys)) {
            if (Test-SecretKey ([string]$k)) { if ($null -ne $o[$k] -and [string]$o[$k] -ne '') { $o[$k] = '***'; $script:MaskHits++ } }
            else { $o[$k] = Protect-JsonObj $o[$k] }
        }
        return , $o
    }
    if ($o -is [System.Collections.IList]) {   # 陣列（含陣列中的陣列、字串）逐一處理
        for ($i = 0; $i -lt $o.Count; $i++) { $o[$i] = Protect-JsonObj $o[$i] }
        return , $o
    }
    return $o
}
function Add-JsonPairs($o, [string]$path, [string]$key, $list) {
    if ($null -eq $o) { return }
    if ($o -is [string] -or $o -is [ValueType]) { $list.Add([pscustomobject]@{ Path = $path; Key = $key; Value = [string]$o; Comps = $path }); return }
    if ($o -is [System.Collections.IDictionary]) { foreach ($k in @($o.Keys)) { Add-JsonPairs $o[$k] "$path/$k" ([string]$k) $list }; return }
    if ($o -is [System.Collections.IList]) { for ($i = 0; $i -lt $o.Count; $i++) { Add-JsonPairs $o[$i] "$path[$i]" $key $list } }
}

# ---------- INI ----------
$RX_INI = New-Object regex('^\s*(?:[;#].*|\[[^\]]*\]\s*|([^=]+?)\s*=(.*))?$')
function Protect-Ini([string]$text) {
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($line in ($text -split "`r?`n")) {
        $m = $RX_INI.Match($line)
        if (-not $m.Success) { throw '不是 INI 格式' }
        if ($m.Groups[1].Success) {
            $k = $m.Groups[1].Value
            if (Test-SecretKey $k.Trim()) { if ($m.Groups[2].Value) { $script:MaskHits++ }; $line = $k + '=***' }
            else { $line = $k + '=' + (Protect-Value $m.Groups[2].Value) }
        } elseif ($line.TrimStart().StartsWith(';') -or $line.TrimStart().StartsWith('#')) { $line = Protect-Value $line }
        $out.Add($line)
    }
    return ($out -join "`r`n")
}
function Get-IniPairs([string]$text) {
    $list = New-Object System.Collections.Generic.List[object]
    $sec = ''
    foreach ($line in ($text -split "`r?`n")) {
        $t = $line.Trim()
        if ($t -match '^\[(.*)\]$') { $sec = $Matches[1]; continue }
        if ($t -match '^[;#]' -or -not $t) { continue }
        $i = $t.IndexOf('=')
        if ($i -gt 0) { $k = $t.Substring(0, $i).Trim(); $list.Add([pscustomobject]@{ Path = "[$sec]/$k"; Key = $k; Value = $t.Substring($i + 1).Trim(); Comps = "/$k" }) }
    }
    return , $list
}

# ---------- 通用逐行（只給 Serv-U .Archive 用） ----------
$RX_FIRSTID = New-Object regex('[A-Za-z][A-Za-z0-9_.\-]*')
$RX_BLOB = New-Object regex('(?<![A-Za-z0-9+/=\\:%.\-])[A-Za-z0-9+/]{32,}={0,2}(?![A-Za-z0-9+/=])')
$RX_GENKV = New-Object regex('^\s*[<"'']?([A-Za-z][A-Za-z0-9_.\- ]{0,60}?)["''>]?\s*(?:=|:|\s)\s*["'']?(.*?)["'']?\s*(?:</[^>]*>)?\s*$')
$ALLOW_TOKENS = @('dir', 'directory', 'path', 'home', 'root', 'folder', 'virtual', 'physical', 'enable', 'enabled', 'disable', 'disabled',
    'ip', 'ips', 'address', 'allow', 'allowed', 'deny', 'denied', 'access', 'permission', 'permissions', 'rights', 'right', 'domain', 'name',
    'login', 'loginid', 'id', 'user', 'username', 'group', 'groups', 'member', 'members', 'port', 'listener', 'log', 'logs', 'logging', 'level',
    'type', 'max', 'min', 'size', 'days', 'retention', 'rotate', 'rotation', 'quota', 'expire', 'expiration', 'expires', 'ssl', 'tls', 'cert',
    'certificate', 'ftps', 'sftp', 'protocol', 'passive', 'pasv', 'mode', 'flags', 'inherit', 'inherited', 'relpaths', 'locked', 'lock',
    'version', 'limit', 'limits', 'recursive', 'upload', 'download', 'read', 'write', 'delete', 'rename', 'append', 'list', 'create', 'hide')
function Test-AllowKey([string]$k) {
    if (Test-SecretKey $k) { return $false }
    foreach ($t in @(Get-KeyTokens $k)) { if ($ALLOW_TOKENS -contains $t) { return $true } }
    return $false
}
function Protect-Generic([string]$text) {
    # 格式不明（Serv-U .Archive）：只保留「白名單欄位」的值（路徑、啟用、IP、權限、domain、帳號名…），
    # 其他欄位只留欄位名、值不落地；密碼欄位與它底下的整個區塊都不輸出。fail closed。
    $out = New-Object System.Collections.Generic.List[string]
    $lines = @($text -split "`r?`n")
    $depth = 0; $skipAt = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $t = $lines[$i].Trim()
        if (-not $t) { continue }
        $opens = ([regex]::Matches($t, '\{')).Count; $closes = ([regex]::Matches($t, '\}')).Count
        if ($skipAt -ge 0) {
            $depth += $opens - $closes
            if ($depth -le $skipAt) { $skipAt = -1 }
            continue
        }
        if ($t -match '^[{}]+$') { $depth += $opens - $closes; $out.Add($t); continue }
        $next = ''; $jn = $i; for ($j = $i + 1; $j -lt $lines.Count; $j++) { if ($lines[$j].Trim()) { $next = $lines[$j].Trim(); $jn = $j; break } }
        if (($opens -gt $closes) -or $next.StartsWith('{')) {
            # 區塊標頭（同一行或下一行是 {）：先判斷是不是密碼區塊，是就整塊不輸出
            $hdr = $t; $bi = $hdr.IndexOf('{'); if ($bi -ge 0) { $hdr = $hdr.Substring(0, $bi) }
            $hdr = $hdr.Trim().TrimEnd('=', ':').Trim()
            $fid = $RX_FIRSTID.Match($hdr)
            $hk = $(if ($fid.Success) { $fid.Value } else { '' })
            if ((Test-SecretKey $hdr) -or (Test-SecretKey $hk)) {
                $script:MaskHits++; $out.Add("$(if ($hk) { $hk } else { '(block)' }) = ***")
                $skipAt = $depth
                if ($opens -gt $closes) { $depth += $opens - $closes } else { $i = $jn; $depth += 1 }
                continue
            }
            $hm = $RX_GENKV.Match($hdr)
            if ($hm.Success -and $hm.Groups[2].Value.Trim()) {
                $hkey = $hm.Groups[1].Value.Trim(); $hval = $hm.Groups[2].Value.Trim().Trim('"', "'")
                if (Test-AllowKey $hkey) { $out.Add("$hkey = " + $RX_BLOB.Replace((Protect-Value $hval), '***')) } else { $out.Add("$hkey = (not kept)") }
            } elseif ($hdr -match '^["''<\[]?[A-Za-z][A-Za-z0-9_.\- ]{0,60}["''>\]]?$') { $out.Add($hdr.Trim('"', "'", '<', '>', '[', ']')) }
            else { $out.Add('(block)') }
            if ($opens -gt $closes) { $depth += $opens - $closes; $out.Add('{') }
            continue
        }
        $m = $RX_GENKV.Match($t)
        $key = ''; $val = ''
        if ($m.Success) { $key = $m.Groups[1].Value.Trim(); $val = $m.Groups[2].Value.Trim().TrimEnd('{').Trim().Trim('"', "'") }
        if ($key -and $val) {
            if (Test-SecretKey $key) { $out.Add("$key = ***"); $script:MaskHits++ }
            elseif (Test-AllowKey $key) { $v2 = $RX_BLOB.Replace((Protect-Value $val), '***'); $out.Add("$key = $v2") }
            else { $out.Add("$key = (not kept)") }
            continue
        }
        # 其他無法辨識的行：不輸出
    }
    return ($out -join "`r`n")
}
function Get-GenericPairs([string]$text) {
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($line in ($text -split "`r?`n")) {
        $m = $RX_GENKV.Match($line)
        if ($m.Success -and $m.Groups[2].Value) { $k = $m.Groups[1].Value.Trim(); $list.Add([pscustomobject]@{ Path = "/$k"; Key = $k; Value = $m.Groups[2].Value; Comps = "/$k" }) }
    }
    return , $list
}

# ---------- Serv-U .Archive 屬性區塊格式（2026-11-11 實機確認，見 ServU格式_實測 (1111).md） ----------
# 每個欄位：<類別> / <欄位名> / <旗標> / <數量> / Val / <值> / << <欄位名>；區塊可巢狀（例 DirAccess 底下的 Dir、Access）
$RX_SU_END = New-Object regex('^<<\s*(\S.*?)\s*$')
$RX_SU_NAME = New-Object regex('^[A-Za-z][A-Za-z0-9_.]*$')
function Protect-ServUArchive([string]$text) {
    # 不是這種格式回傳 $null（交給後面的 INI／白名單）。規則：
    #  - `Val` 的下一行一律是值（就算長得像欄位名、Val 或 << X），不會被當成結構。
    #  - 密碼類欄位（依欄位名，含所在的外層區塊）裡面：除了 Val 與「堆疊裡已有的區塊」的結束標記，其他每一行都換成 ***。
    #  - 其他值再過值內帳密遮罩＋長串遮罩。Pairs 的值把檔內的 \\ 還原成 \；Inst＝區塊實例路徑（重複的區塊各有編號）。
    $lines = @($text -split "`r?`n")
    $ends = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    $hasVal = $false; $skip = $false
    foreach ($l in $lines) {
        $t = $l.Trim()
        if ($skip) { $skip = $false; continue }   # 值不參與結構判斷
        if ($t -ceq 'Val') { $hasVal = $true; $skip = $true; continue }
        $m = $RX_SU_END.Match($t); if ($m.Success) { [void]$ends.Add($m.Groups[1].Value) }
    }
    if (-not $hasVal -or $ends.Count -eq 0) { return $null }
    $out = New-Object System.Collections.Generic.List[string]
    $pairs = New-Object System.Collections.Generic.List[object]
    $stack = New-Object System.Collections.Generic.List[string]
    $inst = New-Object System.Collections.Generic.List[string]
    $secret = 0; $lastName = ''; $afterVal = $false; $seq = 0
    foreach ($l in $lines) {
        $t = $l.Trim()
        if ($afterVal) {
            $afterVal = $false
            $path = '/' + ($stack -join '/'); $ip = '/' + ($inst -join '/')
            if ($secret -gt 0 -or (Test-SecretKey $lastName)) {
                if ($t) { $script:MaskHits++ }
                $out.Add('***'); $pairs.Add([pscustomobject]@{ Path = $path; Key = $lastName; Value = '***'; Comps = $path; Inst = $ip })
                continue
            }
            $v = $RX_BLOB.Replace((Protect-Value $l), '***')
            $out.Add($v)
            $pairs.Add([pscustomobject]@{ Path = $path; Key = $lastName; Value = $v.Trim().Replace('\\', '\'); Comps = $path; Inst = $ip })
            continue
        }
        if ($t -ceq 'Val') { $out.Add($l); $afterVal = $true; continue }
        $m = $RX_SU_END.Match($t)
        if ($m.Success -and $stack.Contains($m.Groups[1].Value)) {
            $i = $stack.LastIndexOf($m.Groups[1].Value)
            $stack.RemoveRange($i, $stack.Count - $i); $inst.RemoveRange($i, $inst.Count - $i)
            $secret = @($stack | Where-Object { Test-SecretKey $_ }).Count
            $out.Add($l); continue
        }
        $isName = ($RX_SU_NAME.IsMatch($t) -and $ends.Contains($t))
        if ($isName) {
            $stack.Add($t); $seq++; $inst.Add("$t#$seq"); $lastName = $t
            if (Test-SecretKey $t) { $secret++ }
            if ($secret -gt 0 -and -not (Test-SecretKey $t)) { $out.Add('***'); $script:MaskHits++; continue }   # 密碼區塊裡的子欄位名也不保留
            $out.Add($l); continue
        }
        if ($RX_SU_NAME.IsMatch($t)) { $lastName = $t }   # 類別名稱、沒有結束標記的欄位名
        if ($secret -gt 0 -and $t) { $out.Add('***'); $script:MaskHits++; continue }
        $out.Add($RX_BLOB.Replace((Protect-Value $l), '***'))
    }
    return [pscustomobject]@{ Text = ($out -join "`r`n"); Pairs = $pairs }
}

# ---------- 遮完自我檢查（殘留就整檔不落地） ----------
function Test-Residual($pairs, [bool]$checkPath) {
    foreach ($p in $pairs) {
        $v = [string]$p.Value
        if ($v -match $PRIVATE_KEY_MARK) { return "殘留私鑰（$($p.Path)）" }
        if (-not $v -or $v -eq '***') { continue }
        if (-not (Test-ValueClean $v)) { return "值內帳密未遮（$($p.Path)）" }
        $secret = Test-SecretKey $p.Key
        if (-not $secret -and $checkPath) { foreach ($c in ($p.Comps -split '/')) { if ($c -and (Test-SecretKey $c)) { $secret = $true; break } } }
        if ($secret) { return "密碼欄位未遮（$($p.Path)）" }
    }
    return ''
}

function Test-XmlBytes([byte[]]$data) {
    $i = 0
    if ($data.Length -ge 3 -and $data[0] -eq 0xEF -and $data[1] -eq 0xBB -and $data[2] -eq 0xBF) { $i = 3 }
    while ($i -lt $data.Length -and @(9, 10, 13, 32) -contains $data[$i]) { $i++ }
    return ($i -lt $data.Length -and $data[$i] -eq 0x3C -and [Array]::IndexOf($data, [byte]0) -lt 0)
}
function Get-TextFromBytes([byte[]]$data) {
    if ($data.Length -ge 2 -and (($data[0] -eq 0xFF -and $data[1] -eq 0xFE) -or ($data[0] -eq 0xFE -and $data[1] -eq 0xFF))) {
        $enc = New-Object Text.UnicodeEncoding(($data[0] -eq 0xFE), $true, $true)
        try { return $enc.GetString($data, 2, $data.Length - 2) } catch { return $null }
    }
    if ([Array]::IndexOf($data, [byte]0) -ge 0) { return $null }   # 二進位
    $start = 0; if ($data.Length -ge 3 -and $data[0] -eq 0xEF -and $data[1] -eq 0xBB -and $data[2] -eq 0xBF) { $start = 3 }
    try { return (New-Object Text.UTF8Encoding($false, $true)).GetString($data, $start, $data.Length - $start) } catch { }
    try { return [Text.Encoding]::GetEncoding(950, [Text.EncoderFallback]::ExceptionFallback, [Text.DecoderFallback]::ExceptionFallback).GetString($data) } catch { }
    return $null
}

# 回傳物件：Bytes(遮後)、Format、Pairs、Doc(XML)、Text(遮後)、Generic
function Protect-Config([byte[]]$data, [string]$text, [string]$ext) {
    $t = $text.TrimStart([char]0xFEFF, ' ', "`t", "`r", "`n")
    if (-not $t -and (Test-XmlBytes $data)) { $t = '<' }
    $r = [pscustomobject]@{ Bytes = $null; Format = ''; Pairs = $null; Doc = $null; Text = ''; Generic = $false }
    if ($t.StartsWith('<')) {
        try {
            $doc = Read-XmlDoc $data $text
            Protect-XmlTree $doc
            $bytes = ConvertTo-XmlBytes $doc
            $doc2 = Read-XmlDoc $bytes $null   # 重讀遮後輸出，確認是合法 XML 並做殘留檢查
            $pairs = New-Object System.Collections.Generic.List[object]
            Add-XmlPairs $doc2.DocumentElement '' $pairs
            $bad = Test-Residual $pairs $true
            if ($bad) { throw "遮罩自我檢查失敗：$bad" }
            $r.Bytes = $bytes; $r.Format = 'XML'; $r.Pairs = $pairs; $r.Doc = $doc2
            return $r
        } catch { if ($ext -ne '.archive') { throw } }
    }
    if ($t.StartsWith('{') -or $t.StartsWith('[')) {
        $obj = $null
        try { $obj = (New-JsonSer).DeserializeObject($text) } catch { $obj = $null }
        if ($null -ne $obj) {
            $obj = Protect-JsonObj $obj
            $out = (New-JsonSer).Serialize($obj)
            $pairs = New-Object System.Collections.Generic.List[object]
            Add-JsonPairs ((New-JsonSer).DeserializeObject($out)) '' '' $pairs
            $bad = Test-Residual $pairs $false
            if ($bad) { throw "遮罩自我檢查失敗：$bad" }
            $r.Bytes = $UTF8.GetBytes($out); $r.Format = 'JSON'; $r.Pairs = $pairs; $r.Text = $out
            return $r
        }
        if ($t.StartsWith('{')) { if ($ext -ne '.archive') { throw 'JSON 解析失敗' } }
    }
    if ($ext -eq '.archive') {
        $sa = Protect-ServUArchive $text
        if ($null -ne $sa) {
            $bad = Test-Residual $sa.Pairs $true
            if (-not $bad) { foreach ($ol in ($sa.Text -split "`r`n")) { if ($ol -match $PRIVATE_KEY_MARK -or -not (Test-ValueClean $ol)) { $bad = 'Serv-U 區塊遮罩有殘留'; break } } }
            if ($bad) { throw "遮罩自我檢查失敗：$bad" }
            $r.Bytes = $UTF8.GetBytes($sa.Text); $r.Format = 'SERVU-ARCHIVE'; $r.Pairs = $sa.Pairs; $r.Text = $sa.Text
            return $r
        }
    }
    $ini = $null
    try { $ini = Protect-Ini $text } catch { $ini = $null }
    if ($null -ne $ini) {
        $pairs = Get-IniPairs $ini
        $bad = Test-Residual $pairs $false
        if ($bad) { throw "遮罩自我檢查失敗：$bad" }
        $r.Bytes = $UTF8.GetBytes($ini); $r.Format = 'INI'; $r.Pairs = $pairs; $r.Text = $ini
        return $r
    }
    if ($ext -eq '.archive') {
        $g = Protect-Generic $text
        foreach ($gl in ($g -split "`r`n")) { if ($gl -match $PRIVATE_KEY_MARK -or -not (Test-ValueClean $gl)) { throw '遮罩自我檢查失敗：通用遮罩有殘留' } }
        $r.Bytes = $UTF8.GetBytes($g); $r.Format = 'TEXT-ALLOWLIST'; $r.Pairs = (Get-GenericPairs $g); $r.Text = $g; $r.Generic = $true
        return $r
    }
    throw '格式無法確認'
}

# ======================= 檔案讀取／複製（唯讀、共用、驗證） =======================
function Open-Source([string]$path) {
    return [IO.File]::Open((ConvertTo-LongPath $path), [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
}
function Read-AllShared([string]$path, [long]$max) {
    # 回傳 @(bytes, 錯誤)；讀不滿長度＝短讀，視為錯誤
    $fs = Open-Source $path
    try {
        $len = $fs.Length
        if ($len -gt $max) { return @($null, "超過上限 $([int]($max / 1MB)) MB") }
        $data = New-Object byte[] $len
        $off = 0
        while ($off -lt $len) { $k = $fs.Read($data, $off, [int]($len - $off)); if ($k -le 0) { break }; $off += $k }
        if ($off -ne $len) { return @($null, "短讀：讀到 $off / $len 位元組") }
        return @($data, '')
    } finally { $fs.Close() }
}
function Get-Sha256Bytes([byte[]]$b) {
    $h = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($b)) -replace '-', '').ToLower() } finally { $h.Dispose() }
}
function Get-Sha256File([string]$path) {
    $h = [Security.Cryptography.SHA256]::Create(); $fs = Open-Source $path
    try { return ([BitConverter]::ToString($h.ComputeHash($fs)) -replace '-', '').ToLower() } finally { $fs.Close(); $h.Dispose() }
}
function Get-MirrorPath([string]$src) {
    $s = ConvertFrom-LongPath $src
    if ($s -match '^([A-Za-z]):\\(.*)$') { return (Join-Path (Join-Path $script:HostDir $Matches[1].ToUpper()) $Matches[2]) }
    if ($s -match '^\\\\(.*)$') { return (Join-Path (Join-Path $script:HostDir 'UNC') $Matches[1]) }
    throw "無法對應路徑：$s"
}
$L1 = [Text.Encoding]::GetEncoding(28591)   # Latin-1：位元組 1:1 對應，遮罩不會弄壞 Big5／UTF-8 內容
$RX_LOGPASS = New-Object regex('(?im)((?:^|[:>\])\-])[ \t]*PASS[ \t]+)([^\r\n]+)')   # FTP PASS 指令（不分大小寫；Serv-U HidePasswordInLog=0 時 log 會有明碼）
$RX_PEMBEGIN = New-Object regex('-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----')
$RX_PEMEND = New-Object regex('-----END [A-Z0-9 ]*PRIVATE KEY-----')
# 被丟棄（不輸出）的位元組也要更新私鑰狀態：BEGIN 落在丟棄區時，後面保留的內容仍要遮到 END
function Update-PemState([string]$t, [bool]$inPem) {
    if ($inPem) { $em = $RX_PEMEND.Match($t); if (-not $em.Success) { return $true }; $t = $t.Substring($em.Index + $em.Length) }
    $bm = $RX_PEMBEGIN.Matches($t)
    if ($bm.Count -gt 0) { $lb = $bm[$bm.Count - 1]; return (-not $RX_PEMEND.IsMatch($t.Substring($lb.Index))) }
    return $false
}
function Protect-LogText([string]$t) {
    $o = $RX_PEMKEY.Replace($t, '***(private key removed)***')
    $o = $RX_LOGPASS.Replace($o, '${1}***')
    $o = $RX_KV.Replace($o, '${1}***')
    $o = $RX_URLCRED.Replace($o, '${1}***@')
    return $o
}
# 本工具自己切的分段檔名：<副本>.partN；但主機上若真的有同名的來源檔（例 FileZilla 的 fzs-日期.log.part2），改用 .splitN 避免撞名。
# 每個 log 實際用了哪些分段，寫在 manifest 的 out_parts（報表照這欄讀，不靠檔名猜）。
$script:LogMirrors = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
function Get-PartPath([string]$dst, [int]$n) {
    $base = [IO.Path]::GetFullPath($dst)
    $p = "$base.part$n"
    $k = 0
    while ($script:LogMirrors.Contains($p) -or [IO.File]::Exists($p)) {   # 來源同名（.part2／.split2…）或已存在：再換名，直到沒人用
        $k++
        $p = if ($k -eq 1) { "$base.split$n" } else { "$base.split$n-$k" }
    }
    return $p
}
function Copy-LogFile([IO.FileInfo]$f, [string]$dst, [long]$partBytes) {
    # 逐塊（在換行處切）讀來源、遮掉帳密後寫出；超過 partBytes 就換下一個分段檔，不丟資料。
    # 回傳物件：Bytes、Sha（全部輸出串起來）、Note、Bad、Skip、Parts、Redacted
    $src = ConvertFrom-LongPath $f.FullName
    $res = [pscustomobject]@{ Bytes = [long]0; Sha = ''; Note = ''; Bad = $false; Skip = $false; Parts = (New-Object System.Collections.Generic.List[string]); Redacted = 0 }
    $note = @()
    $fi = Open-Source $src
    $sha = [Security.Cryptography.SHA256]::Create()
    $fo = $null
    try {
        $lenAtOpen = $fi.Length
        $head = New-Object byte[] 8192; $hk = $fi.Read($head, 0, 8192); [void]$fi.Seek(0, 'Begin')
        if ($hk -ge 2 -and (($head[0] -eq 0xFF -and $head[1] -eq 0xFE) -or ($head[0] -eq 0xFE -and $head[1] -eq 0xFF))) {
            $res.Skip = $true; $res.Note = 'UTF-16 log：無法在主機上安全遮罩，未收集'; return $res
        }
        if ($hk -gt 0 -and [Array]::IndexOf($head, [byte]0, 0, $hk) -ge 0) { $res.Skip = $true; $res.Note = '不是文字檔（二進位），未收集'; return $res }
        $state = @{ part = 1; cur = [IO.Path]::GetFullPath($dst); curBytes = [long]0 }
        New-OutFile $state.cur $null; $res.Parts.Add($state.cur)
        $fo = [IO.File]::Open((ConvertTo-LongPath $state.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $buf = New-Object byte[] $CHUNK
        $carry = New-Object byte[] 0
        $nRead = [long]0; $eof = $false
        $dropToNl = $false   # 超長（64 MB 沒換行）的一行：整行不保留，直到下一個換行
        $inPem = $false      # 私鑰區塊跨塊：遮到 END 為止
        while (-not $eof) {
            $want = [int][Math]::Min([long]$CHUNK, $lenAtOpen - $nRead)   # 只讀到開檔當下的長度，服務一直寫也不會停不下來
            $k = 0; if ($want -gt 0) { $k = $fi.Read($buf, 0, $want) }
            $emit = $null
            if ($k -le 0) { $eof = $true; $data = $carry; $cut = $carry.Length }
            else {
                $nRead += $k
                $data = New-Object byte[] ($carry.Length + $k)
                [Buffer]::BlockCopy($carry, 0, $data, 0, $carry.Length); [Buffer]::BlockCopy($buf, 0, $data, $carry.Length, $k)
                if ($dropToNl) {
                    $i0 = [Array]::IndexOf($data, [byte]10)
                    if ($i0 -lt 0) { $inPem = Update-PemState ($L1.GetString($data)) $inPem; $keep = [Math]::Min(64, $data.Length); $carry = New-Object byte[] $keep; [Buffer]::BlockCopy($data, $data.Length - $keep, $carry, 0, $keep); continue }
                    $inPem = Update-PemState ($L1.GetString($data, 0, $i0)) $inPem
                    $tmp = New-Object byte[] ($data.Length - $i0); [Buffer]::BlockCopy($data, $i0, $tmp, 0, $tmp.Length); $data = $tmp; $dropToNl = $false
                }
                $nl = [Array]::LastIndexOf($data, [byte]10)
                if ($nl -lt 0 -and $data.Length -lt 64MB) { $carry = $data; continue }   # 一律在換行處切，關鍵字與值不會被切開
                if ($nl -lt 0) { $inPem = Update-PemState ($L1.GetString($data)) $inPem; $emit = '***(over-long line without newline, not kept)***'; $dropToNl = $true; $cut = $data.Length; $res.Redacted++ }
                else { $cut = $nl + 1 }
            }
            if ($null -eq $emit -and $cut -gt 0) {
                $txt = $L1.GetString($data, 0, $cut)
                if ($inPem) {
                    $em = $RX_PEMEND.Match($txt)
                    if ($em.Success) { $txt = $txt.Substring($em.Index + $em.Length); $inPem = $false } else { $txt = '' }
                    $res.Redacted++
                }
                $bm = $RX_PEMBEGIN.Matches($txt)
                if ($bm.Count -gt 0) { $lb = $bm[$bm.Count - 1]; if (-not $RX_PEMEND.IsMatch($txt.Substring($lb.Index))) { $inPem = $true } }
                $emit = Protect-LogText $txt
                if ($emit -cne $txt) { $res.Redacted++ }
            }
            if ($emit) {
                $ob = $L1.GetBytes($emit)
                if ($state.curBytes -gt 0 -and ($state.curBytes + $ob.Length) -gt $partBytes) {
                    $fo.Close(); $state.part++; $state.cur = Get-PartPath $dst $state.part; $state.curBytes = 0
                    New-OutFile $state.cur $null; $res.Parts.Add($state.cur)
                    $fo = [IO.File]::Open((ConvertTo-LongPath $state.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
                }
                $fo.Write($ob, 0, $ob.Length); [void]$sha.TransformBlock($ob, 0, $ob.Length, $null, 0)
                $state.curBytes += $ob.Length; $res.Bytes += $ob.Length
            }
            if (-not $eof) { $rest = $data.Length - $cut; $carry = New-Object byte[] $rest; if ($rest) { [Buffer]::BlockCopy($data, $cut, $carry, 0, $rest) } }
        }
        [void]$sha.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        $res.Sha = ([BitConverter]::ToString($sha.Hash) -replace '-', '').ToLower()
        if ($nRead -lt $lenAtOpen) { $note += "短讀：$nRead / $lenAtOpen 位元組"; $res.Bad = $true }
    } finally {
        $fi.Close(); if ($fo) { $fo.Close() }; $sha.Dispose()
    }
    # 驗證：所有分段長度合計與 hash 都要對得上
    $vh = [Security.Cryptography.SHA256]::Create(); $vlen = [long]0
    try {
        foreach ($pp in $res.Parts) {
            $vf = Open-Source $pp
            try { $vb = New-Object byte[] $CHUNK; while (($vk = $vf.Read($vb, 0, $CHUNK)) -gt 0) { [void]$vh.TransformBlock($vb, 0, $vk, $null, 0); $vlen += $vk } } finally { $vf.Close() }
        }
        [void]$vh.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        if ($vlen -ne $res.Bytes -or (([BitConverter]::ToString($vh.Hash) -replace '-', '').ToLower()) -ne $res.Sha) { $note += "副本驗證不符（長度 $vlen／$($res.Bytes)）"; $res.Bad = $true }
    } finally { $vh.Dispose() }
    if ($res.Parts.Count -gt 1) { $note += "分成 $($res.Parts.Count) 段（每段約 $([int]($partBytes / 1MB)) MB）" }
    if ($res.Redacted) { $note += "遮掉帳密（$($res.Redacted) 個區塊有遮）" }
    try {
        $after = New-Object IO.FileInfo((ConvertTo-LongPath $src))
        if (-not $after.Exists) { $note += '複製完成後來源已不在（可能被輪替）' }
        elseif ($after.Length -ne $f.Length -or $after.LastWriteTime -ne $f.LastWriteTime) { $note += '複製中檔案有變動（服務正在寫）' }
    } catch { $note += '複製後無法再讀來源資訊' }
    $res.Note = ($note -join '；')
    return $res
}
# ======================= FileZilla log 精簡複製（slim） =======================
# 原則：slim 的每一個決定，都在「模擬 FtpReport 的 FileZilla 解析器」（ftp_report.py parse_logs）。
#  - 解析器的狀態（每個「連線編號|IP」：目前帳號 user、USER 嘗試的帳號 attempt、掛起的指令 pending）在這裡一模一樣地維護。
#  - 一行只有在「解析器處理它時狀態完全不變、也不產生任何紀錄」才丟；其他都留。因此報表在 slim 上的結果跟原檔相同。
#    例：PASV／TYPE／NOOP 在沒有掛起時、沒有掛起時的回應、掛起中的 1xx 回應 → 丟；
#    會改變帳號的行（括號裡的帳號跟目前不同）、會清掉掛起的指令、最終回應、登入失敗字樣 → 留。
#  - 整台主機第一個被解析的行、第一個回應行一定留（報表用「有沒有回應」決定要不要改用指令次數，不能因精簡而改變）。
#  - 狀態跨檔延續；不論這個檔輸出成 slim 還是整份（格式認不出來），都要過同一個狀態更新（整份的用輸出副本更新，就是報表會看到的內容）。
#    檔案收集失敗時，狀態還原成處理這個檔之前。
#  - 讀到開檔當下的長度為止（服務還在寫也不追）；最後沒有換行的半行照樣處理（整份複製也會留它）。
#  - 單行超過 $FZ_MAXLINE 位元組：那一行不保留，標示「不完整」（狀態 PARTIAL），不宣稱跟原檔相同。
# 解析用 UTF-8 解碼（跟報表一樣）、\s \d 等跟 Python 一致；輸出原始位元組（含帳密遮罩）。
$RX_FZ1L = New-Object regex('^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?)(Z)?\s+(\S{1,3})\s+\[([^\]]*)\]\s?(.*)$', 'Compiled')
$RX_FZBR = New-Object regex('^(.*?Session)\s+(\d+)\s+([0-9A-Fa-f:.]+)(?:\s+(.+?))?\s*$', 'Compiled')
$RX_FZ09L = New-Object regex('^\((\d+)\)\s*(\d{4}/\d{1,2}/\d{1,2} (?:(?:上午|下午|AM|PM) )?\d{1,2}:\d{2}:\d{2})\s*([AP]M|上午|下午)?\s*-\s*(.*?)\s*\(([0-9A-Fa-f:.]+)\)>\s?(.*)$', 'Compiled')   # 0.9：時間前可能有「上午／下午」（中文地區設定，168.100 實測）
$RX_FZCODE = New-Object regex('^(\d{3})(?:[ -]|$)', 'Compiled')
$RX_FZLOGINFAIL = New-Object regex('(?i)login incorrect|authentication failed|invalid password|login failed', 'Compiled')
$RX_FZNEEDMASK = New-Object regex('(?i)-----BEGIN|PASS[ \t]|\b(?:password|passwd|pwd|pass|passphrase|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|shared[_-]?key)[ \t]*[=:]|://\S*@', 'Compiled')   # Protect-LogText 會動到的行一定符合這個（私鑰、PASS 指令、key=、URL 帳密）；其他行不呼叫，省時間
$FZ_MAXLINE = 16MB
$RX_FZHI = New-Object regex('[^\x00-\x7F]', 'Compiled')
$UTF8R = New-Object Text.UTF8Encoding($false, $false)   # 解碼錯誤換成 U+FFFD（同 Python errors='replace'）
$FZ_PEND = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)   # 解析器會掛起等回應的指令
foreach ($v in @('USER', 'PASS', 'CWD', 'XCWD', 'CDUP', 'XCUP', 'STOR', 'APPE', 'STOU', 'RETR', 'DELE', 'RNFR', 'RNTO', 'MKD', 'XMKD', 'RMD', 'XRMD', 'LIST', 'NLST', 'MLSD')) { [void]$FZ_PEND.Add($v) }
$FZ_KEEP = New-Object 'System.Collections.Generic.HashSet[string]' ($FZ_PEND, [StringComparer]::Ordinal)   # 一律留的指令
if ($FzDropListing) { foreach ($v in @('LIST', 'NLST', 'MLSD')) { [void]$FZ_KEEP.Remove($v) } }
# 狀態：S[「連線編號|IP」] = @(目前帳號, USER 嘗試的帳號, 掛起的指令)；undo＝這個檔改過的連線原值（收集失敗時還原）
function New-FzState { return @{ S = (New-Object 'System.Collections.Generic.Dictionary[string,string[]]' ([StringComparer]::Ordinal)); matched = $false; resp = $false; undo = $null; um = $false; ur = $false } }
function Start-FzFile { $z = $script:Fz; $z.undo = (New-Object 'System.Collections.Generic.Dictionary[string,string[]]' ([StringComparer]::Ordinal)); $z.um = $z.matched; $z.ur = $z.resp }
function Undo-FzFile {
    $z = $script:Fz; if ($null -eq $z.undo) { return }
    foreach ($kv in $z.undo.GetEnumerator()) { if ($null -eq $kv.Value) { [void]$z.S.Remove($kv.Key) } else { $z.S[$kv.Key] = $kv.Value } }
    $z.matched = $z.um; $z.resp = $z.ur; $z.undo = $null
}
$script:Fz = New-FzState
function Test-FzLog([IO.FileInfo]$f) {
    # 看開頭 64 KB：有 FileZilla 0.9／1.x 格式的行才輸出 slim（其他整份複製，但狀態一樣要更新）
    $fs = Open-Source (ConvertFrom-LongPath $f.FullName)
    try {
        $buf = New-Object byte[] 65536; $k = $fs.Read($buf, 0, 65536)
        if ($k -le 0) { return $false }
        if ($k -ge 2 -and (($buf[0] -eq 0xFF -and $buf[1] -eq 0xFE) -or ($buf[0] -eq 0xFE -and $buf[1] -eq 0xFF))) { return $false }
        if ([Array]::IndexOf($buf, [byte]0, 0, $k) -ge 0) { return $false }
        $n = 0
        foreach ($ln in ($UTF8R.GetString($buf, 0, $k) -split "`n")) {
            $ln = $ln.TrimEnd("`r")
            if ($RX_FZ09L.IsMatch($ln)) { return $true }
            $m = $RX_FZ1L.Match($ln); if ($m.Success -and $RX_FZBR.IsMatch($m.Groups[4].Value)) { return $true }
            if (++$n -ge 400) { break }
        }
        return $false
    } finally { $fs.Close() }
}
function Write-SlimChunk($st, [IO.MemoryStream]$ms, $sha, $res, [string]$dst, [long]$partBytes) {
    # 把累積的位元組寫出（約 1 MB 一次）；超過 partBytes 換下一段。獨立成函式：迴圈裡不能 dot-source（會讓整個函式的變數變慢）
    if (-not $ms.Length) { return }
    $ob = $ms.ToArray(); $ms.SetLength(0)
    if ($st.curBytes -gt 0 -and ($st.curBytes + $ob.Length) -gt $partBytes) {
        $st.fo.Close(); $st.part++; $st.cur = Get-PartPath $dst $st.part; $st.curBytes = 0
        New-OutFile $st.cur $null; $res.Parts.Add($st.cur)
        $st.fo = [IO.File]::Open((ConvertTo-LongPath $st.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    }
    $st.fo.Write($ob, 0, $ob.Length); [void]$sha.TransformBlock($ob, 0, $ob.Length, $null, 0)
    $st.curBytes += $ob.Length; $res.Bytes += $ob.Length
}
function Invoke-FzStream([string[]]$inputs, [string]$dst, [long]$partBytes, [bool]$write) {
    # $write=$true：讀來源（$inputs 只有一個），輸出 slim；$write=$false：只更新狀態（讀整份複製的輸出副本，依序各段）。
    # 回傳 Bytes、Sha、Parts、Kept、Dropped、Overlong、ReadBytes、Short、Redacted
    $res = [pscustomobject]@{ Bytes = [long]0; Sha = ''; Parts = (New-Object System.Collections.Generic.List[string]); Kept = [long]0; Dropped = [long]0
        Overlong = 0; ReadBytes = [long]0; Short = $false; Redacted = 0 }
    $Z = $script:Fz; $S = $Z.S; $undo = $Z.undo
    $keepV = $FZ_KEEP; $pendV = $FZ_PEND
    $r1 = $RX_FZ1L; $rbr = $RX_FZBR; $r09 = $RX_FZ09L; $rc = $RX_FZCODE; $rlf = $RX_FZLOGINFAIL; $rneed = $RX_FZNEEDMASK; $u8 = $UTF8R; $l1 = $L1
    $sha = $null; $st = @{ part = 1; cur = ''; curBytes = [long]0; fo = $null }; $ms = $null
    $kept = [long]0; $dropped = [long]0; $red = 0; $over = 0
    $sbo = New-Object Text.StringBuilder; $crlf = [char[]]@([char]13, [char]10); $rhi = $RX_FZHI
    $lastTs = $null; $lastOk = $false; $ci = [Globalization.CultureInfo]::InvariantCulture; $tsv = [datetime]::MinValue
    try {
        if ($write) {
            $sha = [Security.Cryptography.SHA256]::Create(); $ms = New-Object IO.MemoryStream
            $st.cur = [IO.Path]::GetFullPath($dst); New-OutFile $st.cur $null; $res.Parts.Add($st.cur)
            $st.fo = [IO.File]::Open((ConvertTo-LongPath $st.cur), [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        }
        $buf = New-Object byte[] 1048576
        foreach ($inp in $inputs) {
            $fs = Open-Source $inp
            try {
                $len = $fs.Length; $nRead = [long]0
                $carry = New-Object byte[] 0; $skipToNl = $false; $eof = $false
                while (-not $eof) {
                    $want = [int][Math]::Min([long]$buf.Length, $len - $nRead)   # 只讀到開檔當下的長度
                    $k = 0; if ($want -gt 0) { $k = $fs.Read($buf, 0, $want) }
                    if ($k -le 0) { $eof = $true; $data = $carry; $end = $carry.Length }
                    else {
                        $nRead += $k
                        $data = New-Object byte[] ($carry.Length + $k)
                        [Buffer]::BlockCopy($carry, 0, $data, 0, $carry.Length); [Buffer]::BlockCopy($buf, 0, $data, $carry.Length, $k)
                        $end = [Array]::LastIndexOf($data, [byte]10) + 1   # 只處理到最後一個換行，其餘留到下一塊
                        if ($end -le 0) {
                            if ($data.Length -gt $FZ_MAXLINE) { if (-not $skipToNl) { $over++ }; $skipToNl = $true; $carry = New-Object byte[] 0 }   # 超長行：不保留、不解析
                            else { $carry = $data }
                            continue
                        }
                    }
                    # 這一塊（到最後一個換行為止）用 Latin-1 轉成字串：位元組 1:1 對應，切行、輸出都不會改到內容
                    $text = $l1.GetString($data, 0, $end)
                    $pos = 0
                    while ($pos -lt $end) {
                        $nl = $text.IndexOf("`n", $pos)
                        if ($nl -lt 0) { $next = $end } else { $next = $nl + 1 }   # EOF 時沒有換行的半行也處理
                        if ($skipToNl) { $skipToNl = $false; $pos = $next; continue }   # 超長行的尾巴
                        if (($next - $pos) -gt $FZ_MAXLINE) { $over++; $pos = $next; continue }
                        $raw = $text.Substring($pos, $next - $pos); $pos = $next   # 原始內容（含換行）
                        if ($rneed.IsMatch($raw)) {   # 可能含帳密：用遮過的內容（報表看到的就是遮過的）
                            $o = Protect-LogText $raw; if ($o -cne $raw) { $red++; $raw = $o }
                        }
                        $line = $raw.TrimEnd($crlf)   # 同 Python rstrip('\r\n')
                        if ($rhi.IsMatch($line)) { $line = $u8.GetString($l1.GetBytes($line)) }   # 有非 ASCII：照報表用 UTF-8 解碼後再解析
                        # ---- 解析（同 ftp_report.parse_logs）
                        $keep = $false; $ok = $false; $isCmd = $false; $isResp = $false
                        $p09 = $line.StartsWith('(', [StringComparison]::Ordinal)   # 0.9 格式以 ( 開頭；1.x 以數字開頭，兩個不會同時成立
                        if (-not $p09) { $m = $r1.Match($line) }
                        if (-not $p09 -and $m.Success) {
                            $g = $m.Groups; $bm = $rbr.Match($g[4].Value)
                            if ($bm.Success) {
                                $tsS = $g[1].Value.Replace(' ', 'T').Substring(0, 19)
                                if ($tsS -cne $lastTs) { $lastTs = $tsS; $lastOk = [datetime]::TryParseExact($tsS, "yyyy-MM-dd'T'HH:mm:ss", $ci, 'None', [ref]$tsv) }
                                if ($lastOk) {
                                    $ok = $true; $key = $bm.Groups[2].Value + '|' + $bm.Groups[3].Value; $buser = $bm.Groups[4].Value.Trim()
                                    $d = $g[3].Value; $msg = $g[5].Value
                                    $isCmd = ($d -ceq '>>'); $isResp = ($d -ceq '<<')
                                    if ($msg.StartsWith('Command: ', [StringComparison]::Ordinal)) { $msg = $msg.Substring(9); $isCmd = $true; $isResp = $false }
                                    elseif ($msg.StartsWith('Response: ', [StringComparison]::Ordinal)) { $msg = $msg.Substring(10); $isCmd = $false; $isResp = $true }
                                }
                            }
                        } elseif ($p09) {
                            $m = $r09.Match($line)
                            if ($m.Success) {
                                $g = $m.Groups; $tsS = $g[2].Value
                                if ($tsS -cne $lastTs) { $lastTs = $tsS; $lastOk = [datetime]::TryParseExact(($tsS -replace ' (上午|下午|AM|PM) ', ' '), 'yyyy/M/d H:mm:ss', $ci, 'None', [ref]$tsv) }
                                if ($lastOk) {
                                    $ok = $true; $key = $g[1].Value + '|' + $g[5].Value; $buser = $g[4].Value.Trim()
                                    if ($buser -eq '(not logged in)' -or $buser -eq 'not logged in') { $buser = '' }   # -eq 不分大小寫＝Python .lower()
                                    $msg = $g[6].Value
                                    $isResp = $rc.IsMatch($msg); $isCmd = -not $isResp
                                }
                            }
                        }
                        if ($ok) {
                            if (-not $Z.matched) { $Z.matched = $true; $keep = $true }
                            $e = $null
                            if ($S.TryGetValue($key, [ref]$e)) { $curU = $e[0]; $curA = $e[1]; $curP = $e[2] } else { $e = $null; $curU = ''; $curA = ''; $curP = '' }
                            $newU = $curU; $newP = $curP; $newA = $curA
                            if ($buser -and $buser -cne $curU) { $newU = $buser; $keep = $true }   # 這行會改變目前帳號
                            if ($isCmd) {
                                $t = $msg.Trim(); $sp = $t.IndexOf(' ')
                                if ($sp -ge 0) { $verb = $t.Substring(0, $sp).ToUpperInvariant(); $arg = $t.Substring($sp + 1).Trim() } else { $verb = $t.ToUpperInvariant(); $arg = '' }
                                if ($keepV.Contains($verb) -or $curP) { $keep = $true }   # 一律留的指令；或有掛起（這行會清掉／換掉掛起）
                                if ($verb -ceq 'USER') { $newA = $arg; $newU = $buser }   # 同報表：attempt＝參數、user＝這行的帳號或空
                                if ($pendV.Contains($verb)) { $newP = $verb } else { $newP = '' }
                            } elseif ($isResp) {
                                if (-not $Z.resp) { $Z.resp = $true; $keep = $true }
                                $cm = $rc.Match($msg.Trim())
                                if (-not $cm.Success -or -not $curP) {
                                    if ($curA -and $rlf.IsMatch($msg)) { $keep = $true }   # 會記一筆登入失敗
                                } elseif ([int]$cm.Groups[1].Value -ge 200) {
                                    $keep = $true; $newP = ''
                                    if (($curP -ceq 'USER' -or $curP -ceq 'PASS') -and [int]$cm.Groups[1].Value -eq 230 -and -not $newU -and $curA) { $newU = $curA }
                                }
                            }
                            if (($keep -or -not $write) -and ($newU -cne $curU -or $newA -cne $curA -or $newP -cne $curP)) {   # 留下的行才改變狀態（丟掉的行本來就不改）；只更新狀態時每行都算
                                if ($null -ne $undo -and -not $undo.ContainsKey($key)) { if ($null -eq $e) { $undo[$key] = $null } else { $undo[$key] = [string[]]$e.Clone() } }
                                if ($null -eq $e) { $e = [string[]]@('', '', ''); $S[$key] = $e }
                                $e[0] = $newU; $e[1] = $newA; $e[2] = $newP
                            }
                        }
                        if ($write) {
                            if ($keep) {
                                [void]$sbo.Append($raw); $kept++
                                if ($sbo.Length -ge 1048576) { $ob = $l1.GetBytes($sbo.ToString()); [void]$sbo.Clear(); $ms.Write($ob, 0, $ob.Length); Write-SlimChunk $st $ms $sha $res $dst $partBytes }
                            }
                            else { $dropped++ }
                        }
                    }
                    if (-not $eof) { $rest = $data.Length - $end; $carry = New-Object byte[] $rest; if ($rest) { [Buffer]::BlockCopy($data, $end, $carry, 0, $rest) } }
                }
                $res.ReadBytes += $nRead
                if ($nRead -lt $len) { $res.Short = $true }
            } finally { $fs.Close() }
        }
        if ($write) {
            $ob = $l1.GetBytes($sbo.ToString()); [void]$sbo.Clear(); $ms.Write($ob, 0, $ob.Length)
            Write-SlimChunk $st $ms $sha $res $dst $partBytes
            [void]$sha.TransformFinalBlock((New-Object byte[] 0), 0, 0)
            $res.Sha = ([BitConverter]::ToString($sha.Hash) -replace '-', '').ToLower()
        }
    } finally {
        if ($st.fo) { $st.fo.Close() }
        if ($sha) { $sha.Dispose() }
    }
    $res.Kept = $kept; $res.Dropped = $dropped; $res.Redacted = $red; $res.Overlong = $over
    return $res
}
function Copy-FzSlim([IO.FileInfo]$f, [string]$dst, [long]$partBytes) {
    # 回傳物件同 Copy-LogFile，另有 Kept、Dropped、SrcBytes、Incomplete
    $src = ConvertFrom-LongPath $f.FullName; $swc = [Diagnostics.Stopwatch]::StartNew()
    $z = Invoke-FzStream @($src) $dst $partBytes $true
    $res = [pscustomobject]@{ Bytes = $z.Bytes; Sha = $z.Sha; Note = ''; Bad = $false; Skip = $false; Parts = $z.Parts; Redacted = $z.Redacted
        Kept = $z.Kept; Dropped = $z.Dropped; SrcBytes = [long]$f.Length; Incomplete = '' }
    $note = @()
    if ($z.Short) { $note += "短讀：$($z.ReadBytes) / $($f.Length) 位元組"; $res.Bad = $true }
    if ($z.Overlong) { $res.Incomplete = "有 $($z.Overlong) 行超過 $([int]($FZ_MAXLINE / 1MB)) MB，未保留（這個檔的 slim 與原檔不完全相同）"; $note += $res.Incomplete }
    $vh = [Security.Cryptography.SHA256]::Create(); $vlen = [long]0
    try {
        foreach ($pp in $res.Parts) {
            $vf = Open-Source $pp
            try { $vb = New-Object byte[] $CHUNK; while (($vk = $vf.Read($vb, 0, $CHUNK)) -gt 0) { [void]$vh.TransformBlock($vb, 0, $vk, $null, 0); $vlen += $vk } } finally { $vf.Close() }
        }
        [void]$vh.TransformFinalBlock((New-Object byte[] 0), 0, 0)
        if ($vlen -ne $res.Bytes -or (([BitConverter]::ToString($vh.Hash) -replace '-', '').ToLower()) -ne $res.Sha) { $note += "副本驗證不符（長度 $vlen／$($res.Bytes)）"; $res.Bad = $true }
    } finally { $vh.Dispose() }
    $pct = $(if ($res.SrcBytes) { [Math]::Round(100.0 * $res.Bytes / $res.SrcBytes, 1) } else { 0 })
    $note += "slim：原始 $($z.ReadBytes) → $($res.Bytes) 位元組（$pct%），保留 $($res.Kept) 行、略過 $($res.Dropped) 行，花 $([int]$swc.Elapsed.TotalSeconds) 秒"
    if ($res.Parts.Count -gt 1) { $note += "分成 $($res.Parts.Count) 段" }
    if ($res.Redacted) { $note += "遮掉帳密 $($res.Redacted) 行" }
    try {
        $after = New-Object IO.FileInfo((ConvertTo-LongPath $src))
        if (-not $after.Exists) { $note += '複製完成後來源已不在（可能被輪替）' }
        elseif ($after.Length -ne $f.Length -or $after.LastWriteTime -ne $f.LastWriteTime) { $note += '複製中檔案有變動（服務正在寫；只收到開檔當下的長度）' }
    } catch { $note += '複製後無法再讀來源資訊' }
    $res.Note = ($note -join '；')
    return $res
}

# ======================= 目錄走訪（串流、上限、長路徑、不跟隨連結） =======================
function Get-WalkFiles([string]$root, [int]$maxEntries, [int]$maxSec) {
    # 回傳 Files(List[FileInfo])、Errors(List[string])、Truncated
    $res = [pscustomobject]@{ Files = (New-Object System.Collections.Generic.List[IO.FileInfo]); Errors = (New-Object System.Collections.Generic.List[string]); Truncated = '' }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $fi = New-Object IO.FileInfo((ConvertTo-LongPath $root))
    if ($fi.Exists) { $res.Files.Add($fi); return $res }
    $stack = New-Object 'System.Collections.Generic.Stack[string]'
    $stack.Push((ConvertTo-LongPath $root))
    $count = 0
    while ($stack.Count -gt 0) {
        if ($sw.Elapsed.TotalSeconds -gt $maxSec) { $res.Truncated = "超過 $maxSec 秒"; break }
        $d = $stack.Pop()
        try {
            foreach ($e in (New-Object IO.DirectoryInfo($d)).EnumerateFileSystemInfos()) {
                $count++
                if ($count -gt $maxEntries) { $res.Truncated = "超過 $maxEntries 項"; break }
                if (($count % 100) -eq 0 -and $sw.Elapsed.TotalSeconds -gt $maxSec) { $res.Truncated = "超過 $maxSec 秒"; break }
                if ($e.Attributes -band [IO.FileAttributes]::Directory) {
                    if (-not ($e.Attributes -band [IO.FileAttributes]::ReparsePoint)) { $stack.Push($e.FullName) }
                } else { $res.Files.Add([IO.FileInfo]$e) }
            }
        } catch { $res.Errors.Add(("{0}：{1}" -f (ConvertFrom-LongPath $d), $_.Exception.GetType().Name)) }
        if ($res.Truncated) { break }
    }
    return $res
}
$script:PatCache = New-Object Collections.Hashtable ([StringComparer]::Ordinal)
function Get-NamePattern([string]$n) {
    # 檔名樣式：數字→#、4 個字母以上的字只留前 3 個＋*、非英數（中文等）→*；保證不會原樣重現完整檔名
    $ck = [regex]::Replace($n, '\d', '#')
    if ($ck -cne $n -and $script:PatCache.ContainsKey($ck)) { return $script:PatCache[$ck] }
    $p = Get-NamePatternCore $n
    if ($ck -cne $n -and $script:PatCache.Count -lt 20000) { $script:PatCache[$ck] = $p }
    return $p
}
function Get-NamePatternCore([string]$n) {
    $ext = [IO.Path]::GetExtension($n); $base = $n
    if ($ext -match '^\.[A-Za-z0-9]{1,6}$') { $base = $n.Substring(0, $n.Length - $ext.Length) } else { $ext = '' }
    $b = [regex]::Replace($base, '\d', '#')
    $b = [regex]::Replace($b, '[A-Za-z]{4,}', { param($m) $m.Value.Substring(0, 3) + '*' })
    $b = [regex]::Replace($b, '[^\x20-\x7E]+', '*')
    $p = $b + [regex]::Replace($ext, '\d', '#')
    if ($p -ceq $n) { $p = [regex]::Replace($b, '[A-Za-z]', 'a') + [regex]::Replace($ext, '\d', '#') }
    if ($p -ceq $n) { $p = '*' + $ext }
    if ($p.Length -gt 80) { $p = $p.Substring(0, 77) + '...' }
    return $p
}
function Get-DirSummary([string]$path, [datetime]$cutoff, [Diagnostics.Stopwatch]$global) {
    # 只統計 -Days 期間內有修改的檔（檔數、大小、檔名樣式）；期間外的只計數；另記整個目錄最新修改時間
    $r = @{ path = $path; exists = 'no'; files = 0; bytes = [long]0; old = 0; dirs = 0; newest = $null
        patterns = @{}; other = 0; seconds = 0; truncated = ''; errors = 0; links = 0; excluded = 0; subs = @{} }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    if (-not (New-Object IO.DirectoryInfo((ConvertTo-LongPath $path))).Exists) { return $r }
    $r.exists = 'yes'
    if ($global.Elapsed.TotalSeconds -gt $SUM_TOTAL_SEC) { $r.truncated = "全部目錄合計超過 $SUM_TOTAL_SEC 秒，未掃"; return $r }
    $stack = New-Object 'System.Collections.Generic.Stack[string]'
    $stack.Push((ConvertTo-LongPath $path))
    $tops = New-Object 'System.Collections.Generic.Stack[string]'   # 每個項目屬於哪個第一層子目錄（根目錄本身的檔＝(root)）
    $tops.Push('(root)')
    $entries = 0
    while ($stack.Count -gt 0) {
        if ($sw.Elapsed.TotalSeconds -gt $SUM_DIR_SEC) { $r.truncated = "超過 $SUM_DIR_SEC 秒"; break }
        if ($global.Elapsed.TotalSeconds -gt $SUM_TOTAL_SEC) { $r.truncated = "全部目錄合計超過 $SUM_TOTAL_SEC 秒"; break }
        $d = $stack.Pop(); $top = $tops.Pop()
        try {
            foreach ($e in (New-Object IO.DirectoryInfo($d)).EnumerateFileSystemInfos()) {
                $entries++
                if ($entries -gt $SUM_MAX_FILES) { $r.truncated = "超過 $SUM_MAX_FILES 項"; break }
                if (($entries % 200) -eq 0) {
                    if ($sw.Elapsed.TotalSeconds -gt $SUM_DIR_SEC) { $r.truncated = "超過 $SUM_DIR_SEC 秒"; break }
                    if ($global.Elapsed.TotalSeconds -gt $SUM_TOTAL_SEC) { $r.truncated = "全部目錄合計超過 $SUM_TOTAL_SEC 秒"; break }
                }
                if ($e.Attributes -band [IO.FileAttributes]::Directory) {
                    if ($e.Attributes -band [IO.FileAttributes]::ReparsePoint) { $r.links++ }
                    elseif (((ConvertFrom-LongPath $e.FullName).TrimEnd('\') + '\').StartsWith($script:OutDirPrefix, [StringComparison]::OrdinalIgnoreCase)) { $r.excluded++ }   # 本工具的存放目錄不算
                    else {
                        $r.dirs++; $stack.Push($e.FullName)
                        if ($top -eq '(root)') { $tops.Push($e.Name) } else { $tops.Push($top) }
                    }
                    continue
                }
                $f = [IO.FileInfo]$e
                $t = $f.LastWriteTime
                if ($null -eq $r.newest -or $t -gt $r.newest) { $r.newest = $t }
                # 第一層子目錄小計（上限 $MAX_SUBS 個，超過的併入 (其他)）
                $sk = $top; if (-not $r.subs.ContainsKey($sk) -and $r.subs.Count -ge $MAX_SUBS) { $sk = '(其他)' }
                if (-not $r.subs.ContainsKey($sk)) { $r.subs[$sk] = @{ files = 0; bytes = [long]0; old = 0; newest = $null; patterns = @{} } }
                $sb = $r.subs[$sk]
                if ($null -eq $sb.newest -or $t -gt $sb.newest) { $sb.newest = $t }
                if ($t -lt $cutoff) { $sb.old++ } else {
                    $sb.files++; $sb.bytes += $f.Length
                    $sp = Get-NamePattern $f.Name
                    if ($sb.patterns.ContainsKey($sp)) { $sb.patterns[$sp]++ } elseif ($sb.patterns.Count -lt 20) { $sb.patterns[$sp] = 1 }
                }
                if ($t -lt $cutoff) { $r.old++; continue }
                $r.files++
                $r.bytes += $f.Length
                $p = Get-NamePattern $f.Name
                if ($r.patterns.ContainsKey($p)) { $r.patterns[$p]++ } elseif ($r.patterns.Count -lt $MAX_PATTERNS) { $r.patterns[$p] = 1 } else { $r.other++ }
            }
        } catch { $r.errors++ }
        if ($r.truncated) { break }
    }
    $r.seconds = [Math]::Round($sw.Elapsed.TotalSeconds, 1)
    return $r
}
# ======================= 帳號／目錄解析（從遮後設定檔） =======================
$script:Accounts = New-Object System.Collections.Generic.List[object]
$script:Dirs = New-Object System.Collections.Generic.List[object]
function CT($el, [string]$name) {
    $n = $el.SelectSingleNode("./*[local-name()='$name']")
    if ($n) { return $n.InnerText.Trim() } else { return '' }
}
function Resolve-NativePath([string]$raw, [string]$account, [string]$domain) {
    # 展開帳號目錄變數：FileZilla %u、%<user>、:u（0.9 版）；Serv-U %USER%、%DOMAIN%；系統環境變數。展不開的留空（只留原值）
    if (-not $raw) { return '' }
    $p = $raw
    $RXU = '(?i)%user_name%|%username%|%user%|%<user>|%u\b|:u\b'
    if ($account) { $p = [regex]::Replace($p, $RXU, { param($m) $account }) }
    elseif ($p -match $RXU) { return '' }   # 群組的帳號變數：之後依成員展開
    if ($domain) { $p = [regex]::Replace($p, '(?i)%domain%', { param($m) $domain }) }
    $p = [Environment]::ExpandEnvironmentVariables($p)
    if ($p -match '%') { return '' }
    $p = $p.Replace('/', '\')
    if ($p -match '^[A-Za-z]:\\?$') { return $p.Substring(0, 2) + '\' }
    return $p.TrimEnd('\')
}
function Add-Account($product, $cfg, $domain, $name, $kind, $enabled, $groups, $allow, $deny, $method) {
    $script:Accounts.Add([pscustomobject]@{ product = $product; config = $cfg; domain = $domain; name = $name; kind = $kind; enabled = $enabled; groups = $groups; allow = $allow; deny = $deny; method = $method })
}
function Add-Dir($product, $cfg, $domain, $ownerKind, $owner, $virtual, $raw, $perm, $isHome, $method) {
    $acct = ''; if ($ownerKind -ne 'group') { $acct = $owner }   # 群組的 %u 不能代入群組名，之後依成員展開
    $script:Dirs.Add([pscustomobject]@{ product = $product; config = $cfg; domain = $domain; ownerKind = $ownerKind; owner = $owner; virtual = $virtual
            raw = $raw; physical = (Resolve-NativePath $raw $acct $domain); perm = $perm; isHome = $isHome; method = $method; expanded = $false })
}
function Read-FzNew($doc, [string]$cfg) {
    # FileZilla Server 1.x：users.xml／groups.xml（<user name>、<group name>、<mount_point>）
    foreach ($kind in @('user', 'group')) {
        foreach ($u in @($doc.SelectNodes("//*[local-name()='$kind' and @name]"))) {
            $name = $u.GetAttribute('name')
            $groups = (@($u.SelectNodes("./*[local-name()='group' and not(@name)]") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
            Add-Account 'FileZilla' $cfg '' $name $kind $u.GetAttribute('enabled') $groups (CT $u 'allowed_ips') (CT $u 'disallowed_ips') 'fz1-xml'
            foreach ($m in @($u.SelectNodes("./*[local-name()='mount_point']"))) {
                $raw = $m.GetAttribute('native_path'); if (-not $raw) { $raw = $m.GetAttribute('new_native_path') }
                $perm = "access=$($m.GetAttribute('access'));recursive=$($m.GetAttribute('recursive'));flags=$($m.GetAttribute('flags'))"
                Add-Dir 'FileZilla' $cfg '' $kind $name $m.GetAttribute('tvfs_path') $raw $perm $(if ($m.GetAttribute('tvfs_path') -eq '/') { 'yes' } else { '' }) 'fz1-xml'
            }
        }
    }
}
function Read-FzOld($doc, [string]$cfg) {
    # FileZilla Server 0.9.x：FileZilla Server.xml（<User Name>、<Option Name>、<Permission Dir>）
    foreach ($kind in @('User', 'Group')) {
        foreach ($u in @($doc.SelectNodes("//*[local-name()='$kind' and @Name]"))) {
            $name = $u.GetAttribute('Name')
            $opt = @{}; foreach ($o in @($u.SelectNodes("./*[local-name()='Option']"))) { $opt[$o.GetAttribute('Name')] = $o.InnerText.Trim() }
            $allow = (@($u.SelectNodes("./*[local-name()='IpFilter']/*[local-name()='Allowed']/*") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
            $deny = (@($u.SelectNodes("./*[local-name()='IpFilter']/*[local-name()='Disallowed']/*") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
            $g = ''; if ($opt.ContainsKey('Group')) { $g = $opt['Group'] }
            $en = ''; if ($opt.ContainsKey('Enabled')) { $en = $opt['Enabled'] }
            Add-Account 'FileZilla' $cfg '' $name $kind.ToLower() $en $g $allow $deny 'fz09-xml'
            foreach ($p in @($u.SelectNodes("./*[local-name()='Permissions']/*[local-name()='Permission']"))) {
                $po = @(); $isHome = ''
                foreach ($o in @($p.SelectNodes("./*[local-name()='Option']"))) {
                    $po += ($o.GetAttribute('Name') + '=' + $o.InnerText.Trim())
                    if ($o.GetAttribute('Name') -eq 'IsHome' -and $o.InnerText.Trim() -eq '1') { $isHome = 'yes' }
                }
                $alias = (@($p.SelectNodes(".//*[local-name()='Alias']") | ForEach-Object { $_.InnerText.Trim() }) -join ';')
                $virt = $alias; if ($isHome) { $virt = '/' + $(if ($alias) { ";$alias" } else { '' }) }
                Add-Dir 'FileZilla' $cfg '' $kind.ToLower() $name $virt $p.GetAttribute('Dir') ($po -join ';') $isHome 'fz09-xml'
            }
        }
    }
}
function Read-ServUIni([string]$text, [string]$cfg) {
    # Serv-U 6 以前：ServUDaemon.ini（[USER=name|domainNo]、HomeDir、AccessN=path|flags、IPAccessN）
    $sec = ''; $cur = $null; $items = @()
    $flush = {
        if ($cur) {
            Add-Account 'ServU' $cfg $cur.domain $cur.name $cur.kind $cur.enabled $cur.groups (($cur.ips | Where-Object { $_ -match '^A' }) -join ';') (($cur.ips | Where-Object { $_ -match '^D' }) -join ';') 'servu-ini'
            if ($cur.home) { Add-Dir 'ServU' $cfg $cur.domain $cur.kind $cur.name '/' $cur.home '' 'yes' 'servu-ini' }
            foreach ($a in $cur.access) { $parts = $a -split '\|', 2; $pm = ''; if ($parts.Count -gt 1) { $pm = $parts[1] }; Add-Dir 'ServU' $cfg $cur.domain $cur.kind $cur.name '' $parts[0] $pm '' 'servu-ini' }
        }
    }
    foreach ($line in ($text -split "`r?`n")) {
        $t = $line.Trim()
        if ($t -match '^\[(.*)\]$') {
            . $flush; $cur = $null
            $sec = $Matches[1]
            if ($sec -match '^(?i)(USER|GROUP)=([^|]+)(?:\|(\d+))?') {
                $cur = @{ kind = $Matches[1].ToLower(); name = $Matches[2]; domain = $(if ($Matches[3]) { $Matches[3] } else { '' }); enabled = ''; groups = ''; home = ''; access = @(); ips = @() }
            }
            continue
        }
        if (-not $cur -or $t -notmatch '^([^=]+)=(.*)$') { continue }
        $k = $Matches[1].Trim(); $v = $Matches[2].Trim()
        if ($k -ieq 'HomeDir') { $cur.home = $v }
        elseif ($k -match '^(?i)Access\d+$') { $cur.access += $v }
        elseif ($k -match '^(?i)IPAccess\d+$') { $cur.ips += $v }
        elseif ($k -ieq 'Enable' -or $k -ieq 'Disable') { $cur.enabled = "$k=$v" }
        elseif ($k -ieq 'Groups' -or $k -ieq 'Group') { $cur.groups = $v }
    }
    . $flush
}
function Read-ServUGeneric([string]$text, [string]$cfg, $pairs) {
    # Serv-U 15 .Archive：格式尚未在本公司主機確認 → 啟發式（帳號＝檔名、domain＝上層資料夾），標 heuristic
    $leaf = [IO.Path]::GetFileNameWithoutExtension($cfg)
    $parent = [IO.Path]::GetFileName([IO.Path]::GetDirectoryName($cfg))
    $isUser = ([IO.Path]::GetFileName([IO.Path]::GetDirectoryName([IO.Path]::GetDirectoryName($cfg))) -ieq 'Users')   # ...\Users\<domain>\<帳號>.Archive
    $name = ''; $domain = ''
    if ($isUser) { $name = $leaf; $domain = $parent }
    $en = ''; $allow = @(); $deny = @(); $ds = @()
    foreach ($p in $pairs) {
        $tk = @(Get-KeyTokens $p.Key)
        $v = [string]$p.Value
        if (-not $isUser -and -not $name -and ($p.Key -match '^(?i)(login ?id|user ?name|user ?id|login)$') -and $v -and $v -ne '***') { $name = $v }
        if ($tk -contains 'enabled' -or $tk -contains 'enable' -or $tk -contains 'disabled') { if (-not $en) { $en = "$($p.Key)=$v" } }
        if ((($tk -contains 'ip') -or ($tk -contains 'ips') -or ($tk -contains 'address')) -and $v -match '\d+\.\d+') { if ($tk -contains 'deny' -or $tk -contains 'disallowed' -or $tk -contains 'denied') { $deny += $v } else { $allow += $v } }
        if (@($tk | Where-Object { @('dir', 'directory', 'path', 'home', 'root', 'folder') -contains $_ }).Count -gt 0 -and ($v -match '^[A-Za-z]:\\|^\\\\|^%')) {
            if (-not (($tk -contains 'log') -or ($tk -contains 'logs') -or ($tk -contains 'cert') -or ($tk -contains 'certificate'))) { $ds += , @($p.Key, $v) }
        }
    }
    if ($name -or $ds.Count) {
        if (-not $name) { $name = "($leaf)" }
        Add-Account 'ServU' $cfg $domain $name $(if ($isUser) { 'user' } else { 'unknown' }) $en '' ($allow -join ';') ($deny -join ';') 'servu-heuristic'
        foreach ($d in $ds) { Add-Dir 'ServU' $cfg $domain $(if ($isUser) { 'user' } else { 'unknown' }) $name '' $d[1] ("key=" + $d[0]) $(if ($d[0] -match '(?i)home') { 'yes' } else { '' }) 'servu-heuristic' }
    }
}
$script:SuUsers = New-Object System.Collections.Generic.List[object]
$script:SuLog = New-Object System.Collections.Generic.List[object]
$script:SuLdap = New-Object System.Collections.Generic.List[object]
$script:SuMain = New-Object System.Collections.Generic.List[string]
$script:SuIssues = New-Object System.Collections.Generic.List[string]
$UNIX0 = New-Object DateTime(1970, 1, 1, 0, 0, 0, [DateTimeKind]::Utc)
function ConvertFrom-UnixSec([string]$v) {
    $n = [long]0
    if ([long]::TryParse(([string]$v).Trim(), [ref]$n) -and $n -gt 0 -and $n -lt 32503680000) { return (Ts $UNIX0.AddSeconds($n).ToLocalTime()) }
    return ''
}
function Read-ServUArchive($pairs, [string]$cfg) {
    # Serv-U 15 .Archive（區塊格式）：Users\<domain>\<帳號>.Archive → 帳號、家目錄、DirAccess、累計統計；
    # Serv-U.Archive → LogFilePath／LogToFile、LDAP 驗證設定（只記錄，AD 登入屬個人不納入轉置）
    $leaf = [IO.Path]::GetFileNameWithoutExtension($cfg)
    $dir = [IO.Path]::GetDirectoryName($cfg)
    $domain = [IO.Path]::GetFileName($dir)
    $gp = [IO.Path]::GetFileName([IO.Path]::GetDirectoryName($dir))
    if ($gp -ieq 'Users' -or $gp -ieq 'Groups') {
        $kind = $(if ($gp -ieq 'Users') { 'user' } else { 'group' })
        $f = @{}; $da = New-Object System.Collections.Generic.List[object]
        foreach ($p in $pairs) {
            $k = [string]$p.Key; $v = [string]$p.Value
            if (-not $k -or $v -eq '***') { continue }
            if ($p.Path -match '(?i)/DirAccess(/|$)' -and $k -ine 'DirAccess') {
                if ($k -ieq 'Dir') { $da.Add(@{ dir = $v; access = '' }) }
                elseif ($k -ieq 'Access' -and $da.Count -and -not $da[$da.Count - 1].access) { $da[$da.Count - 1].access = $v }
                continue
            }
            if (-not $f.ContainsKey($k)) { $f[$k] = $v }
        }
        $g = { param($n) if ($f.ContainsKey($n)) { [string]$f[$n] } else { '' } }
        $name = & $g 'LoginID'; if (-not $name) { $name = $leaf }
        $en = ''
        foreach ($ek in @('Enabled', 'Enable', 'Disabled', 'Disable', 'AccountDisabled')) { if ($f.ContainsKey($ek)) { $en = "$ek=$($f[$ek])"; break } }
        Add-Account 'ServU' $cfg $domain $name $kind $en '' '' '' 'servu-archive'
        $homeDir = & $g 'HomeDir'
        if ($homeDir) { Add-Dir 'ServU' $cfg $domain $kind $name '/' $homeDir '' 'yes' 'servu-archive' }
        foreach ($d in $da) {
            $raw = [string]$d.dir
            if ($homeDir) { $raw = [regex]::Replace($raw, '(?i)%HOME%', { param($m) $homeDir }) }
            Add-Dir 'ServU' $cfg $domain $kind $name '' $raw "access=$($d.access)" '' 'servu-archive'
        }
        $script:SuUsers.Add([pscustomobject]@{ domain = $domain; name = $name; kind = $kind; full = (& $g 'FullName'); home = $homeDir
                up = (& $g 'FilesUploaded'); down = (& $g 'FilesDownloaded'); bup = (& $g 'BytesUploaded'); bdown = (& $g 'BytesDownloaded')
                since = (ConvertFrom-UnixSec (& $g 'StatisticsStartTime')); last = (ConvertFrom-UnixSec (& $g 'LastLoginTime')); lastOut = (ConvertFrom-UnixSec (& $g 'LastLogoutTime')); cfg = $cfg })
        return
    }
    if ($leaf -ieq 'Serv-U') {
        $script:SuMain.Add($cfg)
        # 同一個容器實例（例：第 2 個 Domain 區塊）裡的 LogFilePath 與 LogToFile 才配對；欄位自己的區塊不算容器
        $parentOf = { param($p0) $ip0 = [string]$p0.Inst; $lastSeg = $ip0.Substring($ip0.LastIndexOf('/') + 1); if ($lastSeg -like "$($p0.Key)#*") { $ip0.Substring(0, [Math]::Max(0, $ip0.LastIndexOf('/'))) } else { $ip0 } }
        $ltfAll = @($pairs | Where-Object { $_.Key -ieq 'LogToFile' })
        foreach ($x in @($pairs | Where-Object { $_.Key -ieq 'LogFilePath' -and $_.Value -and $_.Value -ne '***' })) {
            $par = & $parentOf $x
            $ltf = @($ltfAll | Where-Object { (& $parentOf $_) -eq $par } | Select-Object -First 1)
            $script:SuLog.Add([pscustomobject]@{ Config = $cfg; Key = $x.Inst; LogFilePath = [string]$x.Value; LogToFile = $(if ($ltf.Count) { [string]$ltf[0].Value } else { '' }) })
        }
        foreach ($p in $pairs) {
            if ($script:SuLdap.Count -ge 40) { break }
            $full = "$($p.Path)/$($p.Key)"
            if ((@(Get-KeyTokens $full) -contains 'ldap') -and $p.Value -ne '***') { $script:SuLdap.Add([pscustomobject]@{ Path = $full; Key = [string]$p.Key; Value = [string]$p.Value }) }
        }
    }
}

# ======================= log 解析 =======================
$RX_DATE = New-Object regex('(?<y>\d{4})[-/](?<m>\d{1,2})[-/](?<d>\d{1,2})[T ]\d{1,2}:\d{2}|(?<d2>\d{2})(?<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(?<y2>\d{2})\s+\d{2}:\d{2}', 'Compiled, IgnoreCase')
$RX_UTCZ = New-Object regex('\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z', 'Compiled')
$RX_OP = New-Object regex('(?<up>\b(?:STOR|APPE|STOU)\b|Received file|\buploaded\b|已成功收到檔案)|(?<down>\bRETR\b|Sent file|\bdownloaded\b|已成功發送檔)|(?<oth>\b(?:DELE|RNFR|RNTO|X?MKD|X?RMD|NLST|MLSD|LIST)\b|Deleted file|Renamed file|Created directory|Removed directory|檔已移除|目錄已創建)|(?<ok>\b230\b|Logged on|logged in|Login successful|" 已登入)|(?<fail>\b530\b|Login failed|Login incorrect|Invalid password|Authentication failed)', 'Compiled, IgnoreCase')
$MONTHS = @{ jan = 1; feb = 2; mar = 3; apr = 4; may = 5; jun = 6; jul = 7; aug = 8; sep = 9; oct = 10; nov = 11; dec = 12 }

# ======================= 其他小工具 =======================
function Get-LocalIPv4 {
    try {
        $ip = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True' |
            Sort-Object { if ($_.DefaultIPGateway) { 0 } else { 1 } } |
            ForEach-Object { $_.IPAddress } | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' -and $_ -notmatch '^(127|169\.254)\.' } |
            Select-Object -First 1
        if ($ip) { return $ip }
    } catch { ErrLog "取本機 IP 失敗：$($_.Exception.Message)" }
    return 'unknown-ip'
}
function Get-ExePath([string]$cmd) { $m = [regex]::Match($cmd, '^\s*"?([^"]+?\.exe)'); if ($m.Success) { return $m.Groups[1].Value } else { return '' } }
function CimVal($o, [string]$n) { try { $p = $o.CimInstanceProperties[$n]; if ($p) { return $p.Value } } catch { }; return $null }
function Test-PortSpec($spec, $ports, $ranges) {
    foreach ($s in @($spec)) {
        $s = [string]$s
        $lo = -1; $hi = -1
        if ($s -match '^(\d+)-(\d+)$') { $lo = [int]$Matches[1]; $hi = [int]$Matches[2] } elseif ($s -match '^\d+$') { $lo = [int]$s; $hi = $lo } else { continue }
        foreach ($p in $ports) { if ($p -ge $lo -and $p -le $hi) { return $true } }
        foreach ($r in $ranges) { if ($r[0] -le $hi -and $r[1] -ge $lo) { return $true } }
    }
    return $false
}

trap { ErrLog ("未預期錯誤（第 {0} 行）：{1}" -f $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message); if (-not $script:LogFile) { Stop-Early '未預期錯誤，中止' }; continue }

# ============================== 主流程 ==============================
Log "FTP 主機本機收集（PowerShell 版 $VERSION）" 'Green'
Log '只讀不改、不刪除；設定檔遮密碼後才寫入；結果只寫在新開的結果資料夾。'
Log ''

if (-not $SocTicket.Trim()) { $SocTicket = Read-Host '資安／SOC 通知單號（必填）' }
if (-not $SocTicket.Trim()) { Stop-Early '沒有通知單號，不執行。' }
if (-not $OutDir) {
    $def = Join-Path $PSScriptRoot 'out'
    $ans = Read-Host "存放目錄（直接按 Enter＝$def）"
    $OutDir = if ($ans.Trim()) { $ans.Trim().Trim('"') } else { $def }
}
if ($OutDir.StartsWith('\\')) { Stop-Early '存放目錄請用本機磁碟，不要放網路共用。' }
$OutDir = [IO.Path]::GetFullPath($OutDir)
$drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($OutDir))
if ($drive.DriveType -eq 'Network') { Stop-Early '存放目錄請用本機磁碟，不要放對應的網路磁碟。' }

try { $script:LongOK = (New-Object IO.DirectoryInfo('\\?\' + $env:SystemDrive + '\')).Exists } catch { $script:LongOK = $false }

$extra = @($ExtraPaths -split ';' | Where-Object { $_.Trim() } | ForEach-Object { $_.Trim().Trim('"') })
foreach ($p in $extra) { if ($p -notmatch '^[A-Za-z]:\\') { Stop-Early "ExtraPaths 要是 X:\... 完整路徑：$p" } }

# 服務：執行檔目錄、命令列裡的路徑（例如 --config-dir）、執行身分
$svcRoots = @(); $ftpPids = @(); $ftpExes = @(); $services = @()
try {
    $services = @(Get-CimInstance Win32_Service | Where-Object { "$($_.Name) $($_.DisplayName) $($_.PathName)" -match '(?i)ftp|serv-?u|rhinosoft|filezilla|sshd|sftp' })
    foreach ($sv in $services) {
        if ("$($sv.Name) $($sv.PathName)" -notmatch $PRODUCT_RX) { continue }
        $exe = Get-ExePath ([string]$sv.PathName)
        if ($exe) { $svcRoots += [IO.Path]::GetDirectoryName($exe); $ftpExes += $exe }
        foreach ($m in [regex]::Matches([string]$sv.PathName, '"([A-Za-z]:\\[^"]+)"|(?<=\s)([A-Za-z]:\\\S+)')) {
            $p = $m.Value.Trim('"')
            if ($p -notmatch '(?i)\.exe$' -and (Test-Path -LiteralPath $p -PathType Container)) { $svcRoots += $p }
        }
        if ($sv.ProcessId) { $ftpPids += [int]$sv.ProcessId }
        try {   # 服務執行帳號的使用者設定檔底下（FileZilla 以非 SYSTEM 帳號執行時設定會放這裡）
            $acct = [string]$sv.StartName; $prof = ''
            if ($acct -match '^(?i)(LocalSystem|NT AUTHORITY\\SYSTEM)$') { $prof = Join-Path $env:windir 'System32\config\systemprofile' }
            elseif ($acct -match '^(?i)NT AUTHORITY\\(LocalService|NetworkService)$') { $prof = Join-Path $env:windir ('ServiceProfiles\' + ($acct -replace '^.*\\', '')) }
            elseif ($acct) {
                if ($acct.StartsWith('.\')) { $acct = $env:COMPUTERNAME + $acct.Substring(1) }
                $sid = (New-Object Security.Principal.NTAccount($acct)).Translate([Security.Principal.SecurityIdentifier]).Value
                $up = Get-CimInstance Win32_UserProfile -Filter "SID='$sid'" -ErrorAction Stop
                if ($up) { $prof = [string]$up.LocalPath }
            }
            if ($prof) {
                foreach ($sub in @('AppData\Local\filezilla-server', 'AppData\Roaming\filezilla-server', 'AppData\Local\FileZilla Server', 'AppData\Roaming\FileZilla Server', 'AppData\Local\RhinoSoft\Serv-U', 'AppData\Roaming\RhinoSoft\Serv-U')) {
                    $cand = Join-Path $prof $sub
                    if (Test-Path -LiteralPath $cand -PathType Container) { $svcRoots += $cand }
                }
            }
        } catch { ErrLog "找服務帳號設定目錄失敗（$($sv.Name)）：$($_.Exception.GetType().Name)" }
    }
} catch { ErrLog "讀服務資訊失敗：$($_.Exception.Message)" }

$roots = @($DEFAULT_ROOTS + $svcRoots + $extra | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') } | Select-Object -Unique)
foreach ($p in $roots) { if (Test-Inside $OutDir $p) { Stop-Early "存放目錄不能放在要收集的資料夾裡：$p" } }

$ip = Get-LocalIPv4
$hostName = $env:COMPUTERNAME
$start = Get-Date
[void][IO.Directory]::CreateDirectory($OutDir)   # 存放目錄（不存在才建）
$runDir = Join-Path $OutDir ("run_local_{0}_{1}_{2}" -f $ip, $hostName, $start.ToString('yyyyMMdd_HHmmss'))
$k = 1; $baseDir = $runDir
while (Test-Path -LiteralPath $runDir) { $k++; $runDir = "${baseDir}_$k" }
[void][IO.Directory]::CreateDirectory($runDir)
$script:RunDir = [IO.Path]::GetFullPath($runDir)
$script:OutDirPrefix = $OutDir.TrimEnd('\') + '\'
$hdir = Join-Path $runDir $ip
$script:HostDir = $hdir
New-RunSubDir $hdir
Open-RunLogs $runDir
Log "結果資料夾已建立：$runDir"

$isAdmin = $false
try { $isAdmin = (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { }
$info = Join-Path $runDir '_run_info.txt'
$who = [Security.Principal.WindowsIdentity]::GetCurrent().Name
Add-OutText $info @"
SOC 通知單號：$SocTicket
執行者（Windows 登入）：$who（系統管理員權限：$isAdmin）
連線帳號：（本機模式）
執行機器：$hostName（$ip）
開始：$(Ts $start)
收集工具：FtpCollect.ps1 $VERSION
輸出格式版本（schema）：$SCHEMA
log 天數：$Days
log 分段大小：$MaxMB MB
log 讀取上限：$(if ($MaxLogGB -gt 0) { "$MaxLogGB GB（從最新往回挑，超過的較舊 log 不讀）" } else { "不限" })
FileZilla log 模式：$FzLogMode$(if ($FzDropListing) { '（不留 LIST/NLST/MLSD）' } else { '' })
長路徑支援：$script:LongOK
模式：本機（PowerShell $($PSVersionTable.PSVersion)）
從服務找到的目錄：$($svcRoots -join '；')
額外路徑：$($extra -join '；')

"@

# 輸出檔
$runCsv = Join-Path $runDir '_run.csv'
$manifest = Join-Path $hdir 'manifest.csv'
$accCsv = Join-Path $hdir 'accounts.csv'
$dirCsv = Join-Path $hdir 'dirs.csv'
$sumCsv = Join-Path $hdir 'dir_summary.csv'
$subCsv = Join-Path $hdir 'subdir_summary.csv'
$eqCsv = Join-Path $hdir 'evidence_quality.csv'
$covCsv = Join-Path $hdir 'log_coverage.csv'
$suCsv = Join-Path $hdir 'servu_users.csv'
$lsCsv = Join-Path $hdir 'log_settings.csv'
$hostInfo = Join-Path $hdir 'host_info.csv'
$fwCsv = Join-Path $hdir 'firewall.csv'
$taskCsv = Join-Path $hdir 'tasks.csv'
$aclCsv = Join-Path $hdir 'acl.csv'
$shareCsv = Join-Path $hdir 'shares.csv'
$certCsv = Join-Path $hdir 'certs.csv'
Csv $manifest @('kind', 'status', 'source_path', 'size', 'mtime', 'out_path', 'out_bytes', 'sha256', 'format', 'note', 'out_parts')
Csv $accCsv @('product', 'config_file', 'domain', 'name', 'kind', 'enabled', 'groups', 'allowed_ips', 'denied_ips', 'parse_method')
Csv $dirCsv @('product', 'config_file', 'domain', 'owner_kind', 'owner', 'virtual_path', 'physical_path_raw', 'physical_path', 'perm_raw', 'is_home', 'parse_method')
Csv $subCsv @('physical_path', 'subfolder', 'window_days', 'files_in_window', 'bytes_in_window', 'top_patterns_in_window', 'newest_mtime_overall', 'files_older_than_window', 'parent_truncated')
Csv $sumCsv @('physical_path', 'exists', 'window_days', 'files_in_window', 'bytes_in_window', 'top_patterns_in_window', 'newest_mtime_overall', 'files_older_than_window', 'dir_count', 'scan_seconds', 'truncated', 'enum_errors', 'links_skipped', 'scan_time')
Csv $covCsv @('log_file', 'first_date', 'last_date', 'lines', 'dated_lines', 'upload', 'download', 'other_ops', 'login_ok', 'login_fail', 'utc_marker', 'copy_mode', 'source_bytes', 'out_bytes', 'lines_kept', 'lines_dropped')
Csv $lsCsv @('config_file', 'key_path', 'value')
Csv $hostInfo @('item', 'name', 'value')
Csv $certCsv @('source', 'cert_file', 'referenced_by', 'subject', 'issuer', 'not_before', 'not_after', 'thumbprint', 'note')
Csv $suCsv @('domain', 'name', 'kind', 'full_name', 'home_dir', 'files_uploaded', 'files_downloaded', 'bytes_uploaded', 'bytes_downloaded', 'statistics_start', 'last_login', 'last_logout', 'config_file')

function Add-Manifest($kind, $status, $src, $size, $mtime, $out, $outBytes, $sha, $fmt, $note, $parts = $null) {
    $pr = ''; if ($parts) { $pr = (@($parts | ForEach-Object { (ConvertFrom-LongPath $_).Substring($script:RunDir.Length).TrimStart('\') }) -join '|') }   # 輸出分段（依序，含第一段）
    $rel = ''; if ($out) { $rel = (ConvertFrom-LongPath $out).Substring($script:RunDir.Length).TrimStart('\') }
    Csv $manifest @($kind, $status, $src, $size, (Ts $mtime), $rel, $outBytes, $sha, $fmt, $note, $pr)
}

$cutoff = $start.AddDays(-$Days)
$maxBytes = [long]$MaxMB * $CHUNK
$maxLogBytes = $(if ($MaxLogGB -gt 0) { [long][Math]::Max(1, [Math]::Floor($MaxLogGB * 1GB)) } else { [long]0 })   # 只有 0 代表不限；極小正值至少 1 位元組
$logCap = @{ sampled = $false; files = 0; bytes = [long]0; keptFiles = 0; keptBytes = [long]0; from = '' }
$s = @{ found = 0; denied = 0; main = 0; config = 0; log = 0; bytes = [long]0; masked = 0; generic = 0; skipped = 0; copyErr = 0; truncated = 0 }
$types = @()
$endReason = '正常結束'
$aborted = $false
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$cfgFiles = New-Object System.Collections.Generic.List[IO.FileInfo]
$logFiles = New-Object System.Collections.Generic.List[IO.FileInfo]
$certFiles = New-Object System.Collections.Generic.List[IO.FileInfo]
$logDirs = New-Object System.Collections.Generic.List[string]
$certRefs = @{}        # 憑證路徑 → 被哪個設定引用
$inlineCerts = New-Object System.Collections.Generic.List[object]
$extraCfg = New-Object System.Collections.Generic.List[string]
$cfgPorts = New-Object 'System.Collections.Generic.HashSet[int]'
$cfgRanges = New-Object System.Collections.Generic.List[object]
$logSettingText = New-Object System.Collections.Generic.List[string]
$walked = New-Object System.Collections.Generic.List[string]
$copiedLogs = New-Object System.Collections.Generic.List[object]

$PACKED_EXT = @('.zip', '.gz', '.7z', '.rar', '.bz2')
$NOT_LOG_EXT = @('.exe', '.dll', '.sys', '.msi', '.bat', '.cmd', '.ps1', '.vbs', '.js', '.ico', '.png', '.jpg', '.htm', '.html', '.chm', '.pdf',
    '.key', '.pfx', '.p12', '.jks', '.keystore', '.ppk', '.kdbx', '.p8', '.pk8')   # 金鑰／憑證容器一律不當 log
function Test-LogCandidate([IO.FileInfo]$f, [bool]$inLogDir) {
    $n = $f.Name; $ext = $f.Extension.ToLower()
    if ($NOT_LOG_EXT -contains $ext -or $CERT_EXT -contains $ext) { return $false }
    if ($n -match '(?i)\.log$|\.log\.[^\\]+$') { return $true }                      # x.log、x.log.1、x.log.20261101
    if ($inLogDir) { return (($NOT_LOG_EXT -notcontains $ext) -and ($CONFIG_EXT -notcontains $ext) -and ($CERT_EXT -notcontains $ext)) }   # 設定指定的 log 目錄：events.csv、無副檔名、x.txt.1 都收
    $logish = ($n -match '(?i)log|event|xfer|transfer|audit') -or ((ConvertFrom-LongPath $f.DirectoryName) -match '(?i)\\logs?(\\|$)')
    if ($logish -and $n -match '(?i)\.(txt|csv)(\.\d+)?$') { return $true }
    return $false
}
$SU_CLIENT_RX = '(?i)\\Serv-U\\Client\\'
$script:Excl = @{ client = 0; backup = 0 }
function Add-WalkResult([string]$root, [bool]$isLogDir) {
    $w = Get-WalkFiles $root $ROOT_WALK_MAX $ROOT_WALK_SEC
    $walked.Add($root)
    foreach ($e in $w.Errors) { ErrLog "無法列目錄 $e"; Add-Manifest 'error' 'error' $e '' $null '' '' '' '' '無法列目錄' }
    if ($w.Truncated) { $s.truncated++; ErrLog "目錄走訪截斷 $root：$($w.Truncated)"; Add-Manifest 'error' 'truncated' $root '' $null '' '' '' '' "走訪截斷：$($w.Truncated)" }
    foreach ($f in $w.Files) {
        $full = ConvertFrom-LongPath $f.FullName
        if (Test-Inside $full $script:RunDir) { continue }
        if ($full -match $SU_CLIENT_RX) { $script:Excl.client++; continue }      # Serv-U 網頁介面範本，不是設定
        if ($full -match '(?i)\.Archive\.Backup$') { $script:Excl.backup++; continue }   # Serv-U 備份檔：會讓帳號重複
        if ($seen.Contains($full)) { continue }
        $ext = $f.Extension.ToLower()
        if (-not $isLogDir -and ($CONFIG_EXT -contains $ext)) { [void]$seen.Add($full); $cfgFiles.Add($f) }
        elseif ($CERT_EXT -contains $ext) { [void]$seen.Add($full); $certFiles.Add($f) }
        elseif ($PACKED_EXT -contains $ext -and ($isLogDir -or $f.Name -match '(?i)log') -and $f.LastWriteTime -ge $cutoff) {
            [void]$seen.Add($full); $s.skipped++; ErrLog "未收集 $full：壓縮的 log"
            Add-Manifest 'log' 'skipped' $full $f.Length $f.LastWriteTime '' '' '' '' '壓縮的 log：無法在主機上安全遮罩，未收集（請人工處理）'
        }
        elseif (Test-LogCandidate $f $isLogDir) { if ($f.LastWriteTime -ge $cutoff) { [void]$seen.Add($full); $logFiles.Add($f) } }
    }
}

function Invoke-ConfigCollect([IO.FileInfo]$f) {
    $src = ConvertFrom-LongPath $f.FullName
    try {
        $r = Read-AllShared $src $MAX_CONFIG
        if ($null -eq $r[0]) {
            if ($r[1] -match '^短讀') { $s.copyErr++; ErrLog "讀設定檔失敗 $src：$($r[1])"; Add-Manifest 'config' 'error' $src $f.Length $f.LastWriteTime '' '' '' '' $r[1] }
            else { $s.skipped++; ErrLog "未收集 $src：$($r[1])"; Add-Manifest 'config' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' '' $r[1] }
            return
        }
        $data = [byte[]]$r[0]
        $text = Get-TextFromBytes $data
        if ($null -eq $text -and (Test-XmlBytes $data)) { $text = '' }   # 非 UTF-8／Big5 但看起來是 XML：交給 XML 解析器照 encoding 宣告讀
        if ($null -eq $text) { $s.skipped++; ErrLog "未收集 $src：二進位或編碼無法辨識"; Add-Manifest 'config' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' '' '未收集：二進位或編碼無法辨識，無法安全遮罩（請在主機上用主控台匯出）'; return }
        $before = $script:MaskHits
        $pc = $null
        try { $pc = Protect-Config $data $text $f.Extension.ToLower() }
        catch {
            $msg = "$($_.Exception.Message)"; if ($msg -notmatch '^(遮罩自我檢查失敗|格式無法確認|XML 解析失敗|JSON 解析失敗|不是 INI)') { $msg = '解析失敗（' + $_.Exception.GetType().Name + '）' }
            $s.skipped++; ErrLog "未收集 $src：$msg"; Add-Manifest 'config' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' '' "未收集：$msg"; return
        }
        $dst = Get-MirrorPath $src
        New-OutFile $dst $pc.Bytes
        $sha = Get-Sha256Bytes $pc.Bytes
        if ((Get-Sha256File $dst) -ne $sha) { $s.copyErr++; ErrLog "設定檔副本驗證不符 $src"; Add-Manifest 'config' 'error' $src $f.Length $f.LastWriteTime $dst $pc.Bytes.Length $sha $pc.Format '副本驗證不符'; return }
        $changed = $script:MaskHits -gt $before
        if ($changed) { $s.masked++ }
        $note = $(if ($changed) { '已遮密碼' } else { '無密碼欄位' })
        if ($pc.Generic) { $s.generic++; $note += '；格式不明，只保留白名單欄位（路徑、啟用、IP、權限…），請人工抽看' }
        $s.config++
        $accBefore = $script:Accounts.Count
        $product = ''
        if ($src -match '(?i)serv-?u|rhinosoft' -or $text -match '(?i)ServUDaemon|Serv-U') { $product = 'ServU' }
        if ($src -match '(?i)filezilla' -or $text -match '(?i)<filezilla|FileZillaServer') { $product = 'FileZilla' }
        try {
            if ($pc.Format -eq 'XML') {
                $root = $pc.Doc.DocumentElement.LocalName
                if ($root -ieq 'FileZillaServer') { Read-FzOld $pc.Doc $src }
                elseif ($pc.Doc.SelectSingleNode("//*[local-name()='mount_point']") -or ($root -ieq 'filezilla' -and $pc.Doc.SelectSingleNode("//*[(local-name()='user' or local-name()='group') and @name]"))) { Read-FzNew $pc.Doc $src }
                elseif ($f.Extension -ieq '.archive' -or $product -eq 'ServU') { Read-ServUGeneric '' $src $pc.Pairs }
            } elseif ($pc.Format -eq 'SERVU-ARCHIVE') { Read-ServUArchive $pc.Pairs $src
            } elseif ($pc.Format -eq 'INI' -and $pc.Text -match '(?im)^\s*\[(USER|GROUP)=') { Read-ServUIni $pc.Text $src }
            elseif ($f.Extension -ieq '.archive' -or $product -eq 'ServU') { Read-ServUGeneric $pc.Text $src $pc.Pairs }
        } catch { ErrLog "解析帳號失敗 $src：$($_.Exception.GetType().Name)" }
        $nAcc = $script:Accounts.Count - $accBefore
        if ($nAcc) { $note += "；帳號／群組 $nAcc 筆" }
        if ($f.Name -match $MAIN_CONFIG -or $nAcc -gt 0) { $s.main++ }
        Add-Manifest 'config' 'collected' $src $f.Length $f.LastWriteTime $dst $pc.Bytes.Length $sha $pc.Format $note
        # 從設定值找：log 位置與設定、憑證、其他設定檔、埠
        $mins = @{}; $maxs = @{}; $nls = 0
        foreach ($p in $pc.Pairs) {
            $v = ([string]$p.Value).Trim()
            $tk = @(Get-KeyTokens ($p.Path))
            $isLog = @($tk | Where-Object { @('log', 'logs', 'logging', 'logger', 'logfile', 'logfiles', 'logdir') -contains $_ }).Count -gt 0
            if ($isLog -and $nls -lt 300) { Csv $lsCsv @($src, $p.Path, $v); $nls++; if ($logSettingText.Count -lt 40) { $logSettingText.Add("$($p.Key)=$v") } }
            if ($v -match '-----BEGIN CERTIFICATE-----') { $inlineCerts.Add([pscustomobject]@{ Ref = "$src :: $($p.Path)"; Text = $v }) }
            $ev = [Environment]::ExpandEnvironmentVariables($v)
            if ($ev -match '^[A-Za-z]:\\|^\\\\') {
                $pp = ($ev -split '[|<>"*?]')[0]   # 例：Serv-U AccessN=路徑|權限
                if ($pp -match '%') { $i = $pp.IndexOf('%'); $pp = $pp.Substring(0, $pp.LastIndexOf('\', [Math]::Max(0, $i - 1)) + 1) }
                $pp = $pp.TrimEnd('\')
                $ext = [IO.Path]::GetExtension($pp).ToLower()
                if ($CERT_EXT -contains $ext -or @('.pfx', '.p12', '.key') -contains $ext) {
                    if (-not $certRefs.ContainsKey($pp)) { $certRefs[$pp] = @() }
                    $certRefs[$pp] += "$src :: $($p.Path)"
                } elseif ($isLog -and $pp.Length -gt 3 -and $pc.Format -ne 'SERVU-ARCHIVE') {   # Serv-U LogFilePath 另外處理（4b，照檔名樣式收）
                    $d = $pp; if ($ext -and (Test-Path -LiteralPath $pp -PathType Leaf)) { $d = [IO.Path]::GetDirectoryName($pp) } elseif ($ext -in @('.log', '.txt')) { $d = [IO.Path]::GetDirectoryName($pp) }
                    if ($d -and -not $logDirs.Contains($d)) { $logDirs.Add($d) }
                } elseif (($CONFIG_EXT -contains $ext) -and (Test-Path -LiteralPath $pp -PathType Leaf) -and -not $extraCfg.Contains($pp)) { $extraCfg.Add($pp) }
            }
            $kt = @(Get-KeyTokens ([string]$p.Key))
            if (($kt -contains 'port' -or $kt -contains 'ports') -and $v -match '^\d{1,5}$' -and [int]$v -gt 0 -and [int]$v -lt 65536) {
                [void]$cfgPorts.Add([int]$v)
                $par = $p.Path.Substring(0, [Math]::Max(0, $p.Path.LastIndexOf('/')))
                if ($kt -contains 'min' -or $kt -contains 'low' -or $kt -contains 'start' -or $kt -contains 'from') { $mins[$par] = [int]$v }
                if ($kt -contains 'max' -or $kt -contains 'high' -or $kt -contains 'end' -or $kt -contains 'to') { $maxs[$par] = [int]$v }
            }
        }
        foreach ($k2 in $mins.Keys) { if ($maxs.ContainsKey($k2) -and $maxs[$k2] -ge $mins[$k2]) { $cfgRanges.Add(@($mins[$k2], $maxs[$k2])) } }
        if ($product) { $script:types += $product }
    } catch {
        if ("$($_.Exception.Message)".StartsWith('STOP:')) { throw }
        $s.copyErr++
        ErrLog "收集設定檔失敗 $src：$($_.Exception.Message)"
        Add-Manifest 'config' 'error' $src '' $null '' '' '' '' "$($_.Exception.GetType().Name)"
    }
}

$script:types = @()
$logStats = $null
try {
    # 1. 走訪安裝／設定目錄
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        try { [void](Get-Item -LiteralPath $root -Force) } catch { $s.denied++; ErrLog "無法存取 $root：$($_.Exception.Message)"; Add-Manifest 'root' 'error' $root '' $null '' '' '' '' '無法存取'; continue }
        $s.found++
        if ($root -match '(?i)serv-?u|rhinosoft') { $script:types += 'ServU' } elseif ($root -match '(?i)filezilla') { $script:types += 'FileZilla' }
        Add-Manifest 'root' 'found' $root '' $null '' '' '' '' ''
        Log "找到：$root"
        Add-WalkResult $root $false
    }
    if ($script:Excl.client) { Log "排除 Serv-U\Client 網頁範本 $($script:Excl.client) 個檔"; Add-Manifest 'excluded' 'excluded' 'Serv-U\Client\' '' $null '' '' '' '' "網頁介面範本，不是設定：$($script:Excl.client) 個檔，不收" }
    if ($script:Excl.backup) { Log "排除 *.Archive.Backup $($script:Excl.backup) 個檔"; Add-Manifest 'excluded' 'excluded' '*.Archive.Backup' '' $null '' '' '' '' "Serv-U 備份檔：$($script:Excl.backup) 個，不收（避免帳號重複）" }
    # 2. 設定檔（遮罩、寫入、解析帳號）
    foreach ($f in @($cfgFiles)) { Invoke-ConfigCollect $f }
    # 3. 設定檔裡引用的其他設定檔（例如 Serv-U domain 檔在別處）
    for ($qi = 0; $qi -lt $extraCfg.Count -and $qi -lt 500; $qi++) {   # 佇列：被引用的設定檔再引用的也會處理
        $p = $extraCfg[$qi]
        if ($seen.Add($p)) { Log "設定引用的設定檔：$p"; Invoke-ConfigCollect (New-Object IO.FileInfo((ConvertTo-LongPath $p))) }
    }
    if ($extraCfg.Count -gt 500) { ErrLog "設定引用的設定檔超過 500 個，其餘未處理" }
    # 4. 設定檔裡指定的 log 目錄
    foreach ($d in @($logDirs)) {
        if (-not (Test-Path -LiteralPath $d -PathType Container)) { Log "設定指定的 log 目錄不存在：$d"; Add-Manifest 'logdir' 'missing' $d '' $null '' '' '' '' '設定裡指定，但目錄不存在'; continue }
        Add-Manifest 'logdir' 'found' $d '' $null '' '' '' '' '設定裡指定的 log 目錄'
        Log "找 log（設定指定的目錄）：$d"; Add-WalkResult $d $true
    }
    # 4b. Serv-U：照 Serv-U.Archive 的 LogFilePath 收 log（%Y、%M、%D… 換成萬用字元；位置常在別的磁碟）
    if ($script:SuMain.Count -and -not $script:SuLog.Count) {
        $script:SuIssues.Add('Serv-U 設定裡沒有 LogFilePath（log 位置不明）')
        Add-Manifest 'logdir' 'missing' ($script:SuMain -join ';') '' $null '' '' '' '' 'Serv-U.Archive 沒有 LogFilePath'
    }
    foreach ($suL in $script:SuLog.ToArray()) {
        if ($suL.LogToFile -eq '0') {
            $script:SuIssues.Add("Serv-U LogToFile=0（沒有開檔案 log）：$($suL.LogFilePath)")
            Log "Serv-U 沒有開檔案 log（LogToFile=0）：$($suL.LogFilePath)"
            Add-Manifest 'logdir' 'disabled' $suL.LogFilePath '' $null '' '' '' '' "Serv-U LogToFile=0（$($suL.Key)）"; continue
        }
        $lfp = [Environment]::ExpandEnvironmentVariables($suL.LogFilePath.Trim().Trim('"'))
        if ($lfp -notmatch '^[A-Za-z]:\\|^\\\\') { $lfp = Join-Path ([IO.Path]::GetDirectoryName($suL.Config)) $lfp }
        $pi = $lfp.IndexOf('%')
        $base = $(if ($pi -gt 0) { $lfp.Substring(0, [Math]::Max(0, $lfp.LastIndexOf('\', $pi - 1))) } else { [IO.Path]::GetDirectoryName($lfp) })
        $rx = '(?i)^' + [regex]::Replace([regex]::Escape($lfp), '%[A-Za-z]+%|%[A-Za-z]', '[^\\]*') + '$'
        if (-not $base -or -not (Test-Path -LiteralPath $base -PathType Container)) {
            $script:SuIssues.Add("Serv-U log 目錄不存在：$base")
            Add-Manifest 'logdir' 'missing' $lfp '' $null '' '' '' '' "Serv-U LogFilePath 指定，但目錄不存在（$($suL.Key)）"; continue
        }
        $w = Get-WalkFiles $base $ROOT_WALK_MAX $ROOT_WALK_SEC
        foreach ($e in $w.Errors) { ErrLog "無法列目錄 $e"; Add-Manifest 'error' 'error' $e '' $null '' '' '' '' '無法列目錄' }
        if ($w.Truncated) { $s.truncated++; ErrLog "目錄走訪截斷 $base：$($w.Truncated)"; Add-Manifest 'error' 'truncated' $base '' $null '' '' '' '' "走訪截斷：$($w.Truncated)" }
        $nm = 0; $nOld = 0; $nWin = 0   # nWin＝符合樣式且在期間內（含別的步驟已收過的）；nm＝這一步新加的
        foreach ($f in $w.Files) {
            $full = ConvertFrom-LongPath $f.FullName
            if ($full -notmatch $rx -or (Test-Inside $full $script:RunDir)) { continue }
            if ($f.LastWriteTime -lt $cutoff) { $nOld++; continue }
            $nWin++
            if ($seen.Add($full)) { $logFiles.Add($f); $nm++ }
        }
        Log "Serv-U log（LogFilePath=$($suL.LogFilePath)）：近 $Days 天符合 $nWin 個（新加入 $nm 個），更舊 $nOld 個不收"
        Add-Manifest 'logdir' 'found' $base '' $null '' '' '' '' "Serv-U LogFilePath=$($suL.LogFilePath)；LogToFile=$($suL.LogToFile)；近 $Days 天符合 $nWin 個（新加入 $nm）、更舊 $nOld 個"
        if (-not $nWin) { $script:SuIssues.Add("Serv-U log 目錄 $base 近 $Days 天沒有符合 $($suL.LogFilePath) 的檔") }
    }
    # 5. 複製 log（由舊到新：FileZilla slim 的連線狀態要跨輪替檔延續，順序跟報表一樣）
    #    排序＝報表的 (manifest mtime 字串, 來源路徑)，用 Ordinal 比較（跟 Python 字串比較一樣）
    #    v1.1.9 修正：原本 [Array]::Sort($keys, $items, Ordinal) 在 PowerShell 5.1 只排了 keys、沒帶動 items（實測），檔案其實沒照時間處理。
    #    改成把 key 跟檔案綁在同一個物件裡，用 List.Sort（CompareOrdinal）排。
    $lpairs = New-Object 'System.Collections.Generic.List[object]'
    foreach ($lf in @($logFiles)) { $lpairs.Add([pscustomobject]@{ K = (Ts $lf.LastWriteTime) + '|' + (ConvertFrom-LongPath $lf.FullName); F = $lf }) }
    $lpairs.Sort([Comparison[object]] { param($x, $y) [string]::CompareOrdinal($x.K, $y.K) })
    $litems = [object[]]@($lpairs | ForEach-Object { $_.F })
    # 5a. 讀取上限（-MaxLogGB）：從最新的檔往回挑，累計來源大小到上限為止（最新的一個檔一定收）；挑到的再照上面的順序由舊到新處理。
    #     沒挑到的記 manifest（skipped：超過 log 讀取上限），報表據此標「log 抽樣」，抽樣主機沒看到活動不判「沒在用」。
    if ($maxLogBytes -gt 0 -and $litems.Count -gt 0) {
        $acc = [long]0; $keepIdx = New-Object 'System.Collections.Generic.HashSet[int]'
        for ($i = $litems.Count - 1; $i -ge 0; $i--) {
            $ln = [long]$litems[$i].Length
            if ($keepIdx.Count -gt 0 -and ($acc + $ln) -gt $maxLogBytes) { break }   # 一旦超過就停（不跳著挑，保持時間連續）
            [void]$keepIdx.Add($i); $acc += $ln
        }
        if ($keepIdx.Count -lt $litems.Count) {
            $kept = New-Object System.Collections.Generic.List[object]
            for ($i = 0; $i -lt $litems.Count; $i++) {
                $lf = $litems[$i]
                if ($keepIdx.Contains($i)) { $kept.Add($lf); continue }
                $logCap.files++; $logCap.bytes += [long]$lf.Length; $s.skipped++
                Add-Manifest 'log' 'skipped' (ConvertFrom-LongPath $lf.FullName) $lf.Length $lf.LastWriteTime '' '' '' 'LOG' "超過 log 讀取上限（-MaxLogGB $MaxLogGB），未讀（抽樣）"
            }
            $litems = [object[]]$kept.ToArray()
            $logCap.sampled = $true
            Log ("log 讀取上限 $MaxLogGB GB：只讀最新 {0} 個檔（{1:N0} MB，最早一個修改於 {2}），略過較舊 {3} 個檔（{4:N0} MB）" -f $litems.Count, ($acc / 1MB), (Ts $litems[0].LastWriteTime), $logCap.files, ($logCap.bytes / 1MB))
        }
    }
    # 選定要讀的 log（不論有沒有抽樣）：檔數、來源大小、最早一個的修改時間
    $logCap.keptFiles = $litems.Count; $logCap.keptBytes = [long]0
    foreach ($lf in $litems) { $logCap.keptBytes += [long]$lf.Length }
    if ($litems.Count) { $logCap.from = (Ts $litems[0].LastWriteTime) }
    $slimMode = ($FzLogMode -eq 'slim')
    foreach ($lf in $litems) { [void]$script:LogMirrors.Add([IO.Path]::GetFullPath((Get-MirrorPath (ConvertFrom-LongPath $lf.FullName)))) }
    foreach ($f in $litems) {
        $src = ConvertFrom-LongPath $f.FullName
        if ($slimMode) { Start-FzFile }   # 這個檔收集失敗時還原狀態（報表不會讀它）
        try {
            $free = (New-Object IO.DriveInfo([IO.Path]::GetPathRoot($runDir))).AvailableFreeSpace
            if ($free - $f.Length -lt $MIN_FREE) { throw 'STOP:目的磁碟剩不到 2 GB' }
            $dst = Get-MirrorPath $src
            $slim = ($slimMode -and (Test-FzLog $f))
            if ($slim) { $r = Copy-FzSlim $f $dst $maxBytes }
            else {
                $r = Copy-LogFile $f $dst $maxBytes
                # 整份複製的檔也要過 FileZilla 狀態更新（用輸出副本＝報表會看到的內容），後面輪替檔的 slim 才不會配錯
                if ($slimMode -and -not $r.Skip -and -not $r.Bad) { [void](Invoke-FzStream ([string[]]@($r.Parts)) '' 0 $false) }
            }
            if ($slimMode -and ($r.Skip -or $r.Bad)) { Undo-FzFile }
            $fmtL = $(if ($slim) { 'LOG-SLIM' } else { 'LOG-REDACTED' })
            if ($r.Skip) { $s.skipped++; ErrLog "未收集 $src：$($r.Note)"; Add-Manifest 'log' 'skipped' $src $f.Length $f.LastWriteTime '' '' '' 'LOG' $r.Note }
            elseif (-not $r.Bad) {
                $s.log++; $s.bytes += $r.Bytes
                $copiedLogs.Add([pscustomobject]@{ Src = $src; Parts = $r.Parts; Mode = $(if ($slim) { 'slim' } else { 'raw' }); SrcBytes = $f.Length; OutBytes = $r.Bytes
                        Kept = $(if ($slim) { $r.Kept } else { '' }); Dropped = $(if ($slim) { $r.Dropped } else { '' }) })
                Add-Manifest 'log' 'collected' $src $f.Length $f.LastWriteTime $dst $r.Bytes $r.Sha $fmtL $r.Note $r.Parts
                if ($slim -and $r.Incomplete) { $s.copyErr++; ErrLog "log 不完整 $src：$($r.Incomplete)" }
            }
            else { $s.copyErr++; ErrLog "log 複製不完整 $src：$($r.Note)"; Add-Manifest 'log' 'error' $src $f.Length $f.LastWriteTime $dst $r.Bytes $r.Sha $fmtL $r.Note }
        } catch {
            if ($slimMode) { Undo-FzFile }
            if ("$($_.Exception.Message)".StartsWith('STOP:')) { throw }
            $s.copyErr++; ErrLog "收集 log 失敗 $src：$($_.Exception.Message)"
            Add-Manifest 'log' 'error' $src $f.Length $f.LastWriteTime '' '' '' '' "$($_.Exception.GetType().Name)"
        }
    }
} catch {
    $msg = "$($_.Exception.Message)" -replace '^STOP:', ''
    $endReason = "中止：$msg"; ErrLog ("$endReason（第 {0} 行）" -f $_.InvocationInfo.ScriptLineNumber); $aborted = $true
}

# ---------- 6. log 解析：證據品質 ----------
$dates = @{}; $tot = @{ lines = [long]0; dated = [long]0; up = [long]0; down = [long]0; oth = [long]0; ok = [long]0; fail = [long]0 }
$parseIncomplete = ''; $utcFiles = 0
$psw = [Diagnostics.Stopwatch]::StartNew()
try {
    foreach ($row in $copiedLogs) {
        if ($psw.Elapsed.TotalSeconds -gt $LOG_PARSE_SEC) { $parseIncomplete = "超過 $LOG_PARSE_SEC 秒，部分 log 未解析"; break }
        $fd = @{}; $c = @{ lines = 0; dated = 0; up = 0; down = 0; oth = 0; ok = 0; fail = 0 }; $utc = ''
        foreach ($path in $row.Parts) {
        if ($parseIncomplete) { break }
        $sr = New-Object IO.StreamReader((Open-Source $path), $UTF8, $true)
        try {
            while ($null -ne ($line = $sr.ReadLine())) {
                $c.lines++
                $m = $RX_DATE.Match($line, 0, [Math]::Min(80, $line.Length))
                if ($m.Success) {
                    if ($m.Groups['y'].Success) { $key = '{0}-{1:00}-{2:00}' -f $m.Groups['y'].Value, [int]$m.Groups['m'].Value, [int]$m.Groups['d'].Value }
                    else { $key = '20{0}-{1:00}-{2}' -f $m.Groups['y2'].Value, $MONTHS[$m.Groups['mon'].Value.ToLower()], $m.Groups['d2'].Value }
                    if ($fd.ContainsKey($key)) { $fd[$key]++ } else { $fd[$key] = 1 }
                    $c.dated++
                    if (-not $utc) { $utc = $(if ($RX_UTCZ.IsMatch($line)) { 'Z(UTC)' } else { 'none' }) }
                }
                $o = $RX_OP.Match($line)
                if ($o.Success) {
                    if ($o.Groups['up'].Success) { $c.up++ } elseif ($o.Groups['down'].Success) { $c.down++ } elseif ($o.Groups['oth'].Success) { $c.oth++ } elseif ($o.Groups['ok'].Success) { $c.ok++ } else { $c.fail++ }
                }
                if (($c.lines % 20000) -eq 0 -and $psw.Elapsed.TotalSeconds -gt $LOG_PARSE_SEC) { $parseIncomplete = "超過 $LOG_PARSE_SEC 秒，部分 log 未解析完"; break }
            }
        } finally { $sr.Close() }
        }
        $valid = @($fd.Keys | Where-Object { $d = [datetime]::MinValue; [datetime]::TryParseExact($_, 'yyyy-MM-dd', $null, 'None', [ref]$d) } | Sort-Object)
        foreach ($kk in $valid) { if ($dates.ContainsKey($kk)) { $dates[$kk] += $fd[$kk] } else { $dates[$kk] = $fd[$kk] } }
        if ($utc -eq 'Z(UTC)') { $utcFiles++ }
        $first = ''; $last = ''; if ($valid.Count) { $first = $valid[0]; $last = $valid[-1] }
        Csv $covCsv @($row.Src, $first, $last, $c.lines, $c.dated, $c.up, $c.down, $c.oth, $c.ok, $c.fail, $utc, $row.Mode, $row.SrcBytes, $row.OutBytes, $row.Kept, $row.Dropped)
        foreach ($kk in @('lines', 'dated', 'up', 'down', 'oth', 'ok', 'fail')) { $tot[$kk] += $c[$kk] }
        if ($parseIncomplete) { break }
    }
} catch { ErrLog "log 解析失敗（第 $($_.InvocationInfo.ScriptLineNumber) 行）：$($_.Exception.Message)"; if (-not $parseIncomplete) { $parseIncomplete = '解析時發生錯誤' } }
$winStart = $start.Date.AddDays(-$Days).ToString('yyyy-MM-dd')
$beforeWin = @($dates.Keys | Where-Object { $_ -lt $winStart }).Count
$dkeys = @($dates.Keys | Where-Object { $_ -ge $winStart } | Sort-Object)   # 只算 -Days 期間內的日期
$earliest = ''; $latest = ''; $span = 0; $missing = @()
if ($dkeys.Count) {
    $earliest = $dkeys[0]; $latest = $dkeys[-1]
    $d0 = [datetime]::ParseExact($earliest, 'yyyy-MM-dd', $null); $d1 = [datetime]::ParseExact($latest, 'yyyy-MM-dd', $null)
    $span = [int]($d1 - $d0).TotalDays + 1
    for ($d = $d0; $d -le $d1; $d = $d.AddDays(1)) { if (-not $dates.ContainsKey($d.ToString('yyyy-MM-dd'))) { $missing += $d.ToString('yyyy-MM-dd') } }
}
$transfers = ($tot.up + $tot.down) -gt 0
$covered = $dkeys.Count
$eqRows = @(
    @('days_requested', $Days), @('window_start', $winStart), @('dates_before_window_ignored', $beforeWin), @('log_files_collected', $s.log), @('log_earliest_date', $earliest), @('log_latest_date', $latest),
    @('span_days', $span), @('days_with_entries', $covered), @('missing_days_count', $missing.Count), @('missing_days', (($missing | Select-Object -First 120) -join ';')),
    @('coverage_meets_requested', $(if ($covered -ge $Days -and -not $logCap.sampled) { 'yes' } else { 'no' })),
    @('log_sampled', $(if ($logCap.sampled) { 'yes' } else { 'no' })), @('log_read_cap_gb', $MaxLogGB), @('log_cap_skipped_files', $logCap.files), @('log_cap_skipped_bytes', $logCap.bytes),
    @('log_selected_files', $logCap.keptFiles), @('log_selected_source_bytes', $logCap.keptBytes), @('log_selected_earliest_mtime', $logCap.from),
    @('transfers_logged', $(if ($transfers) { 'yes' } else { 'no' })), @('upload_lines', $tot.up), @('download_lines', $tot.down), @('other_op_lines', $tot.oth),
    @('login_ok_lines', $tot.ok), @('login_fail_lines', $tot.fail), @('lines_total', $tot.lines), @('lines_dated', $tot.dated),
    @('files_with_utc_Z_timestamps', $utcFiles), @('parse_complete', $(if ($parseIncomplete) { "no：$parseIncomplete" } else { 'yes' })),
    @('logging_settings', (($logSettingText | Select-Object -First 40) -join ' | ')), @('log_dirs_from_config', ($logDirs -join ';')),
    @('host_timezone', [TimeZoneInfo]::Local.Id), @('host_utc_offset_now', [TimeZoneInfo]::Local.GetUtcOffset((Get-Date)).ToString()),
    @('note', '日期以 log 原文為準；有 Z 的是 UTC。行數為粗略比對（指令字樣），帳號級／目錄級統計由集中整理程式做。')
)
Csv $eqCsv @('key', 'value')
foreach ($r in $eqRows) { Csv $eqCsv $r }
Log "log：$($s.log) 個檔，日期 $earliest ～ $latest，有資料 $covered 天、缺 $($missing.Count) 天，傳輸紀錄：$(if ($transfers) { '有' } else { '沒有' })"

# ---------- 7. 主機資訊：OS、IP、時區、時鐘、服務（含執行身分）、監聽埠 ----------
try {
    foreach ($a in @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True')) {
        foreach ($x in @($a.IPAddress)) { if ($x -match '^\d+\.\d+\.\d+\.\d+$') { Csv $hostInfo @('ipv4', $a.Description, $x) } }
    }
    $os = Get-CimInstance Win32_OperatingSystem
    Csv $hostInfo @('os', $os.Caption, $os.Version)
    Csv $hostInfo @('os', 'last_boot', (Ts $os.LastBootUpTime))
} catch { ErrLog "取 OS／IP 資訊失敗：$($_.Exception.Message)" }
try {
    $tz = [TimeZoneInfo]::Local; $now = Get-Date
    Csv $hostInfo @('timezone', 'id', $tz.Id)
    Csv $hostInfo @('timezone', 'display', $tz.DisplayName)
    Csv $hostInfo @('timezone', 'base_utc_offset', $tz.BaseUtcOffset.ToString())
    Csv $hostInfo @('timezone', 'current_utc_offset', $tz.GetUtcOffset($now).ToString())
    Csv $hostInfo @('timezone', 'dst_now', $tz.IsDaylightSavingTime($now))
    Csv $hostInfo @('clock', 'local', $now.ToString('yyyy-MM-dd HH:mm:ss.fff'))
    Csv $hostInfo @('clock', 'utc', $now.ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss.fff'))
    try {   # 校時設定（唯讀讀登錄檔）
        $tp = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters' -ErrorAction Stop
        Csv $hostInfo @('clock', 'w32time_type', [string]$tp.Type)
        Csv $hostInfo @('clock', 'w32time_ntpserver', [string]$tp.NtpServer)
        $ws = Get-CimInstance Win32_Service -Filter "Name='W32Time'"
        if ($ws) { Csv $hostInfo @('clock', 'w32time_service', "$($ws.State)／$($ws.StartMode)") }
    } catch { Csv $hostInfo @('clock', 'w32time', '讀不到') }
} catch { ErrLog "取時區／時鐘失敗：$($_.Exception.Message)" }
$procNames = @{}
try { foreach ($p in @(Get-Process)) { $procNames[[int]$p.Id] = $p.ProcessName } } catch { }
foreach ($svc in $services) {
    $exe = Get-ExePath ([string]$svc.PathName)
    $ver = ''; try { if ($exe -and (Test-Path -LiteralPath $exe)) { $ver = (Get-Item -LiteralPath $exe).VersionInfo.ProductVersion } } catch { }
    Csv $hostInfo @('service', $svc.Name, "顯示名=$($svc.DisplayName)；狀態=$($svc.State)；啟動=$($svc.StartMode)；執行身分=$($svc.StartName)；版本=$ver；PID=$($svc.ProcessId)；$(Protect-Value ([string]$svc.PathName))")
}
$listenPorts = New-Object 'System.Collections.Generic.HashSet[int]'
try {
    $conns = @(Get-NetTCPConnection -State Listen -ErrorAction Stop)
    foreach ($c in $conns) {
        if (($ftpPids -contains [int]$c.OwningProcess) -or (@(20, 21, 22, 989, 990) -contains [int]$c.LocalPort)) {
            $pn = ''; if ($procNames.ContainsKey([int]$c.OwningProcess)) { $pn = $procNames[[int]$c.OwningProcess] }
            Csv $hostInfo @('listen', "pid $($c.OwningProcess) $pn", "$($c.LocalAddress):$($c.LocalPort)")
            [void]$listenPorts.Add([int]$c.LocalPort)
        }
    }
} catch {
    foreach ($ln in @(netstat -ano -p tcp | Select-String 'LISTENING')) {
        $p = ($ln.ToString().Trim() -split '\s+')
        if ($p.Count -ge 5) {
            $port = 0; [void][int]::TryParse(($p[1] -split ':')[-1], [ref]$port)
            if (($ftpPids -contains [int]$p[4]) -or (@(20, 21, 22, 989, 990) -contains $port)) { Csv $hostInfo @('listen', "pid $($p[4])", $p[1]); [void]$listenPorts.Add($port) }
        }
    }
}
foreach ($p in $cfgPorts) { Csv $hostInfo @('config_port', '', $p) }
foreach ($r in $cfgRanges) { Csv $hostInfo @('config_port_range', '', "$($r[0])-$($r[1])") }

# ---------- 8. 防火牆（跟 FTP 埠或程式有關的規則） ----------
Csv $fwCsv @('display_name', 'rule_id', 'enabled', 'direction', 'action', 'profile', 'protocol', 'local_port', 'remote_address', 'program', 'match')
try {
    $ports = New-Object 'System.Collections.Generic.HashSet[int]'
    foreach ($p in @(20, 21, 22, 989, 990)) { [void]$ports.Add($p) }
    foreach ($p in $listenPorts) { [void]$ports.Add($p) }
    foreach ($p in $cfgPorts) { [void]$ports.Add($p) }
    $pf = @{}; foreach ($x in @(Get-NetFirewallPortFilter -All -PolicyStore ActiveStore -ErrorAction Stop)) { $pf[$x.InstanceID] = $x }
    $af = @{}; foreach ($x in @(Get-NetFirewallApplicationFilter -All -PolicyStore ActiveStore -ErrorAction Stop)) { $af[$x.InstanceID] = $x }
    $adf = @{}; foreach ($x in @(Get-NetFirewallAddressFilter -All -PolicyStore ActiveStore -ErrorAction Stop)) { $adf[$x.InstanceID] = $x }
    $nfw = 0
    foreach ($rule in @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop)) {
        $id = $rule.InstanceID
        $lp = ''; $proto = ''; $prog = ''; $ra = ''
        if ($pf.ContainsKey($id)) { $lp = (@($pf[$id].LocalPort) -join ','); $proto = [string]$pf[$id].Protocol }
        if ($af.ContainsKey($id)) { $prog = [string]$af[$id].Program }
        if ($adf.ContainsKey($id)) { $ra = (@($adf[$id].RemoteAddress) -join ',') }
        $why = @()
        if ("$($rule.DisplayName) $prog" -match '(?i)ftp|serv-?u|filezilla|rhinosoft|sftp|ssh') { $why += 'name/program' }
        foreach ($e in $ftpExes) { if ($prog -and ([Environment]::ExpandEnvironmentVariables($prog) -ieq $e)) { $why += 'service exe' } }
        if ($lp -and (Test-PortSpec @($pf[$id].LocalPort) $ports $cfgRanges)) { $why += 'port' }
        $isFtpProg = $false; foreach ($e in $ftpExes) { if ($prog -and ([Environment]::ExpandEnvironmentVariables($prog) -ieq $e)) { $isFtpProg = $true } }
        if ($lp -eq 'Any' -and [string]$rule.Direction -eq 'Inbound' -and ($proto -match '^(TCP|Any)$') -and (-not $prog -or $prog -eq 'Any' -or $isFtpProg)) { $why += 'any-port' }
        if ($why.Count) { Csv $fwCsv @($rule.DisplayName, $id, $rule.Enabled, $rule.Direction, $rule.Action, $rule.Profile, $proto, $lp, $ra, $prog, ($why -join '+')); $nfw++ }
    }
    foreach ($pr in @(Get-NetFirewallProfile -PolicyStore ActiveStore -ErrorAction Stop)) { Csv $hostInfo @('firewall_profile', $pr.Name, "Enabled=$($pr.Enabled)；DefaultInbound=$($pr.DefaultInboundAction)") }
    Log "防火牆相關規則：$nfw 筆"
} catch { ErrLog "讀防火牆規則失敗：$($_.Exception.Message)" }

# ---------- 9. 帳號／目錄輸出 ----------
foreach ($gd in @($script:Dirs | Where-Object { $_.ownerKind -eq 'group' -and $_.raw })) {
    # 群組的掛載點展開到每個成員（權限來源＝群組），帳號變數代入成員名稱
    foreach ($a in @($script:Accounts | Where-Object { $_.kind -eq 'user' -and $_.product -eq $gd.product -and (@(([string]$_.groups) -split ';') -contains $gd.owner) })) {
        $rp = Resolve-NativePath $gd.raw $a.name $gd.domain
        if ($rp) { if (-not $gd.physical) { $gd.expanded = $true }; $script:Dirs.Add([pscustomobject]@{ product = $gd.product; config = $gd.config; domain = $gd.domain; ownerKind = 'user-via-group'; owner = $a.name; virtual = $gd.virtual
                    raw = $gd.raw; physical = $rp; perm = $gd.perm; isHome = $gd.isHome; method = "$($gd.method);via-group:$($gd.owner)" }) }
    }
}
$unresolved = @($script:Dirs | Where-Object { $_.raw -and -not $_.physical -and -not $_.expanded })
foreach ($u in $unresolved) { Log "目錄路徑無法展開：$($u.owner) $($u.raw)" }
$physDirs = @($script:Dirs | Where-Object { $_.physical } | ForEach-Object { $_.physical } | Sort-Object -Unique)
foreach ($a in $script:Accounts) { Csv $accCsv @($a.product, $a.config, $a.domain, $a.name, $a.kind, $a.enabled, $a.groups, $a.allow, $a.deny, $a.method) }
foreach ($d in $script:Dirs) { Csv $dirCsv @($d.product, $d.config, $d.domain, $d.ownerKind, $d.owner, $d.virtual, $d.raw, $d.physical, $d.perm, $d.isHome, $d.method) }
foreach ($u in $script:SuUsers) { Csv $suCsv @($u.domain, $u.name, $u.kind, $u.full, $u.home, $u.up, $u.down, $u.bup, $u.bdown, $u.since, $u.last, $u.lastOut, $u.cfg) }
# Serv-U 伺服器設定摘要（log 位置、LDAP 驗證；AD／LDAP 登入屬個人，不納入轉置，只記錄）
$suLdapText = ''
if ($script:SuMain.Count) {
    foreach ($suL in $script:SuLog) { Csv $hostInfo @('servu_log', $suL.Key, "LogFilePath=$($suL.LogFilePath)；LogToFile=$($suL.LogToFile)") }
    $ldOn = @($script:SuLdap | Where-Object { $tk = @(Get-KeyTokens $_.Key); (($tk -contains 'enable') -or ($tk -contains 'enabled') -or ($tk -contains 'use') -or ($tk -contains 'auth') -or ($tk -contains 'authentication')) -and $_.Value -match '^(?i)(0|1|true|false|yes|no)$' } | Select-Object -First 1)
    $ldSrv = @($script:SuLdap | Where-Object { $tk = @(Get-KeyTokens $_.Key); (($tk -contains 'server') -or ($tk -contains 'host') -or ($tk -contains 'address') -or ($tk -contains 'url') -or ($tk -contains 'uri')) -and $_.Value } | ForEach-Object { $_.Value } | Select-Object -Unique -First 5)
    $ldEn = $(if ($ldOn.Count) { "$($ldOn[0].Key)=$($ldOn[0].Value)" } elseif ($script:SuLdap.Count) { '有 LDAP 設定（啟用欄位待確認）' } else { '設定裡沒有 LDAP 欄位' })
    $suLdapText = "LDAP 驗證：$ldEn；伺服器：$(if ($ldSrv.Count) { $ldSrv -join ',' } else { '（無）' })（AD 登入屬個人，不納入轉置，只記錄）"
    Csv $hostInfo @('servu_ldap', 'enabled', $ldEn)
    Csv $hostInfo @('servu_ldap', 'server', ($ldSrv -join ','))
    foreach ($l in $script:SuLdap) { Csv $hostInfo @('servu_ldap_raw', $l.Path, $l.Value) }
    Log "Serv-U $suLdapText"
}
Log "帳號／群組 $($script:Accounts.Count) 筆，目錄對應 $($script:Dirs.Count) 筆，實體目錄 $($physDirs.Count) 個"

# ---------- 10. 排程（指到 FTP 程式或帳號目錄的） ----------
Csv $taskCsv @('task_path', 'task_name', 'state', 'run_as', 'logon_type', 'execute', 'arguments', 'working_dir', 'triggers', 'last_run', 'last_result', 'next_run', 'match')
try {
    $needles = @($physDirs + $roots | Where-Object { $_ } | Select-Object -First 300)
    $nt = 0
    foreach ($t in @(Get-ScheduledTask -ErrorAction Stop)) {
        $acts = @($t.Actions)
        $txt = (@($acts | ForEach-Object { "$(CimVal $_ 'Execute') $(CimVal $_ 'Arguments') $(CimVal $_ 'WorkingDirectory')" }) -join ' | ')
        $why = ''
        if ($txt -match '(?i)ftp|winscp|psftp|pscp|filezilla|serv-?u|rhinosoft') { $why = 'keyword' }
        else { foreach ($n in $needles) { if ($txt.IndexOf($n, [StringComparison]::OrdinalIgnoreCase) -ge 0) { $why = 'path'; break } } }
        if (-not $why) { continue }
        $ti = $null; try { $ti = Get-ScheduledTaskInfo -InputObject $t -ErrorAction Stop } catch { }
        $trig = (@($t.Triggers | Where-Object { $_ } | ForEach-Object { $_.CimClass.CimClassName -replace '^MSFT_Task', '' -replace 'Trigger$', '' }) -join ';')
        foreach ($a in $acts) {
            Csv $taskCsv @($t.TaskPath, $t.TaskName, $t.State, (CimVal $t.Principal 'UserId'), (CimVal $t.Principal 'LogonType'), (Protect-Value ([string](CimVal $a 'Execute'))),
                (Protect-Value ([string](CimVal $a 'Arguments'))), (CimVal $a 'WorkingDirectory'), $trig,
                $(if ($ti) { Ts $ti.LastRunTime } else { '' }), $(if ($ti) { $ti.LastTaskResult } else { '' }), $(if ($ti) { Ts $ti.NextRunTime } else { '' }), $why)
        }
        $nt++
    }
    Log "相關排程：$nt 個"
} catch { ErrLog "讀排程失敗：$($_.Exception.Message)" }

# ---------- 11. SMB 分享 ----------
Csv $shareCsv @('share', 'path', 'type', 'description', 'related_to_ftp_dir', 'share_access')
try {
    foreach ($sh in @(Get-CimInstance Win32_Share -ErrorAction Stop)) {
        $rel = ''
        if ($sh.Path -and [long]$sh.Type -eq 0) { foreach ($d in @($physDirs + $roots)) { if ($d -and ((Test-Inside $d $sh.Path) -or (Test-Inside $sh.Path $d))) { $rel = $d; break } } }
        $acc = ''
        if ($rel) { try { $acc = (@(Get-SmbShareAccess -Name $sh.Name -ErrorAction Stop | ForEach-Object { "$($_.AccountName):$($_.AccessControlType):$($_.AccessRight)" }) -join ';') } catch { $acc = '（讀不到）' } }
        Csv $shareCsv @($sh.Name, $sh.Path, $sh.Type, $sh.Description, $rel, $acc)
    }
} catch { ErrLog "讀 SMB 分享失敗：$($_.Exception.Message)" }

# ---------- 12. 憑證（只讀憑證，不碰私鑰；對應到引用它的設定） ----------
$certDone = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
function Write-CertRows([string]$source, [string]$file, [string]$refBy, [byte[]]$data, [string]$text) {
    $n = 0
    if ($text -and $text -match '-----BEGIN CERTIFICATE-----') {
        foreach ($m in [regex]::Matches($text, '-----BEGIN CERTIFICATE-----([A-Za-z0-9+/=\s]+)-----END CERTIFICATE-----')) {
            try {
                $cb = [Convert]::FromBase64String(($m.Groups[1].Value -replace '\s', ''))
                if ([Security.Cryptography.X509Certificates.X509Certificate2]::GetCertContentType($cb) -ne [Security.Cryptography.X509Certificates.X509ContentType]::Cert) { throw '不是單純憑證' }
                $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2(, $cb)
                Csv $certCsv @($source, $file, $refBy, $c.Subject, $c.Issuer, $c.NotBefore.ToString('yyyy/MM/dd'), $c.NotAfter.ToString('yyyy/MM/dd'), $c.Thumbprint, ''); $n++
            } catch { Csv $certCsv @($source, $file, $refBy, '', '', '', '', '', "解析失敗（$($_.Exception.GetType().Name)）") }
        }
    } elseif ($data) {
        try {
            if ([Security.Cryptography.X509Certificates.X509Certificate2]::GetCertContentType($data) -ne [Security.Cryptography.X509Certificates.X509ContentType]::Cert) { throw '不是單純憑證（可能含私鑰），不解析' }
            $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2(, $data); Csv $certCsv @($source, $file, $refBy, $c.Subject, $c.Issuer, $c.NotBefore.ToString('yyyy/MM/dd'), $c.NotAfter.ToString('yyyy/MM/dd'), $c.Thumbprint, 'DER'); $n++ } catch { }
    }
    if (-not $n) { Csv $certCsv @($source, $file, $refBy, '', '', '', '', '', '檔內沒有可讀的憑證') }
}
try {
    $allCertPaths = @(@($certFiles | ForEach-Object { ConvertFrom-LongPath $_.FullName }) + @($certRefs.Keys)) | Select-Object -Unique
    foreach ($cp in $allCertPaths) {
        if (-not $certDone.Add($cp)) { continue }
        $refBy = ''; if ($certRefs.ContainsKey($cp)) { $refBy = ($certRefs[$cp] -join ' ; ') }
        $ext = [IO.Path]::GetExtension($cp).ToLower()
        if ($ext -eq '.key') { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', '私鑰檔：不讀，只記位置'); continue }
        if ($ext -eq '.pfx' -or $ext -eq '.p12') { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', 'PFX 需密碼：不讀，只記位置'); continue }
        if (-not (Test-Path -LiteralPath $cp -PathType Leaf)) { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', '設定指定，但檔案不存在'); continue }
        try {
            $r = Read-AllShared $cp $MAX_CERT
            if ($null -eq $r[0]) { Csv $certCsv @('file', $cp, $refBy, '', '', '', '', '', $r[1]); continue }
            $txt = $null; if ([Array]::IndexOf([byte[]]$r[0], [byte]0) -lt 0) { $txt = [Text.Encoding]::ASCII.GetString([byte[]]$r[0]) }
            Write-CertRows 'file' $cp $refBy ([byte[]]$r[0]) $txt
        } catch { ErrLog "讀憑證失敗 $cp：$($_.Exception.Message)" }
    }
    foreach ($ic in $inlineCerts) { Write-CertRows 'inline' '' $ic.Ref $null $ic.Text }
} catch { ErrLog "憑證步驟失敗：$($_.Exception.Message)" }

# ---------- 13. 目錄摘要（不帶完整檔名）＋ NTFS ACL ----------
Csv $aclCsv @('path', 'owner', 'access_rules_protected', 'identity', 'rights', 'type', 'inherited', 'inheritance_flags', 'propagation_flags')
$gsw = [Diagnostics.Stopwatch]::StartNew()
$sumTrunc = 0; $sumMissing = 0; $sumErr = 0
foreach ($d in $physDirs) {
    if (Test-Inside $d $OutDir) { Log "目錄在存放目錄裡，不掃：$d"; continue }
    try {
        $scanAt = Get-Date
        $r = Get-DirSummary $d $cutoff $gsw
        $top = (@($r.patterns.GetEnumerator() | Sort-Object -Property @{ Expression = 'Value'; Descending = $true }, @{ Expression = 'Name'; Descending = $false } | Select-Object -First 10 | ForEach-Object { "$($_.Name)×$($_.Value)" }) -join ' | ')
        if ($r.other) { $top += " | (超過 $MAX_PATTERNS 種樣式，其餘 $($r.other) 個檔未分類)" }
        Csv $sumCsv @($d, $r.exists, $Days, $r.files, $r.bytes, $top, (Ts $r.newest), $r.old, $r.dirs, $r.seconds, $r.truncated, $r.errors, $r.links, (Ts $scanAt))
        foreach ($sk in @($r.subs.Keys | Sort-Object)) {
            $sb = $r.subs[$sk]
            $stop = (@($sb.patterns.GetEnumerator() | Sort-Object -Property @{ Expression = 'Value'; Descending = $true }, @{ Expression = 'Name'; Descending = $false } | Select-Object -First 5 | ForEach-Object { "$($_.Name)×$($_.Value)" }) -join ' | ')
            Csv $subCsv @($d, $sk, $Days, $sb.files, $sb.bytes, $stop, (Ts $sb.newest), $sb.old, $r.truncated)
        }
        if ($r.truncated) { $sumTrunc++ }
        if ($r.errors) { $sumErr++ }
        if ($r.exists -ne 'yes') { $sumMissing++; continue }
        $acl = Get-Acl -LiteralPath $d
        foreach ($rule in @($acl.Access)) {
            Csv $aclCsv @($d, $acl.Owner, $acl.AreAccessRulesProtected, $rule.IdentityReference, $rule.FileSystemRights, $rule.AccessControlType, $rule.IsInherited, $rule.InheritanceFlags, $rule.PropagationFlags)
        }
    } catch { ErrLog "目錄摘要／ACL 失敗 $d：$($_.Exception.Message)" }
}
Log "目錄摘要 $($physDirs.Count) 個（截斷 $sumTrunc、不存在 $sumMissing），花 $([int]$gsw.Elapsed.TotalSeconds) 秒"

# ---------- 14. 狀態判定 ----------
$reasons = New-Object System.Collections.Generic.List[string]
if ($aborted) { $status = 'FAIL'; $reasons.Add($endReason) }
elseif (-not $s.found -and $s.denied) { $status = 'FAIL'; $reasons.Add("$($s.denied) 個安裝目錄存取被拒") }
elseif (-not $s.found) { $status = 'FAIL'; $reasons.Add('找不到 Serv-U／FileZilla 目錄（裝在別處請用 -ExtraPaths）') }
elseif (-not $s.main) { $status = 'FAIL'; $reasons.Add('找到目錄但沒收到主設定檔（看 manifest）') }
else {
    $status = 'OK'
    if ($script:ErrCount) { $reasons.Add("錯誤 $script:ErrCount 筆（看 _error_log.txt）") }
    if ($s.skipped) { $reasons.Add("$($s.skipped) 個檔未收集（看 manifest）") }
    if ($logCap.sampled) { $reasons.Add("log 抽樣：超過讀取上限 $MaxLogGB GB，較舊 $($logCap.files) 個 log 未讀（只讀最新 $($logCap.keptFiles) 個）") }
    if ($s.copyErr) { $reasons.Add("$($s.copyErr) 個檔讀取／複製不完整") }
    if (-not $script:Accounts.Count) { $reasons.Add('沒解析出帳號') }
    if ($s.generic) { $reasons.Add("$($s.generic) 個設定檔用通用遮罩，需人工抽看") }
    if (-not $s.log) { $reasons.Add("近 $Days 天沒有 log（log 可能沒開或在別處）") }
    elseif (-not $latest) { $reasons.Add('log 裡讀不到日期') }
    elseif ([datetime]::ParseExact($latest, 'yyyy-MM-dd', $null) -lt $start.Date.AddDays(-2)) { $reasons.Add("最新 log 日期 $latest 早於 2 天前") }
    if ($parseIncomplete) { $reasons.Add("log 解析未完成：$parseIncomplete") }
    if ($s.truncated) { $reasons.Add("$($s.truncated) 個安裝／log 目錄走訪截斷") }
    if ($sumTrunc) { $reasons.Add("$sumTrunc 個目錄摘要截斷") }
    if ($sumErr) { $reasons.Add("$sumErr 個目錄有子目錄讀不到（權限）") }
    if ($sumMissing) { $reasons.Add("$sumMissing 個設定的目錄不存在（看 dir_summary）") }
    if ($unresolved.Count) { $reasons.Add("$($unresolved.Count) 個目錄路徑無法展開（看 dirs.csv）") }
    foreach ($suI in $script:SuIssues) { $reasons.Add($suI) }
    if ($reasons.Count) { $status = 'PARTIAL' }
}
$typeStr = (@($script:types | Select-Object -Unique) -join '+'); if (-not $typeStr) { $typeStr = 'auto' }
Csv $runCsv @('#', 'IP', 'Type', '狀態', '原因', '主設定檔', '設定檔', '已遮密碼檔', '通用遮罩檔', 'log 檔', 'log 起', 'log 訖', '有資料天數', '缺日數', '有傳輸紀錄', '帳號群組數', '實體目錄數', '未收集', 'MB', 'Note')
Csv $runCsv @(1, $ip, $typeStr, $status, ($reasons -join '；'), $s.main, $s.config, $s.masked, $s.generic, $s.log, $earliest, $latest, $covered, $missing.Count,
    $(if ($transfers) { 'yes' } else { 'no' }), $script:Accounts.Count, $physDirs.Count, $s.skipped, [Math]::Round($s.bytes / $CHUNK, 1), $hostName)
if ($suLdapText) { Add-OutText $info ("Serv-U $suLdapText`r`n") }
Add-OutText $info ("結束：$(Ts (Get-Date))（$endReason）`r`n狀態：$status`r`n原因：$($reasons -join '；')`r`n")

Log ''
Log "狀態：$status" $(if ($status -eq 'OK') { 'Green' } else { 'Yellow' })
if ($reasons.Count) { Log "原因：$($reasons -join '；')" 'Yellow' }
Log "主設定檔 $($s.main)、設定檔 $($s.config)（遮密碼 $($s.masked)、通用遮罩 $($s.generic)）、log $($s.log)、未收集 $($s.skipped)、共 $([Math]::Round($s.bytes / $CHUNK, 1)) MB"
Log "結果資料夾：$runDir"
Log "執行紀錄：$script:LogFile；錯誤紀錄：$script:ErrFile（錯誤 $script:ErrCount 筆）"
Log '請把整個 run_local_ 資料夾拷回集中的地方；第一次跑請打開一份設定檔確認密碼已遮。'
if ($status -eq 'OK') { exit 0 } elseif ($status -eq 'PARTIAL') { exit 1 } else { exit 2 }

# -*- coding: utf-8 -*-
"""驗收測試（FtpCollect v1.3.0 log 摘要 ↔ FtpReport v0.10.0）：
同一份收集結果，「逐行讀 log」（--parse-logs）與「讀主機算好的摘要」兩種方式產生的報表必須一模一樣
（SP／AP 兩個 xlsx 的每個工作表、每一格，以及 HTML 全文）。另外逐列核對摘要 = 報表解析器的事件彙總、解析統計相同，
引擎裡抄自報表的比對式跟 ftp_report.py 一字不差，引擎的 UTF-8 解碼跟 Python errors='replace' 一樣。

資料：make_fixture 的固定假資料＋亂數產生的 FileZilla（0.9／1.x 混合、跨檔連線、目錄不明的相對路徑、沒有回應的 log、
UTC Z、全形數字、無效 UTF-8、怪字元帳號／路徑、失敗傳輸、多行回應…）與 Serv-U（多 domain 同名帳號、AD 帳號、
家目錄外、路徑剛好等於家目錄…）假主機；再用真的 FtpCollect.ps1 收一台假 FileZilla 主機（走正式流程的第 14b 步）。
摘要由 test_summary_driver.ps1 從 FtpCollect.ps1 原文抽出正式程式來跑。全部是假資料（IP 用 192.0.2.x 等文件用網段）。

用法：python test_summary_equiv.py [--seeds N] [--no-collector] [--keep]
需要 Windows PowerShell 5.1（powershell.exe）。"""
import csv
import datetime as dt
import io
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ftp_report as R  # noqa: E402
import make_fixture as MF  # noqa: E402

COLLECTOR = os.path.normpath(os.path.join(HERE, '..', 'ftp_collect_ps', 'FtpCollect.ps1'))
DRIVER = os.path.join(HERE, 'test_summary_driver.ps1')
PS = ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File']
FAILS = []
BS = chr(92)


def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond:
        FAILS.append(msg)


def run_ps(args, timeout=1800, quiet=False):
    p = subprocess.run(PS + args, capture_output=True, timeout=timeout)
    out = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
    if p.returncode != 0 and not quiet:
        print(out)
    return out


def driver(root):
    out = run_ps([DRIVER, '-Collector', COLLECTOR, '-Root', root])
    return [l for l in out.splitlines() if l.startswith(('SUMMARY', 'SKIP'))], out


# ============================================================ 寫假收集結果（同 make_fixture.common 的格式）

def wbytes(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'wb') as f:
        f.write(data)


def enc(s):
    return s.encode('utf-8', 'surrogateescape')   # \udc80-\udcff → 無效位元組


def write_host(root, ip, host, typ, accounts, dirs, logs, eq, legacy=False, host_info_off='08:00:00'):
    """logs：[(來源路徑, mtime 字串, [分段位元組…], status)]"""
    rd = os.path.join(root, 'run_local_%s_%s_20261111_020000' % (ip, host))
    MF.w(os.path.join(rd, '_run.csv'), MF.csvtext(['#', 'IP', 'Type', '狀態', '原因', 'Note'], [['1', ip, typ, 'OK', '', host]]))
    MF.w(os.path.join(rd, '_run_info.txt'), 'SOC 通知單號：TEST\r\n開始：%s\r\n收集工具：FtpCollect.ps1 1.3.0 (test)\r\n' % MF.START)
    man = []
    for src, mtime, parts, status in logs:
        rel = os.path.join(ip, src[0], src[3:])
        rels = []
        for k, data in enumerate(parts):
            prel = rel if k == 0 else ('%s.part%d' % (rel, k + 1) if legacy else '%s.split%d' % (rel, k + 1))
            wbytes(os.path.join(rd, prel), data)
            rels.append(prel)
        n = sum(len(x) for x in parts)
        man.append(['log', status, src, str(n), mtime, rel if status != 'skipped' else '', str(n), '0' * 64, 'LOG-SLIM', ''] + ([] if legacy else ['|'.join(rels)]))
    random.shuffle(man)   # manifest 的列順序不等於讀取順序
    hdr = ['kind', 'status', 'source_path', 'size', 'mtime', 'out_path', 'out_bytes', 'sha256', 'format', 'note'] + ([] if legacy else ['out_parts'])
    hd = os.path.join(rd, ip)
    MF.w(os.path.join(hd, 'manifest.csv'), MF.csvtext(hdr, man))
    MF.w(os.path.join(hd, 'accounts.csv'), MF.csvtext(['product', 'config_file', 'domain', 'name', 'kind', 'enabled', 'groups', 'allowed_ips', 'denied_ips', 'parse_method'], accounts))
    MF.w(os.path.join(hd, 'dirs.csv'), MF.csvtext(['product', 'config_file', 'domain', 'owner_kind', 'owner', 'virtual_path', 'physical_path_raw', 'physical_path', 'perm_raw', 'is_home', 'parse_method'], dirs))
    MF.w(os.path.join(hd, 'dir_summary.csv'), MF.csvtext(['physical_path', 'exists', 'window_days', 'files_in_window', 'bytes_in_window', 'top_patterns_in_window', 'newest_mtime_overall', 'files_older_than_window', 'dir_count', 'scan_seconds', 'truncated', 'enum_errors', 'links_skipped', 'scan_time'], []))
    MF.w(os.path.join(hd, 'evidence_quality.csv'), MF.csvtext(['key', 'value'], [[k, v] for k, v in eq.items()]))
    MF.w(os.path.join(hd, 'host_info.csv'), MF.csvtext(['item', 'name', 'value'], [['timezone', 'current_utc_offset', host_info_off]]))
    return rd


def split_files(rnd, lines, base_dir, ext='.log', legacy=False):
    """把整條時間軸的行切成多個來源檔（連線跨檔）、有的再切分段；mtime 照時間（偶爾同 mtime，靠來源路徑排）。"""
    nfile = rnd.randint(2, 6)
    cuts = sorted(rnd.sample(range(1, max(2, len(lines))), min(nfile - 1, max(1, len(lines) - 1))))
    chunks, prev = [], 0
    for c in cuts + [len(lines)]:
        chunks.append(lines[prev:c])
        prev = c
    out = []
    names = ['fzs-%c.log' % chr(ord('z') - i) for i in range(len(chunks))]   # 檔名順序跟時間相反
    for i, ch in enumerate(chunks):
        data = b''.join(ch)
        if i == 0 and rnd.random() < 0.5:
            data = b'\xef\xbb\xbf' + data   # 開頭有 BOM
        if data.endswith(b'\n') and rnd.random() < 0.3:
            data = data.rstrip(b'\r\n')   # 最後一行沒換行
        nparts = 1 if (legacy and i % 2) else rnd.choice([1, 1, 2, 3])
        if nparts > 1 and len(ch) > nparts:
            ls = data.split(b'\n')
            ks = sorted(rnd.sample(range(1, len(ls)), nparts - 1))
            parts, p0 = [], 0
            for k in ks + [len(ls)]:
                parts.append(b'\n'.join(ls[p0:k]) + (b'\n' if k < len(ls) else b''))
                p0 = k
        else:
            parts = [data]
        mt = '2026/11/%02d %02d:00:00' % (1 + i, 3) if not (i == 2) else '2026/11/02 03:00:00'
        out.append((base_dir + names[i] if i != 2 else base_dir + 'zz-same-mtime' + ext, mt, parts, 'collected'))
    out.append((base_dir + 'old-skipped.log', '2026/10/01 00:00:00', [b''], 'skipped'))
    return out


# ============================================================ FileZilla 亂數 log

FZ_USERS = ['u1', 'u2', 'U1', 'dup', 'svc user', 'ユーザ', 'pct%x', 'q"t', 'grp_only', 'ghost', 'anonymous']
FZ_IPS = ['192.0.2.1', '192.0.2.2', '192.0.2.3', '198.51.100.7', '203.0.113.9', '2001:db8::5']
SEGS = ['in', 'out', 'a b', 'ü', '%25', '..', '.', 'sub', 'share', 'deep/er', 'f.csv', 'x\udc81y', '中文', '', 'ｆｕｌｌ']


def rpath(rnd, absolute=None):
    segs = [rnd.choice(SEGS) for _ in range(rnd.randint(0, 4))] + ['file%d.csv' % rnd.randint(1, 30)]
    p = '/'.join(segs)
    if absolute is None:
        absolute = rnd.random() < 0.5
    if absolute:
        p = '/' + p
    r = rnd.random()
    if r < 0.08:
        p = '"%s"' % p
    elif r < 0.12:
        p = p + '/'
    elif r < 0.15:
        p = '//' + p
    return p


def rdir(rnd):
    r = rnd.random()
    if r < 0.15:
        return '..'
    if r < 0.2:
        return ''
    if r < 0.25:
        return '/'
    segs = [rnd.choice(['in', 'out', 'share', 'sub', '中文', 'a b', '.', '..']) for _ in range(rnd.randint(1, 3))]
    return ('/' if rnd.random() < 0.5 else '') + '/'.join(segs)


def fz_session(rnd, user):
    """一個連線的 (指令, [回應…]) 序列"""
    steps = []
    if rnd.random() < 0.85:   # 有登入（否則：log 從連線中途開始，目錄不明）
        pw = rnd.choice(['230 Logged on', '230 Login successful.', '530 Login or password incorrect!', None, '331 again'])
        steps.append(('USER ' + user, ['331 Password required for ' + user]))
        steps.append((rnd.choice(['PASS ****', 'pass ****', 'Paß ****']), [pw] if pw else []))
        if pw and pw.startswith('530') and rnd.random() < 0.5:
            steps.append((None, ['421 Login incorrect.']))
    for _ in range(rnd.randint(0, 25)):
        r = rnd.random()
        if r < 0.15:
            steps.append((rnd.choice(['CWD', 'XCWD', 'cwd']) + ' ' + rdir(rnd), [rnd.choice(['250 CWD successful', '250 ok', '550 not found', '２５０ ok' if FW_OK[0] else '250 x'])]))
        elif r < 0.2:
            steps.append((rnd.choice(['CDUP', 'XCUP']), [rnd.choice(['200 CDUP successful', '250 ok', '550 no'])]))
        elif r < 0.45:
            v = rnd.choice(['STOR', 'STOR', 'RETR', 'RETR', 'APPE', 'STOU', 'stor', 'ſtor', 'Retr', 'ﬆor'])
            fin = rnd.choice([['150 Opening', '226 Transfer OK'], ['150 Opening', '226 Successfully transferred'], ['550 Permission denied'],
                              ['150 Opening', '451 aborted'], ['150 Opening'], [], ['226 ok']])
            steps.append((v + ' ' + rpath(rnd), fin))
        elif r < 0.55:
            v = rnd.choice(['DELE', 'MKD', 'XMKD', 'RMD', 'XRMD'])
            steps.append((v + ' ' + rpath(rnd), [rnd.choice(['250 deleted', '257 "x" created', '550 denied'])]))
        elif r < 0.6:
            steps.append(('RNFR ' + rpath(rnd), ['350 ready']))
            steps.append(('RNTO ' + rpath(rnd), [rnd.choice(['250 renamed', '553 no'])]))
        elif r < 0.72:
            v = rnd.choice(['LIST', 'LIST -al', 'NLST -a', 'MLSD', 'LIST -l -a'])
            arg = rnd.choice(['', ' ' + rdir(rnd), ' -R ' + rdir(rnd)])
            steps.append((v + arg, rnd.choice([['150 About to send', '226 Operation successful'], ['550 no'], ['150 x']])))
        elif r < 0.85:
            steps.append((rnd.choice(['TYPE I', 'PASV', 'NOOP', 'PWD', 'SIZE x', 'MDTM y', 'OPTS UTF8 ON', 'STOR\u3000x']),
                          [rnd.choice(['200 Type set to I', '227 Entering Passive Mode', '257 "/" is current', '213 100'])]))
        elif r < 0.9:
            steps.append(('FEAT', ['211-Features:', ' MDTM', '211 End']))
        elif r < 0.95:
            steps.append((None, [rnd.choice(['226 stray', '150 stray', 'Login failed for x', '500 Syntax error'])]))
        else:
            steps.append(('USER ' + rnd.choice(FZ_USERS), ['331 Password required']))
            steps.append(('PASS ****', [rnd.choice(['230 Logged on', '530 Login incorrect'])]))
    return steps


FW_OK = [True]   # 真的跑 FtpCollect 時關掉：v1.2.x 的 slim 引擎遇到全形數字的回應碼／日期會丟例外（既有行為，見測試說明）


def digits_fw(s):
    if not FW_OK[0]:
        return s
    return ''.join(chr(ord(c) - 0x30 + 0xFF10) if c.isdigit() else c for c in s)


def fz_ts(rnd, t, fmt, z):
    """一行的時間字串（偶爾故意不合法：秒 60、2 月 30、全形數字）"""
    r = rnd.random()
    if fmt == 'fz1':
        s = t.strftime('%Y-%m-%dT%H:%M:%S') + ('.%03d' % rnd.randint(0, 999) if rnd.random() < 0.8 else '')
        if r < 0.01:
            s = s[:17] + '60' + s[19:]
        elif r < 0.015:
            s = '2026-02-30' + s[10:]
        elif r < 0.02:
            s = digits_fw(s)
        elif r < 0.05:
            s = s.replace('T', ' ')
        return s + ('Z' if z else '')
    # fz09
    style = rnd.choice(['24', '24', 'ap1', 'ampm', 'ampm_en'])
    d = '%d/%d/%d' % (t.year, t.month, t.day)
    if rnd.random() < 0.3:
        d = t.strftime('%Y/%m/%d')
    if style == '24':
        tm = '%d:%02d:%02d' % (t.hour, t.minute, t.second)
        s = '%s %s' % (d, tm)
    else:
        h12 = t.hour % 12 or 12
        ap = ('下午' if t.hour >= 12 else '上午') if style != 'ampm_en' else ('PM' if t.hour >= 12 else 'AM')
        tm = '%02d:%02d:%02d' % (h12, t.minute, t.second)
        s = ('%s %s %s' % (d, ap, tm)) if style == 'ap1' else ('%s %s %s' % (d, tm, ap))
    if r < 0.01:
        s = s.replace(':%02d' % t.second, ':60', 1) if t.second != 0 else s
    elif r < 0.015:
        s = digits_fw(s)
    return s


def fz_line(rnd, fmt, z, t, sid, ip, buser, is_cmd, msg):
    ts = fz_ts(rnd, t, fmt, z)
    if fmt == 'fz1':
        if rnd.random() < 0.1:
            d, msg2 = ('!!' if is_cmd else '=='), ('Command: ' if is_cmd else 'Response: ') + msg
        else:
            d, msg2 = ('>>' if is_cmd else '<<'), msg
        br = 'FTP Session %d %s%s' % (sid, ip, (' ' + buser) if buser else '')
        if rnd.random() < 0.02:
            br = 'Admin %d %s' % (sid, ip)   # 不是 Session：RX_BRACKET 不符
        line = '%s %s [%s] %s' % (ts, d, br, msg2)
    else:
        u = buser if buser else rnd.choice(['(not logged in)', '(NOT LOGGED IN)', 'not logged in'])
        sep = '' if rnd.random() < 0.5 else ' '
        line = '(%06d)%s%s - %s (%s)> %s' % (sid, sep, ts, u, ip, msg)
    eol = '\r\n' if rnd.random() < 0.7 else '\n'
    return enc(line + eol)


def fz_log(rnd, start, nsess, fmt_mix, z_mode, no_resp=False, busy=False):
    """回傳依時間排序的行（bytes）"""
    events = []   # (time, seq, bytes)
    seq = 0
    for k in range(nsess):
        sid = rnd.randint(1, nsess // 2 + 2)   # 連線編號會重用（不同 IP）
        ip = rnd.choice(FZ_IPS)
        user = rnd.choice(FZ_USERS[:6] if busy else FZ_USERS)
        fmt = rnd.choice(fmt_mix)
        z = z_mode if z_mode is not None else rnd.random() < 0.5
        t = start - dt.timedelta(days=rnd.uniform(-0.3, 100 if not busy else 30), seconds=rnd.randint(0, 3600))
        cur = ''   # 括號裡的帳號
        for cmd, resps in fz_session(rnd, user):
            t += dt.timedelta(seconds=rnd.randint(0, 40))
            if cmd is not None:
                events.append((t, seq, fz_line(rnd, fmt, z, t, sid, ip, cur, True, cmd))); seq += 1
                if cmd.upper().startswith('PASS') and resps and resps[0] and resps[0].startswith('230'):
                    cur = user
            if no_resp:
                continue
            for rs in resps:
                t += dt.timedelta(seconds=rnd.randint(0, 3))
                events.append((t, seq, fz_line(rnd, fmt, z, t, sid, ip, cur, False, rs))); seq += 1
        if rnd.random() < 0.05:
            events.append((t, seq, enc('garbage line \udcff without format\n'))); seq += 1
    events.sort(key=lambda x: (x[0], x[1]))
    return [b for _, _, b in events]


def fz_host(rnd, root, n, nsess=300, fmt_mix=('fz1', 'fz09'), z_mode=None, no_resp=False, legacy=False, busy=False, offset='08:00:00'):
    ip, host = '192.0.2.%d' % (100 + n), 'FZFUZZ%d' % n
    cfg = 'C:\\ProgramData\\filezilla-server\\users.xml'
    acc = [['FileZilla', cfg, '', u, 'user', 'true', '', '', '', 'fz1-xml'] for u in ['u1', 'u2', 'dup', 'svc user', 'ユーザ', 'pct%x', 'grp_only']]
    acc += [['FileZilla', cfg, 'D2', 'dup', 'user', 'true', '', '', '', 'fz1-xml'], ['FileZilla', cfg, '', 'grp1', 'group', '', '', '', '', 'fz1-xml']]
    perm = 'access=1;recursive=2;flags=0'
    dirs = []
    for u in ['u1', 'u2', 'svc user', 'ユーザ', 'pct%x']:
        dirs.append(['FileZilla', cfg, '', 'user', u, '/', 'D:\\FTP\\' + u, 'D:\\FTP\\' + u, perm, 'yes', 'fz1-xml'])
    dirs.append(['FileZilla', cfg, '', 'user', 'u2', '/in', 'D:\\FTP\\u2in', 'D:\\FTP\\u2in', perm, '', 'fz1-xml'])
    dirs.append(['FileZilla', cfg, '', 'user', 'u1', '/中文', 'D:\\FTP\\zh', 'D:\\FTP\\zh', perm, '', 'fz1-xml'])
    for u in ['u1', 'grp_only']:
        dirs.append(['FileZilla', cfg, '', 'user-via-group', u, '/share', 'D:\\FTP\\share', 'D:\\FTP\\share', perm, '', 'fz1-xml;via-group:grp1'])
    dirs.append(['FileZilla', cfg, '', 'user', 'dup', '/', 'D:\\FTP\\dup', 'D:\\FTP\\dup', perm, 'yes', 'fz1-xml'])
    start = dt.datetime.strptime(MF.START, '%Y/%m/%d %H:%M:%S')
    lines = fz_log(rnd, start, nsess, fmt_mix, z_mode, no_resp=no_resp, busy=busy)
    logs = split_files(rnd, lines, 'C:\\Program Files\\FileZilla Server\\Logs\\', legacy=legacy)
    eq = MF.eqd(30, '2026-10-11', '2026-11-10')
    if offset is None:
        del eq['host_utc_offset_now']
    else:
        eq['host_utc_offset_now'] = offset
    return write_host(root, ip, host, 'FileZilla', acc, dirs, logs, eq, legacy=legacy, host_info_off=rnd.choice(['08:00:00', '-05:30:00', 'bad']))


# ============================================================ Serv-U 亂數 log

SU_HOMES = OrderedDict([(('DOM', 'su_a'), 'D:\\SU\\su_a'), (('DOM', 'su_b'), 'D:\\SU\\su_b'), (('DOM', 'dup'), 'D:\\SU\\dup'), (('DOM2', 'dup'), 'D:\\SU2\\dup'),
                        (('DOM', 'tail'), 'D:\\SU\\data'), (('DOM', 'İx'), 'D:\\SU\\İx\\'), (('DOM2', 'nest'), 'D:\\SU\\su_a\\nest')])
SU_USERS = ['su_a', 'SU_A', 'su_b', 'dup', 'tail', 'İx', 'nest', 'ad.sched', 'ad.casual', 'ad.x', '']
MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']


def su_path(rnd):
    r = rnd.random()
    homes = list(SU_HOMES.values())
    h = rnd.choice(homes).rstrip('\\')
    if r < 0.05:
        return h   # 剛好等於家目錄
    if r < 0.1:
        return 'D:\\SU\\su_a\\DATA'   # 檔名＝另一個家目錄的最後一段（data）
    if r < 0.15:
        return 'E:\\other\\x%d.csv' % rnd.randint(1, 5)
    if r < 0.2:
        return h.replace('\\', '/') + '/in/f%d.csv' % rnd.randint(1, 9)
    if r < 0.25:
        return h.upper() + '\\in\\f.csv\\'
    if r < 0.28:
        return h + '\\\\double\\f.csv'
    sub = rnd.choice(['in', 'out', 'in\\deep', '中文', 'a b', 'x\udc80'])
    return '%s\\%s\\f%d.csv' % (h, sub, rnd.randint(1, 40))


def su_line(rnd, t, sid, msg):
    mon = MON3[t.month - 1]
    r = rnd.random()
    if r < 0.03:
        mon = mon.upper()
    elif r < 0.04:
        mon = 'Xyz'
    d = '%02d' % t.day if rnd.random() < 0.7 else '%d' % t.day
    tm = '%02d:%02d:%02d' % (t.hour, t.minute, t.second)
    if rnd.random() < 0.01:
        tm = tm[:6] + '60'
    s = '[%02d] %s %s%s%02d %s - (%06d) %s' % (rnd.choice([1, 2, 3, 5, 11]), t.strftime('%a'), d, mon, t.year % 100, tm, sid, msg)
    if rnd.random() < 0.01:
        s = digits_fw(s)
    if rnd.random() < 0.01:
        s = '\ufeff' + s
    return enc(s + ('\r\n' if rnd.random() < 0.7 else '\n'))


def su_log(rnd, start, nsess):
    ev = []
    seq = 0
    for k in range(nsess):
        sid = rnd.randint(1, nsess // 2 + 2)
        ip = rnd.choice(['192.0.2.50', '192.0.2.51', '192.0.2.60', '198.51.100.9', '2001:db8::7'])
        user = rnd.choice(SU_USERS)
        t = start - dt.timedelta(days=rnd.uniform(-0.3, 100), seconds=rnd.randint(0, 3600))
        if user == 'ad.sched':   # 疑似排程：每天同一小時
            t = (start - dt.timedelta(days=rnd.randint(1, 20))).replace(hour=3, minute=rnd.randint(0, 50))
        msgs = []
        if rnd.random() < 0.85:
            port = rnd.choice(['21', '22', '990', '989', '2121', None])
            msgs.append('已連接到 %s (本地位址 192.0.2.1%s)' % (ip, ('，埠 %s' % port) if port else ''))
        if rnd.random() < 0.6:
            msgs.append(rnd.choice(['IP-名稱： %s.example.test (%s)' % (rnd.choice(['APPSRV01', 'W12-345', 'BATCH02']), ip), 'IP-名稱: H%d (%s )' % (k % 3, ip)]))
        if user and rnd.random() < 0.9:
            msgs.append('使用者 "%s" 已登入' % user)
        for _ in range(rnd.randint(0, 12)):
            r = rnd.random()
            p = su_path(rnd)
            if r < 0.3:
                msgs.append('已成功收到檔案 "%s" (100.00 KB/秒 - 1,024 位元組)' % p)
            elif r < 0.5:
                msgs.append(rnd.choice(['已成功發送檔 "%s" (1 KB/秒)', '已成功發送檔案 "%s"']) % p)
            elif r < 0.6:
                msgs.append('接收檔案 "%s" 時發生錯誤，中斷作業' % p)
            elif r < 0.65:
                msgs.append('發送檔案 "%s" 時發生錯誤' % p)
            elif r < 0.75:
                msgs.append(rnd.choice(['檔已移除："%s"', '檔已移除 "%s"']) % p)
            elif r < 0.82:
                msgs.append('目錄已創建："%s"' % p.rsplit('\\', 1)[0])
            elif r < 0.86:
                msgs.append('使用者 "%s" 已登出' % user)
            elif r < 0.9:
                msgs.append('使用者 "%s" 已登入' % rnd.choice(SU_USERS))
            else:
                msgs.append(rnd.choice(['某個其他訊息', '  已成功收到檔案 "%s"  ' % p, '已成功收到檔案 %s' % p]))
        if rnd.random() < 0.7:
            msgs.append(rnd.choice(['連線期間已關閉', '連線期間空閒逾時']))
        for m in msgs:
            t += dt.timedelta(seconds=rnd.randint(0, 30))
            ev.append((t, seq, su_line(rnd, t, sid, m))); seq += 1
    ev.sort(key=lambda x: (x[0], x[1]))
    return [b for _, _, b in ev]


def su_host(rnd, root, n, nsess=300):
    ip, host = '192.0.2.%d' % (150 + n), 'SUFUZZ%d' % n
    ucfg = 'C:\\ProgramData\\RhinoSoft\\Serv-U\\Users\\%s\\%s.Archive'
    acc, dirs = [], []
    for (dom, name), home in SU_HOMES.items():
        acc.append(['ServU', ucfg % (dom, name), dom, name, 'user', '', '', '', '', 'servu-archive'])
        dirs.append(['ServU', ucfg % (dom, name), dom, 'user', name, '/', home, home, '', 'yes', 'servu-archive'])
        dirs.append(['ServU', ucfg % (dom, name), dom, 'user', name, '', home, home, 'access=7967', '', 'servu-archive'])
    start = dt.datetime.strptime(MF.START, '%Y/%m/%d %H:%M:%S')
    lines = su_log(rnd, start, nsess)
    logs = split_files(rnd, lines, 'D:\\FTP\\LOG\\', ext='.txt')
    return write_host(root, ip, host, 'ServU', acc, dirs, logs, MF.eqd(92, '2026-08-11', '2026-11-10'))


# ============================================================ 比對

def proj(s):
    return ''.join(c for c in s.lower() if ord(c) < 128)


def oracle(h):
    """報表解析器的事件，照摘要的規則（同一小時同欄位一列、檔案操作只留上一層目錄）在 Python 這邊彙總"""
    if h['is_servu']:
        gen, st = R.parse_servu_logs(h)
        events = list(gen)
    else:
        events, st = R.parse_logs(h)
    tails = set()
    for d in h['dirs']:
        x = (d.get('physical_path') or '').rstrip(BS)
        tails.add(proj(x.rsplit(BS, 1)[-1]))
    agg = OrderedDict()
    for e in events:
        if h['is_servu']:
            p = e['phys']
            if '*' not in tails and p and e['verb'] in R.FILE_OPS and BS in p and proj(p.rsplit(BS, 1)[1]) not in tails:
                p = p.rsplit(BS, 1)[0] + BS + '*'
            proto = e['proto']
        else:
            p = e['vpath']
            if p is not None and p != '/' and e['verb'] in R.FILE_OPS:
                par = R.vparent(p)
                p = ('' if par == '/' else par) + '/*'
            proto = None
        k = (e['kind'], e['verb'], e['user'], e['ip'], p, proto, e['ts'].replace(minute=0, second=0))
        a = agg.get(k)
        if a is None:
            agg[k] = [1, e['ts'], e['ts']]
        else:
            a[0] += 1
            a[1] = min(a[1], e['ts'])
            a[2] = max(a[2], e['ts'])
    rows = [(v[0], v[1], v[2]) + k[:6] for k, v in agg.items()]
    return rows, st


def summary_rows(events, servu):
    return [(e['n'], e['ts'], e['ts_last'], e['kind'], e['verb'], e['user'], e['ip'], e['phys'] if servu else e['vpath'], e['proto'] if servu else None)
            for e in events]


def norm_st(st):
    return {k: (dict(v) if k in ('formats', 'ip_names') else v) for k, v in st.items()}


def check_events(root, label):
    nh = 0
    for rd in R.find_runs(root):
        h = R.load_host(rd)
        if not (h['is_fz'] or h['is_servu']):
            continue
        sm = R.load_summary(h)
        if sm is None:
            check(False, '%s %s：沒有摘要' % (label, h['run_name']))
            continue
        ev, st, issues = sm
        check(not issues, '%s %s：摘要核對資訊與報表一致 %s' % (label, h['hostname'], issues or ''))
        orows, ost = oracle(h)
        srows = summary_rows(ev, h['is_servu'])
        same = orows == srows
        if not same:
            for i, (a, b) in enumerate(zip(orows, srows)):
                if a != b:
                    print('    第 %d 列不同：\n      報表 %r\n      摘要 %r' % (i, a, b))
                    break
            print('    列數 報表 %d／摘要 %d' % (len(orows), len(srows)))
        check(same, '%s %s：摘要 %d 列（事件 %d）＝報表解析器的彙總' % (label, h['hostname'], len(srows), sum(r[0] for r in srows)))
        ns, no = norm_st(st), norm_st(ost)
        check(ns == no, '%s %s：解析統計相同（行 %d、符合 %d、回應 %d、指令 %d、Z %d、事件 %d、沒回應=%s）' % (
            label, h['hostname'], no.get('lines', 0), no.get('matched', 0), no.get('responses', 0), no.get('commands', 0), no.get('z', 0), no.get('events', 0), no.get('no_responses')))
        if ns != no:
            print('    摘要', ns, '\n    報表', no)
        nh += 1
    return nh


def report_files(out_parent):
    d = [x for x in os.listdir(out_parent) if x.startswith('盤點報表_')]
    assert len(d) == 1, d
    ts = d[0][len('盤點報表_'):]
    base = os.path.join(out_parent, d[0])
    res = {}
    for f in sorted(os.listdir(base)):
        p = os.path.join(base, f)
        key = f.replace(ts, 'TS')
        if f.endswith('.xlsx'):
            with zipfile.ZipFile(p) as z:
                for n in sorted(z.namelist()):
                    res[key + '!' + n] = z.read(n).replace(ts.encode(), b'TS')
        else:
            with open(p, 'rb') as fh:
                res[key] = fh.read().replace(ts.encode(), b'TS')
    return res


def run_report(root, out, extra):
    os.makedirs(out)
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        rc = R.main([root, '--out', out] + extra)
    finally:
        sys.stdout = old
    return rc, buf.getvalue()


def check_report(root, label):
    rc1, log1 = run_report(root, os.path.join(root, '_out_logs'), ['--parse-logs'])
    rc2, log2 = run_report(root, os.path.join(root, '_out_summary'), [])
    a, b = report_files(os.path.join(root, '_out_logs')), report_files(os.path.join(root, '_out_summary'))
    nsum = log2.count('（log 摘要）')
    check(rc1 == 0 and rc2 == 0, '%s：報表兩種方式都跑完' % label)
    check(nsum > 0 and '（log 摘要）' not in log1, '%s：預設用摘要（%d 台），--parse-logs 時讀 log' % (label, nsum))
    diff = [k for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)]
    for k in diff[:5]:
        print('    不同：%s' % k)
    nsheet = len([k for k in a if '/worksheets/sheet' in k])
    rows = sum(x.count(b'<row ') for k, x in a.items() if '/worksheets/sheet' in k)
    check(not diff, '%s：讀 log 與讀摘要的報表完全相同（%d 個檔內容、%d 個工作表、%d 列、HTML 全文）' % (label, len(a), nsheet, rows))


# ============================================================ 摘要壞掉／對不上、上限（v1.3.1／v0.10.1）

def eval_host(rd, force=False):
    """跟 ftp_report.main 一樣取事件、算列；回傳 (h, 來源, 每列重點)"""
    h = R.load_host(rd)
    old = sys.stdout
    sys.stdout = io.StringIO()
    try:
        ev, st, src = R.host_events(h, force)
        h['st'] = st
        try:
            rows = R.build_rows(h, ev, st)
        except Exception as e:
            R.mark_incomplete(h, 'log 解析失敗：%s' % e)
            rows = R.build_rows(h, [], st)
    finally:
        sys.stdout = old
    return h, src, [(r['A4 舊帳號'], r['A5 虛擬路徑'], r['B7 上傳'], r['B7 下載'], r['B7 其他操作'], r['B5 登入成功'], r['C1 觀察結果']) for r in rows]


def rewrite(path, fn):
    with open(path, 'rb') as f:
        b = f.read()
    with open(path, 'wb') as f:
        f.write(fn(b))


def drop_last_row(b):
    ls = b.split(b'\r\n')
    return b'\r\n'.join(ls[:-2] + [b''])   # 最後一列整列不見（在列邊界截斷）


def bad_number(b):
    ls = b.split(b'\r\n')
    ls[1] = b'"x"' + ls[1][ls[1].index(b','):]
    return b'\r\n'.join(ls)


def robustness(base, fx):
    src_rd = [d for d in R.find_runs(fx) if '_FZHOSTA_' in d][0]
    _, _, want = eval_host(src_rd, force=True)
    check(any(r[2] for r in want) and any(r[6] == '期間內未觀察到活動' for r in want), '基準（讀 log）：有上傳、也有期間內未觀察到活動的列')
    rel_agg, rel_man = os.path.join('192.0.2.10', R.SUMMARY_AGG), os.path.join('192.0.2.10', 'manifest.csv')
    rel_sta = os.path.join('192.0.2.10', R.SUMMARY_STATS)

    def no_summary_empty_manifest(rd):
        os.remove(os.path.join(rd, rel_agg))
        os.remove(os.path.join(rd, rel_sta))
        rewrite(os.path.join(rd, rel_man), lambda b: b.split(b'\r\n')[0] + b'\r\n')
        rewrite(os.path.join(rd, '192.0.2.10', 'evidence_quality.csv'), lambda b: b + b'"log_files_collected","2"\r\n')
    cases = [
        ('完好、log 副本不在（只靠摘要）', None, True, 'same-summary'),
        ('彙總表少最後一列、log 在', lambda rd: rewrite(os.path.join(rd, rel_agg), drop_last_row), False, 'same-log'),
        ('彙總表少最後一列、log 不在', lambda rd: rewrite(os.path.join(rd, rel_agg), drop_last_row), True, 'incomplete'),
        ('彙總表數字壞掉、log 在', lambda rd: rewrite(os.path.join(rd, rel_agg), bad_number), False, 'same-log'),
        ('彙總表數字壞掉、log 不在', lambda rd: rewrite(os.path.join(rd, rel_agg), bad_number), True, 'incomplete'),
        ('彙總表缺欄位、log 在', lambda rd: rewrite(os.path.join(rd, rel_agg), lambda b: b.replace(b'"proto"', b'"protox"', 1)), False, 'same-log'),
        ('統計檔被刪、log 不在（當作沒有摘要→讀 log 失敗）', lambda rd: os.remove(os.path.join(rd, '192.0.2.10', R.SUMMARY_STATS)), True, 'incomplete'),
        ('manifest 只剩標題列（摘要完好、log 在）', lambda rd: rewrite(os.path.join(rd, rel_man), lambda b: b.split(b'\r\n')[0] + b'\r\n'), False, 'incomplete'),
        ('統計檔沒有 agg_sha256（v1.3.0 格式）、log 不在', lambda rd: rewrite(os.path.join(rd, rel_sta), lambda b: b'\r\n'.join(l for l in b.split(b'\r\n') if b'agg_sha256' not in l)), True, 'same-summary'),
        ('manifest 只剩標題列、--parse-logs', lambda rd: rewrite(os.path.join(rd, rel_man), lambda b: b.split(b'\r\n')[0] + b'\r\n'), False, 'incomplete', True),
        ('沒有摘要、manifest 只剩標題列、收集紀錄說有收 2 個 log', no_summary_empty_manifest, False, 'incomplete'),
    ]
    for i, case in enumerate(cases):
        name, mut, drop, expect = case[:4]
        force = len(case) > 4 and case[4]
        rd = os.path.join(base, 'robust%d' % i, os.path.basename(src_rd))
        shutil.copytree(src_rd, rd)
        if drop:
            h0 = R.load_host(rd)
            for _, ps_ in R.iter_log_files(h0):
                for pth in ps_:
                    os.remove(pth)
        if mut:
            mut(rd)
        h, src, got = eval_host(rd, force)
        c1 = [r[6] for r in got]
        if expect == 'same-summary':
            check(src == 'summary' and got == want and not h.get('log_incomplete'), '%s：用摘要，結果與讀 log 相同' % name)
        elif expect == 'same-log':
            check(src == 'log' and got == want and not h.get('log_incomplete'), '%s：改讀 log，結果與讀 log 相同（上傳 %d）' % (name, sum(r[2] for r in got)))
        else:
            ok = bool(h.get('log_incomplete')) and '期間內未觀察到活動' not in c1 and '證據不足' in c1 and h['status'] == 'PARTIAL' and any('不完整' in n or '失敗' in n for n in h['notes'])
            check(ok, '%s：標 log 證據不完整（PARTIAL＋備註），沒看到活動的列＝證據不足、不會是「期間內未觀察到活動」' % name)
            if not ok:
                print('    ', h.get('log_incomplete'), h['status'], h['notes'], c1)


def no_log_host(fx):
    """真的沒有 log 的主機（固定假資料 SUHOST：manifest 沒有 log、收集紀錄也沒說有）：照舊，不標不完整"""
    rd = [d for d in R.find_runs(fx) if '_SUHOST_' in d][0]
    for force in (False, True):
        h, src, got = eval_host(rd, force)
        check(not h.get('log_incomplete') and h['status'] == 'PARTIAL' and not any('不完整' in n for n in h['notes']),
              '真的沒有 log 的主機%s：不標 log 證據不完整（結果照舊：%s）' % ('（--parse-logs）' if force else '', '、'.join(sorted(set(r[6] for r in got)))))


def limits(base, fx):
    """摘要上限：超過就不寫摘要（正式流程改成照舊上傳 log）"""
    for i, (args, word) in enumerate([(['-MaxRows', '5'], '超過 5 列'), (['-MaxStrings', '3'], '超過 3 個不重複字串'),
                                       (['-MaxSessions', '2'], '超過 2 個連線'), (['-LimitSec', '0'], '超過 0 秒'),
                                       (['-MaxLine', '50'], '超過 50 位元組的單行')]):
        root = os.path.join(base, 'limit%d' % i)
        for tag in ('_FZHOSTA_', '_SUHOST2_'):
            src_rd = [d for d in R.find_runs(fx) if tag in d][0]
            shutil.copytree(src_rd, os.path.join(root, os.path.basename(src_rd)))
            hd = [x for x in os.listdir(os.path.join(root, os.path.basename(src_rd))) if x.startswith('192.')][0]
            for f in (R.SUMMARY_AGG, R.SUMMARY_STATS):
                os.remove(os.path.join(root, os.path.basename(src_rd), hd, f))
        out = run_ps([DRIVER, '-Collector', COLLECTOR, '-Root', root] + args)
        sk = [l for l in out.splitlines() if l.startswith('SKIP')]
        left = [f for dp, dn, fn in os.walk(root) for f in fn if f in (R.SUMMARY_AGG, R.SUMMARY_STATS)]
        check(len(sk) == 2 and all(('摘要中止：' + word) in l for l in sk) and not left, '上限 %s：兩台都放棄摘要（%s）、沒留下摘要檔' % (' '.join(args), word))
        if len(sk) != 2:
            print(out[-1500:])


WATCH_PS = r"""param($stop, $out, $ready)
$w = New-Object IO.FileSystemWatcher $env:TEMP
$w.IncludeSubdirectories = $false; $w.EnableRaisingEvents = $true
$global:names = New-Object System.Collections.ArrayList
$null = Register-ObjectEvent $w Created -Action { [void]$global:names.Add($Event.SourceEventArgs.Name) }
[IO.File]::WriteAllText($ready, 'x')
while (-not (Test-Path -LiteralPath $stop)) { Start-Sleep -Milliseconds 100 }
Start-Sleep -Milliseconds 800
[IO.File]::WriteAllLines($out, [string[]]@($global:names))
"""
CODEDOM = re.compile(r'^[a-z0-9]{8}\.(0\.cs|cmdline)$')


def watch_temp(base, tag, action):
    """執行 action 期間，系統 TEMP 新建了哪些 CodeDom 編譯暫存檔（xxxxxxxx.0.cs／.cmdline）"""
    import time
    ps1 = os.path.join(base, 'watch_temp.ps1')
    with open(ps1, 'w', encoding='utf-8-sig') as f:
        f.write(WATCH_PS)
    stop, out, ready = (os.path.join(base, 'watch_%s.%s' % (tag, x)) for x in ('stop', 'out', 'ready'))
    p = subprocess.Popen(PS + [ps1, stop, out, ready], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(300):
        if os.path.exists(ready):
            break
        time.sleep(0.1)
    try:
        action()
    finally:
        open(stop, 'w').close()
        p.wait(timeout=60)
    names = open(out, encoding='utf-8-sig').read().split() if os.path.exists(out) else None
    return None if names is None else [n for n in names if CODEDOM.match(n)]


# ============================================================ 真的跑 FtpCollect.ps1（假 FileZilla 主機）

def collector_run(base, rnd):
    tree = os.path.join(base, 'tree')
    fz = os.path.join(tree, 'FileZilla Server')
    users = ''.join('<User Name="%s"><Option Name="Pass">FAKEHASH0123456789</Option><Option Name="Enabled">1</Option><IpFilter><Disallowed/><Allowed/></IpFilter>'
                    '<Permissions><Permission Dir="%s"><Option Name="FileRead">1</Option><Option Name="FileWrite">1</Option><Option Name="IsHome">1</Option></Permission></Permissions></User>'
                    % (u, os.path.join(tree, 'FTP', u)) for u in ['u1', 'u2', 'dup', 'grp_only'])
    MF.w(os.path.join(fz, 'FileZilla Server.xml'), '<?xml version="1.0" encoding="UTF-8"?><FileZillaServer><Settings><Item name="Admin port" type="numeric">14147</Item></Settings><Users>%s</Users></FileZillaServer>' % users, bom=False)
    for u in ['u1', 'u2']:
        MF.w(os.path.join(tree, 'FTP', u, 'in', 'keep.txt'), 'x', bom=False)
    now = dt.datetime.now().replace(microsecond=0)
    FW_OK[0] = False
    try:
        lines = fz_log(rnd, now, 400, ('fz1', 'fz09'), None)
    finally:
        FW_OK[0] = True
    nf = 4
    k = len(lines) // nf
    for i in range(nf):
        p = os.path.join(fz, 'Logs', 'fzs-%d.log' % i)
        wbytes(p, b''.join(lines[i * k:(i + 1) * k if i < nf - 1 else len(lines)]))
        tm = (now - dt.timedelta(hours=10 * (nf - i))).timestamp()
        os.utime(p, (tm, tm))
    out = os.path.join(base, 'out')
    os.makedirs(out)
    # 對照組：測試用驅動程式用一般 Add-Type（會寫系統 TEMP）→ 監看要抓得到，才證明監看有效
    ctl = watch_temp(base, 'ctl', lambda: run_ps([DRIVER, '-Collector', COLLECTOR, '-Patterns', os.path.join(base, 'p.json')]))
    check(bool(ctl), '對照組：監看系統 TEMP 抓得到一般 Add-Type 的編譯暫存檔（%s）' % (', '.join(ctl[:3]) if ctl else '沒抓到'))
    res = {}
    seen = watch_temp(base, 'col', lambda: res.setdefault('log', run_ps([COLLECTOR, '-SocTicket', 'TEST-SUMMARY', '-OutDir', out, '-Days', '90', '-ExtraPaths', tree, '-MaxMB', '10'], timeout=3600, quiet=True)))
    log = res.get('log', '')
    check(seen == [], 'FtpCollect 編譯快速模式引擎時，系統 TEMP 沒有新的編譯暫存檔（%s）' % (seen if seen else '0 個'))
    runs = [os.path.join(out, x) for x in os.listdir(out) if x.startswith('run_local_')]
    check(len(runs) == 1, 'FtpCollect.ps1 跑完、產生 1 個結果資料夾')
    if len(runs) != 1:
        print(log[-3000:])
        return None
    rl = open(os.path.join(runs[0], '_run_log.txt'), encoding='utf-8-sig').read()
    m = re.search(r'log 摘要：[^\r\n]*列[^\r\n]*', rl)
    check(bool(m), 'FtpCollect 執行紀錄有 log 摘要那一行：%s' % (m.group(0) if m else rl[-500:]))
    check(not os.path.exists(os.path.join(runs[0], '_compile')) or not os.listdir(os.path.join(runs[0], '_compile')), '結果資料夾裡沒有留下編譯暫存檔（_compile）')
    check('快速模式（C#' in rl, 'FtpCollect 仍是快速模式（在結果資料夾裡編譯成功）')
    info = open(os.path.join(runs[0], '_run_info.txt'), encoding='utf-8-sig').read()
    check('log 摘要：有' in info, '_run_info.txt 記錄有 log 摘要')
    return out


# ============================================================ main

def sizes(root):
    """(log 副本位元組, 摘要位元組) 最大的一台"""
    best = None
    for rd in R.find_runs(root):
        h = R.load_host(rd)
        if not h['hdir'] or not os.path.exists(os.path.join(h['hdir'], R.SUMMARY_AGG)):
            continue
        lb = sum(os.path.getsize(p) for _, ps_ in R.iter_log_files(h) for p in ps_)
        sb = os.path.getsize(os.path.join(h['hdir'], R.SUMMARY_AGG)) + os.path.getsize(os.path.join(h['hdir'], R.SUMMARY_STATS))
        if best is None or lb > best[1]:
            best = (h['hostname'], lb, sb)
    return best


def main(argv):
    seeds = 3
    if '--seeds' in argv:
        seeds = int(argv[argv.index('--seeds') + 1])
    base = tempfile.mkdtemp(prefix='sumeq_')
    print('暫存：%s' % base)
    try:
        print('== 1. 引擎的比對式＝ftp_report.py 原文')
        pj = os.path.join(base, 'patterns.json')
        run_ps([DRIVER, '-Collector', COLLECTOR, '-Patterns', pj])
        pat = json.load(open(pj, encoding='utf-8-sig'))
        une = lambda s: re.sub(BS * 2 + r'u([0-9A-F]{4})', lambda m: chr(int(m.group(1), 16)), s)
        for k in ['RX_FZ1', 'RX_BRACKET', 'RX_FZ09', 'RX_CODE', 'LOGIN_FAIL_TEXT', 'RX_SU', 'SU_CONN', 'SU_LOGIN', 'SU_LOGOUT', 'SU_CLOSE', 'SU_HOST']:
            check(une(pat[k]) == getattr(R, k).pattern, '%s 一字不差' % k)
        check([une(x) for x in pat['SU_MSGS']] == [rx.pattern for rx, _, _ in R.SU_MSGS], 'SU_MSGS 一字不差（%d 個）' % len(R.SU_MSGS))

        print('== 2. UTF-8 解碼（errors=replace）與 Python 相同')
        rnd = random.Random(7)
        cases = [b'', b'abc', b'\xe0\x80\x80a', b'\xf0\x90\x80', b'\xed\xa0\x80', b'\xc3', b'\xf4\x90\x80\x80', b'\xc0\xaf', b'\xef\xbb\xbfx\r\n', b'\xf0\x9f\x98\x80z']
        for _ in range(4000):
            n = rnd.randint(0, 12)
            cases.append(bytes(rnd.choice([rnd.randint(0, 255), rnd.choice([0x80, 0xbf, 0xc2, 0xe0, 0xed, 0xef, 0xf0, 0xf4, 0xf5, 0x41, 0x0d])]) for _ in range(n)))
        di, do = os.path.join(base, 'dec_in.txt'), os.path.join(base, 'dec_out.txt')
        with open(di, 'w', encoding='ascii', newline='\n') as f:
            f.write(''.join(c.hex() + '\n' for c in cases))
        run_ps([DRIVER, '-Collector', COLLECTOR, '-DecodeIn', di, '-DecodeOut', do])
        got = open(do, encoding='utf-8-sig').read().split('\n')[:len(cases)]
        bad = [c for c, g in zip(cases, got) if c.decode('utf-8', 'replace').encode('utf-16-le').hex().upper() != g]
        check(len(got) == len(cases) and not bad, '%d 組位元組解碼結果相同%s' % (len(cases), (' 例外 %r' % bad[:3]) if bad else ''))

        print('== 3. 固定假資料（make_fixture）')
        fx = os.path.join(base, 'fixture')
        MF.make(fx)
        MF.make_parts(fx)
        MF.make_acct_lookup(fx)
        MF.make_host_sys(fx)
        lines, out = driver(fx)
        for l in lines:
            print('    ' + l)
        check_events(fx, 'fixture')
        check_report(fx, 'fixture')

        print('== 3b. 摘要壞掉／對不上：改讀 log，或標 log 證據不完整（不會判成沒在用）')
        robustness(base, fx)
        no_log_host(fx)
        print('== 3c. 摘要上限（列數、字串、連線、時間）：超過就不寫摘要')
        limits(base, fx)

        for seed in range(1, seeds + 1):
            print('== 4.%d 亂數假主機（seed %d）' % (seed, seed))
            rnd = random.Random(seed)
            root = os.path.join(base, 'fuzz%d' % seed)
            fz_host(rnd, root, 1, nsess=400)
            fz_host(rnd, root, 2, nsess=300, fmt_mix=('fz1',), z_mode=True, offset='-05:30:00')
            fz_host(rnd, root, 3, nsess=300, fmt_mix=('fz09',), offset=None)
            fz_host(rnd, root, 4, nsess=150, no_resp=True)
            fz_host(rnd, root, 5, nsess=200, legacy=True)
            su_host(rnd, root, 1, nsess=400)
            su_host(rnd, root, 2, nsess=200)
            if seed == 1:
                fz_host(rnd, root, 9, nsess=6000, fmt_mix=('fz1',), z_mode=True, busy=True)
            lines, out = driver(root)
            for l in lines:
                print('    ' + l)
            check(sum(1 for l in lines if l.startswith('SUMMARY')) == (8 if seed == 1 else 7), '每台都有產生摘要')
            check_events(root, 'seed%d' % seed)
            check_report(root, 'seed%d' % seed)
            if seed == 1:
                hn, lb, sb = sizes(root)
                print('    大小：最大的一台 %s：log 副本 %d 位元組 → 摘要 %d 位元組（%.1f%%）' % (hn, lb, sb, 100.0 * sb / lb))

        if '--no-collector' not in argv:
            print('== 5. 真的跑 FtpCollect.ps1（假 FileZilla 主機，正式流程第 14b 步產生摘要）')
            out = collector_run(os.path.join(base, 'collector'), random.Random(99))
            if out:
                check_events(out, 'collector')
                check_report(out, 'collector')
    finally:
        if '--keep' not in argv:
            shutil.rmtree(base, ignore_errors=True)
    print('結果：%s（%d 項失敗）' % ('FAIL' if FAILS else 'PASS', len(FAILS)))
    return 1 if FAILS else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
